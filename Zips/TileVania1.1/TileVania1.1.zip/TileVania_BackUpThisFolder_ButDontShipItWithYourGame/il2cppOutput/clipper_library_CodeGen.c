﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void ClipperLib.DoublePoint::.ctor(System.Double,System.Double)
extern void DoublePoint__ctor_m482D3610D420BFF5DF1EDDFF3C319B5C6DCAC859 (void);
// 0x00000002 System.Void ClipperLib.DoublePoint::.ctor(ClipperLib.DoublePoint)
extern void DoublePoint__ctor_m4DA444C77667ADC06334633460B05370B9CA56F8 (void);
// 0x00000003 System.Int32 ClipperLib.PolyNode::get_ChildCount()
extern void PolyNode_get_ChildCount_mC2378D10B6B9D8CC805F4A123A9A5D69096806D1 (void);
// 0x00000004 System.Void ClipperLib.PolyNode::AddChild(ClipperLib.PolyNode)
extern void PolyNode_AddChild_m7DB863FAF3A3B77198AAAF508856DE1F696A1582 (void);
// 0x00000005 System.Collections.Generic.List`1<ClipperLib.PolyNode> ClipperLib.PolyNode::get_Childs()
extern void PolyNode_get_Childs_m6323F4C10D5D9CD18B4D5A5629E8A9568A9A73B2 (void);
// 0x00000006 System.Void ClipperLib.PolyNode::.ctor()
extern void PolyNode__ctor_m2C22F4592F3CD2C12553108F9D9E88DA916DEED6 (void);
// 0x00000007 System.Void ClipperLib.Int128::.ctor(System.Int64,System.UInt64)
extern void Int128__ctor_mBD38F0ABE017AD0F5D66EBD836D159C574B6022A (void);
// 0x00000008 System.Boolean ClipperLib.Int128::op_Equality(ClipperLib.Int128,ClipperLib.Int128)
extern void Int128_op_Equality_m52655612FA9E991C51354AB62B31D3D04225871A (void);
// 0x00000009 System.Boolean ClipperLib.Int128::Equals(System.Object)
extern void Int128_Equals_m0A40B15C0D2A14127DD34F898693C436CE774707 (void);
// 0x0000000A System.Int32 ClipperLib.Int128::GetHashCode()
extern void Int128_GetHashCode_mCDE2E0DF254213BFC67F8F62111371F3ED9C51D5 (void);
// 0x0000000B ClipperLib.Int128 ClipperLib.Int128::op_UnaryNegation(ClipperLib.Int128)
extern void Int128_op_UnaryNegation_m9C1172745BB39CE6143AF4367360CC554BDEABDE (void);
// 0x0000000C ClipperLib.Int128 ClipperLib.Int128::Int128Mul(System.Int64,System.Int64)
extern void Int128_Int128Mul_mB2BC203BD87908553B71AF17B183A5E53780DCC7 (void);
// 0x0000000D System.Void ClipperLib.IntPoint::.ctor(System.Int64,System.Int64)
extern void IntPoint__ctor_m43FA6E2F1EA903A84E87C40570C002A50492EFE5 (void);
// 0x0000000E System.Void ClipperLib.IntPoint::.ctor(System.Double,System.Double)
extern void IntPoint__ctor_mE5B43837884272FB8DD8256B001F6287A2E6BB63 (void);
// 0x0000000F System.Void ClipperLib.IntPoint::.ctor(ClipperLib.IntPoint)
extern void IntPoint__ctor_mD769F4D36E8F16A4ADF2D231FB6C0752D5120BC5 (void);
// 0x00000010 System.Boolean ClipperLib.IntPoint::op_Equality(ClipperLib.IntPoint,ClipperLib.IntPoint)
extern void IntPoint_op_Equality_mD84506C88E1012BF31DEED68FF333EC538D7C1A9 (void);
// 0x00000011 System.Boolean ClipperLib.IntPoint::op_Inequality(ClipperLib.IntPoint,ClipperLib.IntPoint)
extern void IntPoint_op_Inequality_m1B138D93FF1636CB7CB1DCAA62B8DFDEADDEA2B7 (void);
// 0x00000012 System.Boolean ClipperLib.IntPoint::Equals(System.Object)
extern void IntPoint_Equals_m5E53D2A6836041B94FB0D049B1D33671D9EE4556 (void);
// 0x00000013 System.Int32 ClipperLib.IntPoint::GetHashCode()
extern void IntPoint_GetHashCode_m9322836AAE0BA19EE99F299DF98AA6A3B9126EBE (void);
// 0x00000014 System.Void ClipperLib.IntRect::.ctor(System.Int64,System.Int64,System.Int64,System.Int64)
extern void IntRect__ctor_m93AB3555BB9C12827745826CA4D60984F7752D52 (void);
// 0x00000015 System.Void ClipperLib.TEdge::.ctor()
extern void TEdge__ctor_mA1EB24F2FBD4D8C11F907EF1E6BC03CA7BF4C93E (void);
// 0x00000016 System.Void ClipperLib.IntersectNode::.ctor()
extern void IntersectNode__ctor_m4B2C47C8A8F3F85DF24BACD1E9CD037481557C78 (void);
// 0x00000017 System.Int32 ClipperLib.MyIntersectNodeSort::Compare(ClipperLib.IntersectNode,ClipperLib.IntersectNode)
extern void MyIntersectNodeSort_Compare_m2F66B35EC741C1801BFA4A9EAB4853943A5CF861 (void);
// 0x00000018 System.Void ClipperLib.MyIntersectNodeSort::.ctor()
extern void MyIntersectNodeSort__ctor_m053DA624977E961C096A62DF04074039471A02F7 (void);
// 0x00000019 System.Void ClipperLib.LocalMinima::.ctor()
extern void LocalMinima__ctor_m549BC1F11D26DC5CF0DBC7DF430FCC5DE90D01C2 (void);
// 0x0000001A System.Void ClipperLib.Scanbeam::.ctor()
extern void Scanbeam__ctor_m633912064C71027DBF8ED66D368DE9C6F5935221 (void);
// 0x0000001B System.Void ClipperLib.Maxima::.ctor()
extern void Maxima__ctor_mC4904A4872B389B80D21193C1A820886A8297CF3 (void);
// 0x0000001C System.Void ClipperLib.OutRec::.ctor()
extern void OutRec__ctor_m4D0CE6C9A2F5377A22EFD6997297A39789DC66FF (void);
// 0x0000001D System.Void ClipperLib.OutPt::.ctor()
extern void OutPt__ctor_m0536125B7761CCBDB06B5B61E1656587ADAA1AAC (void);
// 0x0000001E System.Void ClipperLib.Join::.ctor()
extern void Join__ctor_mD170CA55E901088B64A774497379680EC36E6138 (void);
// 0x0000001F System.Boolean ClipperLib.ClipperBase::near_zero(System.Double)
extern void ClipperBase_near_zero_m73B042480AEB4531BDA936D2B266A61B1F4E1A76 (void);
// 0x00000020 System.Boolean ClipperLib.ClipperBase::get_PreserveCollinear()
extern void ClipperBase_get_PreserveCollinear_mF815A8E8F42740154020BC6AE8F940770CCABD8F (void);
// 0x00000021 System.Void ClipperLib.ClipperBase::set_PreserveCollinear(System.Boolean)
extern void ClipperBase_set_PreserveCollinear_m1D8A039E2B937CA6034C17A8A446DA0373C4865F (void);
// 0x00000022 System.Void ClipperLib.ClipperBase::Swap(System.Int64&,System.Int64&)
extern void ClipperBase_Swap_m372564516C68B173A4A143F9F783B7310BF92C34 (void);
// 0x00000023 System.Boolean ClipperLib.ClipperBase::IsHorizontal(ClipperLib.TEdge)
extern void ClipperBase_IsHorizontal_m2C7E9BB42FA46CBB04B6A20CE382BFF35ADCC9C6 (void);
// 0x00000024 System.Boolean ClipperLib.ClipperBase::SlopesEqual(ClipperLib.TEdge,ClipperLib.TEdge,System.Boolean)
extern void ClipperBase_SlopesEqual_m0376A25654525DB9216E30A8C848B2E2CABF16AF (void);
// 0x00000025 System.Boolean ClipperLib.ClipperBase::SlopesEqual(ClipperLib.IntPoint,ClipperLib.IntPoint,ClipperLib.IntPoint,System.Boolean)
extern void ClipperBase_SlopesEqual_mE66FE6BF09981C0D25F7228760E541E5AC7C0E57 (void);
// 0x00000026 System.Boolean ClipperLib.ClipperBase::SlopesEqual(ClipperLib.IntPoint,ClipperLib.IntPoint,ClipperLib.IntPoint,ClipperLib.IntPoint,System.Boolean)
extern void ClipperBase_SlopesEqual_m726344D5585B2A64A96838562BD796D02740320E (void);
// 0x00000027 System.Void ClipperLib.ClipperBase::.ctor()
extern void ClipperBase__ctor_mB35BE76A3465FC86B93D19E4BA047E95BFB65CAF (void);
// 0x00000028 System.Void ClipperLib.ClipperBase::Clear()
extern void ClipperBase_Clear_m2552093878FC5D5F8B4F96A6DE53D7007E77A6A8 (void);
// 0x00000029 System.Void ClipperLib.ClipperBase::DisposeLocalMinimaList()
extern void ClipperBase_DisposeLocalMinimaList_mE8D1728F624E3CBE8A2519DE28D31BEB7AFBD223 (void);
// 0x0000002A System.Void ClipperLib.ClipperBase::RangeTest(ClipperLib.IntPoint,System.Boolean&)
extern void ClipperBase_RangeTest_mA3F47013E6E18BC2E86C630FB2B03C0B3B9981E5 (void);
// 0x0000002B System.Void ClipperLib.ClipperBase::InitEdge(ClipperLib.TEdge,ClipperLib.TEdge,ClipperLib.TEdge,ClipperLib.IntPoint)
extern void ClipperBase_InitEdge_m19B0803C590838C597D2F1418782FD81083848A0 (void);
// 0x0000002C System.Void ClipperLib.ClipperBase::InitEdge2(ClipperLib.TEdge,ClipperLib.PolyType)
extern void ClipperBase_InitEdge2_mCF0AB43E07F594F86F7F30F26F74D13770510A0C (void);
// 0x0000002D ClipperLib.TEdge ClipperLib.ClipperBase::FindNextLocMin(ClipperLib.TEdge)
extern void ClipperBase_FindNextLocMin_mA24AD75724BD42CFFBFD753725729DC72750B247 (void);
// 0x0000002E ClipperLib.TEdge ClipperLib.ClipperBase::ProcessBound(ClipperLib.TEdge,System.Boolean)
extern void ClipperBase_ProcessBound_m1156BC1E43204F034D2407CDD1E162045170D048 (void);
// 0x0000002F System.Boolean ClipperLib.ClipperBase::AddPath(System.Collections.Generic.List`1<ClipperLib.IntPoint>,ClipperLib.PolyType,System.Boolean)
extern void ClipperBase_AddPath_mC9457F91B4A3E5E720AB74406F77607026435C14 (void);
// 0x00000030 System.Boolean ClipperLib.ClipperBase::AddPaths(System.Collections.Generic.List`1<System.Collections.Generic.List`1<ClipperLib.IntPoint>>,ClipperLib.PolyType,System.Boolean)
extern void ClipperBase_AddPaths_mEC27DFC58A9FCBD73E1E9C5DF70CC51298ED4202 (void);
// 0x00000031 System.Boolean ClipperLib.ClipperBase::Pt2IsBetweenPt1AndPt3(ClipperLib.IntPoint,ClipperLib.IntPoint,ClipperLib.IntPoint)
extern void ClipperBase_Pt2IsBetweenPt1AndPt3_m0232ED88825FC7DE0F25980E674ED399EC1D5FCC (void);
// 0x00000032 ClipperLib.TEdge ClipperLib.ClipperBase::RemoveEdge(ClipperLib.TEdge)
extern void ClipperBase_RemoveEdge_m67F38E8D2BAA3DC6E1691B6763218808417AF2BF (void);
// 0x00000033 System.Void ClipperLib.ClipperBase::SetDx(ClipperLib.TEdge)
extern void ClipperBase_SetDx_mACC7E781D83D845A2383EFC9ABD1B012102CA298 (void);
// 0x00000034 System.Void ClipperLib.ClipperBase::InsertLocalMinima(ClipperLib.LocalMinima)
extern void ClipperBase_InsertLocalMinima_mC825C5610F785BB337459AD17856B606CF644764 (void);
// 0x00000035 System.Boolean ClipperLib.ClipperBase::PopLocalMinima(System.Int64,ClipperLib.LocalMinima&)
extern void ClipperBase_PopLocalMinima_mA77DDADD9877C26C9E5915000A4DF0268C869738 (void);
// 0x00000036 System.Void ClipperLib.ClipperBase::ReverseHorizontal(ClipperLib.TEdge)
extern void ClipperBase_ReverseHorizontal_m1EFD3278FD6915456179BD5C2F37FE0D9036BE56 (void);
// 0x00000037 System.Void ClipperLib.ClipperBase::Reset()
extern void ClipperBase_Reset_mC2AB4DE731202A5C3B67E13722C56540BDC489F9 (void);
// 0x00000038 ClipperLib.IntRect ClipperLib.ClipperBase::GetBounds(System.Collections.Generic.List`1<System.Collections.Generic.List`1<ClipperLib.IntPoint>>)
extern void ClipperBase_GetBounds_m7929C7A36D7C108A87538D74E440C8A517741FDE (void);
// 0x00000039 System.Void ClipperLib.ClipperBase::InsertScanbeam(System.Int64)
extern void ClipperBase_InsertScanbeam_m0B684DA2EE3192058D886050D5ECB121FA086059 (void);
// 0x0000003A System.Boolean ClipperLib.ClipperBase::PopScanbeam(System.Int64&)
extern void ClipperBase_PopScanbeam_m7ECA90915F946D7583FED94FB8BC4EC35D408B4C (void);
// 0x0000003B System.Boolean ClipperLib.ClipperBase::LocalMinimaPending()
extern void ClipperBase_LocalMinimaPending_mD819FB3E17C9BE88E0816878266B39FD9A108F17 (void);
// 0x0000003C ClipperLib.OutRec ClipperLib.ClipperBase::CreateOutRec()
extern void ClipperBase_CreateOutRec_m173DBFA1510A4DF9FAFA6EC45D7A2F62C7CB568C (void);
// 0x0000003D System.Void ClipperLib.ClipperBase::DisposeOutRec(System.Int32)
extern void ClipperBase_DisposeOutRec_mA63315ED842B582EDAF61B2F1643E6B500236C86 (void);
// 0x0000003E System.Void ClipperLib.ClipperBase::UpdateEdgeIntoAEL(ClipperLib.TEdge&)
extern void ClipperBase_UpdateEdgeIntoAEL_mBFFEFA68B03191BD3325AD23120BBB15FB6243BF (void);
// 0x0000003F System.Void ClipperLib.ClipperBase::SwapPositionsInAEL(ClipperLib.TEdge,ClipperLib.TEdge)
extern void ClipperBase_SwapPositionsInAEL_m5E8583BFDD7E6153161FC599BF93BA2A16951C9D (void);
// 0x00000040 System.Void ClipperLib.ClipperBase::DeleteFromAEL(ClipperLib.TEdge)
extern void ClipperBase_DeleteFromAEL_m6E7C7F18920490A0CC194E32BA00D6FEF1175DDB (void);
// 0x00000041 System.Void ClipperLib.Clipper::.ctor(System.Int32)
extern void Clipper__ctor_m7CE711A86E713B0AC68C632E6C5EC766E85353DD (void);
// 0x00000042 System.Void ClipperLib.Clipper::InsertMaxima(System.Int64)
extern void Clipper_InsertMaxima_mB6640EC0501821A439002DE10EFA34A06C41F3A2 (void);
// 0x00000043 System.Boolean ClipperLib.Clipper::get_ReverseSolution()
extern void Clipper_get_ReverseSolution_m16CB9BE38C4204F91892877D45A3574AFC94E71A (void);
// 0x00000044 System.Void ClipperLib.Clipper::set_ReverseSolution(System.Boolean)
extern void Clipper_set_ReverseSolution_m841D018306A112D204E00FB2026F09F325C12DAA (void);
// 0x00000045 System.Boolean ClipperLib.Clipper::get_StrictlySimple()
extern void Clipper_get_StrictlySimple_m01C2EFE9DEE3C256C263075A5377D07C2A191695 (void);
// 0x00000046 System.Void ClipperLib.Clipper::set_StrictlySimple(System.Boolean)
extern void Clipper_set_StrictlySimple_mF4815B6637F58516E0A22BC049172F89CBA712E2 (void);
// 0x00000047 System.Boolean ClipperLib.Clipper::Execute(ClipperLib.ClipType,System.Collections.Generic.List`1<System.Collections.Generic.List`1<ClipperLib.IntPoint>>,ClipperLib.PolyFillType,ClipperLib.PolyFillType)
extern void Clipper_Execute_mB4264F9470A5C69626A07F0875AEB40FEAFB81B2 (void);
// 0x00000048 System.Boolean ClipperLib.Clipper::ExecuteInternal()
extern void Clipper_ExecuteInternal_m9ADE942CB713B99830DF07BCCE24E38BE19CA132 (void);
// 0x00000049 System.Void ClipperLib.Clipper::DisposeAllPolyPts()
extern void Clipper_DisposeAllPolyPts_mF05175DA812BD9D8C9D32D60601225B0FCD6BDAB (void);
// 0x0000004A System.Void ClipperLib.Clipper::AddJoin(ClipperLib.OutPt,ClipperLib.OutPt,ClipperLib.IntPoint)
extern void Clipper_AddJoin_m15A0AB0CCFDC67D36EAEBB26E973FCA8D49A9D66 (void);
// 0x0000004B System.Void ClipperLib.Clipper::AddGhostJoin(ClipperLib.OutPt,ClipperLib.IntPoint)
extern void Clipper_AddGhostJoin_mAE51CD773B174F590377CFFE53FA1FCB2E4290B9 (void);
// 0x0000004C System.Void ClipperLib.Clipper::InsertLocalMinimaIntoAEL(System.Int64)
extern void Clipper_InsertLocalMinimaIntoAEL_m5A797CFBDB56BE0CFF30B9797ACFBC73C68923D4 (void);
// 0x0000004D System.Void ClipperLib.Clipper::InsertEdgeIntoAEL(ClipperLib.TEdge,ClipperLib.TEdge)
extern void Clipper_InsertEdgeIntoAEL_mE308B5C094F0FA47F51521D41A48EFF3712E1471 (void);
// 0x0000004E System.Boolean ClipperLib.Clipper::E2InsertsBeforeE1(ClipperLib.TEdge,ClipperLib.TEdge)
extern void Clipper_E2InsertsBeforeE1_m0D0B7A3F51202270FC79DA8A2E29D27BE1C07792 (void);
// 0x0000004F System.Boolean ClipperLib.Clipper::IsEvenOddFillType(ClipperLib.TEdge)
extern void Clipper_IsEvenOddFillType_m55005EC38626CC236C7DA5EBBD2BF9F61C41534B (void);
// 0x00000050 System.Boolean ClipperLib.Clipper::IsEvenOddAltFillType(ClipperLib.TEdge)
extern void Clipper_IsEvenOddAltFillType_mB08A57150173572C658D1BF8D1E72F3CDE7029AD (void);
// 0x00000051 System.Boolean ClipperLib.Clipper::IsContributing(ClipperLib.TEdge)
extern void Clipper_IsContributing_m3D991193E2DD8A8999E58AF05D6827A710112D94 (void);
// 0x00000052 System.Void ClipperLib.Clipper::SetWindingCount(ClipperLib.TEdge)
extern void Clipper_SetWindingCount_m240C092D58AC9BA15244E646F3DD6B939CCF0485 (void);
// 0x00000053 System.Void ClipperLib.Clipper::AddEdgeToSEL(ClipperLib.TEdge)
extern void Clipper_AddEdgeToSEL_m7E0AC9EEC0DFC67832E3F0978A487C0D39FBC41E (void);
// 0x00000054 System.Boolean ClipperLib.Clipper::PopEdgeFromSEL(ClipperLib.TEdge&)
extern void Clipper_PopEdgeFromSEL_m7955633E7A752C1544E0B0A0E3534C1E964AD556 (void);
// 0x00000055 System.Void ClipperLib.Clipper::CopyAELToSEL()
extern void Clipper_CopyAELToSEL_m08A19A0646D4D1D6D9459062707DA7D8A48BC3F3 (void);
// 0x00000056 System.Void ClipperLib.Clipper::SwapPositionsInSEL(ClipperLib.TEdge,ClipperLib.TEdge)
extern void Clipper_SwapPositionsInSEL_m3FDD6456C628F79E1C06ED5EED2A812CA2429B8C (void);
// 0x00000057 System.Void ClipperLib.Clipper::AddLocalMaxPoly(ClipperLib.TEdge,ClipperLib.TEdge,ClipperLib.IntPoint)
extern void Clipper_AddLocalMaxPoly_mE156D6D1A392C1D6949A9A3DB6A60642B4EA9D3A (void);
// 0x00000058 ClipperLib.OutPt ClipperLib.Clipper::AddLocalMinPoly(ClipperLib.TEdge,ClipperLib.TEdge,ClipperLib.IntPoint)
extern void Clipper_AddLocalMinPoly_mE82BA4DE1FCD97D9CB90817D06C015108BC9F29B (void);
// 0x00000059 ClipperLib.OutPt ClipperLib.Clipper::AddOutPt(ClipperLib.TEdge,ClipperLib.IntPoint)
extern void Clipper_AddOutPt_m940A43D61BB4690C6F10543DA4E1D7161A8A7603 (void);
// 0x0000005A ClipperLib.OutPt ClipperLib.Clipper::GetLastOutPt(ClipperLib.TEdge)
extern void Clipper_GetLastOutPt_m8B0DA9F8079EF6A1CBFD0E36E9E09798BB94BD58 (void);
// 0x0000005B System.Boolean ClipperLib.Clipper::HorzSegmentsOverlap(System.Int64,System.Int64,System.Int64,System.Int64)
extern void Clipper_HorzSegmentsOverlap_mF64E4969E718DF972E9F50268633C75905981CC4 (void);
// 0x0000005C System.Void ClipperLib.Clipper::SetHoleState(ClipperLib.TEdge,ClipperLib.OutRec)
extern void Clipper_SetHoleState_m979CFE9719A11385008B1E5AC5FB5F70FBB88F28 (void);
// 0x0000005D System.Double ClipperLib.Clipper::GetDx(ClipperLib.IntPoint,ClipperLib.IntPoint)
extern void Clipper_GetDx_m9B78917D37010CF2BCC9530A7B9C44342D1BF2A1 (void);
// 0x0000005E System.Boolean ClipperLib.Clipper::FirstIsBottomPt(ClipperLib.OutPt,ClipperLib.OutPt)
extern void Clipper_FirstIsBottomPt_m5BC51C2D30FC6938F521A5E424BBCA658C5DA6CB (void);
// 0x0000005F ClipperLib.OutPt ClipperLib.Clipper::GetBottomPt(ClipperLib.OutPt)
extern void Clipper_GetBottomPt_m8A63536D4DC462B311ECB13E84A9E07C6A55D46B (void);
// 0x00000060 ClipperLib.OutRec ClipperLib.Clipper::GetLowermostRec(ClipperLib.OutRec,ClipperLib.OutRec)
extern void Clipper_GetLowermostRec_m4E77165BAFCE56C46F3502CC5723B6E347C32940 (void);
// 0x00000061 System.Boolean ClipperLib.Clipper::OutRec1RightOfOutRec2(ClipperLib.OutRec,ClipperLib.OutRec)
extern void Clipper_OutRec1RightOfOutRec2_mEA35B1F03CFF7D2979944A63C13A789CC68FFDCB (void);
// 0x00000062 ClipperLib.OutRec ClipperLib.Clipper::GetOutRec(System.Int32)
extern void Clipper_GetOutRec_m986C83AD9D655A0EBC519FAB01FB7E620126DEF9 (void);
// 0x00000063 System.Void ClipperLib.Clipper::AppendPolygon(ClipperLib.TEdge,ClipperLib.TEdge)
extern void Clipper_AppendPolygon_mB06377DD5EDAD64B9E12BEB4F1A079E6C291B222 (void);
// 0x00000064 System.Void ClipperLib.Clipper::ReversePolyPtLinks(ClipperLib.OutPt)
extern void Clipper_ReversePolyPtLinks_m293A3CA727EC6AAE9A5EC99BDF8AF0BBEDB03BEE (void);
// 0x00000065 System.Void ClipperLib.Clipper::SwapSides(ClipperLib.TEdge,ClipperLib.TEdge)
extern void Clipper_SwapSides_mBB06776290E1920C297117AC589C605751DF3BFD (void);
// 0x00000066 System.Void ClipperLib.Clipper::SwapPolyIndexes(ClipperLib.TEdge,ClipperLib.TEdge)
extern void Clipper_SwapPolyIndexes_mAF04DBA061E6765EF852FA31C6866819DCE10227 (void);
// 0x00000067 System.Void ClipperLib.Clipper::IntersectEdges(ClipperLib.TEdge,ClipperLib.TEdge,ClipperLib.IntPoint)
extern void Clipper_IntersectEdges_m985A4B42C88B81BC4D0865C8F7685587330B7FB5 (void);
// 0x00000068 System.Void ClipperLib.Clipper::ProcessHorizontals()
extern void Clipper_ProcessHorizontals_mB3E705E90ECA6ED3E2122637B35C9E569713466C (void);
// 0x00000069 System.Void ClipperLib.Clipper::GetHorzDirection(ClipperLib.TEdge,ClipperLib.Direction&,System.Int64&,System.Int64&)
extern void Clipper_GetHorzDirection_m941263F22B68EF41C84F5A2F632AC5017222610D (void);
// 0x0000006A System.Void ClipperLib.Clipper::ProcessHorizontal(ClipperLib.TEdge)
extern void Clipper_ProcessHorizontal_m460F14965796843F48AA7E4E9ACDB4503D7BE7A6 (void);
// 0x0000006B ClipperLib.TEdge ClipperLib.Clipper::GetNextInAEL(ClipperLib.TEdge,ClipperLib.Direction)
extern void Clipper_GetNextInAEL_mC50835834F7FA202CC3D961A5F6DAD96536F72A6 (void);
// 0x0000006C System.Boolean ClipperLib.Clipper::IsMaxima(ClipperLib.TEdge,System.Double)
extern void Clipper_IsMaxima_m9109A835DE576ECA765B5B3823845F58AF8AADB9 (void);
// 0x0000006D System.Boolean ClipperLib.Clipper::IsIntermediate(ClipperLib.TEdge,System.Double)
extern void Clipper_IsIntermediate_m392CB99E9C151EE8B463395295B8F454945F9448 (void);
// 0x0000006E ClipperLib.TEdge ClipperLib.Clipper::GetMaximaPair(ClipperLib.TEdge)
extern void Clipper_GetMaximaPair_mEF916ECCC1CD32A223E267CB611F4DECC5095AF4 (void);
// 0x0000006F ClipperLib.TEdge ClipperLib.Clipper::GetMaximaPairEx(ClipperLib.TEdge)
extern void Clipper_GetMaximaPairEx_mC370B64034463B889DE911AA5009FFAF09050A4E (void);
// 0x00000070 System.Boolean ClipperLib.Clipper::ProcessIntersections(System.Int64)
extern void Clipper_ProcessIntersections_m08D8C5E555DB925CD1D1E8B4603D3E250D88646B (void);
// 0x00000071 System.Void ClipperLib.Clipper::BuildIntersectList(System.Int64)
extern void Clipper_BuildIntersectList_m899EA84B90035F8E44320EB8C6FE1953208F1B2A (void);
// 0x00000072 System.Boolean ClipperLib.Clipper::EdgesAdjacent(ClipperLib.IntersectNode)
extern void Clipper_EdgesAdjacent_mC782734E324C76A396791261A7B2C032F0894973 (void);
// 0x00000073 System.Boolean ClipperLib.Clipper::FixupIntersectionOrder()
extern void Clipper_FixupIntersectionOrder_mC1F0B191A20EAD5A25EB4489788BF7C46CA1D4E3 (void);
// 0x00000074 System.Void ClipperLib.Clipper::ProcessIntersectList()
extern void Clipper_ProcessIntersectList_m36AABA2011ABFC9135F8B86DAB704D82856FA2FB (void);
// 0x00000075 System.Int64 ClipperLib.Clipper::Round(System.Double)
extern void Clipper_Round_m10A9BAFEA5C4A093BD1ABE775056EFFD4830F1B7 (void);
// 0x00000076 System.Int64 ClipperLib.Clipper::TopX(ClipperLib.TEdge,System.Int64)
extern void Clipper_TopX_mD2F777B6B9BA5234F405EA34FD55A0B5898805A6 (void);
// 0x00000077 System.Void ClipperLib.Clipper::IntersectPoint(ClipperLib.TEdge,ClipperLib.TEdge,ClipperLib.IntPoint&)
extern void Clipper_IntersectPoint_mA5F0DCE6EA1BA92BF3684D08702F4D12BC95284E (void);
// 0x00000078 System.Void ClipperLib.Clipper::ProcessEdgesAtTopOfScanbeam(System.Int64)
extern void Clipper_ProcessEdgesAtTopOfScanbeam_m4B2BA787590FB92CC67FE5A7F7A658C5C9B97510 (void);
// 0x00000079 System.Void ClipperLib.Clipper::DoMaxima(ClipperLib.TEdge)
extern void Clipper_DoMaxima_m25565877521042C970F9ABD834B6A306E53E8CEA (void);
// 0x0000007A System.Boolean ClipperLib.Clipper::Orientation(System.Collections.Generic.List`1<ClipperLib.IntPoint>)
extern void Clipper_Orientation_mC3ADC211FC90B408EE5F9C3EFE7AC459B92C40EA (void);
// 0x0000007B System.Int32 ClipperLib.Clipper::PointCount(ClipperLib.OutPt)
extern void Clipper_PointCount_m325EE7AEAF92FDAF2DCFA1D042E9D9D16AF91D3E (void);
// 0x0000007C System.Void ClipperLib.Clipper::BuildResult(System.Collections.Generic.List`1<System.Collections.Generic.List`1<ClipperLib.IntPoint>>)
extern void Clipper_BuildResult_mD8546E202F265E598F43FD06FDFEC0FD7267738D (void);
// 0x0000007D System.Void ClipperLib.Clipper::FixupOutPolyline(ClipperLib.OutRec)
extern void Clipper_FixupOutPolyline_mF4CCED80AE70FAA653438A95958241FCD35D79C7 (void);
// 0x0000007E System.Void ClipperLib.Clipper::FixupOutPolygon(ClipperLib.OutRec)
extern void Clipper_FixupOutPolygon_m9A53E005645CB79DB1930B4B2AD3810FBE3423B3 (void);
// 0x0000007F ClipperLib.OutPt ClipperLib.Clipper::DupOutPt(ClipperLib.OutPt,System.Boolean)
extern void Clipper_DupOutPt_m8A76F442F7EEE7659DD174B2908DDC46A8E8FACF (void);
// 0x00000080 System.Boolean ClipperLib.Clipper::GetOverlap(System.Int64,System.Int64,System.Int64,System.Int64,System.Int64&,System.Int64&)
extern void Clipper_GetOverlap_m074F092F25F32BF09EA90227593B86EBBA2ABE28 (void);
// 0x00000081 System.Boolean ClipperLib.Clipper::JoinHorz(ClipperLib.OutPt,ClipperLib.OutPt,ClipperLib.OutPt,ClipperLib.OutPt,ClipperLib.IntPoint,System.Boolean)
extern void Clipper_JoinHorz_mE58CC9C53B5A03F339EAF14FCA9020891234B9BF (void);
// 0x00000082 System.Boolean ClipperLib.Clipper::JoinPoints(ClipperLib.Join,ClipperLib.OutRec,ClipperLib.OutRec)
extern void Clipper_JoinPoints_m0C29F9202577924442E532481F5E972595B66BC0 (void);
// 0x00000083 System.Int32 ClipperLib.Clipper::PointInPolygon(ClipperLib.IntPoint,System.Collections.Generic.List`1<ClipperLib.IntPoint>)
extern void Clipper_PointInPolygon_m2394FF589C7C4AFE474C1A07BA8C03847BB27023 (void);
// 0x00000084 System.Int32 ClipperLib.Clipper::PointInPolygon(ClipperLib.IntPoint,ClipperLib.OutPt)
extern void Clipper_PointInPolygon_m08FA1871A806B9700991A3C15F958978082EF0AC (void);
// 0x00000085 System.Boolean ClipperLib.Clipper::Poly2ContainsPoly1(ClipperLib.OutPt,ClipperLib.OutPt)
extern void Clipper_Poly2ContainsPoly1_m9397F56DB6FB4B16524F772E7525459978CD5D29 (void);
// 0x00000086 System.Void ClipperLib.Clipper::FixupFirstLefts1(ClipperLib.OutRec,ClipperLib.OutRec)
extern void Clipper_FixupFirstLefts1_mC2F4CA1486ECDA9C84F768B2777E64E1A86C15A5 (void);
// 0x00000087 System.Void ClipperLib.Clipper::FixupFirstLefts2(ClipperLib.OutRec,ClipperLib.OutRec)
extern void Clipper_FixupFirstLefts2_m98F0FEF73082D33845759D1C3D2CB54BAE440261 (void);
// 0x00000088 System.Void ClipperLib.Clipper::FixupFirstLefts3(ClipperLib.OutRec,ClipperLib.OutRec)
extern void Clipper_FixupFirstLefts3_mC1A30B14F43B122FBD0BF9E4B05E1C7E28E627C2 (void);
// 0x00000089 ClipperLib.OutRec ClipperLib.Clipper::ParseFirstLeft(ClipperLib.OutRec)
extern void Clipper_ParseFirstLeft_mD2E3D0244E64AFD0FF824D741DD478F94B36AF7C (void);
// 0x0000008A System.Void ClipperLib.Clipper::JoinCommonEdges()
extern void Clipper_JoinCommonEdges_m5BA0C366B9EC7407AAAE3696BC6A773BD292A471 (void);
// 0x0000008B System.Void ClipperLib.Clipper::UpdateOutPtIdxs(ClipperLib.OutRec)
extern void Clipper_UpdateOutPtIdxs_m40AD80D5C0AED980DB6D93D44179F85312089CBF (void);
// 0x0000008C System.Void ClipperLib.Clipper::DoSimplePolygons()
extern void Clipper_DoSimplePolygons_mB6E331BE157D74FCA04450886D019170E2457255 (void);
// 0x0000008D System.Double ClipperLib.Clipper::Area(System.Collections.Generic.List`1<ClipperLib.IntPoint>)
extern void Clipper_Area_m7F21B72FA2B53A8D8F969D1B61C796ACA7BCE7FA (void);
// 0x0000008E System.Double ClipperLib.Clipper::Area(ClipperLib.OutRec)
extern void Clipper_Area_m1D16CB32B00E0F27BA1A72080F835CCCE311061F (void);
// 0x0000008F System.Double ClipperLib.Clipper::Area(ClipperLib.OutPt)
extern void Clipper_Area_mED7CD4F196CCB84A14E74871D6D4F04CB6D6EDBB (void);
// 0x00000090 System.Double ClipperLib.ClipperOffset::get_ArcTolerance()
extern void ClipperOffset_get_ArcTolerance_mED26777C94CAB339C6D9CC0662148A33BECC56F7 (void);
// 0x00000091 System.Void ClipperLib.ClipperOffset::set_ArcTolerance(System.Double)
extern void ClipperOffset_set_ArcTolerance_mF4A9B334DD73307D61F0C90733251183ECE381C4 (void);
// 0x00000092 System.Double ClipperLib.ClipperOffset::get_MiterLimit()
extern void ClipperOffset_get_MiterLimit_mFDF5FF95106B784C81FE5A8844C109DA6D0CBBEE (void);
// 0x00000093 System.Void ClipperLib.ClipperOffset::set_MiterLimit(System.Double)
extern void ClipperOffset_set_MiterLimit_m447EE2F58E5C7DD101807D10C717AB503B5D5E0A (void);
// 0x00000094 System.Void ClipperLib.ClipperOffset::.ctor(System.Double,System.Double)
extern void ClipperOffset__ctor_mA396D6A41D7E839856125D21A32F89C560D647B2 (void);
// 0x00000095 System.Void ClipperLib.ClipperOffset::Clear()
extern void ClipperOffset_Clear_m4EF9C35DE6D50B86197F14DF2934109FEDCADD52 (void);
// 0x00000096 System.Int64 ClipperLib.ClipperOffset::Round(System.Double)
extern void ClipperOffset_Round_mA2E562E0514312F7E00409BF58B704A840BC2E9A (void);
// 0x00000097 System.Void ClipperLib.ClipperOffset::AddPath(System.Collections.Generic.List`1<ClipperLib.IntPoint>,ClipperLib.JoinType,ClipperLib.EndType)
extern void ClipperOffset_AddPath_mF8045B764877B3D98B276DE57725A73BC74C89A0 (void);
// 0x00000098 System.Void ClipperLib.ClipperOffset::AddPaths(System.Collections.Generic.List`1<System.Collections.Generic.List`1<ClipperLib.IntPoint>>,ClipperLib.JoinType,ClipperLib.EndType)
extern void ClipperOffset_AddPaths_mDAE2AFA97C5CFF4EAE285AF0A5D4FC0CE5997658 (void);
// 0x00000099 System.Void ClipperLib.ClipperOffset::FixOrientations()
extern void ClipperOffset_FixOrientations_m3C3EA430057E016434AC4DB8C8E7E621EDAB5F60 (void);
// 0x0000009A ClipperLib.DoublePoint ClipperLib.ClipperOffset::GetUnitNormal(ClipperLib.IntPoint,ClipperLib.IntPoint)
extern void ClipperOffset_GetUnitNormal_mEA247CF58D8B5184FDD226CC50EFD88D7D8D1212 (void);
// 0x0000009B System.Void ClipperLib.ClipperOffset::DoOffset(System.Double)
extern void ClipperOffset_DoOffset_mE321AC8550FE131533308804CAF7DB104DCA9800 (void);
// 0x0000009C System.Void ClipperLib.ClipperOffset::Execute(System.Collections.Generic.List`1<System.Collections.Generic.List`1<ClipperLib.IntPoint>>&,System.Double)
extern void ClipperOffset_Execute_m276CEEEB2CFBBC77F00F1BFB72907D3A913F6DA0 (void);
// 0x0000009D System.Void ClipperLib.ClipperOffset::OffsetPoint(System.Int32,System.Int32&,ClipperLib.JoinType)
extern void ClipperOffset_OffsetPoint_mD1E80076C94BD7FB9D42663A1E0DBE0F0E601FF7 (void);
// 0x0000009E System.Void ClipperLib.ClipperOffset::DoSquare(System.Int32,System.Int32)
extern void ClipperOffset_DoSquare_m514BC243DEF7B65FF76B91B92D078D3393D45171 (void);
// 0x0000009F System.Void ClipperLib.ClipperOffset::DoMiter(System.Int32,System.Int32,System.Double)
extern void ClipperOffset_DoMiter_mE783D0C0C1B8E671EC8DA4613EFDE2A19C693138 (void);
// 0x000000A0 System.Void ClipperLib.ClipperOffset::DoRound(System.Int32,System.Int32)
extern void ClipperOffset_DoRound_mA445935175DDD85C54187D784757A1044613E3BA (void);
// 0x000000A1 System.Void ClipperLib.ClipperException::.ctor(System.String)
extern void ClipperException__ctor_m40A0F3BBD1E2A1F576B1133A5F75E88F98D3F7AC (void);
static Il2CppMethodPointer s_methodPointers[161] = 
{
	DoublePoint__ctor_m482D3610D420BFF5DF1EDDFF3C319B5C6DCAC859,
	DoublePoint__ctor_m4DA444C77667ADC06334633460B05370B9CA56F8,
	PolyNode_get_ChildCount_mC2378D10B6B9D8CC805F4A123A9A5D69096806D1,
	PolyNode_AddChild_m7DB863FAF3A3B77198AAAF508856DE1F696A1582,
	PolyNode_get_Childs_m6323F4C10D5D9CD18B4D5A5629E8A9568A9A73B2,
	PolyNode__ctor_m2C22F4592F3CD2C12553108F9D9E88DA916DEED6,
	Int128__ctor_mBD38F0ABE017AD0F5D66EBD836D159C574B6022A,
	Int128_op_Equality_m52655612FA9E991C51354AB62B31D3D04225871A,
	Int128_Equals_m0A40B15C0D2A14127DD34F898693C436CE774707,
	Int128_GetHashCode_mCDE2E0DF254213BFC67F8F62111371F3ED9C51D5,
	Int128_op_UnaryNegation_m9C1172745BB39CE6143AF4367360CC554BDEABDE,
	Int128_Int128Mul_mB2BC203BD87908553B71AF17B183A5E53780DCC7,
	IntPoint__ctor_m43FA6E2F1EA903A84E87C40570C002A50492EFE5,
	IntPoint__ctor_mE5B43837884272FB8DD8256B001F6287A2E6BB63,
	IntPoint__ctor_mD769F4D36E8F16A4ADF2D231FB6C0752D5120BC5,
	IntPoint_op_Equality_mD84506C88E1012BF31DEED68FF333EC538D7C1A9,
	IntPoint_op_Inequality_m1B138D93FF1636CB7CB1DCAA62B8DFDEADDEA2B7,
	IntPoint_Equals_m5E53D2A6836041B94FB0D049B1D33671D9EE4556,
	IntPoint_GetHashCode_m9322836AAE0BA19EE99F299DF98AA6A3B9126EBE,
	IntRect__ctor_m93AB3555BB9C12827745826CA4D60984F7752D52,
	TEdge__ctor_mA1EB24F2FBD4D8C11F907EF1E6BC03CA7BF4C93E,
	IntersectNode__ctor_m4B2C47C8A8F3F85DF24BACD1E9CD037481557C78,
	MyIntersectNodeSort_Compare_m2F66B35EC741C1801BFA4A9EAB4853943A5CF861,
	MyIntersectNodeSort__ctor_m053DA624977E961C096A62DF04074039471A02F7,
	LocalMinima__ctor_m549BC1F11D26DC5CF0DBC7DF430FCC5DE90D01C2,
	Scanbeam__ctor_m633912064C71027DBF8ED66D368DE9C6F5935221,
	Maxima__ctor_mC4904A4872B389B80D21193C1A820886A8297CF3,
	OutRec__ctor_m4D0CE6C9A2F5377A22EFD6997297A39789DC66FF,
	OutPt__ctor_m0536125B7761CCBDB06B5B61E1656587ADAA1AAC,
	Join__ctor_mD170CA55E901088B64A774497379680EC36E6138,
	ClipperBase_near_zero_m73B042480AEB4531BDA936D2B266A61B1F4E1A76,
	ClipperBase_get_PreserveCollinear_mF815A8E8F42740154020BC6AE8F940770CCABD8F,
	ClipperBase_set_PreserveCollinear_m1D8A039E2B937CA6034C17A8A446DA0373C4865F,
	ClipperBase_Swap_m372564516C68B173A4A143F9F783B7310BF92C34,
	ClipperBase_IsHorizontal_m2C7E9BB42FA46CBB04B6A20CE382BFF35ADCC9C6,
	ClipperBase_SlopesEqual_m0376A25654525DB9216E30A8C848B2E2CABF16AF,
	ClipperBase_SlopesEqual_mE66FE6BF09981C0D25F7228760E541E5AC7C0E57,
	ClipperBase_SlopesEqual_m726344D5585B2A64A96838562BD796D02740320E,
	ClipperBase__ctor_mB35BE76A3465FC86B93D19E4BA047E95BFB65CAF,
	ClipperBase_Clear_m2552093878FC5D5F8B4F96A6DE53D7007E77A6A8,
	ClipperBase_DisposeLocalMinimaList_mE8D1728F624E3CBE8A2519DE28D31BEB7AFBD223,
	ClipperBase_RangeTest_mA3F47013E6E18BC2E86C630FB2B03C0B3B9981E5,
	ClipperBase_InitEdge_m19B0803C590838C597D2F1418782FD81083848A0,
	ClipperBase_InitEdge2_mCF0AB43E07F594F86F7F30F26F74D13770510A0C,
	ClipperBase_FindNextLocMin_mA24AD75724BD42CFFBFD753725729DC72750B247,
	ClipperBase_ProcessBound_m1156BC1E43204F034D2407CDD1E162045170D048,
	ClipperBase_AddPath_mC9457F91B4A3E5E720AB74406F77607026435C14,
	ClipperBase_AddPaths_mEC27DFC58A9FCBD73E1E9C5DF70CC51298ED4202,
	ClipperBase_Pt2IsBetweenPt1AndPt3_m0232ED88825FC7DE0F25980E674ED399EC1D5FCC,
	ClipperBase_RemoveEdge_m67F38E8D2BAA3DC6E1691B6763218808417AF2BF,
	ClipperBase_SetDx_mACC7E781D83D845A2383EFC9ABD1B012102CA298,
	ClipperBase_InsertLocalMinima_mC825C5610F785BB337459AD17856B606CF644764,
	ClipperBase_PopLocalMinima_mA77DDADD9877C26C9E5915000A4DF0268C869738,
	ClipperBase_ReverseHorizontal_m1EFD3278FD6915456179BD5C2F37FE0D9036BE56,
	ClipperBase_Reset_mC2AB4DE731202A5C3B67E13722C56540BDC489F9,
	ClipperBase_GetBounds_m7929C7A36D7C108A87538D74E440C8A517741FDE,
	ClipperBase_InsertScanbeam_m0B684DA2EE3192058D886050D5ECB121FA086059,
	ClipperBase_PopScanbeam_m7ECA90915F946D7583FED94FB8BC4EC35D408B4C,
	ClipperBase_LocalMinimaPending_mD819FB3E17C9BE88E0816878266B39FD9A108F17,
	ClipperBase_CreateOutRec_m173DBFA1510A4DF9FAFA6EC45D7A2F62C7CB568C,
	ClipperBase_DisposeOutRec_mA63315ED842B582EDAF61B2F1643E6B500236C86,
	ClipperBase_UpdateEdgeIntoAEL_mBFFEFA68B03191BD3325AD23120BBB15FB6243BF,
	ClipperBase_SwapPositionsInAEL_m5E8583BFDD7E6153161FC599BF93BA2A16951C9D,
	ClipperBase_DeleteFromAEL_m6E7C7F18920490A0CC194E32BA00D6FEF1175DDB,
	Clipper__ctor_m7CE711A86E713B0AC68C632E6C5EC766E85353DD,
	Clipper_InsertMaxima_mB6640EC0501821A439002DE10EFA34A06C41F3A2,
	Clipper_get_ReverseSolution_m16CB9BE38C4204F91892877D45A3574AFC94E71A,
	Clipper_set_ReverseSolution_m841D018306A112D204E00FB2026F09F325C12DAA,
	Clipper_get_StrictlySimple_m01C2EFE9DEE3C256C263075A5377D07C2A191695,
	Clipper_set_StrictlySimple_mF4815B6637F58516E0A22BC049172F89CBA712E2,
	Clipper_Execute_mB4264F9470A5C69626A07F0875AEB40FEAFB81B2,
	Clipper_ExecuteInternal_m9ADE942CB713B99830DF07BCCE24E38BE19CA132,
	Clipper_DisposeAllPolyPts_mF05175DA812BD9D8C9D32D60601225B0FCD6BDAB,
	Clipper_AddJoin_m15A0AB0CCFDC67D36EAEBB26E973FCA8D49A9D66,
	Clipper_AddGhostJoin_mAE51CD773B174F590377CFFE53FA1FCB2E4290B9,
	Clipper_InsertLocalMinimaIntoAEL_m5A797CFBDB56BE0CFF30B9797ACFBC73C68923D4,
	Clipper_InsertEdgeIntoAEL_mE308B5C094F0FA47F51521D41A48EFF3712E1471,
	Clipper_E2InsertsBeforeE1_m0D0B7A3F51202270FC79DA8A2E29D27BE1C07792,
	Clipper_IsEvenOddFillType_m55005EC38626CC236C7DA5EBBD2BF9F61C41534B,
	Clipper_IsEvenOddAltFillType_mB08A57150173572C658D1BF8D1E72F3CDE7029AD,
	Clipper_IsContributing_m3D991193E2DD8A8999E58AF05D6827A710112D94,
	Clipper_SetWindingCount_m240C092D58AC9BA15244E646F3DD6B939CCF0485,
	Clipper_AddEdgeToSEL_m7E0AC9EEC0DFC67832E3F0978A487C0D39FBC41E,
	Clipper_PopEdgeFromSEL_m7955633E7A752C1544E0B0A0E3534C1E964AD556,
	Clipper_CopyAELToSEL_m08A19A0646D4D1D6D9459062707DA7D8A48BC3F3,
	Clipper_SwapPositionsInSEL_m3FDD6456C628F79E1C06ED5EED2A812CA2429B8C,
	Clipper_AddLocalMaxPoly_mE156D6D1A392C1D6949A9A3DB6A60642B4EA9D3A,
	Clipper_AddLocalMinPoly_mE82BA4DE1FCD97D9CB90817D06C015108BC9F29B,
	Clipper_AddOutPt_m940A43D61BB4690C6F10543DA4E1D7161A8A7603,
	Clipper_GetLastOutPt_m8B0DA9F8079EF6A1CBFD0E36E9E09798BB94BD58,
	Clipper_HorzSegmentsOverlap_mF64E4969E718DF972E9F50268633C75905981CC4,
	Clipper_SetHoleState_m979CFE9719A11385008B1E5AC5FB5F70FBB88F28,
	Clipper_GetDx_m9B78917D37010CF2BCC9530A7B9C44342D1BF2A1,
	Clipper_FirstIsBottomPt_m5BC51C2D30FC6938F521A5E424BBCA658C5DA6CB,
	Clipper_GetBottomPt_m8A63536D4DC462B311ECB13E84A9E07C6A55D46B,
	Clipper_GetLowermostRec_m4E77165BAFCE56C46F3502CC5723B6E347C32940,
	Clipper_OutRec1RightOfOutRec2_mEA35B1F03CFF7D2979944A63C13A789CC68FFDCB,
	Clipper_GetOutRec_m986C83AD9D655A0EBC519FAB01FB7E620126DEF9,
	Clipper_AppendPolygon_mB06377DD5EDAD64B9E12BEB4F1A079E6C291B222,
	Clipper_ReversePolyPtLinks_m293A3CA727EC6AAE9A5EC99BDF8AF0BBEDB03BEE,
	Clipper_SwapSides_mBB06776290E1920C297117AC589C605751DF3BFD,
	Clipper_SwapPolyIndexes_mAF04DBA061E6765EF852FA31C6866819DCE10227,
	Clipper_IntersectEdges_m985A4B42C88B81BC4D0865C8F7685587330B7FB5,
	Clipper_ProcessHorizontals_mB3E705E90ECA6ED3E2122637B35C9E569713466C,
	Clipper_GetHorzDirection_m941263F22B68EF41C84F5A2F632AC5017222610D,
	Clipper_ProcessHorizontal_m460F14965796843F48AA7E4E9ACDB4503D7BE7A6,
	Clipper_GetNextInAEL_mC50835834F7FA202CC3D961A5F6DAD96536F72A6,
	Clipper_IsMaxima_m9109A835DE576ECA765B5B3823845F58AF8AADB9,
	Clipper_IsIntermediate_m392CB99E9C151EE8B463395295B8F454945F9448,
	Clipper_GetMaximaPair_mEF916ECCC1CD32A223E267CB611F4DECC5095AF4,
	Clipper_GetMaximaPairEx_mC370B64034463B889DE911AA5009FFAF09050A4E,
	Clipper_ProcessIntersections_m08D8C5E555DB925CD1D1E8B4603D3E250D88646B,
	Clipper_BuildIntersectList_m899EA84B90035F8E44320EB8C6FE1953208F1B2A,
	Clipper_EdgesAdjacent_mC782734E324C76A396791261A7B2C032F0894973,
	Clipper_FixupIntersectionOrder_mC1F0B191A20EAD5A25EB4489788BF7C46CA1D4E3,
	Clipper_ProcessIntersectList_m36AABA2011ABFC9135F8B86DAB704D82856FA2FB,
	Clipper_Round_m10A9BAFEA5C4A093BD1ABE775056EFFD4830F1B7,
	Clipper_TopX_mD2F777B6B9BA5234F405EA34FD55A0B5898805A6,
	Clipper_IntersectPoint_mA5F0DCE6EA1BA92BF3684D08702F4D12BC95284E,
	Clipper_ProcessEdgesAtTopOfScanbeam_m4B2BA787590FB92CC67FE5A7F7A658C5C9B97510,
	Clipper_DoMaxima_m25565877521042C970F9ABD834B6A306E53E8CEA,
	Clipper_Orientation_mC3ADC211FC90B408EE5F9C3EFE7AC459B92C40EA,
	Clipper_PointCount_m325EE7AEAF92FDAF2DCFA1D042E9D9D16AF91D3E,
	Clipper_BuildResult_mD8546E202F265E598F43FD06FDFEC0FD7267738D,
	Clipper_FixupOutPolyline_mF4CCED80AE70FAA653438A95958241FCD35D79C7,
	Clipper_FixupOutPolygon_m9A53E005645CB79DB1930B4B2AD3810FBE3423B3,
	Clipper_DupOutPt_m8A76F442F7EEE7659DD174B2908DDC46A8E8FACF,
	Clipper_GetOverlap_m074F092F25F32BF09EA90227593B86EBBA2ABE28,
	Clipper_JoinHorz_mE58CC9C53B5A03F339EAF14FCA9020891234B9BF,
	Clipper_JoinPoints_m0C29F9202577924442E532481F5E972595B66BC0,
	Clipper_PointInPolygon_m2394FF589C7C4AFE474C1A07BA8C03847BB27023,
	Clipper_PointInPolygon_m08FA1871A806B9700991A3C15F958978082EF0AC,
	Clipper_Poly2ContainsPoly1_m9397F56DB6FB4B16524F772E7525459978CD5D29,
	Clipper_FixupFirstLefts1_mC2F4CA1486ECDA9C84F768B2777E64E1A86C15A5,
	Clipper_FixupFirstLefts2_m98F0FEF73082D33845759D1C3D2CB54BAE440261,
	Clipper_FixupFirstLefts3_mC1A30B14F43B122FBD0BF9E4B05E1C7E28E627C2,
	Clipper_ParseFirstLeft_mD2E3D0244E64AFD0FF824D741DD478F94B36AF7C,
	Clipper_JoinCommonEdges_m5BA0C366B9EC7407AAAE3696BC6A773BD292A471,
	Clipper_UpdateOutPtIdxs_m40AD80D5C0AED980DB6D93D44179F85312089CBF,
	Clipper_DoSimplePolygons_mB6E331BE157D74FCA04450886D019170E2457255,
	Clipper_Area_m7F21B72FA2B53A8D8F969D1B61C796ACA7BCE7FA,
	Clipper_Area_m1D16CB32B00E0F27BA1A72080F835CCCE311061F,
	Clipper_Area_mED7CD4F196CCB84A14E74871D6D4F04CB6D6EDBB,
	ClipperOffset_get_ArcTolerance_mED26777C94CAB339C6D9CC0662148A33BECC56F7,
	ClipperOffset_set_ArcTolerance_mF4A9B334DD73307D61F0C90733251183ECE381C4,
	ClipperOffset_get_MiterLimit_mFDF5FF95106B784C81FE5A8844C109DA6D0CBBEE,
	ClipperOffset_set_MiterLimit_m447EE2F58E5C7DD101807D10C717AB503B5D5E0A,
	ClipperOffset__ctor_mA396D6A41D7E839856125D21A32F89C560D647B2,
	ClipperOffset_Clear_m4EF9C35DE6D50B86197F14DF2934109FEDCADD52,
	ClipperOffset_Round_mA2E562E0514312F7E00409BF58B704A840BC2E9A,
	ClipperOffset_AddPath_mF8045B764877B3D98B276DE57725A73BC74C89A0,
	ClipperOffset_AddPaths_mDAE2AFA97C5CFF4EAE285AF0A5D4FC0CE5997658,
	ClipperOffset_FixOrientations_m3C3EA430057E016434AC4DB8C8E7E621EDAB5F60,
	ClipperOffset_GetUnitNormal_mEA247CF58D8B5184FDD226CC50EFD88D7D8D1212,
	ClipperOffset_DoOffset_mE321AC8550FE131533308804CAF7DB104DCA9800,
	ClipperOffset_Execute_m276CEEEB2CFBBC77F00F1BFB72907D3A913F6DA0,
	ClipperOffset_OffsetPoint_mD1E80076C94BD7FB9D42663A1E0DBE0F0E601FF7,
	ClipperOffset_DoSquare_m514BC243DEF7B65FF76B91B92D078D3393D45171,
	ClipperOffset_DoMiter_mE783D0C0C1B8E671EC8DA4613EFDE2A19C693138,
	ClipperOffset_DoRound_mA445935175DDD85C54187D784757A1044613E3BA,
	ClipperException__ctor_m40A0F3BBD1E2A1F576B1133A5F75E88F98D3F7AC,
};
extern void DoublePoint__ctor_m482D3610D420BFF5DF1EDDFF3C319B5C6DCAC859_AdjustorThunk (void);
extern void DoublePoint__ctor_m4DA444C77667ADC06334633460B05370B9CA56F8_AdjustorThunk (void);
extern void Int128__ctor_mBD38F0ABE017AD0F5D66EBD836D159C574B6022A_AdjustorThunk (void);
extern void Int128_Equals_m0A40B15C0D2A14127DD34F898693C436CE774707_AdjustorThunk (void);
extern void Int128_GetHashCode_mCDE2E0DF254213BFC67F8F62111371F3ED9C51D5_AdjustorThunk (void);
extern void IntPoint__ctor_m43FA6E2F1EA903A84E87C40570C002A50492EFE5_AdjustorThunk (void);
extern void IntPoint__ctor_mE5B43837884272FB8DD8256B001F6287A2E6BB63_AdjustorThunk (void);
extern void IntPoint__ctor_mD769F4D36E8F16A4ADF2D231FB6C0752D5120BC5_AdjustorThunk (void);
extern void IntPoint_Equals_m5E53D2A6836041B94FB0D049B1D33671D9EE4556_AdjustorThunk (void);
extern void IntPoint_GetHashCode_m9322836AAE0BA19EE99F299DF98AA6A3B9126EBE_AdjustorThunk (void);
extern void IntRect__ctor_m93AB3555BB9C12827745826CA4D60984F7752D52_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[11] = 
{
	{ 0x06000001, DoublePoint__ctor_m482D3610D420BFF5DF1EDDFF3C319B5C6DCAC859_AdjustorThunk },
	{ 0x06000002, DoublePoint__ctor_m4DA444C77667ADC06334633460B05370B9CA56F8_AdjustorThunk },
	{ 0x06000007, Int128__ctor_mBD38F0ABE017AD0F5D66EBD836D159C574B6022A_AdjustorThunk },
	{ 0x06000009, Int128_Equals_m0A40B15C0D2A14127DD34F898693C436CE774707_AdjustorThunk },
	{ 0x0600000A, Int128_GetHashCode_mCDE2E0DF254213BFC67F8F62111371F3ED9C51D5_AdjustorThunk },
	{ 0x0600000D, IntPoint__ctor_m43FA6E2F1EA903A84E87C40570C002A50492EFE5_AdjustorThunk },
	{ 0x0600000E, IntPoint__ctor_mE5B43837884272FB8DD8256B001F6287A2E6BB63_AdjustorThunk },
	{ 0x0600000F, IntPoint__ctor_mD769F4D36E8F16A4ADF2D231FB6C0752D5120BC5_AdjustorThunk },
	{ 0x06000012, IntPoint_Equals_m5E53D2A6836041B94FB0D049B1D33671D9EE4556_AdjustorThunk },
	{ 0x06000013, IntPoint_GetHashCode_m9322836AAE0BA19EE99F299DF98AA6A3B9126EBE_AdjustorThunk },
	{ 0x06000014, IntRect__ctor_m93AB3555BB9C12827745826CA4D60984F7752D52_AdjustorThunk },
};
static const int32_t s_InvokerIndices[161] = 
{
	1127,
	2527,
	3188,
	2580,
	3207,
	3277,
	1380,
	4458,
	2180,
	3188,
	4758,
	4300,
	1380,
	1127,
	2564,
	4470,
	4470,
	2180,
	3188,
	458,
	3277,
	3277,
	838,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	4908,
	3235,
	2602,
	1111,
	4916,
	4110,
	3864,
	3604,
	3277,
	3277,
	3277,
	1383,
	486,
	1404,
	1951,
	925,
	623,
	623,
	611,
	1951,
	2580,
	2580,
	984,
	2580,
	3277,
	4821,
	2563,
	2089,
	3235,
	3207,
	2562,
	2502,
	1409,
	2580,
	2562,
	2563,
	3235,
	2602,
	3235,
	2602,
	386,
	3235,
	3277,
	734,
	1406,
	2563,
	1409,
	1002,
	2180,
	2180,
	2180,
	2580,
	2580,
	2089,
	3277,
	1409,
	734,
	569,
	923,
	1951,
	388,
	1409,
	793,
	1002,
	1951,
	924,
	1002,
	1945,
	1409,
	2580,
	4619,
	4619,
	734,
	3277,
	462,
	2580,
	922,
	998,
	998,
	1951,
	1951,
	2160,
	2563,
	2180,
	3235,
	3277,
	4803,
	4345,
	731,
	2563,
	2580,
	4916,
	1765,
	2580,
	2580,
	2580,
	925,
	96,
	99,
	625,
	4327,
	4327,
	4486,
	1409,
	1409,
	1409,
	4861,
	3277,
	2580,
	3277,
	4744,
	1602,
	1602,
	3151,
	2526,
	3151,
	2526,
	1127,
	3277,
	4803,
	723,
	723,
	3277,
	4288,
	2526,
	1112,
	685,
	1241,
	689,
	1241,
	2580,
};
extern const CustomAttributesCacheGenerator g_clipper_library_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_clipper_library_CodeGenModule;
const Il2CppCodeGenModule g_clipper_library_CodeGenModule = 
{
	"clipper_library.dll",
	161,
	s_methodPointers,
	11,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	g_clipper_library_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
