﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void UnityEngine.TextCore.FaceInfo::set_familyName(System.String)
extern void FaceInfo_set_familyName_mF2284C683441750136664CE2F54A6A1B8D025BCF (void);
// 0x00000002 System.Void UnityEngine.TextCore.FaceInfo::set_styleName(System.String)
extern void FaceInfo_set_styleName_m2EA494E818600812D1EF63E1B861D930D72DDB2F (void);
// 0x00000003 System.Int32 UnityEngine.TextCore.FaceInfo::get_pointSize()
extern void FaceInfo_get_pointSize_m3C6775E1AE5F27EAAB93CC84480B14AFBDB5E330 (void);
// 0x00000004 System.Void UnityEngine.TextCore.FaceInfo::set_pointSize(System.Int32)
extern void FaceInfo_set_pointSize_m26A4A24116D162BB182959D46AB2FA6576A84CF9 (void);
// 0x00000005 System.Single UnityEngine.TextCore.FaceInfo::get_scale()
extern void FaceInfo_get_scale_mA059FCEE1F13BBDF846AB8D8B8EDA468F4FCD2A4 (void);
// 0x00000006 System.Void UnityEngine.TextCore.FaceInfo::set_scale(System.Single)
extern void FaceInfo_set_scale_mA870178A90FC90A4E7D7149972CF190112244D9C (void);
// 0x00000007 System.Single UnityEngine.TextCore.FaceInfo::get_lineHeight()
extern void FaceInfo_get_lineHeight_m4BC0162351D2C7E607ECDF93534DAF0169AAEFE5 (void);
// 0x00000008 System.Void UnityEngine.TextCore.FaceInfo::set_lineHeight(System.Single)
extern void FaceInfo_set_lineHeight_mF771EE64A254D4ED012070BDC94B06545668D347 (void);
// 0x00000009 System.Single UnityEngine.TextCore.FaceInfo::get_ascentLine()
extern void FaceInfo_get_ascentLine_m69928E2E998FA9441C7628BF7F8D9E888470D983 (void);
// 0x0000000A System.Void UnityEngine.TextCore.FaceInfo::set_ascentLine(System.Single)
extern void FaceInfo_set_ascentLine_m510C3CF1B961D9BEDD79A4BAA7D65742C33AAD06 (void);
// 0x0000000B System.Single UnityEngine.TextCore.FaceInfo::get_capLine()
extern void FaceInfo_get_capLine_m16556D45E8441052D15DAE83CDB3FC31635BE0A7 (void);
// 0x0000000C System.Void UnityEngine.TextCore.FaceInfo::set_capLine(System.Single)
extern void FaceInfo_set_capLine_m6FB88B8953008824E84DBA88B3896DD98A1E8926 (void);
// 0x0000000D System.Single UnityEngine.TextCore.FaceInfo::get_meanLine()
extern void FaceInfo_get_meanLine_m10957577CE99FF794523FA34E4ED873B4888A11D (void);
// 0x0000000E System.Void UnityEngine.TextCore.FaceInfo::set_meanLine(System.Single)
extern void FaceInfo_set_meanLine_m9118E1C37F756267BF93CE1E94C880FACB70E2A2 (void);
// 0x0000000F System.Single UnityEngine.TextCore.FaceInfo::get_baseline()
extern void FaceInfo_get_baseline_m7EB9429D8D329E5DA5DB890CEF02A6C015C056D6 (void);
// 0x00000010 System.Void UnityEngine.TextCore.FaceInfo::set_baseline(System.Single)
extern void FaceInfo_set_baseline_m83DA240FEADBE11609EB11B79AC9FE6165ABBAC7 (void);
// 0x00000011 System.Single UnityEngine.TextCore.FaceInfo::get_descentLine()
extern void FaceInfo_get_descentLine_m0AEF0D85997836B841605DCE178ABA42A92C6EFA (void);
// 0x00000012 System.Void UnityEngine.TextCore.FaceInfo::set_descentLine(System.Single)
extern void FaceInfo_set_descentLine_m91AB76A124FE9E536BD72785512B2C623BA2B067 (void);
// 0x00000013 System.Single UnityEngine.TextCore.FaceInfo::get_superscriptOffset()
extern void FaceInfo_get_superscriptOffset_mAF8D37F78A79780652BAE40384F0C4DED8350769 (void);
// 0x00000014 System.Void UnityEngine.TextCore.FaceInfo::set_superscriptOffset(System.Single)
extern void FaceInfo_set_superscriptOffset_mE0422507D4C2DE3F2CFF7286F90462675741D15E (void);
// 0x00000015 System.Single UnityEngine.TextCore.FaceInfo::get_superscriptSize()
extern void FaceInfo_get_superscriptSize_m7FBEC1B0C97A7DC9D581AF9ADBDDCF14F7565F1A (void);
// 0x00000016 System.Void UnityEngine.TextCore.FaceInfo::set_superscriptSize(System.Single)
extern void FaceInfo_set_superscriptSize_mCDE84F4EA47D69B7D783FE62DA78656BBC17C07E (void);
// 0x00000017 System.Single UnityEngine.TextCore.FaceInfo::get_subscriptOffset()
extern void FaceInfo_get_subscriptOffset_mD3F7F2F5F93364977E3F81E9B693D5CDB1419088 (void);
// 0x00000018 System.Void UnityEngine.TextCore.FaceInfo::set_subscriptOffset(System.Single)
extern void FaceInfo_set_subscriptOffset_mCF79D815311C70E3E8CC2BC241FEFE39CC992A39 (void);
// 0x00000019 System.Single UnityEngine.TextCore.FaceInfo::get_subscriptSize()
extern void FaceInfo_get_subscriptSize_mEC9AEAD24A51AB19FFCC09AE919EF656ED2C6413 (void);
// 0x0000001A System.Void UnityEngine.TextCore.FaceInfo::set_subscriptSize(System.Single)
extern void FaceInfo_set_subscriptSize_m61497C0D29FE50D498648DEC0FAADA9ED151387A (void);
// 0x0000001B System.Single UnityEngine.TextCore.FaceInfo::get_underlineOffset()
extern void FaceInfo_get_underlineOffset_m0F2900E06388C697807D43285BD4979E9D0BDA50 (void);
// 0x0000001C System.Void UnityEngine.TextCore.FaceInfo::set_underlineOffset(System.Single)
extern void FaceInfo_set_underlineOffset_mBE89D25E848FAF83FB750D95A93F6C051D798B54 (void);
// 0x0000001D System.Single UnityEngine.TextCore.FaceInfo::get_underlineThickness()
extern void FaceInfo_get_underlineThickness_m07A6016172DE8DC1514CA780EBB80C32FA209F28 (void);
// 0x0000001E System.Void UnityEngine.TextCore.FaceInfo::set_underlineThickness(System.Single)
extern void FaceInfo_set_underlineThickness_m86B440DB7CBDB6C588FBC03990B980A715726059 (void);
// 0x0000001F System.Single UnityEngine.TextCore.FaceInfo::get_strikethroughOffset()
extern void FaceInfo_get_strikethroughOffset_m705C7A75FFA7E324582D6A1CC404ED4C8E8417EB (void);
// 0x00000020 System.Void UnityEngine.TextCore.FaceInfo::set_strikethroughOffset(System.Single)
extern void FaceInfo_set_strikethroughOffset_m9ACD0A24A8EC5FEB90596BA43E8E8D8FF7EA0623 (void);
// 0x00000021 System.Void UnityEngine.TextCore.FaceInfo::set_strikethroughThickness(System.Single)
extern void FaceInfo_set_strikethroughThickness_mE26FAFBC6C984F88F68F7507CFE8AFB28E1932E7 (void);
// 0x00000022 System.Single UnityEngine.TextCore.FaceInfo::get_tabWidth()
extern void FaceInfo_get_tabWidth_mFBE94B2FBBB301B0FC1011D49A96032A0EE1A588 (void);
// 0x00000023 System.Void UnityEngine.TextCore.FaceInfo::set_tabWidth(System.Single)
extern void FaceInfo_set_tabWidth_mE024C95E768A214E3C85781753658B437F4B6B54 (void);
// 0x00000024 System.Int32 UnityEngine.TextCore.GlyphRect::get_x()
extern void GlyphRect_get_x_m004398D85360A389BCCD4F8B38347C0555F86166 (void);
// 0x00000025 System.Int32 UnityEngine.TextCore.GlyphRect::get_y()
extern void GlyphRect_get_y_mBF2FC84CB7B201F30376B46390D37887B6AD6C20 (void);
// 0x00000026 System.Int32 UnityEngine.TextCore.GlyphRect::get_width()
extern void GlyphRect_get_width_m8B9FBFA897082BA8E5F71222E1AAAB8D4A345A41 (void);
// 0x00000027 System.Int32 UnityEngine.TextCore.GlyphRect::get_height()
extern void GlyphRect_get_height_m319E96AD96E2087C9C9F5A1DF883F06A4D04104F (void);
// 0x00000028 UnityEngine.TextCore.GlyphRect UnityEngine.TextCore.GlyphRect::get_zero()
extern void GlyphRect_get_zero_m4F82533B1FF0E143D6CEB594F68254D925879229 (void);
// 0x00000029 System.Void UnityEngine.TextCore.GlyphRect::.ctor(System.Int32,System.Int32,System.Int32,System.Int32)
extern void GlyphRect__ctor_m278B410AE9B6DE62FF8C2445B8F3C6051B45ED61 (void);
// 0x0000002A System.Int32 UnityEngine.TextCore.GlyphRect::GetHashCode()
extern void GlyphRect_GetHashCode_m6DC4515E8C489593A329B5EA66895BD8C25DF913 (void);
// 0x0000002B System.Boolean UnityEngine.TextCore.GlyphRect::Equals(System.Object)
extern void GlyphRect_Equals_m7F1DB9A21E584BEF84C5F83E6DD290EF54D655C1 (void);
// 0x0000002C System.Boolean UnityEngine.TextCore.GlyphRect::Equals(UnityEngine.TextCore.GlyphRect)
extern void GlyphRect_Equals_mB9F911262F09BC42CD2A461D8692D1C3ECAFCDCE (void);
// 0x0000002D System.Void UnityEngine.TextCore.GlyphRect::.cctor()
extern void GlyphRect__cctor_mC0A746562E15F7DB07264227927E7B9276FA5A9B (void);
// 0x0000002E System.Single UnityEngine.TextCore.GlyphMetrics::get_width()
extern void GlyphMetrics_get_width_m4E2BCD2B54F121478C1D23C43FB6E8C0EF71C70F (void);
// 0x0000002F System.Single UnityEngine.TextCore.GlyphMetrics::get_height()
extern void GlyphMetrics_get_height_m742B169DCF2892774ACEC4F25310CDC0C7F1D85F (void);
// 0x00000030 System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalBearingX()
extern void GlyphMetrics_get_horizontalBearingX_m8474B6C9DB0D4D36516FCAC03B6ECBDAF49247E0 (void);
// 0x00000031 System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalBearingY()
extern void GlyphMetrics_get_horizontalBearingY_m2C5A73B899AFF5F5F594F447160ADB6E0523C16A (void);
// 0x00000032 System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalAdvance()
extern void GlyphMetrics_get_horizontalAdvance_mB204F2676223D5BEF5FEFF8969B159B39F1A617A (void);
// 0x00000033 System.Void UnityEngine.TextCore.GlyphMetrics::.ctor(System.Single,System.Single,System.Single,System.Single,System.Single)
extern void GlyphMetrics__ctor_m6146EC37C12EF153771AEF9983A63B5EBAE0CEFB (void);
// 0x00000034 System.Int32 UnityEngine.TextCore.GlyphMetrics::GetHashCode()
extern void GlyphMetrics_GetHashCode_m4F7985D656AFB70AE746F9A2513D39D3DFF9CD73 (void);
// 0x00000035 System.Boolean UnityEngine.TextCore.GlyphMetrics::Equals(System.Object)
extern void GlyphMetrics_Equals_mCCF68C73B7AE05D97A0D4459384DABD8BEB1097F (void);
// 0x00000036 System.Boolean UnityEngine.TextCore.GlyphMetrics::Equals(UnityEngine.TextCore.GlyphMetrics)
extern void GlyphMetrics_Equals_m54C8D6CAD2653668377F5F7A9F78FD7C4F05E4A8 (void);
// 0x00000037 System.UInt32 UnityEngine.TextCore.Glyph::get_index()
extern void Glyph_get_index_mB9A53E02F757731DC06414DFC6F4F5D1615DC248 (void);
// 0x00000038 System.Void UnityEngine.TextCore.Glyph::set_index(System.UInt32)
extern void Glyph_set_index_m68FA74E7DF133C63E1544913F2ADC38BB27DBED4 (void);
// 0x00000039 UnityEngine.TextCore.GlyphMetrics UnityEngine.TextCore.Glyph::get_metrics()
extern void Glyph_get_metrics_m395A93D5BD1B7859DD95B17386DAA033D2F865B0 (void);
// 0x0000003A System.Void UnityEngine.TextCore.Glyph::set_metrics(UnityEngine.TextCore.GlyphMetrics)
extern void Glyph_set_metrics_mAA75ADA7FEE5D62A48D1558CE4393C8E4FBBBC3B (void);
// 0x0000003B UnityEngine.TextCore.GlyphRect UnityEngine.TextCore.Glyph::get_glyphRect()
extern void Glyph_get_glyphRect_mA3484840AF306B3F9B146D7162424238B4F456F9 (void);
// 0x0000003C System.Void UnityEngine.TextCore.Glyph::set_glyphRect(UnityEngine.TextCore.GlyphRect)
extern void Glyph_set_glyphRect_mC1B26C50850B546BF6CF5AE5765FA6080F983B3B (void);
// 0x0000003D System.Single UnityEngine.TextCore.Glyph::get_scale()
extern void Glyph_get_scale_m446CB523D55E31B00D8AC704A60308C773E7F208 (void);
// 0x0000003E System.Void UnityEngine.TextCore.Glyph::set_scale(System.Single)
extern void Glyph_set_scale_m576BAC2DABBBDDAEB8B84BEB4A0780BC00D90753 (void);
// 0x0000003F System.Int32 UnityEngine.TextCore.Glyph::get_atlasIndex()
extern void Glyph_get_atlasIndex_m6538243B8852D859DE81213EDC5A9FDD837909EF (void);
// 0x00000040 System.Void UnityEngine.TextCore.Glyph::set_atlasIndex(System.Int32)
extern void Glyph_set_atlasIndex_m9994675326C6545B78A3CD5CC4A534D597195A3B (void);
// 0x00000041 System.Void UnityEngine.TextCore.Glyph::.ctor()
extern void Glyph__ctor_m3B14665C4F129AA87DC0FBF1D8E5274729840076 (void);
// 0x00000042 System.Void UnityEngine.TextCore.Glyph::.ctor(UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct)
extern void Glyph__ctor_m926A82734800BFA828FFB469B956F563FF0F1994 (void);
// 0x00000043 System.Void UnityEngine.TextCore.Glyph::.ctor(System.UInt32,UnityEngine.TextCore.GlyphMetrics,UnityEngine.TextCore.GlyphRect,System.Single,System.Int32)
extern void Glyph__ctor_m3B1336D6A76FF3C315E66EC5857E378D7BE50DE2 (void);
// 0x00000044 System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_xPlacement()
extern void GlyphValueRecord_get_xPlacement_mAC5902DE9EE01D98DE9FBC6DB3A8BA7CDC525D14 (void);
// 0x00000045 System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_yPlacement()
extern void GlyphValueRecord_get_yPlacement_m624E2DA69CC5A21117EE275359F66AF88DFC7D2D (void);
// 0x00000046 System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_xAdvance()
extern void GlyphValueRecord_get_xAdvance_m577D4D32490C42890C3F15230479D931B91BDED5 (void);
// 0x00000047 System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_yAdvance()
extern void GlyphValueRecord_get_yAdvance_m9659978FFA9B58B6AA7DE30199E405CF642BA34F (void);
// 0x00000048 System.Int32 UnityEngine.TextCore.LowLevel.GlyphValueRecord::GetHashCode()
extern void GlyphValueRecord_GetHashCode_m5700595527E17C02B923199180E8983105563A71 (void);
// 0x00000049 System.Boolean UnityEngine.TextCore.LowLevel.GlyphValueRecord::Equals(System.Object)
extern void GlyphValueRecord_Equals_mB12EE7C56E781B2DAFF2DEA1AFFFA1EC4DCBA943 (void);
// 0x0000004A System.Boolean UnityEngine.TextCore.LowLevel.GlyphValueRecord::Equals(UnityEngine.TextCore.LowLevel.GlyphValueRecord)
extern void GlyphValueRecord_Equals_m716F55BA3DD7B7E97F3E35BE94A5922BE90FECF4 (void);
// 0x0000004B System.UInt32 UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord::get_glyphIndex()
extern void GlyphAdjustmentRecord_get_glyphIndex_mCD420C739E19E446152534AFA80A6113C0DBCC55 (void);
// 0x0000004C UnityEngine.TextCore.LowLevel.GlyphValueRecord UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord::get_glyphValueRecord()
extern void GlyphAdjustmentRecord_get_glyphValueRecord_mAC27920271FB7166EE305BACE1D595CAA57872EE (void);
// 0x0000004D UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::get_firstAdjustmentRecord()
extern void GlyphPairAdjustmentRecord_get_firstAdjustmentRecord_m92BC7561227D482635EF8AB93B8F20808017FBF8 (void);
// 0x0000004E System.Void UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::set_firstAdjustmentRecord(UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord)
extern void GlyphPairAdjustmentRecord_set_firstAdjustmentRecord_m780CD1495A667852B44DA8EF210172484F917C77 (void);
// 0x0000004F UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::get_secondAdjustmentRecord()
extern void GlyphPairAdjustmentRecord_get_secondAdjustmentRecord_m488CCBCB6802727334E2135E65EBB027A0A01EAD (void);
// 0x00000050 System.Void UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::set_secondAdjustmentRecord(UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord)
extern void GlyphPairAdjustmentRecord_set_secondAdjustmentRecord_mE8AFF0F392DE4B0590C0F7F2AF3D2D85AD756EFE (void);
// 0x00000051 UnityEngine.TextCore.LowLevel.FontFeatureLookupFlags UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::get_featureLookupFlags()
extern void GlyphPairAdjustmentRecord_get_featureLookupFlags_m3BBC32A004335C153CABFFA25F02164DEF20AE58 (void);
// 0x00000052 System.Void UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::set_featureLookupFlags(UnityEngine.TextCore.LowLevel.FontFeatureLookupFlags)
extern void GlyphPairAdjustmentRecord_set_featureLookupFlags_m6F0E8C3CBE5A06B42E8EE4EC0B91028EBE731834 (void);
// 0x00000053 System.Void UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::.ctor(UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord,UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord)
extern void GlyphPairAdjustmentRecord__ctor_mA474AC63D0E4A5B8127FC38A7CC74DC1817BB264 (void);
// 0x00000054 UnityEngine.TextCore.LowLevel.FontEngineError UnityEngine.TextCore.LowLevel.FontEngine::InitializeFontEngine()
extern void FontEngine_InitializeFontEngine_m85697221DC9ED18EC8356014293D423347054C43 (void);
// 0x00000055 System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::InitializeFontEngine_Internal()
extern void FontEngine_InitializeFontEngine_Internal_m50E925BB9BE850ADB0611C2707FCECF3FB728C71 (void);
// 0x00000056 UnityEngine.TextCore.LowLevel.FontEngineError UnityEngine.TextCore.LowLevel.FontEngine::LoadFontFace(UnityEngine.Font,System.Int32)
extern void FontEngine_LoadFontFace_m85674659FD8AA761C771CA869FC345B1555EDD5D (void);
// 0x00000057 System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::LoadFontFace_With_Size_FromFont_Internal(UnityEngine.Font,System.Int32)
extern void FontEngine_LoadFontFace_With_Size_FromFont_Internal_m2904823B237D890C9AC817A13098274D7DEC4FA7 (void);
// 0x00000058 UnityEngine.TextCore.FaceInfo UnityEngine.TextCore.LowLevel.FontEngine::GetFaceInfo()
extern void FontEngine_GetFaceInfo_m76A5E8DEE1846A7D56BC72D8FE177CA6656F8385 (void);
// 0x00000059 System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::GetFaceInfo_Internal(UnityEngine.TextCore.FaceInfo&)
extern void FontEngine_GetFaceInfo_Internal_m86BF1FCC26761DEB15EBC252943F10690612F6CA (void);
// 0x0000005A System.UInt32 UnityEngine.TextCore.LowLevel.FontEngine::GetGlyphIndex(System.UInt32)
extern void FontEngine_GetGlyphIndex_mFA9D09AB6E5FC7234F0154D9BF53923762EE1947 (void);
// 0x0000005B System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryGetGlyphWithUnicodeValue(System.UInt32,UnityEngine.TextCore.LowLevel.GlyphLoadFlags,UnityEngine.TextCore.Glyph&)
extern void FontEngine_TryGetGlyphWithUnicodeValue_m2C8B5D37D097FB1C75846E431D29AC15349CBA3B (void);
// 0x0000005C System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryGetGlyphWithUnicodeValue_Internal(System.UInt32,UnityEngine.TextCore.LowLevel.GlyphLoadFlags,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&)
extern void FontEngine_TryGetGlyphWithUnicodeValue_Internal_m4DDE3BF8F78CEDB763D821454B89997BB9BA276C (void);
// 0x0000005D System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryGetGlyphWithIndexValue(System.UInt32,UnityEngine.TextCore.LowLevel.GlyphLoadFlags,UnityEngine.TextCore.Glyph&)
extern void FontEngine_TryGetGlyphWithIndexValue_m775B743546174CA10A01141847225874AC3EE7D9 (void);
// 0x0000005E System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryGetGlyphWithIndexValue_Internal(System.UInt32,UnityEngine.TextCore.LowLevel.GlyphLoadFlags,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&)
extern void FontEngine_TryGetGlyphWithIndexValue_Internal_mF1CB9EABC97E1A1372A23297EAFBE7EAB5A6313A (void);
// 0x0000005F System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryAddGlyphToTexture(System.UInt32,System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>,System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D,UnityEngine.TextCore.Glyph&)
extern void FontEngine_TryAddGlyphToTexture_mF2513F6DE362FCB9609BE09CC1EFB6D851922200 (void);
// 0x00000060 System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryAddGlyphToTexture_Internal(System.UInt32,System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&)
extern void FontEngine_TryAddGlyphToTexture_Internal_m1A0E3323EADB617657BF97F660649C6FDD1B14B7 (void);
// 0x00000061 System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryAddGlyphsToTexture(System.Collections.Generic.List`1<System.UInt32>,System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>,System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D,UnityEngine.TextCore.Glyph[]&)
extern void FontEngine_TryAddGlyphsToTexture_m61337C5A18F0229A85A6203976715D70F3362655 (void);
// 0x00000062 System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryAddGlyphsToTexture_Internal(System.UInt32[],System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct[],System.Int32&)
extern void FontEngine_TryAddGlyphsToTexture_Internal_mB0FE279387211C00BF9E5891C39462CD6F159CE8 (void);
// 0x00000063 UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord[] UnityEngine.TextCore.LowLevel.FontEngine::GetGlyphPairAdjustmentTable(System.UInt32[])
extern void FontEngine_GetGlyphPairAdjustmentTable_mE93C9A8673C34CAE740DEB22328F2A961DB76014 (void);
// 0x00000064 UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord[] UnityEngine.TextCore.LowLevel.FontEngine::GetGlyphPairAdjustmentRecords(System.Collections.Generic.List`1<System.UInt32>,System.Int32&)
extern void FontEngine_GetGlyphPairAdjustmentRecords_mD48E80AB6EC69715B5D2522AB7B949823298C52F (void);
// 0x00000065 System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::PopulatePairAdjustmentRecordMarshallingArray_from_GlyphIndexes(System.UInt32[],System.Int32&)
extern void FontEngine_PopulatePairAdjustmentRecordMarshallingArray_from_GlyphIndexes_m209060A34247119B382FE9327CDDC85B8A04DEDF (void);
// 0x00000066 System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::GetGlyphPairAdjustmentRecordsFromMarshallingArray(UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord[])
extern void FontEngine_GetGlyphPairAdjustmentRecordsFromMarshallingArray_m0B720E99C766368DA85190A049A4F70C5805DFD4 (void);
// 0x00000067 System.Void UnityEngine.TextCore.LowLevel.FontEngine::GenericListToMarshallingArray(System.Collections.Generic.List`1<T>&,T[]&)
// 0x00000068 System.Void UnityEngine.TextCore.LowLevel.FontEngine::SetMarshallingArraySize(T[]&,System.Int32)
// 0x00000069 System.Void UnityEngine.TextCore.LowLevel.FontEngine::ResetAtlasTexture(UnityEngine.Texture2D)
extern void FontEngine_ResetAtlasTexture_m34415B1BC955B68AC8BFE1F339BA74E4B81C160B (void);
// 0x0000006A System.Void UnityEngine.TextCore.LowLevel.FontEngine::.cctor()
extern void FontEngine__cctor_mACF18DD12F81B34818DC5508BC4EF347445F7FE3 (void);
// 0x0000006B System.Int32 UnityEngine.TextCore.LowLevel.FontEngineUtilities::MaxValue(System.Int32,System.Int32,System.Int32)
extern void FontEngineUtilities_MaxValue_m2EF659954522080160961E35BE6FDF1DD5C98FB7 (void);
static Il2CppMethodPointer s_methodPointers[107] = 
{
	FaceInfo_set_familyName_mF2284C683441750136664CE2F54A6A1B8D025BCF,
	FaceInfo_set_styleName_m2EA494E818600812D1EF63E1B861D930D72DDB2F,
	FaceInfo_get_pointSize_m3C6775E1AE5F27EAAB93CC84480B14AFBDB5E330,
	FaceInfo_set_pointSize_m26A4A24116D162BB182959D46AB2FA6576A84CF9,
	FaceInfo_get_scale_mA059FCEE1F13BBDF846AB8D8B8EDA468F4FCD2A4,
	FaceInfo_set_scale_mA870178A90FC90A4E7D7149972CF190112244D9C,
	FaceInfo_get_lineHeight_m4BC0162351D2C7E607ECDF93534DAF0169AAEFE5,
	FaceInfo_set_lineHeight_mF771EE64A254D4ED012070BDC94B06545668D347,
	FaceInfo_get_ascentLine_m69928E2E998FA9441C7628BF7F8D9E888470D983,
	FaceInfo_set_ascentLine_m510C3CF1B961D9BEDD79A4BAA7D65742C33AAD06,
	FaceInfo_get_capLine_m16556D45E8441052D15DAE83CDB3FC31635BE0A7,
	FaceInfo_set_capLine_m6FB88B8953008824E84DBA88B3896DD98A1E8926,
	FaceInfo_get_meanLine_m10957577CE99FF794523FA34E4ED873B4888A11D,
	FaceInfo_set_meanLine_m9118E1C37F756267BF93CE1E94C880FACB70E2A2,
	FaceInfo_get_baseline_m7EB9429D8D329E5DA5DB890CEF02A6C015C056D6,
	FaceInfo_set_baseline_m83DA240FEADBE11609EB11B79AC9FE6165ABBAC7,
	FaceInfo_get_descentLine_m0AEF0D85997836B841605DCE178ABA42A92C6EFA,
	FaceInfo_set_descentLine_m91AB76A124FE9E536BD72785512B2C623BA2B067,
	FaceInfo_get_superscriptOffset_mAF8D37F78A79780652BAE40384F0C4DED8350769,
	FaceInfo_set_superscriptOffset_mE0422507D4C2DE3F2CFF7286F90462675741D15E,
	FaceInfo_get_superscriptSize_m7FBEC1B0C97A7DC9D581AF9ADBDDCF14F7565F1A,
	FaceInfo_set_superscriptSize_mCDE84F4EA47D69B7D783FE62DA78656BBC17C07E,
	FaceInfo_get_subscriptOffset_mD3F7F2F5F93364977E3F81E9B693D5CDB1419088,
	FaceInfo_set_subscriptOffset_mCF79D815311C70E3E8CC2BC241FEFE39CC992A39,
	FaceInfo_get_subscriptSize_mEC9AEAD24A51AB19FFCC09AE919EF656ED2C6413,
	FaceInfo_set_subscriptSize_m61497C0D29FE50D498648DEC0FAADA9ED151387A,
	FaceInfo_get_underlineOffset_m0F2900E06388C697807D43285BD4979E9D0BDA50,
	FaceInfo_set_underlineOffset_mBE89D25E848FAF83FB750D95A93F6C051D798B54,
	FaceInfo_get_underlineThickness_m07A6016172DE8DC1514CA780EBB80C32FA209F28,
	FaceInfo_set_underlineThickness_m86B440DB7CBDB6C588FBC03990B980A715726059,
	FaceInfo_get_strikethroughOffset_m705C7A75FFA7E324582D6A1CC404ED4C8E8417EB,
	FaceInfo_set_strikethroughOffset_m9ACD0A24A8EC5FEB90596BA43E8E8D8FF7EA0623,
	FaceInfo_set_strikethroughThickness_mE26FAFBC6C984F88F68F7507CFE8AFB28E1932E7,
	FaceInfo_get_tabWidth_mFBE94B2FBBB301B0FC1011D49A96032A0EE1A588,
	FaceInfo_set_tabWidth_mE024C95E768A214E3C85781753658B437F4B6B54,
	GlyphRect_get_x_m004398D85360A389BCCD4F8B38347C0555F86166,
	GlyphRect_get_y_mBF2FC84CB7B201F30376B46390D37887B6AD6C20,
	GlyphRect_get_width_m8B9FBFA897082BA8E5F71222E1AAAB8D4A345A41,
	GlyphRect_get_height_m319E96AD96E2087C9C9F5A1DF883F06A4D04104F,
	GlyphRect_get_zero_m4F82533B1FF0E143D6CEB594F68254D925879229,
	GlyphRect__ctor_m278B410AE9B6DE62FF8C2445B8F3C6051B45ED61,
	GlyphRect_GetHashCode_m6DC4515E8C489593A329B5EA66895BD8C25DF913,
	GlyphRect_Equals_m7F1DB9A21E584BEF84C5F83E6DD290EF54D655C1,
	GlyphRect_Equals_mB9F911262F09BC42CD2A461D8692D1C3ECAFCDCE,
	GlyphRect__cctor_mC0A746562E15F7DB07264227927E7B9276FA5A9B,
	GlyphMetrics_get_width_m4E2BCD2B54F121478C1D23C43FB6E8C0EF71C70F,
	GlyphMetrics_get_height_m742B169DCF2892774ACEC4F25310CDC0C7F1D85F,
	GlyphMetrics_get_horizontalBearingX_m8474B6C9DB0D4D36516FCAC03B6ECBDAF49247E0,
	GlyphMetrics_get_horizontalBearingY_m2C5A73B899AFF5F5F594F447160ADB6E0523C16A,
	GlyphMetrics_get_horizontalAdvance_mB204F2676223D5BEF5FEFF8969B159B39F1A617A,
	GlyphMetrics__ctor_m6146EC37C12EF153771AEF9983A63B5EBAE0CEFB,
	GlyphMetrics_GetHashCode_m4F7985D656AFB70AE746F9A2513D39D3DFF9CD73,
	GlyphMetrics_Equals_mCCF68C73B7AE05D97A0D4459384DABD8BEB1097F,
	GlyphMetrics_Equals_m54C8D6CAD2653668377F5F7A9F78FD7C4F05E4A8,
	Glyph_get_index_mB9A53E02F757731DC06414DFC6F4F5D1615DC248,
	Glyph_set_index_m68FA74E7DF133C63E1544913F2ADC38BB27DBED4,
	Glyph_get_metrics_m395A93D5BD1B7859DD95B17386DAA033D2F865B0,
	Glyph_set_metrics_mAA75ADA7FEE5D62A48D1558CE4393C8E4FBBBC3B,
	Glyph_get_glyphRect_mA3484840AF306B3F9B146D7162424238B4F456F9,
	Glyph_set_glyphRect_mC1B26C50850B546BF6CF5AE5765FA6080F983B3B,
	Glyph_get_scale_m446CB523D55E31B00D8AC704A60308C773E7F208,
	Glyph_set_scale_m576BAC2DABBBDDAEB8B84BEB4A0780BC00D90753,
	Glyph_get_atlasIndex_m6538243B8852D859DE81213EDC5A9FDD837909EF,
	Glyph_set_atlasIndex_m9994675326C6545B78A3CD5CC4A534D597195A3B,
	Glyph__ctor_m3B14665C4F129AA87DC0FBF1D8E5274729840076,
	Glyph__ctor_m926A82734800BFA828FFB469B956F563FF0F1994,
	Glyph__ctor_m3B1336D6A76FF3C315E66EC5857E378D7BE50DE2,
	GlyphValueRecord_get_xPlacement_mAC5902DE9EE01D98DE9FBC6DB3A8BA7CDC525D14,
	GlyphValueRecord_get_yPlacement_m624E2DA69CC5A21117EE275359F66AF88DFC7D2D,
	GlyphValueRecord_get_xAdvance_m577D4D32490C42890C3F15230479D931B91BDED5,
	GlyphValueRecord_get_yAdvance_m9659978FFA9B58B6AA7DE30199E405CF642BA34F,
	GlyphValueRecord_GetHashCode_m5700595527E17C02B923199180E8983105563A71,
	GlyphValueRecord_Equals_mB12EE7C56E781B2DAFF2DEA1AFFFA1EC4DCBA943,
	GlyphValueRecord_Equals_m716F55BA3DD7B7E97F3E35BE94A5922BE90FECF4,
	GlyphAdjustmentRecord_get_glyphIndex_mCD420C739E19E446152534AFA80A6113C0DBCC55,
	GlyphAdjustmentRecord_get_glyphValueRecord_mAC27920271FB7166EE305BACE1D595CAA57872EE,
	GlyphPairAdjustmentRecord_get_firstAdjustmentRecord_m92BC7561227D482635EF8AB93B8F20808017FBF8,
	GlyphPairAdjustmentRecord_set_firstAdjustmentRecord_m780CD1495A667852B44DA8EF210172484F917C77,
	GlyphPairAdjustmentRecord_get_secondAdjustmentRecord_m488CCBCB6802727334E2135E65EBB027A0A01EAD,
	GlyphPairAdjustmentRecord_set_secondAdjustmentRecord_mE8AFF0F392DE4B0590C0F7F2AF3D2D85AD756EFE,
	GlyphPairAdjustmentRecord_get_featureLookupFlags_m3BBC32A004335C153CABFFA25F02164DEF20AE58,
	GlyphPairAdjustmentRecord_set_featureLookupFlags_m6F0E8C3CBE5A06B42E8EE4EC0B91028EBE731834,
	GlyphPairAdjustmentRecord__ctor_mA474AC63D0E4A5B8127FC38A7CC74DC1817BB264,
	FontEngine_InitializeFontEngine_m85697221DC9ED18EC8356014293D423347054C43,
	FontEngine_InitializeFontEngine_Internal_m50E925BB9BE850ADB0611C2707FCECF3FB728C71,
	FontEngine_LoadFontFace_m85674659FD8AA761C771CA869FC345B1555EDD5D,
	FontEngine_LoadFontFace_With_Size_FromFont_Internal_m2904823B237D890C9AC817A13098274D7DEC4FA7,
	FontEngine_GetFaceInfo_m76A5E8DEE1846A7D56BC72D8FE177CA6656F8385,
	FontEngine_GetFaceInfo_Internal_m86BF1FCC26761DEB15EBC252943F10690612F6CA,
	FontEngine_GetGlyphIndex_mFA9D09AB6E5FC7234F0154D9BF53923762EE1947,
	FontEngine_TryGetGlyphWithUnicodeValue_m2C8B5D37D097FB1C75846E431D29AC15349CBA3B,
	FontEngine_TryGetGlyphWithUnicodeValue_Internal_m4DDE3BF8F78CEDB763D821454B89997BB9BA276C,
	FontEngine_TryGetGlyphWithIndexValue_m775B743546174CA10A01141847225874AC3EE7D9,
	FontEngine_TryGetGlyphWithIndexValue_Internal_mF1CB9EABC97E1A1372A23297EAFBE7EAB5A6313A,
	FontEngine_TryAddGlyphToTexture_mF2513F6DE362FCB9609BE09CC1EFB6D851922200,
	FontEngine_TryAddGlyphToTexture_Internal_m1A0E3323EADB617657BF97F660649C6FDD1B14B7,
	FontEngine_TryAddGlyphsToTexture_m61337C5A18F0229A85A6203976715D70F3362655,
	FontEngine_TryAddGlyphsToTexture_Internal_mB0FE279387211C00BF9E5891C39462CD6F159CE8,
	FontEngine_GetGlyphPairAdjustmentTable_mE93C9A8673C34CAE740DEB22328F2A961DB76014,
	FontEngine_GetGlyphPairAdjustmentRecords_mD48E80AB6EC69715B5D2522AB7B949823298C52F,
	FontEngine_PopulatePairAdjustmentRecordMarshallingArray_from_GlyphIndexes_m209060A34247119B382FE9327CDDC85B8A04DEDF,
	FontEngine_GetGlyphPairAdjustmentRecordsFromMarshallingArray_m0B720E99C766368DA85190A049A4F70C5805DFD4,
	NULL,
	NULL,
	FontEngine_ResetAtlasTexture_m34415B1BC955B68AC8BFE1F339BA74E4B81C160B,
	FontEngine__cctor_mACF18DD12F81B34818DC5508BC4EF347445F7FE3,
	FontEngineUtilities_MaxValue_m2EF659954522080160961E35BE6FDF1DD5C98FB7,
};
extern void FaceInfo_set_familyName_mF2284C683441750136664CE2F54A6A1B8D025BCF_AdjustorThunk (void);
extern void FaceInfo_set_styleName_m2EA494E818600812D1EF63E1B861D930D72DDB2F_AdjustorThunk (void);
extern void FaceInfo_get_pointSize_m3C6775E1AE5F27EAAB93CC84480B14AFBDB5E330_AdjustorThunk (void);
extern void FaceInfo_set_pointSize_m26A4A24116D162BB182959D46AB2FA6576A84CF9_AdjustorThunk (void);
extern void FaceInfo_get_scale_mA059FCEE1F13BBDF846AB8D8B8EDA468F4FCD2A4_AdjustorThunk (void);
extern void FaceInfo_set_scale_mA870178A90FC90A4E7D7149972CF190112244D9C_AdjustorThunk (void);
extern void FaceInfo_get_lineHeight_m4BC0162351D2C7E607ECDF93534DAF0169AAEFE5_AdjustorThunk (void);
extern void FaceInfo_set_lineHeight_mF771EE64A254D4ED012070BDC94B06545668D347_AdjustorThunk (void);
extern void FaceInfo_get_ascentLine_m69928E2E998FA9441C7628BF7F8D9E888470D983_AdjustorThunk (void);
extern void FaceInfo_set_ascentLine_m510C3CF1B961D9BEDD79A4BAA7D65742C33AAD06_AdjustorThunk (void);
extern void FaceInfo_get_capLine_m16556D45E8441052D15DAE83CDB3FC31635BE0A7_AdjustorThunk (void);
extern void FaceInfo_set_capLine_m6FB88B8953008824E84DBA88B3896DD98A1E8926_AdjustorThunk (void);
extern void FaceInfo_get_meanLine_m10957577CE99FF794523FA34E4ED873B4888A11D_AdjustorThunk (void);
extern void FaceInfo_set_meanLine_m9118E1C37F756267BF93CE1E94C880FACB70E2A2_AdjustorThunk (void);
extern void FaceInfo_get_baseline_m7EB9429D8D329E5DA5DB890CEF02A6C015C056D6_AdjustorThunk (void);
extern void FaceInfo_set_baseline_m83DA240FEADBE11609EB11B79AC9FE6165ABBAC7_AdjustorThunk (void);
extern void FaceInfo_get_descentLine_m0AEF0D85997836B841605DCE178ABA42A92C6EFA_AdjustorThunk (void);
extern void FaceInfo_set_descentLine_m91AB76A124FE9E536BD72785512B2C623BA2B067_AdjustorThunk (void);
extern void FaceInfo_get_superscriptOffset_mAF8D37F78A79780652BAE40384F0C4DED8350769_AdjustorThunk (void);
extern void FaceInfo_set_superscriptOffset_mE0422507D4C2DE3F2CFF7286F90462675741D15E_AdjustorThunk (void);
extern void FaceInfo_get_superscriptSize_m7FBEC1B0C97A7DC9D581AF9ADBDDCF14F7565F1A_AdjustorThunk (void);
extern void FaceInfo_set_superscriptSize_mCDE84F4EA47D69B7D783FE62DA78656BBC17C07E_AdjustorThunk (void);
extern void FaceInfo_get_subscriptOffset_mD3F7F2F5F93364977E3F81E9B693D5CDB1419088_AdjustorThunk (void);
extern void FaceInfo_set_subscriptOffset_mCF79D815311C70E3E8CC2BC241FEFE39CC992A39_AdjustorThunk (void);
extern void FaceInfo_get_subscriptSize_mEC9AEAD24A51AB19FFCC09AE919EF656ED2C6413_AdjustorThunk (void);
extern void FaceInfo_set_subscriptSize_m61497C0D29FE50D498648DEC0FAADA9ED151387A_AdjustorThunk (void);
extern void FaceInfo_get_underlineOffset_m0F2900E06388C697807D43285BD4979E9D0BDA50_AdjustorThunk (void);
extern void FaceInfo_set_underlineOffset_mBE89D25E848FAF83FB750D95A93F6C051D798B54_AdjustorThunk (void);
extern void FaceInfo_get_underlineThickness_m07A6016172DE8DC1514CA780EBB80C32FA209F28_AdjustorThunk (void);
extern void FaceInfo_set_underlineThickness_m86B440DB7CBDB6C588FBC03990B980A715726059_AdjustorThunk (void);
extern void FaceInfo_get_strikethroughOffset_m705C7A75FFA7E324582D6A1CC404ED4C8E8417EB_AdjustorThunk (void);
extern void FaceInfo_set_strikethroughOffset_m9ACD0A24A8EC5FEB90596BA43E8E8D8FF7EA0623_AdjustorThunk (void);
extern void FaceInfo_set_strikethroughThickness_mE26FAFBC6C984F88F68F7507CFE8AFB28E1932E7_AdjustorThunk (void);
extern void FaceInfo_get_tabWidth_mFBE94B2FBBB301B0FC1011D49A96032A0EE1A588_AdjustorThunk (void);
extern void FaceInfo_set_tabWidth_mE024C95E768A214E3C85781753658B437F4B6B54_AdjustorThunk (void);
extern void GlyphRect_get_x_m004398D85360A389BCCD4F8B38347C0555F86166_AdjustorThunk (void);
extern void GlyphRect_get_y_mBF2FC84CB7B201F30376B46390D37887B6AD6C20_AdjustorThunk (void);
extern void GlyphRect_get_width_m8B9FBFA897082BA8E5F71222E1AAAB8D4A345A41_AdjustorThunk (void);
extern void GlyphRect_get_height_m319E96AD96E2087C9C9F5A1DF883F06A4D04104F_AdjustorThunk (void);
extern void GlyphRect__ctor_m278B410AE9B6DE62FF8C2445B8F3C6051B45ED61_AdjustorThunk (void);
extern void GlyphRect_GetHashCode_m6DC4515E8C489593A329B5EA66895BD8C25DF913_AdjustorThunk (void);
extern void GlyphRect_Equals_m7F1DB9A21E584BEF84C5F83E6DD290EF54D655C1_AdjustorThunk (void);
extern void GlyphRect_Equals_mB9F911262F09BC42CD2A461D8692D1C3ECAFCDCE_AdjustorThunk (void);
extern void GlyphMetrics_get_width_m4E2BCD2B54F121478C1D23C43FB6E8C0EF71C70F_AdjustorThunk (void);
extern void GlyphMetrics_get_height_m742B169DCF2892774ACEC4F25310CDC0C7F1D85F_AdjustorThunk (void);
extern void GlyphMetrics_get_horizontalBearingX_m8474B6C9DB0D4D36516FCAC03B6ECBDAF49247E0_AdjustorThunk (void);
extern void GlyphMetrics_get_horizontalBearingY_m2C5A73B899AFF5F5F594F447160ADB6E0523C16A_AdjustorThunk (void);
extern void GlyphMetrics_get_horizontalAdvance_mB204F2676223D5BEF5FEFF8969B159B39F1A617A_AdjustorThunk (void);
extern void GlyphMetrics__ctor_m6146EC37C12EF153771AEF9983A63B5EBAE0CEFB_AdjustorThunk (void);
extern void GlyphMetrics_GetHashCode_m4F7985D656AFB70AE746F9A2513D39D3DFF9CD73_AdjustorThunk (void);
extern void GlyphMetrics_Equals_mCCF68C73B7AE05D97A0D4459384DABD8BEB1097F_AdjustorThunk (void);
extern void GlyphMetrics_Equals_m54C8D6CAD2653668377F5F7A9F78FD7C4F05E4A8_AdjustorThunk (void);
extern void GlyphValueRecord_get_xPlacement_mAC5902DE9EE01D98DE9FBC6DB3A8BA7CDC525D14_AdjustorThunk (void);
extern void GlyphValueRecord_get_yPlacement_m624E2DA69CC5A21117EE275359F66AF88DFC7D2D_AdjustorThunk (void);
extern void GlyphValueRecord_get_xAdvance_m577D4D32490C42890C3F15230479D931B91BDED5_AdjustorThunk (void);
extern void GlyphValueRecord_get_yAdvance_m9659978FFA9B58B6AA7DE30199E405CF642BA34F_AdjustorThunk (void);
extern void GlyphValueRecord_GetHashCode_m5700595527E17C02B923199180E8983105563A71_AdjustorThunk (void);
extern void GlyphValueRecord_Equals_mB12EE7C56E781B2DAFF2DEA1AFFFA1EC4DCBA943_AdjustorThunk (void);
extern void GlyphValueRecord_Equals_m716F55BA3DD7B7E97F3E35BE94A5922BE90FECF4_AdjustorThunk (void);
extern void GlyphAdjustmentRecord_get_glyphIndex_mCD420C739E19E446152534AFA80A6113C0DBCC55_AdjustorThunk (void);
extern void GlyphAdjustmentRecord_get_glyphValueRecord_mAC27920271FB7166EE305BACE1D595CAA57872EE_AdjustorThunk (void);
extern void GlyphPairAdjustmentRecord_get_firstAdjustmentRecord_m92BC7561227D482635EF8AB93B8F20808017FBF8_AdjustorThunk (void);
extern void GlyphPairAdjustmentRecord_set_firstAdjustmentRecord_m780CD1495A667852B44DA8EF210172484F917C77_AdjustorThunk (void);
extern void GlyphPairAdjustmentRecord_get_secondAdjustmentRecord_m488CCBCB6802727334E2135E65EBB027A0A01EAD_AdjustorThunk (void);
extern void GlyphPairAdjustmentRecord_set_secondAdjustmentRecord_mE8AFF0F392DE4B0590C0F7F2AF3D2D85AD756EFE_AdjustorThunk (void);
extern void GlyphPairAdjustmentRecord_get_featureLookupFlags_m3BBC32A004335C153CABFFA25F02164DEF20AE58_AdjustorThunk (void);
extern void GlyphPairAdjustmentRecord_set_featureLookupFlags_m6F0E8C3CBE5A06B42E8EE4EC0B91028EBE731834_AdjustorThunk (void);
extern void GlyphPairAdjustmentRecord__ctor_mA474AC63D0E4A5B8127FC38A7CC74DC1817BB264_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[68] = 
{
	{ 0x06000001, FaceInfo_set_familyName_mF2284C683441750136664CE2F54A6A1B8D025BCF_AdjustorThunk },
	{ 0x06000002, FaceInfo_set_styleName_m2EA494E818600812D1EF63E1B861D930D72DDB2F_AdjustorThunk },
	{ 0x06000003, FaceInfo_get_pointSize_m3C6775E1AE5F27EAAB93CC84480B14AFBDB5E330_AdjustorThunk },
	{ 0x06000004, FaceInfo_set_pointSize_m26A4A24116D162BB182959D46AB2FA6576A84CF9_AdjustorThunk },
	{ 0x06000005, FaceInfo_get_scale_mA059FCEE1F13BBDF846AB8D8B8EDA468F4FCD2A4_AdjustorThunk },
	{ 0x06000006, FaceInfo_set_scale_mA870178A90FC90A4E7D7149972CF190112244D9C_AdjustorThunk },
	{ 0x06000007, FaceInfo_get_lineHeight_m4BC0162351D2C7E607ECDF93534DAF0169AAEFE5_AdjustorThunk },
	{ 0x06000008, FaceInfo_set_lineHeight_mF771EE64A254D4ED012070BDC94B06545668D347_AdjustorThunk },
	{ 0x06000009, FaceInfo_get_ascentLine_m69928E2E998FA9441C7628BF7F8D9E888470D983_AdjustorThunk },
	{ 0x0600000A, FaceInfo_set_ascentLine_m510C3CF1B961D9BEDD79A4BAA7D65742C33AAD06_AdjustorThunk },
	{ 0x0600000B, FaceInfo_get_capLine_m16556D45E8441052D15DAE83CDB3FC31635BE0A7_AdjustorThunk },
	{ 0x0600000C, FaceInfo_set_capLine_m6FB88B8953008824E84DBA88B3896DD98A1E8926_AdjustorThunk },
	{ 0x0600000D, FaceInfo_get_meanLine_m10957577CE99FF794523FA34E4ED873B4888A11D_AdjustorThunk },
	{ 0x0600000E, FaceInfo_set_meanLine_m9118E1C37F756267BF93CE1E94C880FACB70E2A2_AdjustorThunk },
	{ 0x0600000F, FaceInfo_get_baseline_m7EB9429D8D329E5DA5DB890CEF02A6C015C056D6_AdjustorThunk },
	{ 0x06000010, FaceInfo_set_baseline_m83DA240FEADBE11609EB11B79AC9FE6165ABBAC7_AdjustorThunk },
	{ 0x06000011, FaceInfo_get_descentLine_m0AEF0D85997836B841605DCE178ABA42A92C6EFA_AdjustorThunk },
	{ 0x06000012, FaceInfo_set_descentLine_m91AB76A124FE9E536BD72785512B2C623BA2B067_AdjustorThunk },
	{ 0x06000013, FaceInfo_get_superscriptOffset_mAF8D37F78A79780652BAE40384F0C4DED8350769_AdjustorThunk },
	{ 0x06000014, FaceInfo_set_superscriptOffset_mE0422507D4C2DE3F2CFF7286F90462675741D15E_AdjustorThunk },
	{ 0x06000015, FaceInfo_get_superscriptSize_m7FBEC1B0C97A7DC9D581AF9ADBDDCF14F7565F1A_AdjustorThunk },
	{ 0x06000016, FaceInfo_set_superscriptSize_mCDE84F4EA47D69B7D783FE62DA78656BBC17C07E_AdjustorThunk },
	{ 0x06000017, FaceInfo_get_subscriptOffset_mD3F7F2F5F93364977E3F81E9B693D5CDB1419088_AdjustorThunk },
	{ 0x06000018, FaceInfo_set_subscriptOffset_mCF79D815311C70E3E8CC2BC241FEFE39CC992A39_AdjustorThunk },
	{ 0x06000019, FaceInfo_get_subscriptSize_mEC9AEAD24A51AB19FFCC09AE919EF656ED2C6413_AdjustorThunk },
	{ 0x0600001A, FaceInfo_set_subscriptSize_m61497C0D29FE50D498648DEC0FAADA9ED151387A_AdjustorThunk },
	{ 0x0600001B, FaceInfo_get_underlineOffset_m0F2900E06388C697807D43285BD4979E9D0BDA50_AdjustorThunk },
	{ 0x0600001C, FaceInfo_set_underlineOffset_mBE89D25E848FAF83FB750D95A93F6C051D798B54_AdjustorThunk },
	{ 0x0600001D, FaceInfo_get_underlineThickness_m07A6016172DE8DC1514CA780EBB80C32FA209F28_AdjustorThunk },
	{ 0x0600001E, FaceInfo_set_underlineThickness_m86B440DB7CBDB6C588FBC03990B980A715726059_AdjustorThunk },
	{ 0x0600001F, FaceInfo_get_strikethroughOffset_m705C7A75FFA7E324582D6A1CC404ED4C8E8417EB_AdjustorThunk },
	{ 0x06000020, FaceInfo_set_strikethroughOffset_m9ACD0A24A8EC5FEB90596BA43E8E8D8FF7EA0623_AdjustorThunk },
	{ 0x06000021, FaceInfo_set_strikethroughThickness_mE26FAFBC6C984F88F68F7507CFE8AFB28E1932E7_AdjustorThunk },
	{ 0x06000022, FaceInfo_get_tabWidth_mFBE94B2FBBB301B0FC1011D49A96032A0EE1A588_AdjustorThunk },
	{ 0x06000023, FaceInfo_set_tabWidth_mE024C95E768A214E3C85781753658B437F4B6B54_AdjustorThunk },
	{ 0x06000024, GlyphRect_get_x_m004398D85360A389BCCD4F8B38347C0555F86166_AdjustorThunk },
	{ 0x06000025, GlyphRect_get_y_mBF2FC84CB7B201F30376B46390D37887B6AD6C20_AdjustorThunk },
	{ 0x06000026, GlyphRect_get_width_m8B9FBFA897082BA8E5F71222E1AAAB8D4A345A41_AdjustorThunk },
	{ 0x06000027, GlyphRect_get_height_m319E96AD96E2087C9C9F5A1DF883F06A4D04104F_AdjustorThunk },
	{ 0x06000029, GlyphRect__ctor_m278B410AE9B6DE62FF8C2445B8F3C6051B45ED61_AdjustorThunk },
	{ 0x0600002A, GlyphRect_GetHashCode_m6DC4515E8C489593A329B5EA66895BD8C25DF913_AdjustorThunk },
	{ 0x0600002B, GlyphRect_Equals_m7F1DB9A21E584BEF84C5F83E6DD290EF54D655C1_AdjustorThunk },
	{ 0x0600002C, GlyphRect_Equals_mB9F911262F09BC42CD2A461D8692D1C3ECAFCDCE_AdjustorThunk },
	{ 0x0600002E, GlyphMetrics_get_width_m4E2BCD2B54F121478C1D23C43FB6E8C0EF71C70F_AdjustorThunk },
	{ 0x0600002F, GlyphMetrics_get_height_m742B169DCF2892774ACEC4F25310CDC0C7F1D85F_AdjustorThunk },
	{ 0x06000030, GlyphMetrics_get_horizontalBearingX_m8474B6C9DB0D4D36516FCAC03B6ECBDAF49247E0_AdjustorThunk },
	{ 0x06000031, GlyphMetrics_get_horizontalBearingY_m2C5A73B899AFF5F5F594F447160ADB6E0523C16A_AdjustorThunk },
	{ 0x06000032, GlyphMetrics_get_horizontalAdvance_mB204F2676223D5BEF5FEFF8969B159B39F1A617A_AdjustorThunk },
	{ 0x06000033, GlyphMetrics__ctor_m6146EC37C12EF153771AEF9983A63B5EBAE0CEFB_AdjustorThunk },
	{ 0x06000034, GlyphMetrics_GetHashCode_m4F7985D656AFB70AE746F9A2513D39D3DFF9CD73_AdjustorThunk },
	{ 0x06000035, GlyphMetrics_Equals_mCCF68C73B7AE05D97A0D4459384DABD8BEB1097F_AdjustorThunk },
	{ 0x06000036, GlyphMetrics_Equals_m54C8D6CAD2653668377F5F7A9F78FD7C4F05E4A8_AdjustorThunk },
	{ 0x06000044, GlyphValueRecord_get_xPlacement_mAC5902DE9EE01D98DE9FBC6DB3A8BA7CDC525D14_AdjustorThunk },
	{ 0x06000045, GlyphValueRecord_get_yPlacement_m624E2DA69CC5A21117EE275359F66AF88DFC7D2D_AdjustorThunk },
	{ 0x06000046, GlyphValueRecord_get_xAdvance_m577D4D32490C42890C3F15230479D931B91BDED5_AdjustorThunk },
	{ 0x06000047, GlyphValueRecord_get_yAdvance_m9659978FFA9B58B6AA7DE30199E405CF642BA34F_AdjustorThunk },
	{ 0x06000048, GlyphValueRecord_GetHashCode_m5700595527E17C02B923199180E8983105563A71_AdjustorThunk },
	{ 0x06000049, GlyphValueRecord_Equals_mB12EE7C56E781B2DAFF2DEA1AFFFA1EC4DCBA943_AdjustorThunk },
	{ 0x0600004A, GlyphValueRecord_Equals_m716F55BA3DD7B7E97F3E35BE94A5922BE90FECF4_AdjustorThunk },
	{ 0x0600004B, GlyphAdjustmentRecord_get_glyphIndex_mCD420C739E19E446152534AFA80A6113C0DBCC55_AdjustorThunk },
	{ 0x0600004C, GlyphAdjustmentRecord_get_glyphValueRecord_mAC27920271FB7166EE305BACE1D595CAA57872EE_AdjustorThunk },
	{ 0x0600004D, GlyphPairAdjustmentRecord_get_firstAdjustmentRecord_m92BC7561227D482635EF8AB93B8F20808017FBF8_AdjustorThunk },
	{ 0x0600004E, GlyphPairAdjustmentRecord_set_firstAdjustmentRecord_m780CD1495A667852B44DA8EF210172484F917C77_AdjustorThunk },
	{ 0x0600004F, GlyphPairAdjustmentRecord_get_secondAdjustmentRecord_m488CCBCB6802727334E2135E65EBB027A0A01EAD_AdjustorThunk },
	{ 0x06000050, GlyphPairAdjustmentRecord_set_secondAdjustmentRecord_mE8AFF0F392DE4B0590C0F7F2AF3D2D85AD756EFE_AdjustorThunk },
	{ 0x06000051, GlyphPairAdjustmentRecord_get_featureLookupFlags_m3BBC32A004335C153CABFFA25F02164DEF20AE58_AdjustorThunk },
	{ 0x06000052, GlyphPairAdjustmentRecord_set_featureLookupFlags_m6F0E8C3CBE5A06B42E8EE4EC0B91028EBE731834_AdjustorThunk },
	{ 0x06000053, GlyphPairAdjustmentRecord__ctor_mA474AC63D0E4A5B8127FC38A7CC74DC1817BB264_AdjustorThunk },
};
static const int32_t s_InvokerIndices[107] = 
{
	2580,
	2580,
	3188,
	2562,
	3239,
	2606,
	3239,
	2606,
	3239,
	2606,
	3239,
	2606,
	3239,
	2606,
	3239,
	2606,
	3239,
	2606,
	3239,
	2606,
	3239,
	2606,
	3239,
	2606,
	3239,
	2606,
	3239,
	2606,
	3239,
	2606,
	3239,
	2606,
	2606,
	3239,
	2606,
	3188,
	3188,
	3188,
	3188,
	5047,
	442,
	3188,
	2180,
	2140,
	5090,
	3239,
	3239,
	3239,
	3239,
	3239,
	235,
	3188,
	2180,
	2138,
	3188,
	2562,
	3164,
	2539,
	3166,
	2541,
	3239,
	2606,
	3188,
	2562,
	3277,
	2538,
	189,
	3239,
	3239,
	3239,
	3239,
	3188,
	2180,
	2141,
	3188,
	3167,
	3162,
	2537,
	3162,
	2537,
	3188,
	2562,
	1132,
	5053,
	5053,
	4332,
	4332,
	5043,
	4775,
	4787,
	4094,
	4094,
	4094,
	4094,
	3390,
	3374,
	3394,
	3373,
	4861,
	4380,
	4329,
	4791,
	-1,
	-1,
	4980,
	5090,
	3996,
};
static const Il2CppTokenRangePair s_rgctxIndices[2] = 
{
	{ 0x06000067, { 0, 4 } },
	{ 0x06000068, { 4, 2 } },
};
extern const uint32_t g_rgctx_List_1_get_Count_m91EEA7B533805A3C56159421D1557C61A600D048;
extern const uint32_t g_rgctx_TU5BU5D_t6B348EA2A2E9F507249A804F0406C48CE5AF61AC;
extern const uint32_t g_rgctx_Array_Resize_TisT_t5E2B5401A9F6199E77E14C75B7B05D76053E7B46_m59E421069CAE9D2FDF386AC765D10677F26B4266;
extern const uint32_t g_rgctx_List_1_get_Item_mF80440C8247662810B490AEC506618351FAD7392;
extern const uint32_t g_rgctx_TU5BU5D_t428E22A88D0D615939340449A5B6EA7336405518;
extern const uint32_t g_rgctx_Array_Resize_TisT_t2540A0F3BDC8BDFDBA69AE7A4354F1ADA657DDCA_mE6051D65C7CEF6AFA380F0ED75C6D5A1F1D36652;
static const Il2CppRGCTXDefinition s_rgctxValues[6] = 
{
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_List_1_get_Count_m91EEA7B533805A3C56159421D1557C61A600D048 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_TU5BU5D_t6B348EA2A2E9F507249A804F0406C48CE5AF61AC },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_Array_Resize_TisT_t5E2B5401A9F6199E77E14C75B7B05D76053E7B46_m59E421069CAE9D2FDF386AC765D10677F26B4266 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_List_1_get_Item_mF80440C8247662810B490AEC506618351FAD7392 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_TU5BU5D_t428E22A88D0D615939340449A5B6EA7336405518 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_Array_Resize_TisT_t2540A0F3BDC8BDFDBA69AE7A4354F1ADA657DDCA_mE6051D65C7CEF6AFA380F0ED75C6D5A1F1D36652 },
};
extern const CustomAttributesCacheGenerator g_UnityEngine_TextCoreModule_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_UnityEngine_TextCoreModule_CodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_TextCoreModule_CodeGenModule = 
{
	"UnityEngine.TextCoreModule.dll",
	107,
	s_methodPointers,
	68,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	2,
	s_rgctxIndices,
	6,
	s_rgctxValues,
	NULL,
	g_UnityEngine_TextCoreModule_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
