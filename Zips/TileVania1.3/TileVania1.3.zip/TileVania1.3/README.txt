===========================================================================
[TileVania Ver 1.1]

- 빌드 종류 변경 (기존 MONO에서 IL2CPP로 변경)
	MONO로 빌드할 경우 Unity 유틸 없이 게임을 실행할 수 없음

	IL2CPP로 빌드할 경우 크립트 코드를 직접 실행하지 않고, C++ 코드를 이용하여 프로그램을 
	실행할 수 있는 exe 파일로 변환할 수 있습니다. 

	이렇게 변환된 exe 파일은 Unity 엔진이 설치되지 않은 다른 컴퓨터에서도 실행 가능합니다.

- Start Scene 과 Help Scene 추가
	1.0 버전에서는 시작 화면없이 바로 게임이 실행되는 과정을 좀 더 자연스럽게 개선

===========================================================================

[TileVania Ver 1.2]

- Start Scene 과 Help Scene을 불러올수 없는 오류 해결
	셋팅된 Index값에 문제가 생겨 시작 화면을 불러 올 수 없는 문제 해결

===========================================================================

[TileVania Ver 1.3]

- 게임 내 BGM 및 Sound Effect 다수 추가
	저작권 문제는 상업적 용도로 쓸일은 없음 혹시 문제가 된다면 삭제하겠습니다.

[BGM 음원 정보]

Main Menu - Mappy (NES) Music - Stage Theme
Stage 1 - Green Greens - Kirby Super Star Ultra
Stage 2 - DuckTales Music (NES) - The Moon Theme
Stage 3 - Action 52 - CheetahMen Theme
Stage 4 - Super Mario Bros 3 (NES) Music - Overworld Theme 1

===========================================================================