﻿#include "pch-cpp.hpp"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <limits>
#include <stdint.h>



// System.Collections.Generic.List`1<ClipperLib.IntPoint>
struct List_1_tC143170EE25943366B2DA9D8910EC3E385E53814;
// System.Collections.Generic.List`1<System.Object>
struct List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5;
// System.Collections.Generic.List`1<ClipperLib.PolyNode>
struct List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057;
// System.Char[]
struct CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34;
// ClipperLib.IntPoint[]
struct IntPointU5BU5D_t049A192BF5E5E7640BCAD7DBFAE22E5FCC7F992B;
// System.Object[]
struct ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE;
// ClipperLib.PolyNode[]
struct PolyNodeU5BU5D_t19E97C78421CD261C923A193165AED6D369E1A1F;
// ClipperLib.IntersectNode
struct IntersectNode_tBD6AF15E203C2BCB89E2B09ADDC50D703015BF42;
// ClipperLib.Join
struct Join_t96FD0BDEC6C87E82865E58394DDABC204A582FD1;
// ClipperLib.LocalMinima
struct LocalMinima_t133DF47DE1BF938EAC51FF3B5112D8EA304F0783;
// ClipperLib.Maxima
struct Maxima_tBB2FB92D810BDEE914A5FE9090933F4C11E6F02B;
// ClipperLib.MyIntersectNodeSort
struct MyIntersectNodeSort_tF4AD5DAAF781C2B842820DE7292D23B546BBA457;
// ClipperLib.OutPt
struct OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A;
// ClipperLib.OutRec
struct OutRec_t3CF7790550251AF0446D17A013E45A6CAD5AD04C;
// ClipperLib.PolyNode
struct PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646;
// ClipperLib.Scanbeam
struct Scanbeam_t28862171D2921326F35431731450AE2CE626ACC5;
// System.String
struct String_t;
// ClipperLib.TEdge
struct TEdge_tDCDB088C1F74371FFD51A6D61308864264805320;
// System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52;

IL2CPP_EXTERN_C RuntimeClass* Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* List_1_tC143170EE25943366B2DA9D8910EC3E385E53814_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_Add_mA1375F6BBA5B2B02B1CA1CC7F540882E15AACD8F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1__ctor_m87B27A7F8C4ED8B7F3DC4154BBD701B6D554FB3E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1__ctor_m8B2B7DE262926805C90879A7FE53893EBE03D1B4_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Count_m5C4BAEE6FDBDE5387FBB277BB8ABBA7620A6F56B_RuntimeMethod_var;


IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object


// System.Collections.Generic.List`1<ClipperLib.IntPoint>
struct List_1_tC143170EE25943366B2DA9D8910EC3E385E53814  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	IntPointU5BU5D_t049A192BF5E5E7640BCAD7DBFAE22E5FCC7F992B* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_tC143170EE25943366B2DA9D8910EC3E385E53814, ____items_1)); }
	inline IntPointU5BU5D_t049A192BF5E5E7640BCAD7DBFAE22E5FCC7F992B* get__items_1() const { return ____items_1; }
	inline IntPointU5BU5D_t049A192BF5E5E7640BCAD7DBFAE22E5FCC7F992B** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(IntPointU5BU5D_t049A192BF5E5E7640BCAD7DBFAE22E5FCC7F992B* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____items_1), (void*)value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_tC143170EE25943366B2DA9D8910EC3E385E53814, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_tC143170EE25943366B2DA9D8910EC3E385E53814, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_tC143170EE25943366B2DA9D8910EC3E385E53814, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_4), (void*)value);
	}
};

struct List_1_tC143170EE25943366B2DA9D8910EC3E385E53814_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	IntPointU5BU5D_t049A192BF5E5E7640BCAD7DBFAE22E5FCC7F992B* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_tC143170EE25943366B2DA9D8910EC3E385E53814_StaticFields, ____emptyArray_5)); }
	inline IntPointU5BU5D_t049A192BF5E5E7640BCAD7DBFAE22E5FCC7F992B* get__emptyArray_5() const { return ____emptyArray_5; }
	inline IntPointU5BU5D_t049A192BF5E5E7640BCAD7DBFAE22E5FCC7F992B** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(IntPointU5BU5D_t049A192BF5E5E7640BCAD7DBFAE22E5FCC7F992B* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____emptyArray_5), (void*)value);
	}
};


// System.Collections.Generic.List`1<System.Object>
struct List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5, ____items_1)); }
	inline ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* get__items_1() const { return ____items_1; }
	inline ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____items_1), (void*)value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_4), (void*)value);
	}
};

struct List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5_StaticFields, ____emptyArray_5)); }
	inline ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* get__emptyArray_5() const { return ____emptyArray_5; }
	inline ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____emptyArray_5), (void*)value);
	}
};


// System.Collections.Generic.List`1<ClipperLib.PolyNode>
struct List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	PolyNodeU5BU5D_t19E97C78421CD261C923A193165AED6D369E1A1F* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057, ____items_1)); }
	inline PolyNodeU5BU5D_t19E97C78421CD261C923A193165AED6D369E1A1F* get__items_1() const { return ____items_1; }
	inline PolyNodeU5BU5D_t19E97C78421CD261C923A193165AED6D369E1A1F** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(PolyNodeU5BU5D_t19E97C78421CD261C923A193165AED6D369E1A1F* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____items_1), (void*)value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_4), (void*)value);
	}
};

struct List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	PolyNodeU5BU5D_t19E97C78421CD261C923A193165AED6D369E1A1F* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057_StaticFields, ____emptyArray_5)); }
	inline PolyNodeU5BU5D_t19E97C78421CD261C923A193165AED6D369E1A1F* get__emptyArray_5() const { return ____emptyArray_5; }
	inline PolyNodeU5BU5D_t19E97C78421CD261C923A193165AED6D369E1A1F** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(PolyNodeU5BU5D_t19E97C78421CD261C923A193165AED6D369E1A1F* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____emptyArray_5), (void*)value);
	}
};

struct Il2CppArrayBounds;

// System.Array


// ClipperLib.LocalMinima
struct LocalMinima_t133DF47DE1BF938EAC51FF3B5112D8EA304F0783  : public RuntimeObject
{
public:
	// System.Int64 ClipperLib.LocalMinima::Y
	int64_t ___Y_0;
	// ClipperLib.TEdge ClipperLib.LocalMinima::LeftBound
	TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * ___LeftBound_1;
	// ClipperLib.TEdge ClipperLib.LocalMinima::RightBound
	TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * ___RightBound_2;
	// ClipperLib.LocalMinima ClipperLib.LocalMinima::Next
	LocalMinima_t133DF47DE1BF938EAC51FF3B5112D8EA304F0783 * ___Next_3;

public:
	inline static int32_t get_offset_of_Y_0() { return static_cast<int32_t>(offsetof(LocalMinima_t133DF47DE1BF938EAC51FF3B5112D8EA304F0783, ___Y_0)); }
	inline int64_t get_Y_0() const { return ___Y_0; }
	inline int64_t* get_address_of_Y_0() { return &___Y_0; }
	inline void set_Y_0(int64_t value)
	{
		___Y_0 = value;
	}

	inline static int32_t get_offset_of_LeftBound_1() { return static_cast<int32_t>(offsetof(LocalMinima_t133DF47DE1BF938EAC51FF3B5112D8EA304F0783, ___LeftBound_1)); }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * get_LeftBound_1() const { return ___LeftBound_1; }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 ** get_address_of_LeftBound_1() { return &___LeftBound_1; }
	inline void set_LeftBound_1(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * value)
	{
		___LeftBound_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___LeftBound_1), (void*)value);
	}

	inline static int32_t get_offset_of_RightBound_2() { return static_cast<int32_t>(offsetof(LocalMinima_t133DF47DE1BF938EAC51FF3B5112D8EA304F0783, ___RightBound_2)); }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * get_RightBound_2() const { return ___RightBound_2; }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 ** get_address_of_RightBound_2() { return &___RightBound_2; }
	inline void set_RightBound_2(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * value)
	{
		___RightBound_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___RightBound_2), (void*)value);
	}

	inline static int32_t get_offset_of_Next_3() { return static_cast<int32_t>(offsetof(LocalMinima_t133DF47DE1BF938EAC51FF3B5112D8EA304F0783, ___Next_3)); }
	inline LocalMinima_t133DF47DE1BF938EAC51FF3B5112D8EA304F0783 * get_Next_3() const { return ___Next_3; }
	inline LocalMinima_t133DF47DE1BF938EAC51FF3B5112D8EA304F0783 ** get_address_of_Next_3() { return &___Next_3; }
	inline void set_Next_3(LocalMinima_t133DF47DE1BF938EAC51FF3B5112D8EA304F0783 * value)
	{
		___Next_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Next_3), (void*)value);
	}
};


// ClipperLib.Maxima
struct Maxima_tBB2FB92D810BDEE914A5FE9090933F4C11E6F02B  : public RuntimeObject
{
public:
	// System.Int64 ClipperLib.Maxima::X
	int64_t ___X_0;
	// ClipperLib.Maxima ClipperLib.Maxima::Next
	Maxima_tBB2FB92D810BDEE914A5FE9090933F4C11E6F02B * ___Next_1;
	// ClipperLib.Maxima ClipperLib.Maxima::Prev
	Maxima_tBB2FB92D810BDEE914A5FE9090933F4C11E6F02B * ___Prev_2;

public:
	inline static int32_t get_offset_of_X_0() { return static_cast<int32_t>(offsetof(Maxima_tBB2FB92D810BDEE914A5FE9090933F4C11E6F02B, ___X_0)); }
	inline int64_t get_X_0() const { return ___X_0; }
	inline int64_t* get_address_of_X_0() { return &___X_0; }
	inline void set_X_0(int64_t value)
	{
		___X_0 = value;
	}

	inline static int32_t get_offset_of_Next_1() { return static_cast<int32_t>(offsetof(Maxima_tBB2FB92D810BDEE914A5FE9090933F4C11E6F02B, ___Next_1)); }
	inline Maxima_tBB2FB92D810BDEE914A5FE9090933F4C11E6F02B * get_Next_1() const { return ___Next_1; }
	inline Maxima_tBB2FB92D810BDEE914A5FE9090933F4C11E6F02B ** get_address_of_Next_1() { return &___Next_1; }
	inline void set_Next_1(Maxima_tBB2FB92D810BDEE914A5FE9090933F4C11E6F02B * value)
	{
		___Next_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Next_1), (void*)value);
	}

	inline static int32_t get_offset_of_Prev_2() { return static_cast<int32_t>(offsetof(Maxima_tBB2FB92D810BDEE914A5FE9090933F4C11E6F02B, ___Prev_2)); }
	inline Maxima_tBB2FB92D810BDEE914A5FE9090933F4C11E6F02B * get_Prev_2() const { return ___Prev_2; }
	inline Maxima_tBB2FB92D810BDEE914A5FE9090933F4C11E6F02B ** get_address_of_Prev_2() { return &___Prev_2; }
	inline void set_Prev_2(Maxima_tBB2FB92D810BDEE914A5FE9090933F4C11E6F02B * value)
	{
		___Prev_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Prev_2), (void*)value);
	}
};


// ClipperLib.MyIntersectNodeSort
struct MyIntersectNodeSort_tF4AD5DAAF781C2B842820DE7292D23B546BBA457  : public RuntimeObject
{
public:

public:
};


// ClipperLib.OutRec
struct OutRec_t3CF7790550251AF0446D17A013E45A6CAD5AD04C  : public RuntimeObject
{
public:
	// System.Int32 ClipperLib.OutRec::Idx
	int32_t ___Idx_0;
	// System.Boolean ClipperLib.OutRec::IsHole
	bool ___IsHole_1;
	// System.Boolean ClipperLib.OutRec::IsOpen
	bool ___IsOpen_2;
	// ClipperLib.OutRec ClipperLib.OutRec::FirstLeft
	OutRec_t3CF7790550251AF0446D17A013E45A6CAD5AD04C * ___FirstLeft_3;
	// ClipperLib.OutPt ClipperLib.OutRec::Pts
	OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A * ___Pts_4;
	// ClipperLib.OutPt ClipperLib.OutRec::BottomPt
	OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A * ___BottomPt_5;
	// ClipperLib.PolyNode ClipperLib.OutRec::PolyNode
	PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646 * ___PolyNode_6;

public:
	inline static int32_t get_offset_of_Idx_0() { return static_cast<int32_t>(offsetof(OutRec_t3CF7790550251AF0446D17A013E45A6CAD5AD04C, ___Idx_0)); }
	inline int32_t get_Idx_0() const { return ___Idx_0; }
	inline int32_t* get_address_of_Idx_0() { return &___Idx_0; }
	inline void set_Idx_0(int32_t value)
	{
		___Idx_0 = value;
	}

	inline static int32_t get_offset_of_IsHole_1() { return static_cast<int32_t>(offsetof(OutRec_t3CF7790550251AF0446D17A013E45A6CAD5AD04C, ___IsHole_1)); }
	inline bool get_IsHole_1() const { return ___IsHole_1; }
	inline bool* get_address_of_IsHole_1() { return &___IsHole_1; }
	inline void set_IsHole_1(bool value)
	{
		___IsHole_1 = value;
	}

	inline static int32_t get_offset_of_IsOpen_2() { return static_cast<int32_t>(offsetof(OutRec_t3CF7790550251AF0446D17A013E45A6CAD5AD04C, ___IsOpen_2)); }
	inline bool get_IsOpen_2() const { return ___IsOpen_2; }
	inline bool* get_address_of_IsOpen_2() { return &___IsOpen_2; }
	inline void set_IsOpen_2(bool value)
	{
		___IsOpen_2 = value;
	}

	inline static int32_t get_offset_of_FirstLeft_3() { return static_cast<int32_t>(offsetof(OutRec_t3CF7790550251AF0446D17A013E45A6CAD5AD04C, ___FirstLeft_3)); }
	inline OutRec_t3CF7790550251AF0446D17A013E45A6CAD5AD04C * get_FirstLeft_3() const { return ___FirstLeft_3; }
	inline OutRec_t3CF7790550251AF0446D17A013E45A6CAD5AD04C ** get_address_of_FirstLeft_3() { return &___FirstLeft_3; }
	inline void set_FirstLeft_3(OutRec_t3CF7790550251AF0446D17A013E45A6CAD5AD04C * value)
	{
		___FirstLeft_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FirstLeft_3), (void*)value);
	}

	inline static int32_t get_offset_of_Pts_4() { return static_cast<int32_t>(offsetof(OutRec_t3CF7790550251AF0446D17A013E45A6CAD5AD04C, ___Pts_4)); }
	inline OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A * get_Pts_4() const { return ___Pts_4; }
	inline OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A ** get_address_of_Pts_4() { return &___Pts_4; }
	inline void set_Pts_4(OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A * value)
	{
		___Pts_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Pts_4), (void*)value);
	}

	inline static int32_t get_offset_of_BottomPt_5() { return static_cast<int32_t>(offsetof(OutRec_t3CF7790550251AF0446D17A013E45A6CAD5AD04C, ___BottomPt_5)); }
	inline OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A * get_BottomPt_5() const { return ___BottomPt_5; }
	inline OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A ** get_address_of_BottomPt_5() { return &___BottomPt_5; }
	inline void set_BottomPt_5(OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A * value)
	{
		___BottomPt_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___BottomPt_5), (void*)value);
	}

	inline static int32_t get_offset_of_PolyNode_6() { return static_cast<int32_t>(offsetof(OutRec_t3CF7790550251AF0446D17A013E45A6CAD5AD04C, ___PolyNode_6)); }
	inline PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646 * get_PolyNode_6() const { return ___PolyNode_6; }
	inline PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646 ** get_address_of_PolyNode_6() { return &___PolyNode_6; }
	inline void set_PolyNode_6(PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646 * value)
	{
		___PolyNode_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PolyNode_6), (void*)value);
	}
};


// ClipperLib.Scanbeam
struct Scanbeam_t28862171D2921326F35431731450AE2CE626ACC5  : public RuntimeObject
{
public:
	// System.Int64 ClipperLib.Scanbeam::Y
	int64_t ___Y_0;
	// ClipperLib.Scanbeam ClipperLib.Scanbeam::Next
	Scanbeam_t28862171D2921326F35431731450AE2CE626ACC5 * ___Next_1;

public:
	inline static int32_t get_offset_of_Y_0() { return static_cast<int32_t>(offsetof(Scanbeam_t28862171D2921326F35431731450AE2CE626ACC5, ___Y_0)); }
	inline int64_t get_Y_0() const { return ___Y_0; }
	inline int64_t* get_address_of_Y_0() { return &___Y_0; }
	inline void set_Y_0(int64_t value)
	{
		___Y_0 = value;
	}

	inline static int32_t get_offset_of_Next_1() { return static_cast<int32_t>(offsetof(Scanbeam_t28862171D2921326F35431731450AE2CE626ACC5, ___Next_1)); }
	inline Scanbeam_t28862171D2921326F35431731450AE2CE626ACC5 * get_Next_1() const { return ___Next_1; }
	inline Scanbeam_t28862171D2921326F35431731450AE2CE626ACC5 ** get_address_of_Next_1() { return &___Next_1; }
	inline void set_Next_1(Scanbeam_t28862171D2921326F35431731450AE2CE626ACC5 * value)
	{
		___Next_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Next_1), (void*)value);
	}
};


// System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52  : public RuntimeObject
{
public:

public:
};

// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52_marshaled_com
{
};

// System.Boolean
struct Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37, ___m_value_0)); }
	inline bool get_m_value_0() const { return ___m_value_0; }
	inline bool* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(bool value)
	{
		___m_value_0 = value;
	}
};

struct Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields
{
public:
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;

public:
	inline static int32_t get_offset_of_TrueString_5() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields, ___TrueString_5)); }
	inline String_t* get_TrueString_5() const { return ___TrueString_5; }
	inline String_t** get_address_of_TrueString_5() { return &___TrueString_5; }
	inline void set_TrueString_5(String_t* value)
	{
		___TrueString_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TrueString_5), (void*)value);
	}

	inline static int32_t get_offset_of_FalseString_6() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields, ___FalseString_6)); }
	inline String_t* get_FalseString_6() const { return ___FalseString_6; }
	inline String_t** get_address_of_FalseString_6() { return &___FalseString_6; }
	inline void set_FalseString_6(String_t* value)
	{
		___FalseString_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FalseString_6), (void*)value);
	}
};


// System.Double
struct Double_t42821932CB52DE2057E685D0E1AF3DE5033D2181 
{
public:
	// System.Double System.Double::m_value
	double ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Double_t42821932CB52DE2057E685D0E1AF3DE5033D2181, ___m_value_0)); }
	inline double get_m_value_0() const { return ___m_value_0; }
	inline double* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(double value)
	{
		___m_value_0 = value;
	}
};

struct Double_t42821932CB52DE2057E685D0E1AF3DE5033D2181_StaticFields
{
public:
	// System.Double System.Double::NegativeZero
	double ___NegativeZero_7;

public:
	inline static int32_t get_offset_of_NegativeZero_7() { return static_cast<int32_t>(offsetof(Double_t42821932CB52DE2057E685D0E1AF3DE5033D2181_StaticFields, ___NegativeZero_7)); }
	inline double get_NegativeZero_7() const { return ___NegativeZero_7; }
	inline double* get_address_of_NegativeZero_7() { return &___NegativeZero_7; }
	inline void set_NegativeZero_7(double value)
	{
		___NegativeZero_7 = value;
	}
};


// ClipperLib.DoublePoint
struct DoublePoint_t3A8833DEE90FAA325145090762A28622351F3C60 
{
public:
	// System.Double ClipperLib.DoublePoint::X
	double ___X_0;
	// System.Double ClipperLib.DoublePoint::Y
	double ___Y_1;

public:
	inline static int32_t get_offset_of_X_0() { return static_cast<int32_t>(offsetof(DoublePoint_t3A8833DEE90FAA325145090762A28622351F3C60, ___X_0)); }
	inline double get_X_0() const { return ___X_0; }
	inline double* get_address_of_X_0() { return &___X_0; }
	inline void set_X_0(double value)
	{
		___X_0 = value;
	}

	inline static int32_t get_offset_of_Y_1() { return static_cast<int32_t>(offsetof(DoublePoint_t3A8833DEE90FAA325145090762A28622351F3C60, ___Y_1)); }
	inline double get_Y_1() const { return ___Y_1; }
	inline double* get_address_of_Y_1() { return &___Y_1; }
	inline void set_Y_1(double value)
	{
		___Y_1 = value;
	}
};


// System.Enum
struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA  : public ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52
{
public:

public:
};

struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t23B90B40F60E677A8025267341651C94AE079CDA_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumSeperatorCharArray_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_marshaled_com
{
};

// ClipperLib.Int128
struct Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911 
{
public:
	// System.Int64 ClipperLib.Int128::hi
	int64_t ___hi_0;
	// System.UInt64 ClipperLib.Int128::lo
	uint64_t ___lo_1;

public:
	inline static int32_t get_offset_of_hi_0() { return static_cast<int32_t>(offsetof(Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911, ___hi_0)); }
	inline int64_t get_hi_0() const { return ___hi_0; }
	inline int64_t* get_address_of_hi_0() { return &___hi_0; }
	inline void set_hi_0(int64_t value)
	{
		___hi_0 = value;
	}

	inline static int32_t get_offset_of_lo_1() { return static_cast<int32_t>(offsetof(Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911, ___lo_1)); }
	inline uint64_t get_lo_1() const { return ___lo_1; }
	inline uint64_t* get_address_of_lo_1() { return &___lo_1; }
	inline void set_lo_1(uint64_t value)
	{
		___lo_1 = value;
	}
};


// System.Int32
struct Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046, ___m_value_0)); }
	inline int32_t get_m_value_0() const { return ___m_value_0; }
	inline int32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int32_t value)
	{
		___m_value_0 = value;
	}
};


// System.Int64
struct Int64_t378EE0D608BD3107E77238E85F30D2BBD46981F3 
{
public:
	// System.Int64 System.Int64::m_value
	int64_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int64_t378EE0D608BD3107E77238E85F30D2BBD46981F3, ___m_value_0)); }
	inline int64_t get_m_value_0() const { return ___m_value_0; }
	inline int64_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int64_t value)
	{
		___m_value_0 = value;
	}
};


// ClipperLib.IntPoint
struct IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 
{
public:
	// System.Int64 ClipperLib.IntPoint::X
	int64_t ___X_0;
	// System.Int64 ClipperLib.IntPoint::Y
	int64_t ___Y_1;

public:
	inline static int32_t get_offset_of_X_0() { return static_cast<int32_t>(offsetof(IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06, ___X_0)); }
	inline int64_t get_X_0() const { return ___X_0; }
	inline int64_t* get_address_of_X_0() { return &___X_0; }
	inline void set_X_0(int64_t value)
	{
		___X_0 = value;
	}

	inline static int32_t get_offset_of_Y_1() { return static_cast<int32_t>(offsetof(IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06, ___Y_1)); }
	inline int64_t get_Y_1() const { return ___Y_1; }
	inline int64_t* get_address_of_Y_1() { return &___Y_1; }
	inline void set_Y_1(int64_t value)
	{
		___Y_1 = value;
	}
};


// ClipperLib.IntRect
struct IntRect_t48A2D89AA21EEA6A83F1B7DD777EEEE4AC7F9A4E 
{
public:
	// System.Int64 ClipperLib.IntRect::left
	int64_t ___left_0;
	// System.Int64 ClipperLib.IntRect::top
	int64_t ___top_1;
	// System.Int64 ClipperLib.IntRect::right
	int64_t ___right_2;
	// System.Int64 ClipperLib.IntRect::bottom
	int64_t ___bottom_3;

public:
	inline static int32_t get_offset_of_left_0() { return static_cast<int32_t>(offsetof(IntRect_t48A2D89AA21EEA6A83F1B7DD777EEEE4AC7F9A4E, ___left_0)); }
	inline int64_t get_left_0() const { return ___left_0; }
	inline int64_t* get_address_of_left_0() { return &___left_0; }
	inline void set_left_0(int64_t value)
	{
		___left_0 = value;
	}

	inline static int32_t get_offset_of_top_1() { return static_cast<int32_t>(offsetof(IntRect_t48A2D89AA21EEA6A83F1B7DD777EEEE4AC7F9A4E, ___top_1)); }
	inline int64_t get_top_1() const { return ___top_1; }
	inline int64_t* get_address_of_top_1() { return &___top_1; }
	inline void set_top_1(int64_t value)
	{
		___top_1 = value;
	}

	inline static int32_t get_offset_of_right_2() { return static_cast<int32_t>(offsetof(IntRect_t48A2D89AA21EEA6A83F1B7DD777EEEE4AC7F9A4E, ___right_2)); }
	inline int64_t get_right_2() const { return ___right_2; }
	inline int64_t* get_address_of_right_2() { return &___right_2; }
	inline void set_right_2(int64_t value)
	{
		___right_2 = value;
	}

	inline static int32_t get_offset_of_bottom_3() { return static_cast<int32_t>(offsetof(IntRect_t48A2D89AA21EEA6A83F1B7DD777EEEE4AC7F9A4E, ___bottom_3)); }
	inline int64_t get_bottom_3() const { return ___bottom_3; }
	inline int64_t* get_address_of_bottom_3() { return &___bottom_3; }
	inline void set_bottom_3(int64_t value)
	{
		___bottom_3 = value;
	}
};


// System.UInt64
struct UInt64_tEC57511B3E3CA2DBA1BEBD434C6983E31C943281 
{
public:
	// System.UInt64 System.UInt64::m_value
	uint64_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(UInt64_tEC57511B3E3CA2DBA1BEBD434C6983E31C943281, ___m_value_0)); }
	inline uint64_t get_m_value_0() const { return ___m_value_0; }
	inline uint64_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint64_t value)
	{
		___m_value_0 = value;
	}
};


// System.Void
struct Void_t700C6383A2A510C2CF4DD86DABD5CA9FF70ADAC5 
{
public:
	union
	{
		struct
		{
		};
		uint8_t Void_t700C6383A2A510C2CF4DD86DABD5CA9FF70ADAC5__padding[1];
	};

public:
};


// ClipperLib.Direction
struct Direction_t6E85A6C37E52F987F2367EE29189FDEF72AC38AC 
{
public:
	// System.Int32 ClipperLib.Direction::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Direction_t6E85A6C37E52F987F2367EE29189FDEF72AC38AC, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// ClipperLib.EdgeSide
struct EdgeSide_tCED8FDAB282B3D8F841843DE0D48BC3E1D725121 
{
public:
	// System.Int32 ClipperLib.EdgeSide::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(EdgeSide_tCED8FDAB282B3D8F841843DE0D48BC3E1D725121, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// ClipperLib.EndType
struct EndType_t5B34E674C6F99C668DA42F108399B91786748C3C 
{
public:
	// System.Int32 ClipperLib.EndType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(EndType_t5B34E674C6F99C668DA42F108399B91786748C3C, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// ClipperLib.IntersectNode
struct IntersectNode_tBD6AF15E203C2BCB89E2B09ADDC50D703015BF42  : public RuntimeObject
{
public:
	// ClipperLib.TEdge ClipperLib.IntersectNode::Edge1
	TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * ___Edge1_0;
	// ClipperLib.TEdge ClipperLib.IntersectNode::Edge2
	TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * ___Edge2_1;
	// ClipperLib.IntPoint ClipperLib.IntersectNode::Pt
	IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  ___Pt_2;

public:
	inline static int32_t get_offset_of_Edge1_0() { return static_cast<int32_t>(offsetof(IntersectNode_tBD6AF15E203C2BCB89E2B09ADDC50D703015BF42, ___Edge1_0)); }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * get_Edge1_0() const { return ___Edge1_0; }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 ** get_address_of_Edge1_0() { return &___Edge1_0; }
	inline void set_Edge1_0(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * value)
	{
		___Edge1_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Edge1_0), (void*)value);
	}

	inline static int32_t get_offset_of_Edge2_1() { return static_cast<int32_t>(offsetof(IntersectNode_tBD6AF15E203C2BCB89E2B09ADDC50D703015BF42, ___Edge2_1)); }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * get_Edge2_1() const { return ___Edge2_1; }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 ** get_address_of_Edge2_1() { return &___Edge2_1; }
	inline void set_Edge2_1(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * value)
	{
		___Edge2_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Edge2_1), (void*)value);
	}

	inline static int32_t get_offset_of_Pt_2() { return static_cast<int32_t>(offsetof(IntersectNode_tBD6AF15E203C2BCB89E2B09ADDC50D703015BF42, ___Pt_2)); }
	inline IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  get_Pt_2() const { return ___Pt_2; }
	inline IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * get_address_of_Pt_2() { return &___Pt_2; }
	inline void set_Pt_2(IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  value)
	{
		___Pt_2 = value;
	}
};


// ClipperLib.Join
struct Join_t96FD0BDEC6C87E82865E58394DDABC204A582FD1  : public RuntimeObject
{
public:
	// ClipperLib.OutPt ClipperLib.Join::OutPt1
	OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A * ___OutPt1_0;
	// ClipperLib.OutPt ClipperLib.Join::OutPt2
	OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A * ___OutPt2_1;
	// ClipperLib.IntPoint ClipperLib.Join::OffPt
	IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  ___OffPt_2;

public:
	inline static int32_t get_offset_of_OutPt1_0() { return static_cast<int32_t>(offsetof(Join_t96FD0BDEC6C87E82865E58394DDABC204A582FD1, ___OutPt1_0)); }
	inline OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A * get_OutPt1_0() const { return ___OutPt1_0; }
	inline OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A ** get_address_of_OutPt1_0() { return &___OutPt1_0; }
	inline void set_OutPt1_0(OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A * value)
	{
		___OutPt1_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___OutPt1_0), (void*)value);
	}

	inline static int32_t get_offset_of_OutPt2_1() { return static_cast<int32_t>(offsetof(Join_t96FD0BDEC6C87E82865E58394DDABC204A582FD1, ___OutPt2_1)); }
	inline OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A * get_OutPt2_1() const { return ___OutPt2_1; }
	inline OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A ** get_address_of_OutPt2_1() { return &___OutPt2_1; }
	inline void set_OutPt2_1(OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A * value)
	{
		___OutPt2_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___OutPt2_1), (void*)value);
	}

	inline static int32_t get_offset_of_OffPt_2() { return static_cast<int32_t>(offsetof(Join_t96FD0BDEC6C87E82865E58394DDABC204A582FD1, ___OffPt_2)); }
	inline IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  get_OffPt_2() const { return ___OffPt_2; }
	inline IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * get_address_of_OffPt_2() { return &___OffPt_2; }
	inline void set_OffPt_2(IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  value)
	{
		___OffPt_2 = value;
	}
};


// ClipperLib.JoinType
struct JoinType_t4F462E9D68727CA4415D42BC03AB783F2871D66B 
{
public:
	// System.Int32 ClipperLib.JoinType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(JoinType_t4F462E9D68727CA4415D42BC03AB783F2871D66B, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// ClipperLib.OutPt
struct OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A  : public RuntimeObject
{
public:
	// System.Int32 ClipperLib.OutPt::Idx
	int32_t ___Idx_0;
	// ClipperLib.IntPoint ClipperLib.OutPt::Pt
	IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  ___Pt_1;
	// ClipperLib.OutPt ClipperLib.OutPt::Next
	OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A * ___Next_2;
	// ClipperLib.OutPt ClipperLib.OutPt::Prev
	OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A * ___Prev_3;

public:
	inline static int32_t get_offset_of_Idx_0() { return static_cast<int32_t>(offsetof(OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A, ___Idx_0)); }
	inline int32_t get_Idx_0() const { return ___Idx_0; }
	inline int32_t* get_address_of_Idx_0() { return &___Idx_0; }
	inline void set_Idx_0(int32_t value)
	{
		___Idx_0 = value;
	}

	inline static int32_t get_offset_of_Pt_1() { return static_cast<int32_t>(offsetof(OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A, ___Pt_1)); }
	inline IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  get_Pt_1() const { return ___Pt_1; }
	inline IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * get_address_of_Pt_1() { return &___Pt_1; }
	inline void set_Pt_1(IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  value)
	{
		___Pt_1 = value;
	}

	inline static int32_t get_offset_of_Next_2() { return static_cast<int32_t>(offsetof(OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A, ___Next_2)); }
	inline OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A * get_Next_2() const { return ___Next_2; }
	inline OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A ** get_address_of_Next_2() { return &___Next_2; }
	inline void set_Next_2(OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A * value)
	{
		___Next_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Next_2), (void*)value);
	}

	inline static int32_t get_offset_of_Prev_3() { return static_cast<int32_t>(offsetof(OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A, ___Prev_3)); }
	inline OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A * get_Prev_3() const { return ___Prev_3; }
	inline OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A ** get_address_of_Prev_3() { return &___Prev_3; }
	inline void set_Prev_3(OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A * value)
	{
		___Prev_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Prev_3), (void*)value);
	}
};


// ClipperLib.PolyFillType
struct PolyFillType_t8D935A0C03491A522AE3393024B57F42C2062965 
{
public:
	// System.Int32 ClipperLib.PolyFillType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(PolyFillType_t8D935A0C03491A522AE3393024B57F42C2062965, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// ClipperLib.PolyType
struct PolyType_t8692A4ACAE1CA7C8423B3871FE98D392B1063015 
{
public:
	// System.Int32 ClipperLib.PolyType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(PolyType_t8692A4ACAE1CA7C8423B3871FE98D392B1063015, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// ClipperLib.PolyNode
struct PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646  : public RuntimeObject
{
public:
	// ClipperLib.PolyNode ClipperLib.PolyNode::m_Parent
	PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646 * ___m_Parent_0;
	// System.Collections.Generic.List`1<ClipperLib.IntPoint> ClipperLib.PolyNode::m_polygon
	List_1_tC143170EE25943366B2DA9D8910EC3E385E53814 * ___m_polygon_1;
	// System.Int32 ClipperLib.PolyNode::m_Index
	int32_t ___m_Index_2;
	// ClipperLib.JoinType ClipperLib.PolyNode::m_jointype
	int32_t ___m_jointype_3;
	// ClipperLib.EndType ClipperLib.PolyNode::m_endtype
	int32_t ___m_endtype_4;
	// System.Collections.Generic.List`1<ClipperLib.PolyNode> ClipperLib.PolyNode::m_Childs
	List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057 * ___m_Childs_5;
	// System.Boolean ClipperLib.PolyNode::<IsOpen>k__BackingField
	bool ___U3CIsOpenU3Ek__BackingField_6;

public:
	inline static int32_t get_offset_of_m_Parent_0() { return static_cast<int32_t>(offsetof(PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646, ___m_Parent_0)); }
	inline PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646 * get_m_Parent_0() const { return ___m_Parent_0; }
	inline PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646 ** get_address_of_m_Parent_0() { return &___m_Parent_0; }
	inline void set_m_Parent_0(PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646 * value)
	{
		___m_Parent_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Parent_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_polygon_1() { return static_cast<int32_t>(offsetof(PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646, ___m_polygon_1)); }
	inline List_1_tC143170EE25943366B2DA9D8910EC3E385E53814 * get_m_polygon_1() const { return ___m_polygon_1; }
	inline List_1_tC143170EE25943366B2DA9D8910EC3E385E53814 ** get_address_of_m_polygon_1() { return &___m_polygon_1; }
	inline void set_m_polygon_1(List_1_tC143170EE25943366B2DA9D8910EC3E385E53814 * value)
	{
		___m_polygon_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_polygon_1), (void*)value);
	}

	inline static int32_t get_offset_of_m_Index_2() { return static_cast<int32_t>(offsetof(PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646, ___m_Index_2)); }
	inline int32_t get_m_Index_2() const { return ___m_Index_2; }
	inline int32_t* get_address_of_m_Index_2() { return &___m_Index_2; }
	inline void set_m_Index_2(int32_t value)
	{
		___m_Index_2 = value;
	}

	inline static int32_t get_offset_of_m_jointype_3() { return static_cast<int32_t>(offsetof(PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646, ___m_jointype_3)); }
	inline int32_t get_m_jointype_3() const { return ___m_jointype_3; }
	inline int32_t* get_address_of_m_jointype_3() { return &___m_jointype_3; }
	inline void set_m_jointype_3(int32_t value)
	{
		___m_jointype_3 = value;
	}

	inline static int32_t get_offset_of_m_endtype_4() { return static_cast<int32_t>(offsetof(PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646, ___m_endtype_4)); }
	inline int32_t get_m_endtype_4() const { return ___m_endtype_4; }
	inline int32_t* get_address_of_m_endtype_4() { return &___m_endtype_4; }
	inline void set_m_endtype_4(int32_t value)
	{
		___m_endtype_4 = value;
	}

	inline static int32_t get_offset_of_m_Childs_5() { return static_cast<int32_t>(offsetof(PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646, ___m_Childs_5)); }
	inline List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057 * get_m_Childs_5() const { return ___m_Childs_5; }
	inline List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057 ** get_address_of_m_Childs_5() { return &___m_Childs_5; }
	inline void set_m_Childs_5(List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057 * value)
	{
		___m_Childs_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Childs_5), (void*)value);
	}

	inline static int32_t get_offset_of_U3CIsOpenU3Ek__BackingField_6() { return static_cast<int32_t>(offsetof(PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646, ___U3CIsOpenU3Ek__BackingField_6)); }
	inline bool get_U3CIsOpenU3Ek__BackingField_6() const { return ___U3CIsOpenU3Ek__BackingField_6; }
	inline bool* get_address_of_U3CIsOpenU3Ek__BackingField_6() { return &___U3CIsOpenU3Ek__BackingField_6; }
	inline void set_U3CIsOpenU3Ek__BackingField_6(bool value)
	{
		___U3CIsOpenU3Ek__BackingField_6 = value;
	}
};


// ClipperLib.TEdge
struct TEdge_tDCDB088C1F74371FFD51A6D61308864264805320  : public RuntimeObject
{
public:
	// ClipperLib.IntPoint ClipperLib.TEdge::Bot
	IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  ___Bot_0;
	// ClipperLib.IntPoint ClipperLib.TEdge::Curr
	IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  ___Curr_1;
	// ClipperLib.IntPoint ClipperLib.TEdge::Top
	IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  ___Top_2;
	// ClipperLib.IntPoint ClipperLib.TEdge::Delta
	IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  ___Delta_3;
	// System.Double ClipperLib.TEdge::Dx
	double ___Dx_4;
	// ClipperLib.PolyType ClipperLib.TEdge::PolyTyp
	int32_t ___PolyTyp_5;
	// ClipperLib.EdgeSide ClipperLib.TEdge::Side
	int32_t ___Side_6;
	// System.Int32 ClipperLib.TEdge::WindDelta
	int32_t ___WindDelta_7;
	// System.Int32 ClipperLib.TEdge::WindCnt
	int32_t ___WindCnt_8;
	// System.Int32 ClipperLib.TEdge::WindCnt2
	int32_t ___WindCnt2_9;
	// System.Int32 ClipperLib.TEdge::OutIdx
	int32_t ___OutIdx_10;
	// ClipperLib.TEdge ClipperLib.TEdge::Next
	TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * ___Next_11;
	// ClipperLib.TEdge ClipperLib.TEdge::Prev
	TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * ___Prev_12;
	// ClipperLib.TEdge ClipperLib.TEdge::NextInLML
	TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * ___NextInLML_13;
	// ClipperLib.TEdge ClipperLib.TEdge::NextInAEL
	TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * ___NextInAEL_14;
	// ClipperLib.TEdge ClipperLib.TEdge::PrevInAEL
	TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * ___PrevInAEL_15;
	// ClipperLib.TEdge ClipperLib.TEdge::NextInSEL
	TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * ___NextInSEL_16;
	// ClipperLib.TEdge ClipperLib.TEdge::PrevInSEL
	TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * ___PrevInSEL_17;

public:
	inline static int32_t get_offset_of_Bot_0() { return static_cast<int32_t>(offsetof(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320, ___Bot_0)); }
	inline IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  get_Bot_0() const { return ___Bot_0; }
	inline IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * get_address_of_Bot_0() { return &___Bot_0; }
	inline void set_Bot_0(IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  value)
	{
		___Bot_0 = value;
	}

	inline static int32_t get_offset_of_Curr_1() { return static_cast<int32_t>(offsetof(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320, ___Curr_1)); }
	inline IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  get_Curr_1() const { return ___Curr_1; }
	inline IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * get_address_of_Curr_1() { return &___Curr_1; }
	inline void set_Curr_1(IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  value)
	{
		___Curr_1 = value;
	}

	inline static int32_t get_offset_of_Top_2() { return static_cast<int32_t>(offsetof(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320, ___Top_2)); }
	inline IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  get_Top_2() const { return ___Top_2; }
	inline IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * get_address_of_Top_2() { return &___Top_2; }
	inline void set_Top_2(IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  value)
	{
		___Top_2 = value;
	}

	inline static int32_t get_offset_of_Delta_3() { return static_cast<int32_t>(offsetof(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320, ___Delta_3)); }
	inline IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  get_Delta_3() const { return ___Delta_3; }
	inline IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * get_address_of_Delta_3() { return &___Delta_3; }
	inline void set_Delta_3(IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  value)
	{
		___Delta_3 = value;
	}

	inline static int32_t get_offset_of_Dx_4() { return static_cast<int32_t>(offsetof(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320, ___Dx_4)); }
	inline double get_Dx_4() const { return ___Dx_4; }
	inline double* get_address_of_Dx_4() { return &___Dx_4; }
	inline void set_Dx_4(double value)
	{
		___Dx_4 = value;
	}

	inline static int32_t get_offset_of_PolyTyp_5() { return static_cast<int32_t>(offsetof(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320, ___PolyTyp_5)); }
	inline int32_t get_PolyTyp_5() const { return ___PolyTyp_5; }
	inline int32_t* get_address_of_PolyTyp_5() { return &___PolyTyp_5; }
	inline void set_PolyTyp_5(int32_t value)
	{
		___PolyTyp_5 = value;
	}

	inline static int32_t get_offset_of_Side_6() { return static_cast<int32_t>(offsetof(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320, ___Side_6)); }
	inline int32_t get_Side_6() const { return ___Side_6; }
	inline int32_t* get_address_of_Side_6() { return &___Side_6; }
	inline void set_Side_6(int32_t value)
	{
		___Side_6 = value;
	}

	inline static int32_t get_offset_of_WindDelta_7() { return static_cast<int32_t>(offsetof(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320, ___WindDelta_7)); }
	inline int32_t get_WindDelta_7() const { return ___WindDelta_7; }
	inline int32_t* get_address_of_WindDelta_7() { return &___WindDelta_7; }
	inline void set_WindDelta_7(int32_t value)
	{
		___WindDelta_7 = value;
	}

	inline static int32_t get_offset_of_WindCnt_8() { return static_cast<int32_t>(offsetof(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320, ___WindCnt_8)); }
	inline int32_t get_WindCnt_8() const { return ___WindCnt_8; }
	inline int32_t* get_address_of_WindCnt_8() { return &___WindCnt_8; }
	inline void set_WindCnt_8(int32_t value)
	{
		___WindCnt_8 = value;
	}

	inline static int32_t get_offset_of_WindCnt2_9() { return static_cast<int32_t>(offsetof(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320, ___WindCnt2_9)); }
	inline int32_t get_WindCnt2_9() const { return ___WindCnt2_9; }
	inline int32_t* get_address_of_WindCnt2_9() { return &___WindCnt2_9; }
	inline void set_WindCnt2_9(int32_t value)
	{
		___WindCnt2_9 = value;
	}

	inline static int32_t get_offset_of_OutIdx_10() { return static_cast<int32_t>(offsetof(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320, ___OutIdx_10)); }
	inline int32_t get_OutIdx_10() const { return ___OutIdx_10; }
	inline int32_t* get_address_of_OutIdx_10() { return &___OutIdx_10; }
	inline void set_OutIdx_10(int32_t value)
	{
		___OutIdx_10 = value;
	}

	inline static int32_t get_offset_of_Next_11() { return static_cast<int32_t>(offsetof(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320, ___Next_11)); }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * get_Next_11() const { return ___Next_11; }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 ** get_address_of_Next_11() { return &___Next_11; }
	inline void set_Next_11(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * value)
	{
		___Next_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Next_11), (void*)value);
	}

	inline static int32_t get_offset_of_Prev_12() { return static_cast<int32_t>(offsetof(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320, ___Prev_12)); }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * get_Prev_12() const { return ___Prev_12; }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 ** get_address_of_Prev_12() { return &___Prev_12; }
	inline void set_Prev_12(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * value)
	{
		___Prev_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Prev_12), (void*)value);
	}

	inline static int32_t get_offset_of_NextInLML_13() { return static_cast<int32_t>(offsetof(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320, ___NextInLML_13)); }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * get_NextInLML_13() const { return ___NextInLML_13; }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 ** get_address_of_NextInLML_13() { return &___NextInLML_13; }
	inline void set_NextInLML_13(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * value)
	{
		___NextInLML_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___NextInLML_13), (void*)value);
	}

	inline static int32_t get_offset_of_NextInAEL_14() { return static_cast<int32_t>(offsetof(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320, ___NextInAEL_14)); }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * get_NextInAEL_14() const { return ___NextInAEL_14; }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 ** get_address_of_NextInAEL_14() { return &___NextInAEL_14; }
	inline void set_NextInAEL_14(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * value)
	{
		___NextInAEL_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___NextInAEL_14), (void*)value);
	}

	inline static int32_t get_offset_of_PrevInAEL_15() { return static_cast<int32_t>(offsetof(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320, ___PrevInAEL_15)); }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * get_PrevInAEL_15() const { return ___PrevInAEL_15; }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 ** get_address_of_PrevInAEL_15() { return &___PrevInAEL_15; }
	inline void set_PrevInAEL_15(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * value)
	{
		___PrevInAEL_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PrevInAEL_15), (void*)value);
	}

	inline static int32_t get_offset_of_NextInSEL_16() { return static_cast<int32_t>(offsetof(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320, ___NextInSEL_16)); }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * get_NextInSEL_16() const { return ___NextInSEL_16; }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 ** get_address_of_NextInSEL_16() { return &___NextInSEL_16; }
	inline void set_NextInSEL_16(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * value)
	{
		___NextInSEL_16 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___NextInSEL_16), (void*)value);
	}

	inline static int32_t get_offset_of_PrevInSEL_17() { return static_cast<int32_t>(offsetof(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320, ___PrevInSEL_17)); }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * get_PrevInSEL_17() const { return ___PrevInSEL_17; }
	inline TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 ** get_address_of_PrevInSEL_17() { return &___PrevInSEL_17; }
	inline void set_PrevInSEL_17(TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * value)
	{
		___PrevInSEL_17 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PrevInSEL_17), (void*)value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif


// System.Int32 System.Collections.Generic.List`1<System.Object>::get_Count()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t List_1_get_Count_m5D847939ABB9A78203B062CAFFE975792174D00F_gshared_inline (List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<System.Object>::Add(!0)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1_Add_mF15250BF947CA27BE9A23C08BAC6DB6F180B0EDD_gshared (List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * __this, RuntimeObject * ___item0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<ClipperLib.IntPoint>::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1__ctor_m8B2B7DE262926805C90879A7FE53893EBE03D1B4_gshared (List_1_tC143170EE25943366B2DA9D8910EC3E385E53814 * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<System.Object>::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1__ctor_m0F0E00088CF56FEACC9E32D8B7D91B93D91DAA3B_gshared (List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * __this, const RuntimeMethod* method);

// System.Void ClipperLib.DoublePoint::.ctor(System.Double,System.Double)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DoublePoint__ctor_m482D3610D420BFF5DF1EDDFF3C319B5C6DCAC859 (DoublePoint_t3A8833DEE90FAA325145090762A28622351F3C60 * __this, double ___x0, double ___y1, const RuntimeMethod* method);
// System.Void ClipperLib.DoublePoint::.ctor(ClipperLib.DoublePoint)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DoublePoint__ctor_m4DA444C77667ADC06334633460B05370B9CA56F8 (DoublePoint_t3A8833DEE90FAA325145090762A28622351F3C60 * __this, DoublePoint_t3A8833DEE90FAA325145090762A28622351F3C60  ___dp0, const RuntimeMethod* method);
// System.Void ClipperLib.Int128::.ctor(System.Int64,System.UInt64)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Int128__ctor_mBD38F0ABE017AD0F5D66EBD836D159C574B6022A (Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911 * __this, int64_t ____hi0, uint64_t ____lo1, const RuntimeMethod* method);
// System.Boolean ClipperLib.Int128::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Int128_Equals_m0A40B15C0D2A14127DD34F898693C436CE774707 (Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911 * __this, RuntimeObject * ___obj0, const RuntimeMethod* method);
// System.Int32 System.Int64::GetHashCode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Int64_GetHashCode_mF049F7E1956554FB36DA6671F55BE2CAA4937CC5 (int64_t* __this, const RuntimeMethod* method);
// System.Int32 System.UInt64::GetHashCode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t UInt64_GetHashCode_mCDF662897A3F02CED11A9F9E66C5BF4E28C02B33 (uint64_t* __this, const RuntimeMethod* method);
// System.Int32 ClipperLib.Int128::GetHashCode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Int128_GetHashCode_mCDE2E0DF254213BFC67F8F62111371F3ED9C51D5 (Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911 * __this, const RuntimeMethod* method);
// ClipperLib.Int128 ClipperLib.Int128::op_UnaryNegation(ClipperLib.Int128)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  Int128_op_UnaryNegation_m9C1172745BB39CE6143AF4367360CC554BDEABDE (Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  ___val0, const RuntimeMethod* method);
// System.Void ClipperLib.IntPoint::.ctor(System.Int64,System.Int64)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void IntPoint__ctor_m43FA6E2F1EA903A84E87C40570C002A50492EFE5 (IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * __this, int64_t ___X0, int64_t ___Y1, const RuntimeMethod* method);
// System.Void ClipperLib.IntPoint::.ctor(System.Double,System.Double)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void IntPoint__ctor_mE5B43837884272FB8DD8256B001F6287A2E6BB63 (IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * __this, double ___x0, double ___y1, const RuntimeMethod* method);
// System.Void ClipperLib.IntPoint::.ctor(ClipperLib.IntPoint)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void IntPoint__ctor_mD769F4D36E8F16A4ADF2D231FB6C0752D5120BC5 (IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * __this, IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  ___pt0, const RuntimeMethod* method);
// System.Boolean ClipperLib.IntPoint::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool IntPoint_Equals_m5E53D2A6836041B94FB0D049B1D33671D9EE4556 (IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * __this, RuntimeObject * ___obj0, const RuntimeMethod* method);
// System.Int32 System.ValueType::GetHashCode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t ValueType_GetHashCode_mE3FC55FA0D7099043434B9F8F0A4B30C8B63BFF4 (RuntimeObject * __this, const RuntimeMethod* method);
// System.Int32 ClipperLib.IntPoint::GetHashCode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t IntPoint_GetHashCode_m9322836AAE0BA19EE99F299DF98AA6A3B9126EBE (IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * __this, const RuntimeMethod* method);
// System.Void ClipperLib.IntRect::.ctor(System.Int64,System.Int64,System.Int64,System.Int64)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void IntRect__ctor_m93AB3555BB9C12827745826CA4D60984F7752D52 (IntRect_t48A2D89AA21EEA6A83F1B7DD777EEEE4AC7F9A4E * __this, int64_t ___l0, int64_t ___t1, int64_t ___r2, int64_t ___b3, const RuntimeMethod* method);
// System.Void System.Object::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405 (RuntimeObject * __this, const RuntimeMethod* method);
// System.Int32 System.Collections.Generic.List`1<ClipperLib.PolyNode>::get_Count()
inline int32_t List_1_get_Count_m5C4BAEE6FDBDE5387FBB277BB8ABBA7620A6F56B_inline (List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057 * __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057 *, const RuntimeMethod*))List_1_get_Count_m5D847939ABB9A78203B062CAFFE975792174D00F_gshared_inline)(__this, method);
}
// System.Void System.Collections.Generic.List`1<ClipperLib.PolyNode>::Add(!0)
inline void List_1_Add_mA1375F6BBA5B2B02B1CA1CC7F540882E15AACD8F (List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057 * __this, PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646 * ___item0, const RuntimeMethod* method)
{
	((  void (*) (List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057 *, PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646 *, const RuntimeMethod*))List_1_Add_mF15250BF947CA27BE9A23C08BAC6DB6F180B0EDD_gshared)(__this, ___item0, method);
}
// System.Void System.Collections.Generic.List`1<ClipperLib.IntPoint>::.ctor()
inline void List_1__ctor_m8B2B7DE262926805C90879A7FE53893EBE03D1B4 (List_1_tC143170EE25943366B2DA9D8910EC3E385E53814 * __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_tC143170EE25943366B2DA9D8910EC3E385E53814 *, const RuntimeMethod*))List_1__ctor_m8B2B7DE262926805C90879A7FE53893EBE03D1B4_gshared)(__this, method);
}
// System.Void System.Collections.Generic.List`1<ClipperLib.PolyNode>::.ctor()
inline void List_1__ctor_m87B27A7F8C4ED8B7F3DC4154BBD701B6D554FB3E (List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057 * __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057 *, const RuntimeMethod*))List_1__ctor_m0F0E00088CF56FEACC9E32D8B7D91B93D91DAA3B_gshared)(__this, method);
}
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ClipperLib.DoublePoint::.ctor(System.Double,System.Double)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DoublePoint__ctor_m482D3610D420BFF5DF1EDDFF3C319B5C6DCAC859 (DoublePoint_t3A8833DEE90FAA325145090762A28622351F3C60 * __this, double ___x0, double ___y1, const RuntimeMethod* method)
{
	{
		double L_0 = ___x0;
		__this->set_X_0(L_0);
		double L_1 = ___y1;
		__this->set_Y_1(L_1);
		return;
	}
}
IL2CPP_EXTERN_C  void DoublePoint__ctor_m482D3610D420BFF5DF1EDDFF3C319B5C6DCAC859_AdjustorThunk (RuntimeObject * __this, double ___x0, double ___y1, const RuntimeMethod* method)
{
	DoublePoint_t3A8833DEE90FAA325145090762A28622351F3C60 * _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<DoublePoint_t3A8833DEE90FAA325145090762A28622351F3C60 *>(__this + _offset);
	DoublePoint__ctor_m482D3610D420BFF5DF1EDDFF3C319B5C6DCAC859(_thisAdjusted, ___x0, ___y1, method);
}
// System.Void ClipperLib.DoublePoint::.ctor(ClipperLib.DoublePoint)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DoublePoint__ctor_m4DA444C77667ADC06334633460B05370B9CA56F8 (DoublePoint_t3A8833DEE90FAA325145090762A28622351F3C60 * __this, DoublePoint_t3A8833DEE90FAA325145090762A28622351F3C60  ___dp0, const RuntimeMethod* method)
{
	{
		DoublePoint_t3A8833DEE90FAA325145090762A28622351F3C60  L_0 = ___dp0;
		double L_1 = L_0.get_X_0();
		__this->set_X_0(L_1);
		DoublePoint_t3A8833DEE90FAA325145090762A28622351F3C60  L_2 = ___dp0;
		double L_3 = L_2.get_Y_1();
		__this->set_Y_1(L_3);
		return;
	}
}
IL2CPP_EXTERN_C  void DoublePoint__ctor_m4DA444C77667ADC06334633460B05370B9CA56F8_AdjustorThunk (RuntimeObject * __this, DoublePoint_t3A8833DEE90FAA325145090762A28622351F3C60  ___dp0, const RuntimeMethod* method)
{
	DoublePoint_t3A8833DEE90FAA325145090762A28622351F3C60 * _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<DoublePoint_t3A8833DEE90FAA325145090762A28622351F3C60 *>(__this + _offset);
	DoublePoint__ctor_m4DA444C77667ADC06334633460B05370B9CA56F8(_thisAdjusted, ___dp0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ClipperLib.Int128::.ctor(System.Int64,System.UInt64)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Int128__ctor_mBD38F0ABE017AD0F5D66EBD836D159C574B6022A (Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911 * __this, int64_t ____hi0, uint64_t ____lo1, const RuntimeMethod* method)
{
	{
		uint64_t L_0 = ____lo1;
		__this->set_lo_1(L_0);
		int64_t L_1 = ____hi0;
		__this->set_hi_0(L_1);
		return;
	}
}
IL2CPP_EXTERN_C  void Int128__ctor_mBD38F0ABE017AD0F5D66EBD836D159C574B6022A_AdjustorThunk (RuntimeObject * __this, int64_t ____hi0, uint64_t ____lo1, const RuntimeMethod* method)
{
	Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911 * _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911 *>(__this + _offset);
	Int128__ctor_mBD38F0ABE017AD0F5D66EBD836D159C574B6022A(_thisAdjusted, ____hi0, ____lo1, method);
}
// System.Boolean ClipperLib.Int128::op_Equality(ClipperLib.Int128,ClipperLib.Int128)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Int128_op_Equality_m52655612FA9E991C51354AB62B31D3D04225871A (Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  ___val10, Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  ___val21, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  L_0 = ___val10;
		Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  L_1 = L_0;
		RuntimeObject * L_2 = Box(Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911_il2cpp_TypeInfo_var, &L_1);
		Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  L_3 = ___val21;
		Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  L_4 = L_3;
		RuntimeObject * L_5 = Box(Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911_il2cpp_TypeInfo_var, &L_4);
		if ((!(((RuntimeObject*)(RuntimeObject *)L_2) == ((RuntimeObject*)(RuntimeObject *)L_5))))
		{
			goto IL_0010;
		}
	}
	{
		return (bool)1;
	}

IL_0010:
	{
	}
	{
		goto IL_0022;
	}

IL_0020:
	{
		return (bool)0;
	}

IL_0022:
	{
		Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  L_8 = ___val10;
		int64_t L_9 = L_8.get_hi_0();
		Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  L_10 = ___val21;
		int64_t L_11 = L_10.get_hi_0();
		if ((!(((uint64_t)L_9) == ((uint64_t)L_11))))
		{
			goto IL_003f;
		}
	}
	{
		Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  L_12 = ___val10;
		uint64_t L_13 = L_12.get_lo_1();
		Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  L_14 = ___val21;
		uint64_t L_15 = L_14.get_lo_1();
		return (bool)((((int64_t)L_13) == ((int64_t)L_15))? 1 : 0);
	}

IL_003f:
	{
		return (bool)0;
	}
}
// System.Boolean ClipperLib.Int128::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Int128_Equals_m0A40B15C0D2A14127DD34F898693C436CE774707 (Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911 * __this, RuntimeObject * ___obj0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		RuntimeObject * L_0 = ___obj0;
		if (!L_0)
		{
			goto IL_000b;
		}
	}
	{
		RuntimeObject * L_1 = ___obj0;
		if (((RuntimeObject *)IsInstSealed((RuntimeObject*)L_1, Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911_il2cpp_TypeInfo_var)))
		{
			goto IL_000d;
		}
	}

IL_000b:
	{
		return (bool)0;
	}

IL_000d:
	{
		RuntimeObject * L_2 = ___obj0;
		V_0 = ((*(Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911 *)((Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911 *)UnBox(L_2, Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911_il2cpp_TypeInfo_var))));
		Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  L_3 = V_0;
		int64_t L_4 = L_3.get_hi_0();
		int64_t L_5 = __this->get_hi_0();
		if ((!(((uint64_t)L_4) == ((uint64_t)L_5))))
		{
			goto IL_0031;
		}
	}
	{
		Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  L_6 = V_0;
		uint64_t L_7 = L_6.get_lo_1();
		uint64_t L_8 = __this->get_lo_1();
		return (bool)((((int64_t)L_7) == ((int64_t)L_8))? 1 : 0);
	}

IL_0031:
	{
		return (bool)0;
	}
}
IL2CPP_EXTERN_C  bool Int128_Equals_m0A40B15C0D2A14127DD34F898693C436CE774707_AdjustorThunk (RuntimeObject * __this, RuntimeObject * ___obj0, const RuntimeMethod* method)
{
	Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911 * _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911 *>(__this + _offset);
	bool _returnValue;
	_returnValue = Int128_Equals_m0A40B15C0D2A14127DD34F898693C436CE774707(_thisAdjusted, ___obj0, method);
	return _returnValue;
}
// System.Int32 ClipperLib.Int128::GetHashCode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Int128_GetHashCode_mCDE2E0DF254213BFC67F8F62111371F3ED9C51D5 (Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911 * __this, const RuntimeMethod* method)
{
	{
		int64_t* L_0 = __this->get_address_of_hi_0();
		int32_t L_1;
		L_1 = Int64_GetHashCode_mF049F7E1956554FB36DA6671F55BE2CAA4937CC5((int64_t*)L_0, /*hidden argument*/NULL);
		uint64_t* L_2 = __this->get_address_of_lo_1();
		int32_t L_3;
		L_3 = UInt64_GetHashCode_mCDF662897A3F02CED11A9F9E66C5BF4E28C02B33((uint64_t*)L_2, /*hidden argument*/NULL);
		return ((int32_t)((int32_t)L_1^(int32_t)L_3));
	}
}
IL2CPP_EXTERN_C  int32_t Int128_GetHashCode_mCDE2E0DF254213BFC67F8F62111371F3ED9C51D5_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911 * _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911 *>(__this + _offset);
	int32_t _returnValue;
	_returnValue = Int128_GetHashCode_mCDE2E0DF254213BFC67F8F62111371F3ED9C51D5(_thisAdjusted, method);
	return _returnValue;
}
// ClipperLib.Int128 ClipperLib.Int128::op_UnaryNegation(ClipperLib.Int128)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  Int128_op_UnaryNegation_m9C1172745BB39CE6143AF4367360CC554BDEABDE (Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  ___val0, const RuntimeMethod* method)
{
	{
		Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  L_0 = ___val0;
		uint64_t L_1 = L_0.get_lo_1();
		if (L_1)
		{
			goto IL_0017;
		}
	}
	{
		Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  L_2 = ___val0;
		int64_t L_3 = L_2.get_hi_0();
		Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  L_4;
		memset((&L_4), 0, sizeof(L_4));
		Int128__ctor_mBD38F0ABE017AD0F5D66EBD836D159C574B6022A((&L_4), ((-L_3)), ((int64_t)((int64_t)0)), /*hidden argument*/NULL);
		return L_4;
	}

IL_0017:
	{
		Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  L_5 = ___val0;
		int64_t L_6 = L_5.get_hi_0();
		Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  L_7 = ___val0;
		uint64_t L_8 = L_7.get_lo_1();
		Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  L_9;
		memset((&L_9), 0, sizeof(L_9));
		Int128__ctor_mBD38F0ABE017AD0F5D66EBD836D159C574B6022A((&L_9), ((~L_6)), ((int64_t)il2cpp_codegen_add((int64_t)((~L_8)), (int64_t)((int64_t)((int64_t)1)))), /*hidden argument*/NULL);
		return L_9;
	}
}
// ClipperLib.Int128 ClipperLib.Int128::Int128Mul(System.Int64,System.Int64)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  Int128_Int128Mul_mB2BC203BD87908553B71AF17B183A5E53780DCC7 (int64_t ___lhs0, int64_t ___rhs1, const RuntimeMethod* method)
{
	uint64_t V_0 = 0;
	uint64_t V_1 = 0;
	uint64_t V_2 = 0;
	uint64_t V_3 = 0;
	uint64_t V_4 = 0;
	uint64_t V_5 = 0;
	uint64_t V_6 = 0;
	int64_t V_7 = 0;
	Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  V_8;
	memset((&V_8), 0, sizeof(V_8));
	int32_t G_B2_0 = 0;
	int32_t G_B1_0 = 0;
	int32_t G_B4_0 = 0;
	int32_t G_B3_0 = 0;
	int32_t G_B6_0 = 0;
	int32_t G_B5_0 = 0;
	{
		int64_t L_0 = ___lhs0;
		int64_t L_1 = ___rhs1;
		int64_t L_2 = ___lhs0;
		G_B1_0 = ((((int32_t)((((int32_t)((((int64_t)L_0) < ((int64_t)((int64_t)((int64_t)0))))? 1 : 0)) == ((int32_t)((((int64_t)L_1) < ((int64_t)((int64_t)((int64_t)0))))? 1 : 0)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		if ((((int64_t)L_2) >= ((int64_t)((int64_t)((int64_t)0)))))
		{
			G_B2_0 = ((((int32_t)((((int32_t)((((int64_t)L_0) < ((int64_t)((int64_t)((int64_t)0))))? 1 : 0)) == ((int32_t)((((int64_t)L_1) < ((int64_t)((int64_t)((int64_t)0))))? 1 : 0)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
			goto IL_0018;
		}
	}
	{
		int64_t L_3 = ___lhs0;
		___lhs0 = ((-L_3));
		G_B2_0 = G_B1_0;
	}

IL_0018:
	{
		int64_t L_4 = ___rhs1;
		G_B3_0 = G_B2_0;
		if ((((int64_t)L_4) >= ((int64_t)((int64_t)((int64_t)0)))))
		{
			G_B4_0 = G_B2_0;
			goto IL_0021;
		}
	}
	{
		int64_t L_5 = ___rhs1;
		___rhs1 = ((-L_5));
		G_B4_0 = G_B3_0;
	}

IL_0021:
	{
		int64_t L_6 = ___lhs0;
		int64_t L_7 = ___lhs0;
		V_0 = ((int64_t)((int64_t)L_7&(int64_t)((int64_t)((uint64_t)((uint32_t)((uint32_t)(-1)))))));
		int64_t L_8 = ___rhs1;
		V_1 = ((int64_t)((uint64_t)L_8>>((int32_t)32)));
		int64_t L_9 = ___rhs1;
		V_2 = ((int64_t)((int64_t)L_9&(int64_t)((int64_t)((uint64_t)((uint32_t)((uint32_t)(-1)))))));
		int64_t L_10 = ((int64_t)((uint64_t)L_6>>((int32_t)32)));
		uint64_t L_11 = V_1;
		V_3 = ((int64_t)il2cpp_codegen_multiply((int64_t)L_10, (int64_t)L_11));
		uint64_t L_12 = V_0;
		uint64_t L_13 = V_2;
		V_4 = ((int64_t)il2cpp_codegen_multiply((int64_t)L_12, (int64_t)L_13));
		uint64_t L_14 = V_2;
		uint64_t L_15 = V_0;
		uint64_t L_16 = V_1;
		V_5 = ((int64_t)il2cpp_codegen_add((int64_t)((int64_t)il2cpp_codegen_multiply((int64_t)L_10, (int64_t)L_14)), (int64_t)((int64_t)il2cpp_codegen_multiply((int64_t)L_15, (int64_t)L_16))));
		uint64_t L_17 = V_3;
		uint64_t L_18 = V_5;
		V_7 = ((int64_t)il2cpp_codegen_add((int64_t)L_17, (int64_t)((int64_t)((uint64_t)L_18>>((int32_t)32)))));
		uint64_t L_19 = V_5;
		uint64_t L_20 = V_4;
		V_6 = ((int64_t)il2cpp_codegen_add((int64_t)((int64_t)((int64_t)L_19<<(int32_t)((int32_t)32))), (int64_t)L_20));
		uint64_t L_21 = V_6;
		uint64_t L_22 = V_4;
		G_B5_0 = G_B4_0;
		if ((!(((uint64_t)L_21) < ((uint64_t)L_22))))
		{
			G_B6_0 = G_B4_0;
			goto IL_0065;
		}
	}
	{
		int64_t L_23 = V_7;
		V_7 = ((int64_t)il2cpp_codegen_add((int64_t)L_23, (int64_t)((int64_t)((int64_t)1))));
		G_B6_0 = G_B5_0;
	}

IL_0065:
	{
		int64_t L_24 = V_7;
		uint64_t L_25 = V_6;
		Int128__ctor_mBD38F0ABE017AD0F5D66EBD836D159C574B6022A((Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911 *)(&V_8), L_24, L_25, /*hidden argument*/NULL);
		if (G_B6_0)
		{
			goto IL_0075;
		}
	}
	{
		Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  L_26 = V_8;
		return L_26;
	}

IL_0075:
	{
		Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  L_27 = V_8;
		Int128_tB21572CCAAC64512BC830E6C0FB28A39E73E9911  L_28;
		L_28 = Int128_op_UnaryNegation_m9C1172745BB39CE6143AF4367360CC554BDEABDE(L_27, /*hidden argument*/NULL);
		return L_28;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ClipperLib.IntPoint::.ctor(System.Int64,System.Int64)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void IntPoint__ctor_m43FA6E2F1EA903A84E87C40570C002A50492EFE5 (IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * __this, int64_t ___X0, int64_t ___Y1, const RuntimeMethod* method)
{
	{
		int64_t L_0 = ___X0;
		__this->set_X_0(L_0);
		int64_t L_1 = ___Y1;
		__this->set_Y_1(L_1);
		return;
	}
}
IL2CPP_EXTERN_C  void IntPoint__ctor_m43FA6E2F1EA903A84E87C40570C002A50492EFE5_AdjustorThunk (RuntimeObject * __this, int64_t ___X0, int64_t ___Y1, const RuntimeMethod* method)
{
	IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 *>(__this + _offset);
	IntPoint__ctor_m43FA6E2F1EA903A84E87C40570C002A50492EFE5(_thisAdjusted, ___X0, ___Y1, method);
}
// System.Void ClipperLib.IntPoint::.ctor(System.Double,System.Double)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void IntPoint__ctor_mE5B43837884272FB8DD8256B001F6287A2E6BB63 (IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * __this, double ___x0, double ___y1, const RuntimeMethod* method)
{
	{
		double L_0 = ___x0;
		__this->set_X_0(((int64_t)((int64_t)L_0)));
		double L_1 = ___y1;
		__this->set_Y_1(((int64_t)((int64_t)L_1)));
		return;
	}
}
IL2CPP_EXTERN_C  void IntPoint__ctor_mE5B43837884272FB8DD8256B001F6287A2E6BB63_AdjustorThunk (RuntimeObject * __this, double ___x0, double ___y1, const RuntimeMethod* method)
{
	IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 *>(__this + _offset);
	IntPoint__ctor_mE5B43837884272FB8DD8256B001F6287A2E6BB63(_thisAdjusted, ___x0, ___y1, method);
}
// System.Void ClipperLib.IntPoint::.ctor(ClipperLib.IntPoint)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void IntPoint__ctor_mD769F4D36E8F16A4ADF2D231FB6C0752D5120BC5 (IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * __this, IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  ___pt0, const RuntimeMethod* method)
{
	{
		IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  L_0 = ___pt0;
		int64_t L_1 = L_0.get_X_0();
		__this->set_X_0(L_1);
		IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  L_2 = ___pt0;
		int64_t L_3 = L_2.get_Y_1();
		__this->set_Y_1(L_3);
		return;
	}
}
IL2CPP_EXTERN_C  void IntPoint__ctor_mD769F4D36E8F16A4ADF2D231FB6C0752D5120BC5_AdjustorThunk (RuntimeObject * __this, IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  ___pt0, const RuntimeMethod* method)
{
	IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 *>(__this + _offset);
	IntPoint__ctor_mD769F4D36E8F16A4ADF2D231FB6C0752D5120BC5(_thisAdjusted, ___pt0, method);
}
// System.Boolean ClipperLib.IntPoint::op_Equality(ClipperLib.IntPoint,ClipperLib.IntPoint)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool IntPoint_op_Equality_mD84506C88E1012BF31DEED68FF333EC538D7C1A9 (IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  ___a0, IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  ___b1, const RuntimeMethod* method)
{
	{
		IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  L_0 = ___a0;
		int64_t L_1 = L_0.get_X_0();
		IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  L_2 = ___b1;
		int64_t L_3 = L_2.get_X_0();
		if ((!(((uint64_t)L_1) == ((uint64_t)L_3))))
		{
			goto IL_001d;
		}
	}
	{
		IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  L_4 = ___a0;
		int64_t L_5 = L_4.get_Y_1();
		IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  L_6 = ___b1;
		int64_t L_7 = L_6.get_Y_1();
		return (bool)((((int64_t)L_5) == ((int64_t)L_7))? 1 : 0);
	}

IL_001d:
	{
		return (bool)0;
	}
}
// System.Boolean ClipperLib.IntPoint::op_Inequality(ClipperLib.IntPoint,ClipperLib.IntPoint)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool IntPoint_op_Inequality_m1B138D93FF1636CB7CB1DCAA62B8DFDEADDEA2B7 (IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  ___a0, IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  ___b1, const RuntimeMethod* method)
{
	{
		IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  L_0 = ___a0;
		int64_t L_1 = L_0.get_X_0();
		IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  L_2 = ___b1;
		int64_t L_3 = L_2.get_X_0();
		if ((!(((uint64_t)L_1) == ((uint64_t)L_3))))
		{
			goto IL_0020;
		}
	}
	{
		IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  L_4 = ___a0;
		int64_t L_5 = L_4.get_Y_1();
		IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  L_6 = ___b1;
		int64_t L_7 = L_6.get_Y_1();
		return (bool)((((int32_t)((((int64_t)L_5) == ((int64_t)L_7))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}

IL_0020:
	{
		return (bool)1;
	}
}
// System.Boolean ClipperLib.IntPoint::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool IntPoint_Equals_m5E53D2A6836041B94FB0D049B1D33671D9EE4556 (IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * __this, RuntimeObject * ___obj0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		RuntimeObject * L_0 = ___obj0;
		if (L_0)
		{
			goto IL_0005;
		}
	}
	{
		return (bool)0;
	}

IL_0005:
	{
		RuntimeObject * L_1 = ___obj0;
		if (!((RuntimeObject *)IsInstSealed((RuntimeObject*)L_1, IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06_il2cpp_TypeInfo_var)))
		{
			goto IL_0033;
		}
	}
	{
		RuntimeObject * L_2 = ___obj0;
		V_0 = ((*(IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 *)((IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 *)UnBox(L_2, IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06_il2cpp_TypeInfo_var))));
		int64_t L_3 = __this->get_X_0();
		IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  L_4 = V_0;
		int64_t L_5 = L_4.get_X_0();
		if ((!(((uint64_t)L_3) == ((uint64_t)L_5))))
		{
			goto IL_0031;
		}
	}
	{
		int64_t L_6 = __this->get_Y_1();
		IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  L_7 = V_0;
		int64_t L_8 = L_7.get_Y_1();
		return (bool)((((int64_t)L_6) == ((int64_t)L_8))? 1 : 0);
	}

IL_0031:
	{
		return (bool)0;
	}

IL_0033:
	{
		return (bool)0;
	}
}
IL2CPP_EXTERN_C  bool IntPoint_Equals_m5E53D2A6836041B94FB0D049B1D33671D9EE4556_AdjustorThunk (RuntimeObject * __this, RuntimeObject * ___obj0, const RuntimeMethod* method)
{
	IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 *>(__this + _offset);
	bool _returnValue;
	_returnValue = IntPoint_Equals_m5E53D2A6836041B94FB0D049B1D33671D9EE4556(_thisAdjusted, ___obj0, method);
	return _returnValue;
}
// System.Int32 ClipperLib.IntPoint::GetHashCode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t IntPoint_GetHashCode_m9322836AAE0BA19EE99F299DF98AA6A3B9126EBE (IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  L_0 = (*(IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 *)__this);
		IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06  L_1 = L_0;
		RuntimeObject * L_2 = Box(IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06_il2cpp_TypeInfo_var, &L_1);
		NullCheck((ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52 *)L_2);
		int32_t L_3;
		L_3 = ValueType_GetHashCode_mE3FC55FA0D7099043434B9F8F0A4B30C8B63BFF4((ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52 *)L_2, /*hidden argument*/NULL);
		return L_3;
	}
}
IL2CPP_EXTERN_C  int32_t IntPoint_GetHashCode_m9322836AAE0BA19EE99F299DF98AA6A3B9126EBE_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 *>(__this + _offset);
	int32_t _returnValue;
	_returnValue = IntPoint_GetHashCode_m9322836AAE0BA19EE99F299DF98AA6A3B9126EBE(_thisAdjusted, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ClipperLib.IntRect::.ctor(System.Int64,System.Int64,System.Int64,System.Int64)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void IntRect__ctor_m93AB3555BB9C12827745826CA4D60984F7752D52 (IntRect_t48A2D89AA21EEA6A83F1B7DD777EEEE4AC7F9A4E * __this, int64_t ___l0, int64_t ___t1, int64_t ___r2, int64_t ___b3, const RuntimeMethod* method)
{
	{
		int64_t L_0 = ___l0;
		__this->set_left_0(L_0);
		int64_t L_1 = ___t1;
		__this->set_top_1(L_1);
		int64_t L_2 = ___r2;
		__this->set_right_2(L_2);
		int64_t L_3 = ___b3;
		__this->set_bottom_3(L_3);
		return;
	}
}
IL2CPP_EXTERN_C  void IntRect__ctor_m93AB3555BB9C12827745826CA4D60984F7752D52_AdjustorThunk (RuntimeObject * __this, int64_t ___l0, int64_t ___t1, int64_t ___r2, int64_t ___b3, const RuntimeMethod* method)
{
	IntRect_t48A2D89AA21EEA6A83F1B7DD777EEEE4AC7F9A4E * _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<IntRect_t48A2D89AA21EEA6A83F1B7DD777EEEE4AC7F9A4E *>(__this + _offset);
	IntRect__ctor_m93AB3555BB9C12827745826CA4D60984F7752D52(_thisAdjusted, ___l0, ___t1, ___r2, ___b3, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ClipperLib.IntersectNode::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void IntersectNode__ctor_m4B2C47C8A8F3F85DF24BACD1E9CD037481557C78 (IntersectNode_tBD6AF15E203C2BCB89E2B09ADDC50D703015BF42 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ClipperLib.Join::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Join__ctor_mD170CA55E901088B64A774497379680EC36E6138 (Join_t96FD0BDEC6C87E82865E58394DDABC204A582FD1 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ClipperLib.LocalMinima::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void LocalMinima__ctor_m549BC1F11D26DC5CF0DBC7DF430FCC5DE90D01C2 (LocalMinima_t133DF47DE1BF938EAC51FF3B5112D8EA304F0783 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ClipperLib.Maxima::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Maxima__ctor_mC4904A4872B389B80D21193C1A820886A8297CF3 (Maxima_tBB2FB92D810BDEE914A5FE9090933F4C11E6F02B * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Int32 ClipperLib.MyIntersectNodeSort::Compare(ClipperLib.IntersectNode,ClipperLib.IntersectNode)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t MyIntersectNodeSort_Compare_m2F66B35EC741C1801BFA4A9EAB4853943A5CF861 (MyIntersectNodeSort_tF4AD5DAAF781C2B842820DE7292D23B546BBA457 * __this, IntersectNode_tBD6AF15E203C2BCB89E2B09ADDC50D703015BF42 * ___node10, IntersectNode_tBD6AF15E203C2BCB89E2B09ADDC50D703015BF42 * ___node21, const RuntimeMethod* method)
{
	int64_t V_0 = 0;
	{
		IntersectNode_tBD6AF15E203C2BCB89E2B09ADDC50D703015BF42 * L_0 = ___node21;
		NullCheck(L_0);
		IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * L_1 = L_0->get_address_of_Pt_2();
		int64_t L_2 = L_1->get_Y_1();
		IntersectNode_tBD6AF15E203C2BCB89E2B09ADDC50D703015BF42 * L_3 = ___node10;
		NullCheck(L_3);
		IntPoint_t4FCEFEFC3AA9AB4E769043D0F8CCB2E2D3D8ED06 * L_4 = L_3->get_address_of_Pt_2();
		int64_t L_5 = L_4->get_Y_1();
		V_0 = ((int64_t)il2cpp_codegen_subtract((int64_t)L_2, (int64_t)L_5));
		int64_t L_6 = V_0;
		if ((((int64_t)L_6) <= ((int64_t)((int64_t)((int64_t)0)))))
		{
			goto IL_001f;
		}
	}
	{
		return 1;
	}

IL_001f:
	{
		int64_t L_7 = V_0;
		if ((((int64_t)L_7) >= ((int64_t)((int64_t)((int64_t)0)))))
		{
			goto IL_0026;
		}
	}
	{
		return (-1);
	}

IL_0026:
	{
		return 0;
	}
}
// System.Void ClipperLib.MyIntersectNodeSort::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MyIntersectNodeSort__ctor_m053DA624977E961C096A62DF04074039471A02F7 (MyIntersectNodeSort_tF4AD5DAAF781C2B842820DE7292D23B546BBA457 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ClipperLib.OutPt::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void OutPt__ctor_m0536125B7761CCBDB06B5B61E1656587ADAA1AAC (OutPt_t7222069AC479B324A1CDC0D0A632350C3DE5249A * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ClipperLib.OutRec::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void OutRec__ctor_m4D0CE6C9A2F5377A22EFD6997297A39789DC66FF (OutRec_t3CF7790550251AF0446D17A013E45A6CAD5AD04C * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Int32 ClipperLib.PolyNode::get_ChildCount()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t PolyNode_get_ChildCount_mC2378D10B6B9D8CC805F4A123A9A5D69096806D1 (PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Count_m5C4BAEE6FDBDE5387FBB277BB8ABBA7620A6F56B_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057 * L_0 = __this->get_m_Childs_5();
		NullCheck(L_0);
		int32_t L_1;
		L_1 = List_1_get_Count_m5C4BAEE6FDBDE5387FBB277BB8ABBA7620A6F56B_inline(L_0, /*hidden argument*/List_1_get_Count_m5C4BAEE6FDBDE5387FBB277BB8ABBA7620A6F56B_RuntimeMethod_var);
		return L_1;
	}
}
// System.Void ClipperLib.PolyNode::AddChild(ClipperLib.PolyNode)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PolyNode_AddChild_m7DB863FAF3A3B77198AAAF508856DE1F696A1582 (PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646 * __this, PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646 * ___Child0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_Add_mA1375F6BBA5B2B02B1CA1CC7F540882E15AACD8F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Count_m5C4BAEE6FDBDE5387FBB277BB8ABBA7620A6F56B_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057 * L_0 = __this->get_m_Childs_5();
		NullCheck(L_0);
		int32_t L_1;
		L_1 = List_1_get_Count_m5C4BAEE6FDBDE5387FBB277BB8ABBA7620A6F56B_inline(L_0, /*hidden argument*/List_1_get_Count_m5C4BAEE6FDBDE5387FBB277BB8ABBA7620A6F56B_RuntimeMethod_var);
		V_0 = L_1;
		List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057 * L_2 = __this->get_m_Childs_5();
		PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646 * L_3 = ___Child0;
		NullCheck(L_2);
		List_1_Add_mA1375F6BBA5B2B02B1CA1CC7F540882E15AACD8F(L_2, L_3, /*hidden argument*/List_1_Add_mA1375F6BBA5B2B02B1CA1CC7F540882E15AACD8F_RuntimeMethod_var);
		PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646 * L_4 = ___Child0;
		NullCheck(L_4);
		L_4->set_m_Parent_0(__this);
		PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646 * L_5 = ___Child0;
		int32_t L_6 = V_0;
		NullCheck(L_5);
		L_5->set_m_Index_2(L_6);
		return;
	}
}
// System.Collections.Generic.List`1<ClipperLib.PolyNode> ClipperLib.PolyNode::get_Childs()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057 * PolyNode_get_Childs_m6323F4C10D5D9CD18B4D5A5629E8A9568A9A73B2 (PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646 * __this, const RuntimeMethod* method)
{
	{
		List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057 * L_0 = __this->get_m_Childs_5();
		return L_0;
	}
}
// System.Void ClipperLib.PolyNode::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PolyNode__ctor_m2C22F4592F3CD2C12553108F9D9E88DA916DEED6 (PolyNode_t0F17C43F7853AF74B566B04F6B129343E20E8646 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1__ctor_m87B27A7F8C4ED8B7F3DC4154BBD701B6D554FB3E_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1__ctor_m8B2B7DE262926805C90879A7FE53893EBE03D1B4_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_tC143170EE25943366B2DA9D8910EC3E385E53814_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		List_1_tC143170EE25943366B2DA9D8910EC3E385E53814 * L_0 = (List_1_tC143170EE25943366B2DA9D8910EC3E385E53814 *)il2cpp_codegen_object_new(List_1_tC143170EE25943366B2DA9D8910EC3E385E53814_il2cpp_TypeInfo_var);
		List_1__ctor_m8B2B7DE262926805C90879A7FE53893EBE03D1B4(L_0, /*hidden argument*/List_1__ctor_m8B2B7DE262926805C90879A7FE53893EBE03D1B4_RuntimeMethod_var);
		__this->set_m_polygon_1(L_0);
		List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057 * L_1 = (List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057 *)il2cpp_codegen_object_new(List_1_t31D0CEA52A12DD3DB7713590B49FC912CD4C7057_il2cpp_TypeInfo_var);
		List_1__ctor_m87B27A7F8C4ED8B7F3DC4154BBD701B6D554FB3E(L_1, /*hidden argument*/List_1__ctor_m87B27A7F8C4ED8B7F3DC4154BBD701B6D554FB3E_RuntimeMethod_var);
		__this->set_m_Childs_5(L_1);
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ClipperLib.Scanbeam::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Scanbeam__ctor_m633912064C71027DBF8ED66D368DE9C6F5935221 (Scanbeam_t28862171D2921326F35431731450AE2CE626ACC5 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ClipperLib.TEdge::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TEdge__ctor_mA1EB24F2FBD4D8C11F907EF1E6BC03CA7BF4C93E (TEdge_tDCDB088C1F74371FFD51A6D61308864264805320 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t List_1_get_Count_m5D847939ABB9A78203B062CAFFE975792174D00F_gshared_inline (List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = (int32_t)__this->get__size_2();
		return (int32_t)L_0;
	}
}
