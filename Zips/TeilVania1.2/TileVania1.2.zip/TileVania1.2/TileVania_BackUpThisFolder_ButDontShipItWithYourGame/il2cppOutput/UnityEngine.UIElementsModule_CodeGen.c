﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void Microsoft.CodeAnalysis.EmbeddedAttribute::.ctor()
extern void EmbeddedAttribute__ctor_m35649EE3B9671A19785552230116420086304147 (void);
// 0x00000002 System.Void System.Runtime.CompilerServices.IsReadOnlyAttribute::.ctor()
extern void IsReadOnlyAttribute__ctor_mA9A8E58FB04548467EBD2CB7907AE0B94A770E29 (void);
// 0x00000003 System.Int32 UnityEngine.UIElements.ClickDetector::get_s_DoubleClickTime()
extern void ClickDetector_get_s_DoubleClickTime_m0F9BBCF5920D2D67BB6E3098233016CC6A9607BC (void);
// 0x00000004 System.Void UnityEngine.UIElements.ClickDetector::StartClickTracking(UnityEngine.UIElements.EventBase)
extern void ClickDetector_StartClickTracking_m0BF023CF553A59753D881A89127E2CDF17A32930 (void);
// 0x00000005 System.Void UnityEngine.UIElements.ClickDetector::SendClickEvent(UnityEngine.UIElements.EventBase)
extern void ClickDetector_SendClickEvent_mA685627EEFA411331A7D67DC7965E8856060F0A9 (void);
// 0x00000006 System.Void UnityEngine.UIElements.ClickDetector::CancelClickTracking(UnityEngine.UIElements.EventBase)
extern void ClickDetector_CancelClickTracking_mF399CE2F19E40E2182350F45C27429C3D53E22B4 (void);
// 0x00000007 System.Void UnityEngine.UIElements.ClickDetector::ProcessEvent(UnityEngine.UIElements.EventBase)
extern void ClickDetector_ProcessEvent_m9F5E295A0C61982BF18E912900BD6993884E1035 (void);
// 0x00000008 System.Void UnityEngine.UIElements.ClickDetector::.cctor()
extern void ClickDetector__cctor_mBA504C797063E6FD44FD3EB84432DDEB11A9A2A1 (void);
// 0x00000009 System.Void UnityEngine.UIElements.ClickDetector/ButtonClickStatus::Reset()
extern void ButtonClickStatus_Reset_m41A20C7A1F938EF9818A481DF11AA97D97E337EC (void);
// 0x0000000A UnityEngine.Texture2D UnityEngine.UIElements.Cursor::get_texture()
extern void Cursor_get_texture_mB0B9D7B2D91E1035B27E05742D5CFAFC6E35D7B0 (void);
// 0x0000000B UnityEngine.Vector2 UnityEngine.UIElements.Cursor::get_hotspot()
extern void Cursor_get_hotspot_m64A89A4010D9037EE97CE02AF70C80B7CCA8DE84 (void);
// 0x0000000C System.Int32 UnityEngine.UIElements.Cursor::get_defaultCursorId()
extern void Cursor_get_defaultCursorId_m78BEDF5FAB1CF3E17784CAC1F1A62622B8B32F54 (void);
// 0x0000000D System.Boolean UnityEngine.UIElements.Cursor::Equals(System.Object)
extern void Cursor_Equals_m97AA23240C606F7A0FCB6DAE1AFF7A46879AA6D6 (void);
// 0x0000000E System.Boolean UnityEngine.UIElements.Cursor::Equals(UnityEngine.UIElements.Cursor)
extern void Cursor_Equals_mA3A02D884C1AE5C4FE6EE98EFE4A1AA83F4EBB21 (void);
// 0x0000000F System.Int32 UnityEngine.UIElements.Cursor::GetHashCode()
extern void Cursor_GetHashCode_m7B79CE5374C05CACBAB2E07C1652F6AD590212ED (void);
// 0x00000010 System.Boolean UnityEngine.UIElements.Cursor::op_Equality(UnityEngine.UIElements.Cursor,UnityEngine.UIElements.Cursor)
extern void Cursor_op_Equality_m300C3570B44FC8A99D8D2535F62A2060AD53EE53 (void);
// 0x00000011 System.String UnityEngine.UIElements.Cursor::ToString()
extern void Cursor_ToString_mD424F81BE23CCE5136FC4960563778689B151833 (void);
// 0x00000012 System.Void UnityEngine.UIElements.EventDispatcherGate::.ctor(UnityEngine.UIElements.EventDispatcher)
extern void EventDispatcherGate__ctor_mD718DC5ECF3A6990B671179A426E65F90CC3A319 (void);
// 0x00000013 System.Void UnityEngine.UIElements.EventDispatcherGate::Dispose()
extern void EventDispatcherGate_Dispose_mA0793129F4766892329859A6E302937105667152 (void);
// 0x00000014 System.Boolean UnityEngine.UIElements.EventDispatcherGate::Equals(UnityEngine.UIElements.EventDispatcherGate)
extern void EventDispatcherGate_Equals_mFDAEDA595E240127DC97FFE152FDB462464688C4 (void);
// 0x00000015 System.Boolean UnityEngine.UIElements.EventDispatcherGate::Equals(System.Object)
extern void EventDispatcherGate_Equals_mB0458E71B92D036951E926355B979A38DEBCEAC6 (void);
// 0x00000016 System.Int32 UnityEngine.UIElements.EventDispatcherGate::GetHashCode()
extern void EventDispatcherGate_GetHashCode_mA36AC6A55B840FA03FECCF56E3E5D66E4D3D4148 (void);
// 0x00000017 UnityEngine.UIElements.PointerDispatchState UnityEngine.UIElements.EventDispatcher::get_pointerState()
extern void EventDispatcher_get_pointerState_mA675C72BDE1A673E104ECFD96FADBD3BC13D6F70 (void);
// 0x00000018 System.Boolean UnityEngine.UIElements.EventDispatcher::get_dispatchImmediately()
extern void EventDispatcher_get_dispatchImmediately_mBD3D55762F81F440182F23109509585E988A655A (void);
// 0x00000019 System.Void UnityEngine.UIElements.EventDispatcher::Dispatch(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.IPanel,UnityEngine.UIElements.DispatchMode)
extern void EventDispatcher_Dispatch_mEB5607C872C77F6A4F47A3E0798CB4B2779D6B2B (void);
// 0x0000001A System.Void UnityEngine.UIElements.EventDispatcher::CloseGate()
extern void EventDispatcher_CloseGate_m7A57D81737E4B475788112F16D11692D72E84C38 (void);
// 0x0000001B System.Void UnityEngine.UIElements.EventDispatcher::OpenGate()
extern void EventDispatcher_OpenGate_mDD6FCDF015D4201CBEF5D869F85C278B4AA6F542 (void);
// 0x0000001C System.Void UnityEngine.UIElements.EventDispatcher::ProcessEventQueue()
extern void EventDispatcher_ProcessEventQueue_m35DBA2C05D70BD851AE542AE20BABE0C79014B09 (void);
// 0x0000001D System.Void UnityEngine.UIElements.EventDispatcher::ProcessEvent(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.IPanel)
extern void EventDispatcher_ProcessEvent_mCBD6A882A7381AB372302C0B18B555EF3DAE6A8B (void);
// 0x0000001E System.Void UnityEngine.UIElements.EventDispatcher::ApplyDispatchingStrategies(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.IPanel,System.Boolean)
extern void EventDispatcher_ApplyDispatchingStrategies_m2A3E4C99B36D3FBD950F1ADFC56EAB7FF5C60971 (void);
// 0x0000001F System.Void UnityEngine.UIElements.EventDispatcher::.cctor()
extern void EventDispatcher__cctor_m2F89AEF49348CE0D08A2C13310784D8B6236B05A (void);
// 0x00000020 UnityEngine.UIElements.FocusController UnityEngine.UIElements.Focusable::get_focusController()
// 0x00000021 System.Boolean UnityEngine.UIElements.Focusable::get_focusable()
extern void Focusable_get_focusable_mA3BF33F025B1AE6F0E8E220E58DE6BDC1FDAB310 (void);
// 0x00000022 System.Int32 UnityEngine.UIElements.Focusable::get_tabIndex()
extern void Focusable_get_tabIndex_mB8299F9106AA1B50FD651FDF64BD51AB4739F78B (void);
// 0x00000023 System.Boolean UnityEngine.UIElements.Focusable::get_delegatesFocus()
extern void Focusable_get_delegatesFocus_mD840ED62D32B55FC515E0005894A77461138E596 (void);
// 0x00000024 System.Boolean UnityEngine.UIElements.Focusable::get_canGrabFocus()
extern void Focusable_get_canGrabFocus_m1DD7773DC0E9FBFB974798FADE855DA478F0DDFB (void);
// 0x00000025 System.Void UnityEngine.UIElements.Focusable::Focus()
extern void Focusable_Focus_mAF200A29C8799725EFC936792943AC5E908F5BB0 (void);
// 0x00000026 System.Void UnityEngine.UIElements.Focusable::Blur()
extern void Focusable_Blur_mD8EAE7355B4DCDB4C1FB630256A6A4901B9EA880 (void);
// 0x00000027 UnityEngine.UIElements.Focusable UnityEngine.UIElements.Focusable::GetFocusDelegate()
extern void Focusable_GetFocusDelegate_m3BFF0CF505A6ABD4489926DB38F95F5976DD069B (void);
// 0x00000028 UnityEngine.UIElements.Focusable UnityEngine.UIElements.Focusable::GetFirstFocusableChild(UnityEngine.UIElements.VisualElement)
extern void Focusable_GetFirstFocusableChild_m879859314A494503C12811E40ACE51C018DE001B (void);
// 0x00000029 UnityEngine.UIElements.FocusChangeDirection UnityEngine.UIElements.FocusChangeDirection::get_unspecified()
extern void FocusChangeDirection_get_unspecified_mB6539EF9E8F9F8E354F55ABDBBBBC4C9F921CACC (void);
// 0x0000002A UnityEngine.UIElements.FocusChangeDirection UnityEngine.UIElements.FocusChangeDirection::get_none()
extern void FocusChangeDirection_get_none_m702BB27310D1EA0511E7CD4FB0B9515D331BA53A (void);
// 0x0000002B UnityEngine.UIElements.FocusChangeDirection UnityEngine.UIElements.FocusChangeDirection::get_lastValue()
extern void FocusChangeDirection_get_lastValue_mF67FF11312EC1CDB50948F86C1A683BFB58F1A13 (void);
// 0x0000002C System.Void UnityEngine.UIElements.FocusChangeDirection::.ctor(System.Int32)
extern void FocusChangeDirection__ctor_mF243D8E15FE0671129149DCA8555FCF7D58FFEAF (void);
// 0x0000002D System.Int32 UnityEngine.UIElements.FocusChangeDirection::op_Implicit(UnityEngine.UIElements.FocusChangeDirection)
extern void FocusChangeDirection_op_Implicit_m438839D193CB93D1376BC58E2846AEBF016C3EFE (void);
// 0x0000002E System.Void UnityEngine.UIElements.FocusChangeDirection::System.IDisposable.Dispose()
extern void FocusChangeDirection_System_IDisposable_Dispose_m8047EBA61A0A684E21353BC537114880949E9022 (void);
// 0x0000002F System.Void UnityEngine.UIElements.FocusChangeDirection::Dispose()
extern void FocusChangeDirection_Dispose_m825DE917594C05C5808E6BD59B74466EF901EE44 (void);
// 0x00000030 System.Void UnityEngine.UIElements.FocusChangeDirection::ApplyTo(UnityEngine.UIElements.FocusController,UnityEngine.UIElements.Focusable)
extern void FocusChangeDirection_ApplyTo_m4FC13F3E93D929D4FB2ED185A6B18750BD60DC33 (void);
// 0x00000031 System.Void UnityEngine.UIElements.FocusChangeDirection::.cctor()
extern void FocusChangeDirection__cctor_m6A0201289A7CB4B6B05406A494228FBB1DA7E08B (void);
// 0x00000032 UnityEngine.UIElements.FocusChangeDirection UnityEngine.UIElements.IFocusRing::GetFocusChangeDirection(UnityEngine.UIElements.Focusable,UnityEngine.UIElements.EventBase)
// 0x00000033 UnityEngine.UIElements.Focusable UnityEngine.UIElements.IFocusRing::GetNextFocusable(UnityEngine.UIElements.Focusable,UnityEngine.UIElements.FocusChangeDirection)
// 0x00000034 UnityEngine.UIElements.IFocusRing UnityEngine.UIElements.FocusController::get_focusRing()
extern void FocusController_get_focusRing_m4F1F97ACCF6AABC41A33130C6FE0B4CCADC24FED (void);
// 0x00000035 System.Boolean UnityEngine.UIElements.FocusController::IsFocused(UnityEngine.UIElements.Focusable)
extern void FocusController_IsFocused_mE39F652794F63E05C4E058CC4D5DA7CAD1562E89 (void);
// 0x00000036 UnityEngine.UIElements.Focusable UnityEngine.UIElements.FocusController::GetLeafFocusedElement()
extern void FocusController_GetLeafFocusedElement_mAD6C9E5DAD9BF161AADFF12FA93B2D3750ACEA3D (void);
// 0x00000037 System.Void UnityEngine.UIElements.FocusController::SetFocusToLastFocusedElement()
extern void FocusController_SetFocusToLastFocusedElement_m26CDB0A41E45E0EC7CC1A20DB57AD29B5CA60A0F (void);
// 0x00000038 System.Void UnityEngine.UIElements.FocusController::BlurLastFocusedElement()
extern void FocusController_BlurLastFocusedElement_m28627F4A6375718A5453C6757790C5055458067F (void);
// 0x00000039 System.Void UnityEngine.UIElements.FocusController::DoFocusChange(UnityEngine.UIElements.Focusable)
extern void FocusController_DoFocusChange_m3E6D899B8A7C21B20346514763E2F9EC1A49C2DF (void);
// 0x0000003A System.Void UnityEngine.UIElements.FocusController::AboutToReleaseFocus(UnityEngine.UIElements.Focusable,UnityEngine.UIElements.Focusable,UnityEngine.UIElements.FocusChangeDirection)
extern void FocusController_AboutToReleaseFocus_mE77836E22D7D76FA7CF4405B05F24C827D6FFE07 (void);
// 0x0000003B System.Void UnityEngine.UIElements.FocusController::ReleaseFocus(UnityEngine.UIElements.Focusable,UnityEngine.UIElements.Focusable,UnityEngine.UIElements.FocusChangeDirection)
extern void FocusController_ReleaseFocus_m012B8E2F60D7223D4435F1B64B0CA128671630CA (void);
// 0x0000003C System.Void UnityEngine.UIElements.FocusController::AboutToGrabFocus(UnityEngine.UIElements.Focusable,UnityEngine.UIElements.Focusable,UnityEngine.UIElements.FocusChangeDirection)
extern void FocusController_AboutToGrabFocus_m625ABD4C834E4BAD9977D0A244A06C8EE2F41DAB (void);
// 0x0000003D System.Void UnityEngine.UIElements.FocusController::GrabFocus(UnityEngine.UIElements.Focusable,UnityEngine.UIElements.Focusable,UnityEngine.UIElements.FocusChangeDirection,System.Boolean)
extern void FocusController_GrabFocus_m33DF8F9054BD4AACD3B863C1E396C6BC17E0567D (void);
// 0x0000003E System.Void UnityEngine.UIElements.FocusController::SwitchFocus(UnityEngine.UIElements.Focusable,System.Boolean)
extern void FocusController_SwitchFocus_m23B5554A489547A337768C6813A85F53C132A543 (void);
// 0x0000003F System.Void UnityEngine.UIElements.FocusController::SwitchFocus(UnityEngine.UIElements.Focusable,UnityEngine.UIElements.FocusChangeDirection,System.Boolean)
extern void FocusController_SwitchFocus_m7FDD963260CA15ABC695F32FD655B96D7581FD21 (void);
// 0x00000040 UnityEngine.UIElements.Focusable UnityEngine.UIElements.FocusController::SwitchFocusOnEvent(UnityEngine.UIElements.EventBase)
extern void FocusController_SwitchFocusOnEvent_mFA7FC7B2C42FEE01FE80C3C88FEB43B0AED64BFE (void);
// 0x00000041 System.Int32 UnityEngine.UIElements.FocusController::get_imguiKeyboardControl()
extern void FocusController_get_imguiKeyboardControl_mBE7CB44518FCA881F216C44C4495AF31B27F64B9 (void);
// 0x00000042 System.Void UnityEngine.UIElements.FocusController::set_imguiKeyboardControl(System.Int32)
extern void FocusController_set_imguiKeyboardControl_mFA1DE58DC2F23604F24B86A66C773BD10849DFAA (void);
// 0x00000043 System.Void UnityEngine.UIElements.FocusController::SyncIMGUIFocus(System.Int32,UnityEngine.UIElements.Focusable,System.Boolean)
extern void FocusController_SyncIMGUIFocus_m0076B10EA65A939BFFCE54FD55AB5E4D054FACBF (void);
// 0x00000044 System.Action UnityEngine.UIElements.IMGUIContainer::get_onGUIHandler()
extern void IMGUIContainer_get_onGUIHandler_mE8916A7AA27757E097C9880526CCE55B1361444D (void);
// 0x00000045 UnityEngine.ObjectGUIState UnityEngine.UIElements.IMGUIContainer::get_guiState()
extern void IMGUIContainer_get_guiState_mB925B5A4A9F71D6FA5562B2AEBF87194DE035ED2 (void);
// 0x00000046 UnityEngine.Rect UnityEngine.UIElements.IMGUIContainer::get_lastWorldClip()
extern void IMGUIContainer_get_lastWorldClip_m559BC7B8AC19A0E9EFBFE1818D2B0FFCF95088AF (void);
// 0x00000047 UnityEngine.GUILayoutUtility/LayoutCache UnityEngine.UIElements.IMGUIContainer::get_cache()
extern void IMGUIContainer_get_cache_mDF4F3F6C76DEB7DACCE68A061534B7D683FE1069 (void);
// 0x00000048 System.Single UnityEngine.UIElements.IMGUIContainer::get_layoutMeasuredWidth()
extern void IMGUIContainer_get_layoutMeasuredWidth_m3218A2834EEDF43812093AD4AAB271604642786D (void);
// 0x00000049 System.Single UnityEngine.UIElements.IMGUIContainer::get_layoutMeasuredHeight()
extern void IMGUIContainer_get_layoutMeasuredHeight_mE9DE1B8DD1203F85DDB0F50F57502A18A2D384E6 (void);
// 0x0000004A UnityEngine.UIElements.ContextType UnityEngine.UIElements.IMGUIContainer::get_contextType()
extern void IMGUIContainer_get_contextType_mEED3AA9B355FBF46948D9CA19EB97AC6F01ABF29 (void);
// 0x0000004B System.Boolean UnityEngine.UIElements.IMGUIContainer::get_focusOnlyIfHasFocusableControls()
extern void IMGUIContainer_get_focusOnlyIfHasFocusableControls_m1A4C1DDB09520D386617676965A094D201F0FC5B (void);
// 0x0000004C System.Void UnityEngine.UIElements.IMGUIContainer::.cctor()
extern void IMGUIContainer__cctor_mA0DAED497F1CB5CB63C694D6AACED331D8D2DEEB (void);
// 0x0000004D System.Void UnityEngine.UIElements.IMGUIContainer::SaveGlobals()
extern void IMGUIContainer_SaveGlobals_m2F7109F670586228D47A82BF97B8E82337CAAB85 (void);
// 0x0000004E System.Void UnityEngine.UIElements.IMGUIContainer::RestoreGlobals()
extern void IMGUIContainer_RestoreGlobals_m502765489B54E97FC770B5A3F685DFD07D161999 (void);
// 0x0000004F System.Void UnityEngine.UIElements.IMGUIContainer::DoOnGUI(UnityEngine.Event,UnityEngine.Matrix4x4,UnityEngine.Rect,System.Boolean,UnityEngine.Rect,System.Action,System.Boolean)
extern void IMGUIContainer_DoOnGUI_m1974D60CE778967E391748F655C7436B26739B22 (void);
// 0x00000050 System.Void UnityEngine.UIElements.IMGUIContainer::MarkDirtyLayout()
extern void IMGUIContainer_MarkDirtyLayout_m41F18251C98328413347C8723F4DB1B363981E5F (void);
// 0x00000051 System.Boolean UnityEngine.UIElements.IMGUIContainer::SendEventToIMGUI(UnityEngine.UIElements.EventBase,System.Boolean,System.Boolean)
extern void IMGUIContainer_SendEventToIMGUI_m04C1240B4C85A8D0D21EBB8EAE1FEAF9A2512FDE (void);
// 0x00000052 System.Boolean UnityEngine.UIElements.IMGUIContainer::SendEventToIMGUIRaw(UnityEngine.UIElements.EventBase,System.Boolean,System.Boolean)
extern void IMGUIContainer_SendEventToIMGUIRaw_m1CF195260874023183303567A7290C5CCAC4734C (void);
// 0x00000053 System.Boolean UnityEngine.UIElements.IMGUIContainer::VerifyBounds(UnityEngine.UIElements.EventBase)
extern void IMGUIContainer_VerifyBounds_m0BF476D805D2288A7409A7FE745E86939B899942 (void);
// 0x00000054 System.Boolean UnityEngine.UIElements.IMGUIContainer::IsContainerCapturingTheMouse()
extern void IMGUIContainer_IsContainerCapturingTheMouse_mD1F324F84B607E41B818560D7FFF13E432E65CE2 (void);
// 0x00000055 System.Boolean UnityEngine.UIElements.IMGUIContainer::IsLocalEvent(UnityEngine.UIElements.EventBase)
extern void IMGUIContainer_IsLocalEvent_mE1750D8C9145641C95C3C1BD9A6453EF5A5A3D01 (void);
// 0x00000056 System.Boolean UnityEngine.UIElements.IMGUIContainer::IsEventInsideLocalWindow(UnityEngine.UIElements.EventBase)
extern void IMGUIContainer_IsEventInsideLocalWindow_m59D338511C72D45AAC58761D2702E08C2A504E63 (void);
// 0x00000057 System.Boolean UnityEngine.UIElements.IMGUIContainer::HandleIMGUIEvent(UnityEngine.Event,System.Boolean)
extern void IMGUIContainer_HandleIMGUIEvent_m8AE2543F9F24AE851F39E216BDB63DBDFA1D00D7 (void);
// 0x00000058 System.Boolean UnityEngine.UIElements.IMGUIContainer::HandleIMGUIEvent(UnityEngine.Event,System.Action,System.Boolean)
extern void IMGUIContainer_HandleIMGUIEvent_mA00CF4168AE43D49DCCAA1E2E581191BE2729F35 (void);
// 0x00000059 System.Boolean UnityEngine.UIElements.IMGUIContainer::HandleIMGUIEvent(UnityEngine.Event,UnityEngine.Matrix4x4,UnityEngine.Rect,System.Action,System.Boolean)
extern void IMGUIContainer_HandleIMGUIEvent_m0AA59C0E7F82185E42597792A9D58C0B1DAF9014 (void);
// 0x0000005A UnityEngine.Rect UnityEngine.UIElements.IMGUIContainer::GetCurrentClipRect()
extern void IMGUIContainer_GetCurrentClipRect_mB7F3F57A55C200782574787593C7331055684F87 (void);
// 0x0000005B System.Void UnityEngine.UIElements.IMGUIContainer::GetCurrentTransformAndClip(UnityEngine.UIElements.IMGUIContainer,UnityEngine.Event,UnityEngine.Matrix4x4&,UnityEngine.Rect&)
extern void IMGUIContainer_GetCurrentTransformAndClip_m3EFCE53D64C0546E11B5F41D3FB259FF7EAD98D5 (void);
// 0x0000005C System.Void UnityEngine.UIElements.IMGUIContainer::Dispose()
extern void IMGUIContainer_Dispose_m7EAEBFC44197E554D040C15BFFF029F2D159FBD7 (void);
// 0x0000005D System.Void UnityEngine.UIElements.IMGUIContainer::Dispose(System.Boolean)
extern void IMGUIContainer_Dispose_m6585C1777076DD61B513B23F02EC39F4CED07C4C (void);
// 0x0000005E System.Void UnityEngine.UIElements.IMGUIContainer::<DoOnGUI>b__55_0()
extern void IMGUIContainer_U3CDoOnGUIU3Eb__55_0_m7B609E2BBF96D93484F1A18875E617E01E48B8BC (void);
// 0x0000005F System.Boolean UnityEngine.UIElements.MouseCaptureController::HasMouseCapture(UnityEngine.UIElements.IEventHandler)
extern void MouseCaptureController_HasMouseCapture_m9760F1E89C054D37CC2C819C30C02219EC51B53C (void);
// 0x00000060 System.Void UnityEngine.UIElements.MouseCaptureController::CaptureMouse(UnityEngine.UIElements.IEventHandler)
extern void MouseCaptureController_CaptureMouse_mFD566FC54CFDDE4D7C23C2CE6CAF0C55BA87DCB6 (void);
// 0x00000061 System.Void UnityEngine.UIElements.MouseCaptureController::ReleaseMouse(UnityEngine.UIElements.IEventHandler)
extern void MouseCaptureController_ReleaseMouse_m85961EA94DC96AF6FB4600DF153B18857FE55F3B (void);
// 0x00000062 System.Void UnityEngine.UIElements.MouseCaptureController::.cctor()
extern void MouseCaptureController__cctor_mADF0597882A51411BCA5E0A48063DF60FE3A3DE9 (void);
// 0x00000063 System.Int32 UnityEngine.UIElements.ObjectPool`1::get_maxSize()
// 0x00000064 System.Void UnityEngine.UIElements.ObjectPool`1::set_maxSize(System.Int32)
// 0x00000065 System.Void UnityEngine.UIElements.ObjectPool`1::.ctor(System.Int32)
// 0x00000066 System.Int32 UnityEngine.UIElements.ObjectPool`1::Size()
// 0x00000067 T UnityEngine.UIElements.ObjectPool`1::Get()
// 0x00000068 System.Void UnityEngine.UIElements.ObjectPool`1::Release(T)
// 0x00000069 UnityEngine.Matrix4x4 UnityEngine.UIElements.RepaintData::get_currentOffset()
extern void RepaintData_get_currentOffset_mA1CF953FC14565CC923AD638AE8766B6EB288B34 (void);
// 0x0000006A System.Void UnityEngine.UIElements.RepaintData::set_repaintEvent(UnityEngine.Event)
extern void RepaintData_set_repaintEvent_m017C75D49486B04AB55CBBE44474DB785DCB1EBA (void);
// 0x0000006B System.Void UnityEngine.UIElements.HierarchyEvent::.ctor(System.Object,System.IntPtr)
extern void HierarchyEvent__ctor_m786CC2E0FB91181FFDA27187EE28139678D3AB58 (void);
// 0x0000006C System.Void UnityEngine.UIElements.HierarchyEvent::Invoke(UnityEngine.UIElements.VisualElement,UnityEngine.UIElements.HierarchyChangeType)
extern void HierarchyEvent_Invoke_m0E35EB540F1C21463F878C41559A729C9FF77139 (void);
// 0x0000006D UnityEngine.UIElements.VisualElement UnityEngine.UIElements.IPanel::get_visualTree()
// 0x0000006E UnityEngine.UIElements.EventDispatcher UnityEngine.UIElements.IPanel::get_dispatcher()
// 0x0000006F UnityEngine.UIElements.ContextType UnityEngine.UIElements.IPanel::get_contextType()
// 0x00000070 UnityEngine.UIElements.FocusController UnityEngine.UIElements.IPanel::get_focusController()
// 0x00000071 UnityEngine.EventInterests UnityEngine.UIElements.BaseVisualElementPanel::get_IMGUIEventInterests()
// 0x00000072 UnityEngine.ScriptableObject UnityEngine.UIElements.BaseVisualElementPanel::get_ownerObject()
// 0x00000073 System.Int32 UnityEngine.UIElements.BaseVisualElementPanel::get_IMGUIContainersCount()
// 0x00000074 UnityEngine.UIElements.FocusController UnityEngine.UIElements.BaseVisualElementPanel::get_focusController()
// 0x00000075 UnityEngine.UIElements.IMGUIContainer UnityEngine.UIElements.BaseVisualElementPanel::get_rootIMGUIContainer()
// 0x00000076 System.Void UnityEngine.UIElements.BaseVisualElementPanel::Dispose()
extern void BaseVisualElementPanel_Dispose_m6C4F04D1A1DCCC642F73FA2CB7BD02808FEA1FDD (void);
// 0x00000077 System.Void UnityEngine.UIElements.BaseVisualElementPanel::Dispose(System.Boolean)
extern void BaseVisualElementPanel_Dispose_m9474549B916298CAD9F8340BDC3BED82B991B668 (void);
// 0x00000078 System.Void UnityEngine.UIElements.BaseVisualElementPanel::Repaint(UnityEngine.Event)
// 0x00000079 System.Void UnityEngine.UIElements.BaseVisualElementPanel::ValidateLayout()
// 0x0000007A System.Single UnityEngine.UIElements.BaseVisualElementPanel::get_scale()
extern void BaseVisualElementPanel_get_scale_mC96D823764B70A190360976F325C9D428C30F764 (void);
// 0x0000007B System.Void UnityEngine.UIElements.BaseVisualElementPanel::set_pixelsPerPoint(System.Single)
extern void BaseVisualElementPanel_set_pixelsPerPoint_m8F4E48021048241523B133D3F60AF2273587241A (void);
// 0x0000007C System.Single UnityEngine.UIElements.BaseVisualElementPanel::get_scaledPixelsPerPoint()
extern void BaseVisualElementPanel_get_scaledPixelsPerPoint_mD1138DFAAF4DB674D78EF7C28421808DFC4A60B8 (void);
// 0x0000007D System.Single UnityEngine.UIElements.BaseVisualElementPanel::get_sortingPriority()
extern void BaseVisualElementPanel_get_sortingPriority_mB571FBE28BCD5C6985C1BF6424D0FC9D99B57BC0 (void);
// 0x0000007E System.Boolean UnityEngine.UIElements.BaseVisualElementPanel::get_duringLayoutPhase()
extern void BaseVisualElementPanel_get_duringLayoutPhase_m29E7AA00103718DF6E84688201C1851BF0590F6E (void);
// 0x0000007F System.UInt32 UnityEngine.UIElements.BaseVisualElementPanel::get_version()
// 0x00000080 System.Void UnityEngine.UIElements.BaseVisualElementPanel::OnVersionChanged(UnityEngine.UIElements.VisualElement,UnityEngine.UIElements.VersionChangeType)
// 0x00000081 UnityEngine.UIElements.RepaintData UnityEngine.UIElements.BaseVisualElementPanel::get_repaintData()
extern void BaseVisualElementPanel_get_repaintData_m8C0EB53A84D72681A5F64DB7D7138DEBDF79B907 (void);
// 0x00000082 UnityEngine.UIElements.VisualElement UnityEngine.UIElements.BaseVisualElementPanel::get_visualTree()
// 0x00000083 UnityEngine.UIElements.EventDispatcher UnityEngine.UIElements.BaseVisualElementPanel::get_dispatcher()
// 0x00000084 System.Void UnityEngine.UIElements.BaseVisualElementPanel::SendEvent(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.DispatchMode)
extern void BaseVisualElementPanel_SendEvent_mE90F7BA962A358F4AC6F841B3700ACD004EC5600 (void);
// 0x00000085 UnityEngine.UIElements.IScheduler UnityEngine.UIElements.BaseVisualElementPanel::get_scheduler()
// 0x00000086 UnityEngine.UIElements.ContextType UnityEngine.UIElements.BaseVisualElementPanel::get_contextType()
// 0x00000087 UnityEngine.UIElements.VisualElement UnityEngine.UIElements.BaseVisualElementPanel::Pick(UnityEngine.Vector2)
// 0x00000088 System.Boolean UnityEngine.UIElements.BaseVisualElementPanel::get_disposed()
extern void BaseVisualElementPanel_get_disposed_m44D50828E8ABCBD3F4B02AAAF1814D07F6DAA345 (void);
// 0x00000089 System.Void UnityEngine.UIElements.BaseVisualElementPanel::set_disposed(System.Boolean)
extern void BaseVisualElementPanel_set_disposed_mF2065052DC7234B7934AA0ABD7F3DDA6712956B3 (void);
// 0x0000008A UnityEngine.UIElements.VisualElement UnityEngine.UIElements.BaseVisualElementPanel::GetTopElementUnderPointer(System.Int32)
extern void BaseVisualElementPanel_GetTopElementUnderPointer_m1A8CBAC45A893CA9F04F99D018D289083C96B559 (void);
// 0x0000008B UnityEngine.UIElements.VisualElement UnityEngine.UIElements.BaseVisualElementPanel::RecomputeTopElementUnderPointer(UnityEngine.Vector2,UnityEngine.UIElements.EventBase)
extern void BaseVisualElementPanel_RecomputeTopElementUnderPointer_mDDFB8233390967E80E95EB962162CCD8E3135B94 (void);
// 0x0000008C System.Void UnityEngine.UIElements.BaseVisualElementPanel::ClearCachedElementUnderPointer(UnityEngine.UIElements.EventBase)
extern void BaseVisualElementPanel_ClearCachedElementUnderPointer_m4DBDFB43E4AF4C3D5953C4B47B05A297B2B67E97 (void);
// 0x0000008D System.Void UnityEngine.UIElements.BaseVisualElementPanel::CommitElementUnderPointers()
extern void BaseVisualElementPanel_CommitElementUnderPointers_m30230955A9B99A1B2B7F2412C43201B29A516246 (void);
// 0x0000008E System.Void UnityEngine.UIElements.BaseVisualElementPanel::InvokeBeforeUpdate()
extern void BaseVisualElementPanel_InvokeBeforeUpdate_mE3525D9C553612F37858C3DB252EAD954C68E8CA (void);
// 0x0000008F System.Void UnityEngine.UIElements.LoadResourceFunction::.ctor(System.Object,System.IntPtr)
extern void LoadResourceFunction__ctor_m0F9587876DB13EB88030C36455300685EA758D30 (void);
// 0x00000090 UnityEngine.Object UnityEngine.UIElements.LoadResourceFunction::Invoke(System.String,System.Type,System.Single)
extern void LoadResourceFunction_Invoke_m597E0E01088C806293BF63BD853EDB0FFF5ACB69 (void);
// 0x00000091 System.Void UnityEngine.UIElements.TimeMsFunction::.ctor(System.Object,System.IntPtr)
extern void TimeMsFunction__ctor_mA7148B9CE14C60C09E624C8FF95C7CE0F72E4AAF (void);
// 0x00000092 System.Int64 UnityEngine.UIElements.TimeMsFunction::Invoke()
extern void TimeMsFunction_Invoke_m767F92DD36939414D0B5AAF07578B244093322F1 (void);
// 0x00000093 System.Void UnityEngine.UIElements.GetViewDataDictionary::.ctor(System.Object,System.IntPtr)
extern void GetViewDataDictionary__ctor_mAB64BAB68A196B3D542A19A494E4F556AD258E6B (void);
// 0x00000094 UnityEngine.UIElements.ISerializableJsonDictionary UnityEngine.UIElements.GetViewDataDictionary::Invoke()
extern void GetViewDataDictionary_Invoke_mD60DC6A289655094AA28931217FD78036D4E6D1F (void);
// 0x00000095 System.Void UnityEngine.UIElements.SavePersistentViewData::.ctor(System.Object,System.IntPtr)
extern void SavePersistentViewData__ctor_mE59E51B854E93B9985A9C05F13DA47EC97EE2D13 (void);
// 0x00000096 System.Void UnityEngine.UIElements.SavePersistentViewData::Invoke()
extern void SavePersistentViewData_Invoke_mB08932768F7A80E931327779BF40E70AFE887611 (void);
// 0x00000097 UnityEngine.UIElements.VisualElement UnityEngine.UIElements.Panel::get_visualTree()
extern void Panel_get_visualTree_mB2346C6D7BF2CCA720A3439ECFB2217EAE487730 (void);
// 0x00000098 UnityEngine.UIElements.EventDispatcher UnityEngine.UIElements.Panel::get_dispatcher()
extern void Panel_get_dispatcher_m0B3FE190F0E1ADA939DE90A467137336D9095613 (void);
// 0x00000099 UnityEngine.UIElements.TimerEventScheduler UnityEngine.UIElements.Panel::get_timerEventScheduler()
extern void Panel_get_timerEventScheduler_m85B4D5BBF66F9F816BE3740549A085495BA2844B (void);
// 0x0000009A UnityEngine.UIElements.IScheduler UnityEngine.UIElements.Panel::get_scheduler()
extern void Panel_get_scheduler_mEB6147CBCB3F82DCFEF418C11D07DE12C94FAB52 (void);
// 0x0000009B UnityEngine.ScriptableObject UnityEngine.UIElements.Panel::get_ownerObject()
extern void Panel_get_ownerObject_m9BFDEF2F68F4E81D60039B9A09A1D77549D95ADC (void);
// 0x0000009C UnityEngine.UIElements.ContextType UnityEngine.UIElements.Panel::get_contextType()
extern void Panel_get_contextType_m4592156375BE89F7962C8F34F5DA2907C469F781 (void);
// 0x0000009D UnityEngine.UIElements.FocusController UnityEngine.UIElements.Panel::get_focusController()
extern void Panel_get_focusController_mC3C8E03BBD6E411FD6DF506A5A5FDAC187E6C3B8 (void);
// 0x0000009E UnityEngine.EventInterests UnityEngine.UIElements.Panel::get_IMGUIEventInterests()
extern void Panel_get_IMGUIEventInterests_m331B2B7A88A756B47B6B752F33F6BE4384517BEB (void);
// 0x0000009F System.Void UnityEngine.UIElements.Panel::Focus()
extern void Panel_Focus_m648524C6386D4FCC1A8ED4CF6A0F36C2B9E8C48C (void);
// 0x000000A0 System.Void UnityEngine.UIElements.Panel::Blur()
extern void Panel_Blur_m0E7521CF78827E9BB15D9FED307EF01FC8955601 (void);
// 0x000000A1 System.String UnityEngine.UIElements.Panel::get_name()
extern void Panel_get_name_mA801AF49D8609FBB3B07047D8D6F61E17321D97E (void);
// 0x000000A2 UnityEngine.UIElements.TimeMsFunction UnityEngine.UIElements.Panel::get_TimeSinceStartup()
extern void Panel_get_TimeSinceStartup_mD5C764851154DFF6101A959C2D145E914EEABAF6 (void);
// 0x000000A3 System.Int32 UnityEngine.UIElements.Panel::get_IMGUIContainersCount()
extern void Panel_get_IMGUIContainersCount_m780ADFFAB6763A905C0D50179C7E16A51E91A80E (void);
// 0x000000A4 UnityEngine.UIElements.IMGUIContainer UnityEngine.UIElements.Panel::get_rootIMGUIContainer()
extern void Panel_get_rootIMGUIContainer_m19EDFB767FF2FC6CDA39F8683405A630389963EF (void);
// 0x000000A5 System.UInt32 UnityEngine.UIElements.Panel::get_version()
extern void Panel_get_version_mB1575E2DC4705B34BF72DF96D0A56DC6CBC6D0F2 (void);
// 0x000000A6 System.Int64 UnityEngine.UIElements.Panel::TimeSinceStartupMs()
extern void Panel_TimeSinceStartupMs_mA7302F2BDBFA020E9BE4B8378E392FD151DE7F74 (void);
// 0x000000A7 System.Int64 UnityEngine.UIElements.Panel::DefaultTimeSinceStartupMs()
extern void Panel_DefaultTimeSinceStartupMs_m9BEB61FEFF46DAA66BFD9E8CFF3AA4C61AFE31D4 (void);
// 0x000000A8 UnityEngine.UIElements.VisualElement UnityEngine.UIElements.Panel::PickAll(UnityEngine.UIElements.VisualElement,UnityEngine.Vector2,System.Collections.Generic.List`1<UnityEngine.UIElements.VisualElement>)
extern void Panel_PickAll_mDC969CBC7DC5218C630D5C9C247F21E4748C183F (void);
// 0x000000A9 UnityEngine.UIElements.VisualElement UnityEngine.UIElements.Panel::PerformPick(UnityEngine.UIElements.VisualElement,UnityEngine.Vector2,System.Collections.Generic.List`1<UnityEngine.UIElements.VisualElement>)
extern void Panel_PerformPick_m586CA5285C8F1306D562D07BF608F54628F8786B (void);
// 0x000000AA UnityEngine.UIElements.VisualElement UnityEngine.UIElements.Panel::Pick(UnityEngine.Vector2)
extern void Panel_Pick_m97178E46F1CCA67276FB9C4AD4FEEFE04F854B38 (void);
// 0x000000AB System.Void UnityEngine.UIElements.Panel::ValidateLayout()
extern void Panel_ValidateLayout_m2F6611613CC1F3B4F6CAACFAC04BA76E1F31A744 (void);
// 0x000000AC System.Void UnityEngine.UIElements.Panel::UpdateForRepaint()
extern void Panel_UpdateForRepaint_m66F4FBCADA00FE2EA676D316210E5F667279A833 (void);
// 0x000000AD System.Void UnityEngine.UIElements.Panel::Repaint(UnityEngine.Event)
extern void Panel_Repaint_m8E1FF84D8B3BED705EA472BDA3FE14182056EE49 (void);
// 0x000000AE System.Void UnityEngine.UIElements.Panel::OnVersionChanged(UnityEngine.UIElements.VisualElement,UnityEngine.UIElements.VersionChangeType)
extern void Panel_OnVersionChanged_m924923A41ECD84D03160C55210AB5C425A715376 (void);
// 0x000000AF System.Void UnityEngine.UIElements.Panel::.cctor()
extern void Panel__cctor_mE231B9FFE7B056C25D00C200D501BCD860390EE0 (void);
// 0x000000B0 UnityEngine.GameObject UnityEngine.UIElements.BaseRuntimePanel::get_selectableGameObject()
extern void BaseRuntimePanel_get_selectableGameObject_m2E4236700CCA6D969AB605140EB19A821C13C06D (void);
// 0x000000B1 System.Void UnityEngine.UIElements.BaseRuntimePanel::set_selectableGameObject(UnityEngine.GameObject)
extern void BaseRuntimePanel_set_selectableGameObject_m9ACAE61722BC9B4CB94A8D4D2205FD567314B731 (void);
// 0x000000B2 System.Void UnityEngine.UIElements.BaseRuntimePanel::add_destroyed(System.Action)
extern void BaseRuntimePanel_add_destroyed_mB314BB1911A52AFF1B07E63CC0EB7229F7B47551 (void);
// 0x000000B3 System.Void UnityEngine.UIElements.BaseRuntimePanel::remove_destroyed(System.Action)
extern void BaseRuntimePanel_remove_destroyed_mE8D90F08FEADEE30957023301032013AF568894B (void);
// 0x000000B4 System.Boolean UnityEngine.UIElements.BaseRuntimePanel::get_drawToCameras()
extern void BaseRuntimePanel_get_drawToCameras_m81B2EFDBB9E380E8541D30E40C75C624C51A3E1F (void);
// 0x000000B5 System.Int32 UnityEngine.UIElements.BaseRuntimePanel::get_targetDisplay()
extern void BaseRuntimePanel_get_targetDisplay_m969C6CBB80B6A7CEB843FDFF0E1B550219D507CB (void);
// 0x000000B6 System.Func`2<UnityEngine.Vector2,UnityEngine.Vector2> UnityEngine.UIElements.BaseRuntimePanel::get_screenToPanelSpace()
extern void BaseRuntimePanel_get_screenToPanelSpace_m868A9D47CB9FF5786F10AC937BEF10680FA3770A (void);
// 0x000000B7 UnityEngine.Vector2 UnityEngine.UIElements.BaseRuntimePanel::ScreenToPanel(UnityEngine.Vector2)
extern void BaseRuntimePanel_ScreenToPanel_m7FCB64A28984294854D016E25F8579C37BBABE6E (void);
// 0x000000B8 System.Boolean UnityEngine.UIElements.BaseRuntimePanel::ScreenToPanel(UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.Vector2&,UnityEngine.Vector2&)
extern void BaseRuntimePanel_ScreenToPanel_mBD9FE72AF98435E9C7FED9A545401BB2B1626F58 (void);
// 0x000000B9 System.Void UnityEngine.UIElements.BaseRuntimePanel::AssignPanelToComponents(UnityEngine.UIElements.BaseRuntimePanel)
extern void BaseRuntimePanel_AssignPanelToComponents_m460CEED1BE4EA8FB4D5C13DC3EB9C20229379B62 (void);
// 0x000000BA System.Void UnityEngine.UIElements.BaseRuntimePanel::.cctor()
extern void BaseRuntimePanel__cctor_mDBA4F993E25A36125BB1C9B071373FE14EA04989 (void);
// 0x000000BB System.Void UnityEngine.UIElements.BaseRuntimePanel/<>c::.cctor()
extern void U3CU3Ec__cctor_mFF3A19C910FD2ECD868BFCA869E7A2DE6BB27D1A (void);
// 0x000000BC System.Void UnityEngine.UIElements.BaseRuntimePanel/<>c::.ctor()
extern void U3CU3Ec__ctor_mC4C1E775016D1A6FB529350E9FD126375426BCC9 (void);
// 0x000000BD UnityEngine.Vector2 UnityEngine.UIElements.BaseRuntimePanel/<>c::<.cctor>b__36_0(UnityEngine.Vector2)
extern void U3CU3Ec_U3C_cctorU3Eb__36_0_m2416285E934D715C2DA88E63220EC21B6BEFF211 (void);
// 0x000000BE System.Void UnityEngine.UIElements.IRuntimePanelComponent::set_panel(UnityEngine.UIElements.IPanel)
// 0x000000BF UnityEngine.UIElements.PointerDispatchState UnityEngine.UIElements.PointerCaptureHelper::GetStateFor(UnityEngine.UIElements.IEventHandler)
extern void PointerCaptureHelper_GetStateFor_m5D42640113AFF9AA1D80FFD97045220F8EFA32AF (void);
// 0x000000C0 System.Boolean UnityEngine.UIElements.PointerCaptureHelper::HasPointerCapture(UnityEngine.UIElements.IEventHandler,System.Int32)
extern void PointerCaptureHelper_HasPointerCapture_m9A28C223A9F5A8240EC5925729F164FD3EB3B9E9 (void);
// 0x000000C1 System.Void UnityEngine.UIElements.PointerCaptureHelper::CapturePointer(UnityEngine.UIElements.IEventHandler,System.Int32)
extern void PointerCaptureHelper_CapturePointer_m2BB09CA5A4D89C0E1C804E2D5DC0F829838B7660 (void);
// 0x000000C2 System.Void UnityEngine.UIElements.PointerCaptureHelper::ReleasePointer(UnityEngine.UIElements.IEventHandler,System.Int32)
extern void PointerCaptureHelper_ReleasePointer_m910C9893619D5809B69D5FE8A76741F4FD30ABFF (void);
// 0x000000C3 UnityEngine.UIElements.IEventHandler UnityEngine.UIElements.PointerCaptureHelper::GetCapturingElement(UnityEngine.UIElements.IPanel,System.Int32)
extern void PointerCaptureHelper_GetCapturingElement_m5BEFCC83FABC55CEA3DD4AED99807A310DBCC720 (void);
// 0x000000C4 System.Void UnityEngine.UIElements.PointerCaptureHelper::ReleasePointer(UnityEngine.UIElements.IPanel,System.Int32)
extern void PointerCaptureHelper_ReleasePointer_m7B13B02182935DC9960A336680E58A4C930B1198 (void);
// 0x000000C5 System.Void UnityEngine.UIElements.PointerCaptureHelper::ActivateCompatibilityMouseEvents(UnityEngine.UIElements.IPanel,System.Int32)
extern void PointerCaptureHelper_ActivateCompatibilityMouseEvents_m4AB492162DCC884007307DCC3D2C0DF71EB713F8 (void);
// 0x000000C6 System.Void UnityEngine.UIElements.PointerCaptureHelper::PreventCompatibilityMouseEvents(UnityEngine.UIElements.IPanel,System.Int32)
extern void PointerCaptureHelper_PreventCompatibilityMouseEvents_m327E2C2B84B8F171819384DDFD5511775725BC58 (void);
// 0x000000C7 System.Boolean UnityEngine.UIElements.PointerCaptureHelper::ShouldSendCompatibilityMouseEvents(UnityEngine.UIElements.IPanel,UnityEngine.UIElements.IPointerEvent)
extern void PointerCaptureHelper_ShouldSendCompatibilityMouseEvents_m6549DB7737673EAB222390A5E7BB3D7F2A40A456 (void);
// 0x000000C8 System.Void UnityEngine.UIElements.PointerCaptureHelper::ProcessPointerCapture(UnityEngine.UIElements.IPanel,System.Int32)
extern void PointerCaptureHelper_ProcessPointerCapture_m64D286EDBD2D21F619B7EABB4C16FE931FECE854 (void);
// 0x000000C9 UnityEngine.UIElements.IEventHandler UnityEngine.UIElements.PointerDispatchState::GetCapturingElement(System.Int32)
extern void PointerDispatchState_GetCapturingElement_mB247250AA9F1A1CA1ED50EB0F67D6D27CBE36409 (void);
// 0x000000CA System.Boolean UnityEngine.UIElements.PointerDispatchState::HasPointerCapture(UnityEngine.UIElements.IEventHandler,System.Int32)
extern void PointerDispatchState_HasPointerCapture_m68E6406587A571D645B13C718F0CCCF2D16E64C1 (void);
// 0x000000CB System.Void UnityEngine.UIElements.PointerDispatchState::CapturePointer(UnityEngine.UIElements.IEventHandler,System.Int32)
extern void PointerDispatchState_CapturePointer_mE6DBA11E5D3C84DA1878181F7D5E1FC2DE52CDE0 (void);
// 0x000000CC System.Void UnityEngine.UIElements.PointerDispatchState::ReleasePointer(System.Int32)
extern void PointerDispatchState_ReleasePointer_m883A2568DAAC88EC5ADAC51BA91923BA4259FB60 (void);
// 0x000000CD System.Void UnityEngine.UIElements.PointerDispatchState::ReleasePointer(UnityEngine.UIElements.IEventHandler,System.Int32)
extern void PointerDispatchState_ReleasePointer_mB4415D2639C107DED4CE22BF87DA0B3599F37FC3 (void);
// 0x000000CE System.Void UnityEngine.UIElements.PointerDispatchState::ProcessPointerCapture(System.Int32)
extern void PointerDispatchState_ProcessPointerCapture_mF62860D5D2B863B460383A90AC534BD7BC1E503C (void);
// 0x000000CF System.Void UnityEngine.UIElements.PointerDispatchState::ActivateCompatibilityMouseEvents(System.Int32)
extern void PointerDispatchState_ActivateCompatibilityMouseEvents_m06BDE68275511A6A5AAA7071CE690CCDA1231C0B (void);
// 0x000000D0 System.Void UnityEngine.UIElements.PointerDispatchState::PreventCompatibilityMouseEvents(System.Int32)
extern void PointerDispatchState_PreventCompatibilityMouseEvents_m1AEC8D2673CB99BEE674E7C41FC233359F09C0F4 (void);
// 0x000000D1 System.Boolean UnityEngine.UIElements.PointerDispatchState::ShouldSendCompatibilityMouseEvents(UnityEngine.UIElements.IPointerEvent)
extern void PointerDispatchState_ShouldSendCompatibilityMouseEvents_m8E3B674A0253A02696052101986B72FC0FA980DB (void);
// 0x000000D2 System.Void UnityEngine.UIElements.IScheduler::Unschedule(UnityEngine.UIElements.ScheduledItem)
// 0x000000D3 System.Void UnityEngine.UIElements.IScheduler::Schedule(UnityEngine.UIElements.ScheduledItem)
// 0x000000D4 System.Void UnityEngine.UIElements.ScheduledItem::set_startMs(System.Int64)
extern void ScheduledItem_set_startMs_m6842F7126F6A114BC1D0069131B774C8D819CCDE (void);
// 0x000000D5 System.Void UnityEngine.UIElements.ScheduledItem::.ctor()
extern void ScheduledItem__ctor_m756F18760E06D20D65B9E31BE6B187CA34425551 (void);
// 0x000000D6 System.Void UnityEngine.UIElements.ScheduledItem::ResetStartTime()
extern void ScheduledItem_ResetStartTime_mB99EC01A8CE8FF074BAB5E46675E6A53EABD5CF8 (void);
// 0x000000D7 System.Void UnityEngine.UIElements.ScheduledItem::OnItemUnscheduled()
extern void ScheduledItem_OnItemUnscheduled_mF3738B5D249F7C3FDB949ADBE93AF97464655748 (void);
// 0x000000D8 System.Void UnityEngine.UIElements.ScheduledItem::.cctor()
extern void ScheduledItem__cctor_mD5F57B2AB9A6FD7DD8AA2AD61C52DA4EC3022F91 (void);
// 0x000000D9 System.Void UnityEngine.UIElements.ScheduledItem/<>c::.cctor()
extern void U3CU3Ec__cctor_mC60D9667AFDB517D1E71AEB3A1DDF740E988301D (void);
// 0x000000DA System.Void UnityEngine.UIElements.ScheduledItem/<>c::.ctor()
extern void U3CU3Ec__ctor_m4241F9DB8E37E7CECCDEEA3406FFDA8EF57A6A4F (void);
// 0x000000DB System.Boolean UnityEngine.UIElements.ScheduledItem/<>c::<.cctor>b__25_0()
extern void U3CU3Ec_U3C_cctorU3Eb__25_0_m99215A05B153711A7FD22F9A0FD8BF1EC71F10C3 (void);
// 0x000000DC System.Boolean UnityEngine.UIElements.ScheduledItem/<>c::<.cctor>b__25_1()
extern void U3CU3Ec_U3C_cctorU3Eb__25_1_m84BEA02ED1C405C59E4A69413CE5362EF2ED90CB (void);
// 0x000000DD System.Void UnityEngine.UIElements.TimerEventScheduler::Schedule(UnityEngine.UIElements.ScheduledItem)
extern void TimerEventScheduler_Schedule_m646D29C19E0E4B88279F5A18DB0030263D852A11 (void);
// 0x000000DE System.Boolean UnityEngine.UIElements.TimerEventScheduler::RemovedScheduledItemAt(System.Int32)
extern void TimerEventScheduler_RemovedScheduledItemAt_m90ADCFB291028D1EA23BC521DEF0DDE534BEBB2D (void);
// 0x000000DF System.Void UnityEngine.UIElements.TimerEventScheduler::Unschedule(UnityEngine.UIElements.ScheduledItem)
extern void TimerEventScheduler_Unschedule_m0CFD128FFC0E0106F4721D59D21943BCAD69FE19 (void);
// 0x000000E0 System.Boolean UnityEngine.UIElements.TimerEventScheduler::PrivateUnSchedule(UnityEngine.UIElements.ScheduledItem)
extern void TimerEventScheduler_PrivateUnSchedule_m12C1AD493BA6C9CEEC9C28DC7C463238A04661E9 (void);
// 0x000000E1 System.Void UnityEngine.UIElements.TimerEventScheduler::.ctor()
extern void TimerEventScheduler__ctor_mF63D9637F967224988089244834C3B5CA3968E81 (void);
// 0x000000E2 System.Boolean UnityEngine.UIElements.TextShadow::Equals(System.Object)
extern void TextShadow_Equals_m9F22E055311CEF3A21E4AB2B3BF66D67F61C7918 (void);
// 0x000000E3 System.Boolean UnityEngine.UIElements.TextShadow::Equals(UnityEngine.UIElements.TextShadow)
extern void TextShadow_Equals_m293B417AFF54CEAF53B45AB850ABF8659F828165 (void);
// 0x000000E4 System.Int32 UnityEngine.UIElements.TextShadow::GetHashCode()
extern void TextShadow_GetHashCode_m12B9A1BF70F328130924AAA64C5405233FFD8050 (void);
// 0x000000E5 System.Boolean UnityEngine.UIElements.TextShadow::op_Equality(UnityEngine.UIElements.TextShadow,UnityEngine.UIElements.TextShadow)
extern void TextShadow_op_Equality_m03809E137A2951ED4164421E72FB060FED09207C (void);
// 0x000000E6 System.String UnityEngine.UIElements.TextShadow::ToString()
extern void TextShadow_ToString_mB02E43753C499E391F39F01C20084E8AA251BE7B (void);
// 0x000000E7 System.Void UnityEngine.UIElements.UIElementsPackageUtility::.cctor()
extern void UIElementsPackageUtility__cctor_m33D967855FCD0B3B13E34FA175E5E569DFD07F6A (void);
// 0x000000E8 System.Void UnityEngine.UIElements.UIElementsRuntimeUtility::add_onCreatePanel(System.Action`1<UnityEngine.UIElements.BaseRuntimePanel>)
extern void UIElementsRuntimeUtility_add_onCreatePanel_mBC5FE203D52F506AACB17DB3BF6FB7D70DCA6C26 (void);
// 0x000000E9 System.Void UnityEngine.UIElements.UIElementsRuntimeUtility::remove_onCreatePanel(System.Action`1<UnityEngine.UIElements.BaseRuntimePanel>)
extern void UIElementsRuntimeUtility_remove_onCreatePanel_m890B1702B239817C18DCA3267FC0E4A3711F38E5 (void);
// 0x000000EA System.Void UnityEngine.UIElements.UIElementsRuntimeUtility::.cctor()
extern void UIElementsRuntimeUtility__cctor_m939E07004D08E7142D53B77151F61ACA735ABF13 (void);
// 0x000000EB System.Void UnityEngine.UIElements.UIElementsRuntimeUtility::RepaintOverlayPanels()
extern void UIElementsRuntimeUtility_RepaintOverlayPanels_m6D76DE142375920666B28618B12651B7A4CDAC5C (void);
// 0x000000EC System.Void UnityEngine.UIElements.UIElementsRuntimeUtility::RepaintOverlayPanel(UnityEngine.UIElements.BaseRuntimePanel)
extern void UIElementsRuntimeUtility_RepaintOverlayPanel_m73DB3F8A9AB93065C6C5F5A6E7C3AE75B087C4EE (void);
// 0x000000ED UnityEngine.Object UnityEngine.UIElements.UIElementsRuntimeUtility::get_activeEventSystem()
extern void UIElementsRuntimeUtility_get_activeEventSystem_mB553CD0C404232075D7D464B820178CD4395FB60 (void);
// 0x000000EE System.Void UnityEngine.UIElements.UIElementsRuntimeUtility::set_activeEventSystem(UnityEngine.Object)
extern void UIElementsRuntimeUtility_set_activeEventSystem_mADEA322BB28902A549098C400A808AB5567E99C3 (void);
// 0x000000EF System.Void UnityEngine.UIElements.UIElementsRuntimeUtility::RegisterEventSystem(UnityEngine.Object)
extern void UIElementsRuntimeUtility_RegisterEventSystem_mC891BB0DE95040D0443CF37DA2BE88FA530EFBCD (void);
// 0x000000F0 System.Void UnityEngine.UIElements.UIElementsRuntimeUtility::UnregisterEventSystem(UnityEngine.Object)
extern void UIElementsRuntimeUtility_UnregisterEventSystem_m2FEC8D77B57F3FCAFE04C4017A3F48623AD99147 (void);
// 0x000000F1 System.Collections.Generic.List`1<UnityEngine.UIElements.Panel> UnityEngine.UIElements.UIElementsRuntimeUtility::GetSortedPlayerPanels()
extern void UIElementsRuntimeUtility_GetSortedPlayerPanels_m94938DF53D3B8A41892B12295D786B6DB336AE5F (void);
// 0x000000F2 System.Void UnityEngine.UIElements.UIElementsRuntimeUtility::SortPanels()
extern void UIElementsRuntimeUtility_SortPanels_m37C97CC304F594C53C1D60F596251D5668AD48EE (void);
// 0x000000F3 System.Void UnityEngine.UIElements.UIElementsRuntimeUtility/<>c::.cctor()
extern void U3CU3Ec__cctor_m68BAB78A0C4600E269BC0706BB751D3CEF9F08D0 (void);
// 0x000000F4 System.Void UnityEngine.UIElements.UIElementsRuntimeUtility/<>c::.ctor()
extern void U3CU3Ec__ctor_m979877505A27D176787C097A0BB892BD21D65FDE (void);
// 0x000000F5 System.Int32 UnityEngine.UIElements.UIElementsRuntimeUtility/<>c::<SortPanels>b__43_0(UnityEngine.UIElements.Panel,UnityEngine.UIElements.Panel)
extern void U3CU3Ec_U3CSortPanelsU3Eb__43_0_mB0C5A4B7F1CD9700B696CA7D9B8422CFBAAB2332 (void);
// 0x000000F6 System.Boolean UnityEngine.UIElements.IUIElementsUtility::TakeCapture()
// 0x000000F7 System.Boolean UnityEngine.UIElements.IUIElementsUtility::ReleaseCapture()
// 0x000000F8 System.Boolean UnityEngine.UIElements.IUIElementsUtility::ProcessEvent(System.Int32,System.IntPtr,System.Boolean&)
// 0x000000F9 System.Boolean UnityEngine.UIElements.IUIElementsUtility::CleanupRoots()
// 0x000000FA System.Boolean UnityEngine.UIElements.IUIElementsUtility::EndContainerGUIFromException(System.Exception)
// 0x000000FB System.Boolean UnityEngine.UIElements.IUIElementsUtility::MakeCurrentIMGUIContainerDirty()
// 0x000000FC System.Void UnityEngine.UIElements.UIEventRegistration::.cctor()
extern void UIEventRegistration__cctor_mFD7B1CB72ED798E586C3C36D229F8477BBE1A4F0 (void);
// 0x000000FD System.Void UnityEngine.UIElements.UIEventRegistration::RegisterUIElementSystem(UnityEngine.UIElements.IUIElementsUtility)
extern void UIEventRegistration_RegisterUIElementSystem_mA03AC93A6BA67C277466234518C7C9C4444D1694 (void);
// 0x000000FE System.Void UnityEngine.UIElements.UIEventRegistration::TakeCapture()
extern void UIEventRegistration_TakeCapture_mA619C455ACC7F479AF17A9AF2221F4713AD37C84 (void);
// 0x000000FF System.Void UnityEngine.UIElements.UIEventRegistration::ReleaseCapture()
extern void UIEventRegistration_ReleaseCapture_mCB9497D68888E7A264DC7F9AA5989D0C276AB4E8 (void);
// 0x00000100 System.Boolean UnityEngine.UIElements.UIEventRegistration::EndContainerGUIFromException(System.Exception)
extern void UIEventRegistration_EndContainerGUIFromException_mE9F7538B7D0CC32C2D3FB92C6024D73D6FEDCB7B (void);
// 0x00000101 System.Boolean UnityEngine.UIElements.UIEventRegistration::ProcessEvent(System.Int32,System.IntPtr)
extern void UIEventRegistration_ProcessEvent_m4E686D1E3C90ADEE581CEA536437269EF85D3435 (void);
// 0x00000102 System.Void UnityEngine.UIElements.UIEventRegistration::CleanupRoots()
extern void UIEventRegistration_CleanupRoots_mBC0B207BBB9954E6914DDA84E560953948380E4C (void);
// 0x00000103 System.Void UnityEngine.UIElements.UIEventRegistration::MakeCurrentIMGUIContainerDirty()
extern void UIEventRegistration_MakeCurrentIMGUIContainerDirty_mB332BE310D3C69A42BADECF4EB75252753EA472C (void);
// 0x00000104 System.Void UnityEngine.UIElements.UIEventRegistration/<>c::.cctor()
extern void U3CU3Ec__cctor_m39CD29EF2AAA2DE5A62DD2A5B42052386A16F8DC (void);
// 0x00000105 System.Void UnityEngine.UIElements.UIEventRegistration/<>c::.ctor()
extern void U3CU3Ec__ctor_m8173E517B38C5D4665E58BE36F01E1AED62A9BBA (void);
// 0x00000106 System.Void UnityEngine.UIElements.UIEventRegistration/<>c::<.cctor>b__1_0()
extern void U3CU3Ec_U3C_cctorU3Eb__1_0_m1276BB1D8BE532589C69B9EF7FF6F46950CB2FFF (void);
// 0x00000107 System.Void UnityEngine.UIElements.UIEventRegistration/<>c::<.cctor>b__1_1()
extern void U3CU3Ec_U3C_cctorU3Eb__1_1_mE27A9FAE95C7D8556DF476FC672CE8656C30F68D (void);
// 0x00000108 System.Boolean UnityEngine.UIElements.UIEventRegistration/<>c::<.cctor>b__1_2(System.Int32,System.IntPtr)
extern void U3CU3Ec_U3C_cctorU3Eb__1_2_mC9EB4AFC634837113778B826633482A993AE25F6 (void);
// 0x00000109 System.Void UnityEngine.UIElements.UIEventRegistration/<>c::<.cctor>b__1_3()
extern void U3CU3Ec_U3C_cctorU3Eb__1_3_mE25A61ED9B86A7BF471F2971C9C10E18CA189785 (void);
// 0x0000010A System.Boolean UnityEngine.UIElements.UIEventRegistration/<>c::<.cctor>b__1_4(System.Exception)
extern void U3CU3Ec_U3C_cctorU3Eb__1_4_m0B10AA421E0CE4476EEE7AF813AE5632C0C52824 (void);
// 0x0000010B System.Void UnityEngine.UIElements.UIEventRegistration/<>c::<.cctor>b__1_5()
extern void U3CU3Ec_U3C_cctorU3Eb__1_5_mA465B970669D77B7B5BB638A32D6C927DF7EA030 (void);
// 0x0000010C System.Void UnityEngine.UIElements.UIElementsUtility::.ctor()
extern void UIElementsUtility__ctor_m7B909BD0BC62D88CC3F453F71C3E98C72823FCF5 (void);
// 0x0000010D System.Boolean UnityEngine.UIElements.UIElementsUtility::UnityEngine.UIElements.IUIElementsUtility.MakeCurrentIMGUIContainerDirty()
extern void UIElementsUtility_UnityEngine_UIElements_IUIElementsUtility_MakeCurrentIMGUIContainerDirty_mE2662C98FF9702421C9729DB1DA934B6517A4B6B (void);
// 0x0000010E System.Boolean UnityEngine.UIElements.UIElementsUtility::UnityEngine.UIElements.IUIElementsUtility.TakeCapture()
extern void UIElementsUtility_UnityEngine_UIElements_IUIElementsUtility_TakeCapture_mEC113CAA67F6EA16F9017CC523731F04A532A4CC (void);
// 0x0000010F System.Boolean UnityEngine.UIElements.UIElementsUtility::UnityEngine.UIElements.IUIElementsUtility.ReleaseCapture()
extern void UIElementsUtility_UnityEngine_UIElements_IUIElementsUtility_ReleaseCapture_m34B950938F1006FD7DFEA7E23AAB2DCAB1FD5447 (void);
// 0x00000110 System.Boolean UnityEngine.UIElements.UIElementsUtility::UnityEngine.UIElements.IUIElementsUtility.ProcessEvent(System.Int32,System.IntPtr,System.Boolean&)
extern void UIElementsUtility_UnityEngine_UIElements_IUIElementsUtility_ProcessEvent_m5BD45422AE537AE7058FA78E2CD6429A99ADE8A2 (void);
// 0x00000111 System.Boolean UnityEngine.UIElements.UIElementsUtility::UnityEngine.UIElements.IUIElementsUtility.CleanupRoots()
extern void UIElementsUtility_UnityEngine_UIElements_IUIElementsUtility_CleanupRoots_m40CDABEF3CF3F206E5324C4BF37F81FA21DA04AE (void);
// 0x00000112 System.Boolean UnityEngine.UIElements.UIElementsUtility::UnityEngine.UIElements.IUIElementsUtility.EndContainerGUIFromException(System.Exception)
extern void UIElementsUtility_UnityEngine_UIElements_IUIElementsUtility_EndContainerGUIFromException_m034AD89EC020D1072B20555A24C3D453A7837DE5 (void);
// 0x00000113 System.Void UnityEngine.UIElements.UIElementsUtility::RemoveCachedPanel(System.Int32)
extern void UIElementsUtility_RemoveCachedPanel_mEF6C58EA19A301A524A4442F6405A4DFBC1794AE (void);
// 0x00000114 System.Void UnityEngine.UIElements.UIElementsUtility::BeginContainerGUI(UnityEngine.GUILayoutUtility/LayoutCache,UnityEngine.Event,UnityEngine.UIElements.IMGUIContainer)
extern void UIElementsUtility_BeginContainerGUI_m5783968AA983119AEDBFAD6BD6079829FAEAFCB1 (void);
// 0x00000115 System.Void UnityEngine.UIElements.UIElementsUtility::EndContainerGUI(UnityEngine.Event,UnityEngine.Rect)
extern void UIElementsUtility_EndContainerGUI_m946871CB9D25AC18D6184F310F5F4668653CE828 (void);
// 0x00000116 UnityEngine.UIElements.EventBase UnityEngine.UIElements.UIElementsUtility::CreateEvent(UnityEngine.Event)
extern void UIElementsUtility_CreateEvent_m7A51F79B29D5324A89E5569B46DAA3AE50ADE47D (void);
// 0x00000117 UnityEngine.UIElements.EventBase UnityEngine.UIElements.UIElementsUtility::CreateEvent(UnityEngine.Event,UnityEngine.EventType)
extern void UIElementsUtility_CreateEvent_mA60531DDC5A989C3275CF93EB627150E3CEB3A74 (void);
// 0x00000118 System.Boolean UnityEngine.UIElements.UIElementsUtility::DoDispatch(UnityEngine.UIElements.BaseVisualElementPanel)
extern void UIElementsUtility_DoDispatch_mEDAD415A4F5F82C78923CE68FF526AEDB0E3E9DD (void);
// 0x00000119 System.Void UnityEngine.UIElements.UIElementsUtility::GetAllPanels(System.Collections.Generic.List`1<UnityEngine.UIElements.Panel>,UnityEngine.UIElements.ContextType)
extern void UIElementsUtility_GetAllPanels_m3ADEC830E8AD51FAB21608B34F7D974CF1BB2C73 (void);
// 0x0000011A System.Collections.Generic.Dictionary`2/Enumerator<System.Int32,UnityEngine.UIElements.Panel> UnityEngine.UIElements.UIElementsUtility::GetPanelsIterator()
extern void UIElementsUtility_GetPanelsIterator_m7F8B7AF85117D366681C02F0AAE74D9D176F470E (void);
// 0x0000011B System.Void UnityEngine.UIElements.UIElementsUtility::.cctor()
extern void UIElementsUtility__cctor_mF292D98B5BC608EE666F2571EB833949490FE9DE (void);
// 0x0000011C System.Collections.Generic.List`1<UnityEngine.UIElements.VisualElement> UnityEngine.UIElements.VisualElementListPool::Get(System.Int32)
extern void VisualElementListPool_Get_m2E8B0CCB6C110C9B817A734738C588407305F11A (void);
// 0x0000011D System.Void UnityEngine.UIElements.VisualElementListPool::Release(System.Collections.Generic.List`1<UnityEngine.UIElements.VisualElement>)
extern void VisualElementListPool_Release_m4E9C1625C6852CAE8C11F5390AC6972F3DB57C53 (void);
// 0x0000011E System.Void UnityEngine.UIElements.VisualElementListPool::.cctor()
extern void VisualElementListPool__cctor_m4C69F99404448E1A81EA4B119CFC35AA8282154E (void);
// 0x0000011F System.Collections.Generic.List`1<T> UnityEngine.UIElements.ObjectListPool`1::Get()
// 0x00000120 System.Void UnityEngine.UIElements.ObjectListPool`1::Release(System.Collections.Generic.List`1<T>)
// 0x00000121 System.Void UnityEngine.UIElements.ObjectListPool`1::.cctor()
// 0x00000122 System.Boolean UnityEngine.UIElements.VisualElement::get_isCompositeRoot()
extern void VisualElement_get_isCompositeRoot_m889DC20180458B9CCA010BC204D6AFB1D03C437E (void);
// 0x00000123 UnityEngine.UIElements.FocusController UnityEngine.UIElements.VisualElement::get_focusController()
extern void VisualElement_get_focusController_mAC0559C7F4549ADFDF342C4062B5A22242F1B098 (void);
// 0x00000124 System.Boolean UnityEngine.UIElements.VisualElement::get_isLayoutManual()
extern void VisualElement_get_isLayoutManual_mB50AE7DC815D10B9FF46E331F0304E9FAFDF2149 (void);
// 0x00000125 UnityEngine.Rect UnityEngine.UIElements.VisualElement::get_layout()
extern void VisualElement_get_layout_mDAE3AD984D0CE9D7B4F92518051D2060EA928E79 (void);
// 0x00000126 System.Boolean UnityEngine.UIElements.VisualElement::get_isBoundingBoxDirty()
extern void VisualElement_get_isBoundingBoxDirty_m0A2C105391965AF78B2B456B2C92CEF569CE74D5 (void);
// 0x00000127 System.Void UnityEngine.UIElements.VisualElement::set_isBoundingBoxDirty(System.Boolean)
extern void VisualElement_set_isBoundingBoxDirty_mC7088003B6CF7829D9508828DBF85B1E749459AD (void);
// 0x00000128 System.Boolean UnityEngine.UIElements.VisualElement::get_isWorldBoundingBoxDirty()
extern void VisualElement_get_isWorldBoundingBoxDirty_m8B726BAC627506AF9D68E52BDE1E76B99162B9BC (void);
// 0x00000129 System.Void UnityEngine.UIElements.VisualElement::set_isWorldBoundingBoxDirty(System.Boolean)
extern void VisualElement_set_isWorldBoundingBoxDirty_m459A1315B443D5200AE1D8199121E8B265E2BFF7 (void);
// 0x0000012A UnityEngine.Rect UnityEngine.UIElements.VisualElement::get_boundingBox()
extern void VisualElement_get_boundingBox_m9738D6C756683E78721C3048E3E59FFAD354CE6F (void);
// 0x0000012B UnityEngine.Rect UnityEngine.UIElements.VisualElement::get_worldBoundingBox()
extern void VisualElement_get_worldBoundingBox_m82BAFF4780B0D9D902B527358F243141ABC7F1ED (void);
// 0x0000012C UnityEngine.Rect UnityEngine.UIElements.VisualElement::get_boundingBoxInParentSpace()
extern void VisualElement_get_boundingBoxInParentSpace_m0E278A8F1E5F9121DD8B9A5AD9AF5C7A185113EC (void);
// 0x0000012D System.Void UnityEngine.UIElements.VisualElement::UpdateBoundingBox()
extern void VisualElement_UpdateBoundingBox_m27F9996B7AF1EB566CFA60735FE6AAC11CBF8E5F (void);
// 0x0000012E System.Void UnityEngine.UIElements.VisualElement::UpdateWorldBoundingBox()
extern void VisualElement_UpdateWorldBoundingBox_m62DADBD4F85C83F6DDA0D81C63DC1BEF14C8C182 (void);
// 0x0000012F UnityEngine.Rect UnityEngine.UIElements.VisualElement::get_worldBound()
extern void VisualElement_get_worldBound_mC221843EE8E209555CAC96D4F99C93B17DC4057D (void);
// 0x00000130 UnityEngine.Rect UnityEngine.UIElements.VisualElement::get_rect()
extern void VisualElement_get_rect_m4E4FDC471C507245F3E552D45A32A6A7A92A4480 (void);
// 0x00000131 System.Boolean UnityEngine.UIElements.VisualElement::get_isWorldTransformDirty()
extern void VisualElement_get_isWorldTransformDirty_m4C8DE186B4C0F27424E9F0D88B92D88483EDCEAA (void);
// 0x00000132 System.Void UnityEngine.UIElements.VisualElement::set_isWorldTransformDirty(System.Boolean)
extern void VisualElement_set_isWorldTransformDirty_m32730E4295A6A4E6FEFD384DB9D91C8EB67827C8 (void);
// 0x00000133 System.Boolean UnityEngine.UIElements.VisualElement::get_isWorldTransformInverseDirty()
extern void VisualElement_get_isWorldTransformInverseDirty_m2B2001D300C6423AE04DE2EDC633AADF7D1FB423 (void);
// 0x00000134 System.Void UnityEngine.UIElements.VisualElement::set_isWorldTransformInverseDirty(System.Boolean)
extern void VisualElement_set_isWorldTransformInverseDirty_m175871A577D104D7C9380B9C1A078515813163A8 (void);
// 0x00000135 UnityEngine.Matrix4x4 UnityEngine.UIElements.VisualElement::get_worldTransform()
extern void VisualElement_get_worldTransform_m2328FC02A3E7FA5483DF43E90F91E566F728B1D9 (void);
// 0x00000136 UnityEngine.Matrix4x4& UnityEngine.UIElements.VisualElement::get_worldTransformRef()
extern void VisualElement_get_worldTransformRef_m9960B2E350D4327C1E6173D59D8FC91507402F37 (void);
// 0x00000137 UnityEngine.Matrix4x4& UnityEngine.UIElements.VisualElement::get_worldTransformInverse()
extern void VisualElement_get_worldTransformInverse_m692FAAB9BC3E9351A10C5229786BF6EB6AC34A46 (void);
// 0x00000138 System.Void UnityEngine.UIElements.VisualElement::UpdateWorldTransform()
extern void VisualElement_UpdateWorldTransform_m7522C78C8ECA1D6C68D540A070ABD033925CA1FE (void);
// 0x00000139 System.Void UnityEngine.UIElements.VisualElement::UpdateWorldTransformInverse()
extern void VisualElement_UpdateWorldTransformInverse_m82FBF5BC23EE81DAC94B4CE3B4D5EE1DE21577EB (void);
// 0x0000013A UnityEngine.UIElements.PseudoStates UnityEngine.UIElements.VisualElement::get_pseudoStates()
extern void VisualElement_get_pseudoStates_mF0B31C86C3CF44C4FA2F42F7641DAF33C9F4B736 (void);
// 0x0000013B UnityEngine.UIElements.PickingMode UnityEngine.UIElements.VisualElement::get_pickingMode()
extern void VisualElement_get_pickingMode_m941A6399B8BC544A8C516A157EE677369FD2D5F8 (void);
// 0x0000013C UnityEngine.Yoga.YogaNode UnityEngine.UIElements.VisualElement::get_yogaNode()
extern void VisualElement_get_yogaNode_m5CA07AF1958F42E7831FA71C571449B659290A93 (void);
// 0x0000013D UnityEngine.UIElements.ComputedStyle UnityEngine.UIElements.VisualElement::get_computedStyle()
extern void VisualElement_get_computedStyle_m1B4DA56E8F0A56EE2FF03AD1020DC803A01CF4C8 (void);
// 0x0000013E System.Void UnityEngine.UIElements.VisualElement::SendEvent(UnityEngine.UIElements.EventBase)
extern void VisualElement_SendEvent_mE8299D39D5A55DDDB5C079CAD8A265F2E46BD958 (void);
// 0x0000013F System.Void UnityEngine.UIElements.VisualElement::IncrementVersion(UnityEngine.UIElements.VersionChangeType)
extern void VisualElement_IncrementVersion_mB583875ADC5D9BD3DC7CAA49722BBFD617A16477 (void);
// 0x00000140 System.Boolean UnityEngine.UIElements.VisualElement::get_enabledInHierarchy()
extern void VisualElement_get_enabledInHierarchy_mA94B8F82641FD0CEBA18B9BA27FCA33F14F8FD97 (void);
// 0x00000141 System.Boolean UnityEngine.UIElements.VisualElement::get_visible()
extern void VisualElement_get_visible_mAB6E36F62562D0577D2F62E68EAAF101F279DBAC (void);
// 0x00000142 System.Boolean UnityEngine.UIElements.VisualElement::ContainsPoint(UnityEngine.Vector2)
extern void VisualElement_ContainsPoint_m282678268DA39084B61AB2EC601EC79071AE9C31 (void);
// 0x00000143 UnityEngine.UIElements.VisualElement/Hierarchy UnityEngine.UIElements.VisualElement::get_hierarchy()
extern void VisualElement_get_hierarchy_m4B2AD83FE8FA93302B534E4EF77E356901F1A90A (void);
// 0x00000144 System.Boolean UnityEngine.UIElements.VisualElement::get_disableClipping()
extern void VisualElement_get_disableClipping_m7AEDB8630B1E94831BC3EA00228EA58B348B1A38 (void);
// 0x00000145 System.Boolean UnityEngine.UIElements.VisualElement::ShouldClip()
extern void VisualElement_ShouldClip_m4003A9EA0539E41681D50ABF24AC714A5737D179 (void);
// 0x00000146 UnityEngine.UIElements.BaseVisualElementPanel UnityEngine.UIElements.VisualElement::get_elementPanel()
extern void VisualElement_get_elementPanel_mC3F8CF4D43D0C5841CCCB92D5A95398065B7282C (void);
// 0x00000147 UnityEngine.UIElements.IPanel UnityEngine.UIElements.VisualElement::get_panel()
extern void VisualElement_get_panel_m8362331515135E7044CECFED9260FAA1EBD53E43 (void);
// 0x00000148 UnityEngine.UIElements.VisualElement UnityEngine.UIElements.VisualElement::get_contentContainer()
extern void VisualElement_get_contentContainer_m9AEB8A806ED94BA748041BB3421E1C22B0D0897B (void);
// 0x00000149 UnityEngine.UIElements.VisualElement UnityEngine.UIElements.VisualElement::FindCommonAncestor(UnityEngine.UIElements.VisualElement)
extern void VisualElement_FindCommonAncestor_mB165E7F21BC9C527E596783A072BFC01812CA884 (void);
// 0x0000014A UnityEngine.UIElements.VisualElement UnityEngine.UIElements.VisualElement::RetargetElement(UnityEngine.UIElements.VisualElement)
extern void VisualElement_RetargetElement_m123AA4EF0C544681D449BEA23D4046048F9B47CA (void);
// 0x0000014B UnityEngine.Vector3 UnityEngine.UIElements.VisualElement::get_positionWithLayout()
extern void VisualElement_get_positionWithLayout_mD14565DE33EEB2AD579D1ED8B18DB657A22DBB06 (void);
// 0x0000014C UnityEngine.Matrix4x4 UnityEngine.UIElements.VisualElement::get_matrixWithLayout()
extern void VisualElement_get_matrixWithLayout_mE83663BFD6474B8E7DD4600C19B67792E3B91C91 (void);
// 0x0000014D System.Void UnityEngine.UIElements.VisualElement::TransformAlignedRect(UnityEngine.Rect&)
extern void VisualElement_TransformAlignedRect_mE59EDF0EA19E62964E8E536214CE187C7C5A4615 (void);
// 0x0000014E System.Void UnityEngine.UIElements.VisualElement::TransformAlignedRect(UnityEngine.Matrix4x4&,UnityEngine.Rect&)
extern void VisualElement_TransformAlignedRect_m5C0CAC1A54F2609BB47CC13B668E1D8F1612DB5D (void);
// 0x0000014F System.Void UnityEngine.UIElements.VisualElement::OrderMinMaxRect(UnityEngine.Rect&)
extern void VisualElement_OrderMinMaxRect_mB35FA4EDEC667B393914818AE2926691FCC87052 (void);
// 0x00000150 UnityEngine.Vector2 UnityEngine.UIElements.VisualElement::MultiplyMatrix44Point2(UnityEngine.Matrix4x4&,UnityEngine.Vector2)
extern void VisualElement_MultiplyMatrix44Point2_mA3E8672F4224D072A40F21FE425C5777B631F0DF (void);
// 0x00000151 UnityEngine.Vector2 UnityEngine.UIElements.VisualElement::MultiplyVector2(UnityEngine.Matrix4x4&,UnityEngine.Vector2)
extern void VisualElement_MultiplyVector2_m998F0401A4D7B338A355EF5944A9EA8B496197A0 (void);
// 0x00000152 System.Void UnityEngine.UIElements.VisualElement::MultiplyMatrix34(UnityEngine.Matrix4x4&,UnityEngine.Matrix4x4&,UnityEngine.Matrix4x4&)
extern void VisualElement_MultiplyMatrix34_m3E6174DBB758ED4EC69BA129A97367472F79415D (void);
// 0x00000153 UnityEngine.UIElements.IVisualElementScheduler UnityEngine.UIElements.VisualElement::get_schedule()
extern void VisualElement_get_schedule_mF41FC0F87DBDA94CBE816C8341159956E4E0065F (void);
// 0x00000154 UnityEngine.UIElements.IVisualElementScheduledItem UnityEngine.UIElements.VisualElement::UnityEngine.UIElements.IVisualElementScheduler.Execute(System.Action)
extern void VisualElement_UnityEngine_UIElements_IVisualElementScheduler_Execute_m2ED6DE1F4D45B758506009167CDDE0AD35CCCBA0 (void);
// 0x00000155 UnityEngine.UIElements.IResolvedStyle UnityEngine.UIElements.VisualElement::get_resolvedStyle()
extern void VisualElement_get_resolvedStyle_mA04F20686F08336054580BABA585416DE1D2071F (void);
// 0x00000156 UnityEngine.UIElements.DisplayStyle UnityEngine.UIElements.VisualElement::UnityEngine.UIElements.IResolvedStyle.get_display()
extern void VisualElement_UnityEngine_UIElements_IResolvedStyle_get_display_m647045B0AA08BBB6121BA4D8F8866388222893E6 (void);
// 0x00000157 UnityEngine.UIElements.Visibility UnityEngine.UIElements.VisualElement::UnityEngine.UIElements.IResolvedStyle.get_visibility()
extern void VisualElement_UnityEngine_UIElements_IResolvedStyle_get_visibility_mDF08FC3BF23AA2F766AE117AD1B8952ACA223825 (void);
// 0x00000158 System.Void UnityEngine.UIElements.VisualElement::.cctor()
extern void VisualElement__cctor_m44215ACB2EE76BE1FC750838A9595AF230284049 (void);
// 0x00000159 UnityEngine.UIElements.VisualElement UnityEngine.UIElements.VisualElement/Hierarchy::get_parent()
extern void Hierarchy_get_parent_m95543CF2F0974BC89228441F8789764F6F10F502 (void);
// 0x0000015A System.Int32 UnityEngine.UIElements.VisualElement/Hierarchy::get_childCount()
extern void Hierarchy_get_childCount_m53DC6BD1E3F83390D53D5DF31EEBB68EA533DE56 (void);
// 0x0000015B UnityEngine.UIElements.VisualElement UnityEngine.UIElements.VisualElement/Hierarchy::get_Item(System.Int32)
extern void Hierarchy_get_Item_mC13B7FAA90B9AB3295560406C5223DB80046D6FA (void);
// 0x0000015C System.Boolean UnityEngine.UIElements.VisualElement/Hierarchy::Equals(UnityEngine.UIElements.VisualElement/Hierarchy)
extern void Hierarchy_Equals_mD61D088EAA5FF9E5EB5FC51C8443890382D342F0 (void);
// 0x0000015D System.Boolean UnityEngine.UIElements.VisualElement/Hierarchy::Equals(System.Object)
extern void Hierarchy_Equals_m4E001F4C66AF4D844E883AAE5BF761684695116D (void);
// 0x0000015E System.Int32 UnityEngine.UIElements.VisualElement/Hierarchy::GetHashCode()
extern void Hierarchy_GetHashCode_m07B0319B25E28C4473DD6F864553DDCC17EBD515 (void);
// 0x0000015F System.Boolean UnityEngine.UIElements.VisualElement/Hierarchy::op_Equality(UnityEngine.UIElements.VisualElement/Hierarchy,UnityEngine.UIElements.VisualElement/Hierarchy)
extern void Hierarchy_op_Equality_m643B32353437693227839E357274B0926FF44F78 (void);
// 0x00000160 UnityEngine.UIElements.VisualElement UnityEngine.UIElements.VisualElement/BaseVisualElementScheduledItem::get_element()
extern void BaseVisualElementScheduledItem_get_element_m68B5219A07633C6019E97AC594E8099269B2BB8C (void);
// 0x00000161 System.Void UnityEngine.UIElements.VisualElement/BaseVisualElementScheduledItem::set_element(UnityEngine.UIElements.VisualElement)
extern void BaseVisualElementScheduledItem_set_element_m3E1A847EAFF3AF3C249BB51B5ED1DA9E51247880 (void);
// 0x00000162 System.Void UnityEngine.UIElements.VisualElement/BaseVisualElementScheduledItem::.ctor(UnityEngine.UIElements.VisualElement)
extern void BaseVisualElementScheduledItem__ctor_mA49382DB1A844E129F3A372A2E0BC91F45DE88C1 (void);
// 0x00000163 System.Void UnityEngine.UIElements.VisualElement/BaseVisualElementScheduledItem::OnItemUnscheduled()
extern void BaseVisualElementScheduledItem_OnItemUnscheduled_m11212547146BD9846DE362BCD06BA2FD11262CDA (void);
// 0x00000164 System.Void UnityEngine.UIElements.VisualElement/BaseVisualElementScheduledItem::Resume()
extern void BaseVisualElementScheduledItem_Resume_m37F2B94DD6013D79EEB85342EFA2CE231AAC66D3 (void);
// 0x00000165 System.Void UnityEngine.UIElements.VisualElement/BaseVisualElementScheduledItem::OnPanelActivate()
extern void BaseVisualElementScheduledItem_OnPanelActivate_mCF07693CC148404E8E7CE12C90FA01720284C2A0 (void);
// 0x00000166 System.Void UnityEngine.UIElements.VisualElement/BaseVisualElementScheduledItem::OnPanelDeactivate()
extern void BaseVisualElementScheduledItem_OnPanelDeactivate_m226B026AEF6EBAB6B4BF8414EB26110D7E6F4691 (void);
// 0x00000167 System.Boolean UnityEngine.UIElements.VisualElement/BaseVisualElementScheduledItem::CanBeActivated()
extern void BaseVisualElementScheduledItem_CanBeActivated_mE36E839682A6C323B5624EBB8368D4FAC64F5FC0 (void);
// 0x00000168 System.Void UnityEngine.UIElements.VisualElement/VisualElementScheduledItem`1::.ctor(UnityEngine.UIElements.VisualElement,ActionType)
// 0x00000169 System.Void UnityEngine.UIElements.VisualElement/SimpleScheduledItem::.ctor(UnityEngine.UIElements.VisualElement,System.Action)
extern void SimpleScheduledItem__ctor_m53D11B49106C5F3DEB9FAF325C00180F1C2EAEBA (void);
// 0x0000016A UnityEngine.Vector2 UnityEngine.UIElements.VisualElementExtensions::WorldToLocal(UnityEngine.UIElements.VisualElement,UnityEngine.Vector2)
extern void VisualElementExtensions_WorldToLocal_m817AA6D587FA9723DB4F3580FBCD095DD7720595 (void);
// 0x0000016B UnityEngine.UIElements.FocusChangeDirection UnityEngine.UIElements.VisualElementFocusChangeDirection::get_left()
extern void VisualElementFocusChangeDirection_get_left_mA7F353435BEAE57EAFEBA75B86564432C03F085C (void);
// 0x0000016C UnityEngine.UIElements.FocusChangeDirection UnityEngine.UIElements.VisualElementFocusChangeDirection::get_right()
extern void VisualElementFocusChangeDirection_get_right_mD9B70FCE433CA74E5361FE74F7AA6A01B1248342 (void);
// 0x0000016D System.Void UnityEngine.UIElements.VisualElementFocusChangeDirection::.ctor(System.Int32)
extern void VisualElementFocusChangeDirection__ctor_mB497716BA2D8949EB060C21B154334919C967A87 (void);
// 0x0000016E System.Void UnityEngine.UIElements.VisualElementFocusChangeDirection::.cctor()
extern void VisualElementFocusChangeDirection__cctor_m075F66411EF46E9F51C1145568E4F87C0B18F553 (void);
// 0x0000016F UnityEngine.UIElements.IVisualElementScheduledItem UnityEngine.UIElements.IVisualElementScheduler::Execute(System.Action)
// 0x00000170 UnityEngine.UIElements.VisualElement UnityEngine.UIElements.IVisualElementPanelActivatable::get_element()
// 0x00000171 System.Boolean UnityEngine.UIElements.IVisualElementPanelActivatable::CanBeActivated()
// 0x00000172 System.Void UnityEngine.UIElements.IVisualElementPanelActivatable::OnPanelActivate()
// 0x00000173 System.Void UnityEngine.UIElements.IVisualElementPanelActivatable::OnPanelDeactivate()
// 0x00000174 System.Boolean UnityEngine.UIElements.VisualElementPanelActivator::get_isActive()
extern void VisualElementPanelActivator_get_isActive_mFA4041CC2963E5D2D88C63EA3836F496E2576398 (void);
// 0x00000175 System.Void UnityEngine.UIElements.VisualElementPanelActivator::set_isActive(System.Boolean)
extern void VisualElementPanelActivator_set_isActive_m729B25C8EAD4377C752D04390FD2AB9B38529E75 (void);
// 0x00000176 System.Boolean UnityEngine.UIElements.VisualElementPanelActivator::get_isDetaching()
extern void VisualElementPanelActivator_get_isDetaching_m2ED9B5DF7F9063215CD2F691C57FAAC16DD19CC5 (void);
// 0x00000177 System.Void UnityEngine.UIElements.VisualElementPanelActivator::set_isDetaching(System.Boolean)
extern void VisualElementPanelActivator_set_isDetaching_mD4CAC44FA31DC700177A11C4292D98241FD6AB79 (void);
// 0x00000178 System.Void UnityEngine.UIElements.VisualElementPanelActivator::.ctor(UnityEngine.UIElements.IVisualElementPanelActivatable)
extern void VisualElementPanelActivator__ctor_m6253EC6859136187CA2311B57401E1166D2B9084 (void);
// 0x00000179 System.Void UnityEngine.UIElements.VisualElementPanelActivator::SetActive(System.Boolean)
extern void VisualElementPanelActivator_SetActive_mEF62F79FC0D6B79A461EE131AB29E8285F5C8ADF (void);
// 0x0000017A System.Void UnityEngine.UIElements.VisualElementPanelActivator::SendActivation()
extern void VisualElementPanelActivator_SendActivation_mD4E51A6DCFF15A9DE50145C568F4232020B00B74 (void);
// 0x0000017B System.Void UnityEngine.UIElements.VisualElementPanelActivator::SendDeactivation()
extern void VisualElementPanelActivator_SendDeactivation_m40975D6281CF92F8CDC8C1C66E710774480B45CF (void);
// 0x0000017C System.Void UnityEngine.UIElements.VisualElementPanelActivator::OnEnter(UnityEngine.UIElements.AttachToPanelEvent)
extern void VisualElementPanelActivator_OnEnter_mAC503F7299D01BBEA727C19CDC54B86363A0E95D (void);
// 0x0000017D System.Void UnityEngine.UIElements.VisualElementPanelActivator::OnLeave(UnityEngine.UIElements.DetachFromPanelEvent)
extern void VisualElementPanelActivator_OnLeave_mE1768C69309EDBA85179252CB5C3949EC08D2620 (void);
// 0x0000017E System.Void UnityEngine.UIElements.VisualTreeUpdater::UpdateVisualTreePhase(UnityEngine.UIElements.VisualTreeUpdatePhase)
extern void VisualTreeUpdater_UpdateVisualTreePhase_m1D07B623D69CC03ED552CD0942C6B20C2E235897 (void);
// 0x0000017F System.Void UnityEngine.UIElements.VisualTreeUpdater::OnVersionChanged(UnityEngine.UIElements.VisualElement,UnityEngine.UIElements.VersionChangeType)
extern void VisualTreeUpdater_OnVersionChanged_mE8F69561A928E2801617B577AA92BC5E1210B865 (void);
// 0x00000180 UnityEngine.UIElements.IVisualTreeUpdater UnityEngine.UIElements.VisualTreeUpdater/UpdaterArray::get_Item(UnityEngine.UIElements.VisualTreeUpdatePhase)
extern void UpdaterArray_get_Item_mAFAF068DEE331E50496982E388FFF67A74092740 (void);
// 0x00000181 UnityEngine.UIElements.IVisualTreeUpdater UnityEngine.UIElements.VisualTreeUpdater/UpdaterArray::get_Item(System.Int32)
extern void UpdaterArray_get_Item_mFC61CA9A14C4F1C014BBBA565459E9377AE40AFD (void);
// 0x00000182 Unity.Profiling.ProfilerMarker UnityEngine.UIElements.IVisualTreeUpdater::get_profilerMarker()
// 0x00000183 System.Void UnityEngine.UIElements.IVisualTreeUpdater::Update()
// 0x00000184 System.Void UnityEngine.UIElements.IVisualTreeUpdater::OnVersionChanged(UnityEngine.UIElements.VisualElement,UnityEngine.UIElements.VersionChangeType)
// 0x00000185 System.Void UnityEngine.UIElements.Foldout::.cctor()
extern void Foldout__cctor_m94EAEF439C0FB19DE1B027EFD668ECB295364DE4 (void);
// 0x00000186 System.Void UnityEngine.UIElements.PointerCaptureEventBase`1::set_relatedTarget(UnityEngine.UIElements.IEventHandler)
// 0x00000187 System.Void UnityEngine.UIElements.PointerCaptureEventBase`1::set_pointerId(System.Int32)
// 0x00000188 System.Void UnityEngine.UIElements.PointerCaptureEventBase`1::Init()
// 0x00000189 System.Void UnityEngine.UIElements.PointerCaptureEventBase`1::LocalInit()
// 0x0000018A T UnityEngine.UIElements.PointerCaptureEventBase`1::GetPooled(UnityEngine.UIElements.IEventHandler,UnityEngine.UIElements.IEventHandler,System.Int32)
// 0x0000018B System.Void UnityEngine.UIElements.PointerCaptureEventBase`1::.ctor()
// 0x0000018C System.Void UnityEngine.UIElements.PointerCaptureOutEvent::.ctor()
extern void PointerCaptureOutEvent__ctor_m5C154DE31521FA590359379C0367B2AA46F5D48E (void);
// 0x0000018D System.Void UnityEngine.UIElements.PointerCaptureEvent::.ctor()
extern void PointerCaptureEvent__ctor_m2CD51742C0BCA6263D6E35BA5BB1EED232860591 (void);
// 0x0000018E System.Void UnityEngine.UIElements.MouseCaptureEventBase`1::Init()
// 0x0000018F System.Void UnityEngine.UIElements.MouseCaptureEventBase`1::.ctor()
// 0x00000190 System.Void UnityEngine.UIElements.MouseCaptureOutEvent::.ctor()
extern void MouseCaptureOutEvent__ctor_m28FC2BF08FB9814BEEC4D554AD18E6585DD2D0D0 (void);
// 0x00000191 System.Void UnityEngine.UIElements.MouseCaptureEvent::.ctor()
extern void MouseCaptureEvent__ctor_m3007A7F43189519CA0AAC3EE6F61699C5FFF23C3 (void);
// 0x00000192 System.Boolean UnityEngine.UIElements.CommandEventDispatchingStrategy::CanDispatchEvent(UnityEngine.UIElements.EventBase)
extern void CommandEventDispatchingStrategy_CanDispatchEvent_mFFC01C287248E1F67B9C0A04C94299B4B57C1BAB (void);
// 0x00000193 System.Void UnityEngine.UIElements.CommandEventDispatchingStrategy::DispatchEvent(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.IPanel)
extern void CommandEventDispatchingStrategy_DispatchEvent_m48BF91D717276E712355D42B8BF2ED080D478171 (void);
// 0x00000194 System.Void UnityEngine.UIElements.CommandEventDispatchingStrategy::.ctor()
extern void CommandEventDispatchingStrategy__ctor_mE1E6A29BD4B8D1BAD45112A5DE390FC73C3C5EBE (void);
// 0x00000195 System.Void UnityEngine.UIElements.CommandEventBase`1::set_commandName(System.String)
// 0x00000196 System.Void UnityEngine.UIElements.CommandEventBase`1::Init()
// 0x00000197 System.Void UnityEngine.UIElements.CommandEventBase`1::LocalInit()
// 0x00000198 T UnityEngine.UIElements.CommandEventBase`1::GetPooled(UnityEngine.Event)
// 0x00000199 System.Void UnityEngine.UIElements.CommandEventBase`1::.ctor()
// 0x0000019A System.Void UnityEngine.UIElements.ValidateCommandEvent::.ctor()
extern void ValidateCommandEvent__ctor_mEF115FFA17BFA6106E67AC22F4C289227C5504C8 (void);
// 0x0000019B System.Void UnityEngine.UIElements.ExecuteCommandEvent::.ctor()
extern void ExecuteCommandEvent__ctor_mD48281641BE52D713AB8C7BF394EEDD2DC4B3920 (void);
// 0x0000019C System.Boolean UnityEngine.UIElements.DefaultDispatchingStrategy::CanDispatchEvent(UnityEngine.UIElements.EventBase)
extern void DefaultDispatchingStrategy_CanDispatchEvent_m6ACEF0B7C67A07E3093395E7D7E21F57533545E1 (void);
// 0x0000019D System.Void UnityEngine.UIElements.DefaultDispatchingStrategy::DispatchEvent(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.IPanel)
extern void DefaultDispatchingStrategy_DispatchEvent_m569EFC07ED703BB47D1E1F6C2780FBEAE3E201F8 (void);
// 0x0000019E System.Void UnityEngine.UIElements.DefaultDispatchingStrategy::.ctor()
extern void DefaultDispatchingStrategy__ctor_m52B8F90BFA65578FAAD432D902EF5C1DEBFABD33 (void);
// 0x0000019F UnityEngine.UIElements.VisualElement UnityEngine.UIElements.ElementUnderPointer::GetTopElementUnderPointer(System.Int32,UnityEngine.Vector2&,System.Boolean&)
extern void ElementUnderPointer_GetTopElementUnderPointer_m2B196EE08260E01BBF81112D831FE29477120EB7 (void);
// 0x000001A0 UnityEngine.UIElements.VisualElement UnityEngine.UIElements.ElementUnderPointer::GetTopElementUnderPointer(System.Int32)
extern void ElementUnderPointer_GetTopElementUnderPointer_mD1D1C5A3C264654C9CB19666CC1097408E49D139 (void);
// 0x000001A1 UnityEngine.Vector2 UnityEngine.UIElements.ElementUnderPointer::GetEventPointerPosition(UnityEngine.UIElements.EventBase)
extern void ElementUnderPointer_GetEventPointerPosition_m50EF3CA06C044065574907AC9CB8A2FB1F64EFD8 (void);
// 0x000001A2 System.Void UnityEngine.UIElements.ElementUnderPointer::SetTemporaryElementUnderPointer(UnityEngine.UIElements.VisualElement,UnityEngine.UIElements.EventBase)
extern void ElementUnderPointer_SetTemporaryElementUnderPointer_mE9F63DDCF4AAF65877DDCAFEB94C69A002ADB017 (void);
// 0x000001A3 System.Void UnityEngine.UIElements.ElementUnderPointer::SetElementUnderPointer(UnityEngine.UIElements.VisualElement,UnityEngine.UIElements.EventBase)
extern void ElementUnderPointer_SetElementUnderPointer_mEEB043B3F851939AFAB31A493C2742C316B3094B (void);
// 0x000001A4 System.Void UnityEngine.UIElements.ElementUnderPointer::SetElementUnderPointer(UnityEngine.UIElements.VisualElement,UnityEngine.UIElements.EventBase,System.Boolean)
extern void ElementUnderPointer_SetElementUnderPointer_m28C80675B9B5A7FD92D56A5E99CC40C90E66E68E (void);
// 0x000001A5 System.Void UnityEngine.UIElements.ElementUnderPointer::CommitElementUnderPointers(UnityEngine.UIElements.EventDispatcher)
extern void ElementUnderPointer_CommitElementUnderPointers_m6FA3E7B972629EAB789D1902406D99F0096A4D4E (void);
// 0x000001A6 System.Int64 UnityEngine.UIElements.EventBase::RegisterEventType()
extern void EventBase_RegisterEventType_mACD00E065C77D62FCB73159B71E915D3A7D247F0 (void);
// 0x000001A7 System.Int64 UnityEngine.UIElements.EventBase::get_eventTypeId()
extern void EventBase_get_eventTypeId_mE3958C191E09FA1710A197348124ECBD0F34FF1D (void);
// 0x000001A8 System.Int64 UnityEngine.UIElements.EventBase::get_timestamp()
extern void EventBase_get_timestamp_mBE46F8C2C0B85FFD1D4B7B6CDA21C2C82FCDBCC4 (void);
// 0x000001A9 System.Void UnityEngine.UIElements.EventBase::set_timestamp(System.Int64)
extern void EventBase_set_timestamp_mE56824EA2FF801EEAECC91C532FC730AD6DC73D8 (void);
// 0x000001AA System.UInt64 UnityEngine.UIElements.EventBase::get_eventId()
extern void EventBase_get_eventId_m59ED33B729E24BF0C7D55303D11B70538B007912 (void);
// 0x000001AB System.Void UnityEngine.UIElements.EventBase::set_eventId(System.UInt64)
extern void EventBase_set_eventId_m93D08BAA45F62D212E4564E5D0CC8AACA418F03F (void);
// 0x000001AC System.Void UnityEngine.UIElements.EventBase::set_triggerEventId(System.UInt64)
extern void EventBase_set_triggerEventId_m6E2574EA72F69317B99C74A6478B7576F024EAAA (void);
// 0x000001AD System.Void UnityEngine.UIElements.EventBase::SetTriggerEventId(System.UInt64)
extern void EventBase_SetTriggerEventId_m2637F8FFBE2A30700DFE12378DB5AAFCF5D8F6C2 (void);
// 0x000001AE UnityEngine.UIElements.EventBase/EventPropagation UnityEngine.UIElements.EventBase::get_propagation()
extern void EventBase_get_propagation_m55C0F2EB5B86D1911DC9513AA65F97359A114F3F (void);
// 0x000001AF System.Void UnityEngine.UIElements.EventBase::set_propagation(UnityEngine.UIElements.EventBase/EventPropagation)
extern void EventBase_set_propagation_mAC9E99EE268E3A5D1715739AA03FA014B460F0D7 (void);
// 0x000001B0 UnityEngine.UIElements.PropagationPaths UnityEngine.UIElements.EventBase::get_path()
extern void EventBase_get_path_m7F34D8626F0314CD14C3FC1307B0E87B7981E5D2 (void);
// 0x000001B1 System.Void UnityEngine.UIElements.EventBase::set_path(UnityEngine.UIElements.PropagationPaths)
extern void EventBase_set_path_m6C6416464FE0FAAA9DF37C9C1FD34C01818EE3ED (void);
// 0x000001B2 UnityEngine.UIElements.EventBase/LifeCycleStatus UnityEngine.UIElements.EventBase::get_lifeCycleStatus()
extern void EventBase_get_lifeCycleStatus_mE2FE4D023CBF3092A11B6358D700D8E5AA34DF7A (void);
// 0x000001B3 System.Void UnityEngine.UIElements.EventBase::set_lifeCycleStatus(UnityEngine.UIElements.EventBase/LifeCycleStatus)
extern void EventBase_set_lifeCycleStatus_m00DCC6852FB999F743D06C1F3B9F94268543F87E (void);
// 0x000001B4 System.Void UnityEngine.UIElements.EventBase::PreDispatch()
extern void EventBase_PreDispatch_m99F93BCF0242E70AF5FEB7749014CA3D2E71E4DF (void);
// 0x000001B5 System.Void UnityEngine.UIElements.EventBase::PreDispatch(UnityEngine.UIElements.IPanel)
extern void EventBase_PreDispatch_mE7A4322A35B89AA39D47A7EF08A0FF2FF1EC53C0 (void);
// 0x000001B6 System.Void UnityEngine.UIElements.EventBase::PostDispatch()
extern void EventBase_PostDispatch_mDF67FEC7415D902731D588DD0A628B12991F51F2 (void);
// 0x000001B7 System.Void UnityEngine.UIElements.EventBase::PostDispatch(UnityEngine.UIElements.IPanel)
extern void EventBase_PostDispatch_mE19DE5735A3325E50E2BB51949ECA45D1074CA67 (void);
// 0x000001B8 System.Boolean UnityEngine.UIElements.EventBase::get_bubbles()
extern void EventBase_get_bubbles_mD57DAA916C9A595F207F9B38B04D7AABC2528469 (void);
// 0x000001B9 System.Boolean UnityEngine.UIElements.EventBase::get_tricklesDown()
extern void EventBase_get_tricklesDown_m1C0915991B8756E0C40F0DB2D471DAE945ECBC1F (void);
// 0x000001BA UnityEngine.UIElements.IEventHandler UnityEngine.UIElements.EventBase::get_leafTarget()
extern void EventBase_get_leafTarget_mA5FB9DF6EAB0F7186D19BBE28F5CC8DC832FD2AB (void);
// 0x000001BB System.Void UnityEngine.UIElements.EventBase::set_leafTarget(UnityEngine.UIElements.IEventHandler)
extern void EventBase_set_leafTarget_m86D05832A47FCE780426807CA7293970C4875EE1 (void);
// 0x000001BC UnityEngine.UIElements.IEventHandler UnityEngine.UIElements.EventBase::get_target()
extern void EventBase_get_target_m9EF112412E3EDCC34273873C1800A83F08A251D3 (void);
// 0x000001BD System.Void UnityEngine.UIElements.EventBase::set_target(UnityEngine.UIElements.IEventHandler)
extern void EventBase_set_target_m0DB62F906DB05078428D06B8FCBD8D393D23294B (void);
// 0x000001BE System.Collections.Generic.List`1<UnityEngine.UIElements.IEventHandler> UnityEngine.UIElements.EventBase::get_skipElements()
extern void EventBase_get_skipElements_mEE50112B390E7AA109B098D7AF379A2A947A6900 (void);
// 0x000001BF System.Boolean UnityEngine.UIElements.EventBase::Skip(UnityEngine.UIElements.IEventHandler)
extern void EventBase_Skip_m4CD7DF38D443353E17777495F355EB1895D26745 (void);
// 0x000001C0 System.Boolean UnityEngine.UIElements.EventBase::get_isPropagationStopped()
extern void EventBase_get_isPropagationStopped_m4856E14BCD1287019DE0A487D15809586A8B11E9 (void);
// 0x000001C1 System.Void UnityEngine.UIElements.EventBase::set_isPropagationStopped(System.Boolean)
extern void EventBase_set_isPropagationStopped_m20B06E7376B943FBD0F95D20EB33AF4DB562C580 (void);
// 0x000001C2 System.Void UnityEngine.UIElements.EventBase::StopPropagation()
extern void EventBase_StopPropagation_m6BABC2698D9BEE8E9044B58DB65363591C26EBDF (void);
// 0x000001C3 System.Boolean UnityEngine.UIElements.EventBase::get_isImmediatePropagationStopped()
extern void EventBase_get_isImmediatePropagationStopped_mF6A1A67BAA11F4EC486346252211FBDA4078091D (void);
// 0x000001C4 System.Void UnityEngine.UIElements.EventBase::set_isImmediatePropagationStopped(System.Boolean)
extern void EventBase_set_isImmediatePropagationStopped_mA19F0FDE98B7C761E9C36428BA8219D30A2AC452 (void);
// 0x000001C5 System.Void UnityEngine.UIElements.EventBase::StopImmediatePropagation()
extern void EventBase_StopImmediatePropagation_m008E632FCE3DEF14249F7E6AFCC76F35011C55FD (void);
// 0x000001C6 System.Boolean UnityEngine.UIElements.EventBase::get_isDefaultPrevented()
extern void EventBase_get_isDefaultPrevented_mCE6C63CA42AE3EB7197F8B145BB305CC617AB674 (void);
// 0x000001C7 System.Void UnityEngine.UIElements.EventBase::set_isDefaultPrevented(System.Boolean)
extern void EventBase_set_isDefaultPrevented_m7F299A8200B34FD5467C212DF78E222EC1AC0BBF (void);
// 0x000001C8 System.Void UnityEngine.UIElements.EventBase::PreventDefault()
extern void EventBase_PreventDefault_m4B240A9D61D80226E2FD28F60128F74084810848 (void);
// 0x000001C9 UnityEngine.UIElements.PropagationPhase UnityEngine.UIElements.EventBase::get_propagationPhase()
extern void EventBase_get_propagationPhase_mC3F6691B2E84AB5C0942A6C4F478D6A45FF784E8 (void);
// 0x000001CA System.Void UnityEngine.UIElements.EventBase::set_propagationPhase(UnityEngine.UIElements.PropagationPhase)
extern void EventBase_set_propagationPhase_m906F58ECDF1F529BA3B198451B00FCE2133F9731 (void);
// 0x000001CB UnityEngine.UIElements.IEventHandler UnityEngine.UIElements.EventBase::get_currentTarget()
extern void EventBase_get_currentTarget_m53E8F94F987823E5065FC53AEC0C87B1ADF1C9DD (void);
// 0x000001CC System.Void UnityEngine.UIElements.EventBase::set_currentTarget(UnityEngine.UIElements.IEventHandler)
extern void EventBase_set_currentTarget_m7ABD5BA0A703839B542F757AD6084F168301C776 (void);
// 0x000001CD System.Boolean UnityEngine.UIElements.EventBase::get_dispatch()
extern void EventBase_get_dispatch_m83094094F27EF0942E73F1EDF712878A729E51A1 (void);
// 0x000001CE System.Void UnityEngine.UIElements.EventBase::set_dispatch(System.Boolean)
extern void EventBase_set_dispatch_m210C16B1DCD976CB965336FA666EEDDAEA7EB26F (void);
// 0x000001CF System.Void UnityEngine.UIElements.EventBase::MarkReceivedByDispatcher()
extern void EventBase_MarkReceivedByDispatcher_mCD5AECF121EE4DF722BEB64828DC14EF34E1C8C3 (void);
// 0x000001D0 System.Boolean UnityEngine.UIElements.EventBase::get_dispatched()
extern void EventBase_get_dispatched_m6EBAE7263103466C265ED51CC63253EFF9CE097F (void);
// 0x000001D1 System.Void UnityEngine.UIElements.EventBase::set_dispatched(System.Boolean)
extern void EventBase_set_dispatched_mB36266C96B1D5DACB25FBFC7E1F2AE99A11E7110 (void);
// 0x000001D2 System.Boolean UnityEngine.UIElements.EventBase::get_processed()
extern void EventBase_get_processed_m691D8CBBCEA051DF7C1F46376243E0A2542CF763 (void);
// 0x000001D3 System.Void UnityEngine.UIElements.EventBase::set_processed(System.Boolean)
extern void EventBase_set_processed_mC772D21D94B8447A2D56741270A4637BF4CF5A8D (void);
// 0x000001D4 System.Boolean UnityEngine.UIElements.EventBase::get_processedByFocusController()
extern void EventBase_get_processedByFocusController_mBC615641CAF2264434CB5C4D8EFF2BB2E2844213 (void);
// 0x000001D5 System.Void UnityEngine.UIElements.EventBase::set_processedByFocusController(System.Boolean)
extern void EventBase_set_processedByFocusController_m275D4E3D33CBF66F6F330DAA69FE2BB45C3414BC (void);
// 0x000001D6 System.Boolean UnityEngine.UIElements.EventBase::get_stopDispatch()
extern void EventBase_get_stopDispatch_m3DA4402031FDECC0416B84830B76CFC1F0341A4D (void);
// 0x000001D7 System.Void UnityEngine.UIElements.EventBase::set_stopDispatch(System.Boolean)
extern void EventBase_set_stopDispatch_m205E6F1247BCE14D3C5DBDEEFDE14EB9311CC2F9 (void);
// 0x000001D8 System.Boolean UnityEngine.UIElements.EventBase::get_propagateToIMGUI()
extern void EventBase_get_propagateToIMGUI_m28F31AD863BD73D46440D974EEB4CAEF2CA0FA2E (void);
// 0x000001D9 System.Void UnityEngine.UIElements.EventBase::set_propagateToIMGUI(System.Boolean)
extern void EventBase_set_propagateToIMGUI_mBED8533FA995A78CC9C8F9843909B26A00BFCD00 (void);
// 0x000001DA System.Boolean UnityEngine.UIElements.EventBase::get_imguiEventIsValid()
extern void EventBase_get_imguiEventIsValid_mB285F9A66AA61AE7DA585B45ED8DD767403F7F64 (void);
// 0x000001DB System.Void UnityEngine.UIElements.EventBase::set_imguiEventIsValid(System.Boolean)
extern void EventBase_set_imguiEventIsValid_m1401EA7452C2B4BE7936932A3D469B3D86FDA6C1 (void);
// 0x000001DC UnityEngine.Event UnityEngine.UIElements.EventBase::get_imguiEvent()
extern void EventBase_get_imguiEvent_m810A49C5C6373AE3723CBE252BE2298A5BBF090C (void);
// 0x000001DD System.Void UnityEngine.UIElements.EventBase::set_imguiEvent(UnityEngine.Event)
extern void EventBase_set_imguiEvent_mC4D6A8E08A41E53F774E6A736C77F2AA1DADDF1C (void);
// 0x000001DE UnityEngine.Vector2 UnityEngine.UIElements.EventBase::get_originalMousePosition()
extern void EventBase_get_originalMousePosition_mD40FA45A685D281A1A03AB38B40390D27ADACD04 (void);
// 0x000001DF System.Void UnityEngine.UIElements.EventBase::set_originalMousePosition(UnityEngine.Vector2)
extern void EventBase_set_originalMousePosition_m0065AA01464C8AED3B2D8E03069E9E1EDC06E46B (void);
// 0x000001E0 System.Void UnityEngine.UIElements.EventBase::Init()
extern void EventBase_Init_m8E736BE6A717A7DE7894AD42F4681A783A2D8D72 (void);
// 0x000001E1 System.Void UnityEngine.UIElements.EventBase::LocalInit()
extern void EventBase_LocalInit_m712BDEA793FC6D0547EF6D0D4465FB748678B7DA (void);
// 0x000001E2 System.Void UnityEngine.UIElements.EventBase::.ctor()
extern void EventBase__ctor_mF95C69400D2505F84C3CC1460ABEFA906CF3D82D (void);
// 0x000001E3 System.Boolean UnityEngine.UIElements.EventBase::get_pooled()
extern void EventBase_get_pooled_m06BB533163C3D0B89FBAF5308948CF38B2ED4358 (void);
// 0x000001E4 System.Void UnityEngine.UIElements.EventBase::set_pooled(System.Boolean)
extern void EventBase_set_pooled_m131A347E2ECB46EC42FF8BE356E54F8663A665B9 (void);
// 0x000001E5 System.Void UnityEngine.UIElements.EventBase::Acquire()
// 0x000001E6 System.Void UnityEngine.UIElements.EventBase::Dispose()
// 0x000001E7 System.Void UnityEngine.UIElements.EventBase::.cctor()
extern void EventBase__cctor_m0DC5F1D9A04D67BE6DF1D8096C366841B1FC1CB1 (void);
// 0x000001E8 System.Void UnityEngine.UIElements.EventBase`1::.ctor()
// 0x000001E9 System.Int64 UnityEngine.UIElements.EventBase`1::TypeId()
// 0x000001EA System.Void UnityEngine.UIElements.EventBase`1::Init()
// 0x000001EB T UnityEngine.UIElements.EventBase`1::GetPooled()
// 0x000001EC T UnityEngine.UIElements.EventBase`1::GetPooled(UnityEngine.UIElements.EventBase)
// 0x000001ED System.Void UnityEngine.UIElements.EventBase`1::ReleasePooled(T)
// 0x000001EE System.Void UnityEngine.UIElements.EventBase`1::Acquire()
// 0x000001EF System.Void UnityEngine.UIElements.EventBase`1::Dispose()
// 0x000001F0 System.Int64 UnityEngine.UIElements.EventBase`1::get_eventTypeId()
// 0x000001F1 System.Void UnityEngine.UIElements.EventBase`1::.cctor()
// 0x000001F2 System.Void UnityEngine.UIElements.EventCallback`1::.ctor(System.Object,System.IntPtr)
// 0x000001F3 System.Void UnityEngine.UIElements.EventCallback`1::Invoke(TEventType)
// 0x000001F4 UnityEngine.UIElements.CallbackPhase UnityEngine.UIElements.EventCallbackFunctorBase::get_phase()
extern void EventCallbackFunctorBase_get_phase_m26681E62F951BBC9D3A0D929267BBA16ABDC8176 (void);
// 0x000001F5 System.Void UnityEngine.UIElements.EventCallbackFunctorBase::set_phase(UnityEngine.UIElements.CallbackPhase)
extern void EventCallbackFunctorBase_set_phase_mA803DEEE131EE6DF5B13E624AE692CEE3EFD2680 (void);
// 0x000001F6 System.Void UnityEngine.UIElements.EventCallbackFunctorBase::.ctor(UnityEngine.UIElements.CallbackPhase)
extern void EventCallbackFunctorBase__ctor_m7FA913AEEDECA07F4A79AA3873CDFD017B258BB5 (void);
// 0x000001F7 System.Void UnityEngine.UIElements.EventCallbackFunctorBase::Invoke(UnityEngine.UIElements.EventBase)
// 0x000001F8 System.Boolean UnityEngine.UIElements.EventCallbackFunctorBase::IsEquivalentTo(System.Int64,System.Delegate,UnityEngine.UIElements.CallbackPhase)
// 0x000001F9 System.Boolean UnityEngine.UIElements.EventCallbackFunctorBase::PhaseMatches(UnityEngine.UIElements.EventBase)
extern void EventCallbackFunctorBase_PhaseMatches_m76E4574A745A89B67CA6DDCB2A50560636FEA7FF (void);
// 0x000001FA System.Void UnityEngine.UIElements.EventCallbackFunctor`1::.ctor(UnityEngine.UIElements.EventCallback`1<TEventType>,UnityEngine.UIElements.CallbackPhase)
// 0x000001FB System.Void UnityEngine.UIElements.EventCallbackFunctor`1::Invoke(UnityEngine.UIElements.EventBase)
// 0x000001FC System.Boolean UnityEngine.UIElements.EventCallbackFunctor`1::IsEquivalentTo(System.Int64,System.Delegate,UnityEngine.UIElements.CallbackPhase)
// 0x000001FD UnityEngine.UIElements.EventCallbackList UnityEngine.UIElements.EventCallbackListPool::Get(UnityEngine.UIElements.EventCallbackList)
extern void EventCallbackListPool_Get_mC25881B07E43CDD608C1E55B9879E450CB4C1FBB (void);
// 0x000001FE System.Void UnityEngine.UIElements.EventCallbackListPool::Release(UnityEngine.UIElements.EventCallbackList)
extern void EventCallbackListPool_Release_m24B2350E963E879BF75D314AA547990C772C490E (void);
// 0x000001FF System.Void UnityEngine.UIElements.EventCallbackListPool::.ctor()
extern void EventCallbackListPool__ctor_m2D083694479DC5C05B9370627D9384BD07D53DCB (void);
// 0x00000200 System.Int32 UnityEngine.UIElements.EventCallbackList::get_trickleDownCallbackCount()
extern void EventCallbackList_get_trickleDownCallbackCount_mDA5D744D0015687CE22269F43C215EB2973F46A2 (void);
// 0x00000201 System.Void UnityEngine.UIElements.EventCallbackList::set_trickleDownCallbackCount(System.Int32)
extern void EventCallbackList_set_trickleDownCallbackCount_mD35C97D3F730BA23738A8CB68BCE42398A3E3FBD (void);
// 0x00000202 System.Int32 UnityEngine.UIElements.EventCallbackList::get_bubbleUpCallbackCount()
extern void EventCallbackList_get_bubbleUpCallbackCount_m781703B980F67C081CEA743E87580675B481CBB4 (void);
// 0x00000203 System.Void UnityEngine.UIElements.EventCallbackList::set_bubbleUpCallbackCount(System.Int32)
extern void EventCallbackList_set_bubbleUpCallbackCount_m75C48F15BA4E2966F999C230CD4D2F9658602D47 (void);
// 0x00000204 System.Void UnityEngine.UIElements.EventCallbackList::.ctor()
extern void EventCallbackList__ctor_m987EB24DB79D6FFFDAD1D5E5FD5DAEB28361C552 (void);
// 0x00000205 System.Void UnityEngine.UIElements.EventCallbackList::.ctor(UnityEngine.UIElements.EventCallbackList)
extern void EventCallbackList__ctor_m648517F07107158FA5415FB65EED192397094894 (void);
// 0x00000206 System.Boolean UnityEngine.UIElements.EventCallbackList::Contains(System.Int64,System.Delegate,UnityEngine.UIElements.CallbackPhase)
extern void EventCallbackList_Contains_mDD0301728E02A3336E211CF0B8CD9CD26BC49828 (void);
// 0x00000207 UnityEngine.UIElements.EventCallbackFunctorBase UnityEngine.UIElements.EventCallbackList::Find(System.Int64,System.Delegate,UnityEngine.UIElements.CallbackPhase)
extern void EventCallbackList_Find_m75710F3FEBF84AF3C3A09CB8C3615C942536AED2 (void);
// 0x00000208 System.Boolean UnityEngine.UIElements.EventCallbackList::Remove(System.Int64,System.Delegate,UnityEngine.UIElements.CallbackPhase)
extern void EventCallbackList_Remove_m92C09F39132042C72B52C98621CFFA843CC237EC (void);
// 0x00000209 System.Void UnityEngine.UIElements.EventCallbackList::Add(UnityEngine.UIElements.EventCallbackFunctorBase)
extern void EventCallbackList_Add_m63BF0F96927693DA0B5CCFA1CF61CCFCA50CFABA (void);
// 0x0000020A System.Void UnityEngine.UIElements.EventCallbackList::AddRange(UnityEngine.UIElements.EventCallbackList)
extern void EventCallbackList_AddRange_mB8297D2A3ECAE1B6252541AC2114CF02641B0141 (void);
// 0x0000020B System.Int32 UnityEngine.UIElements.EventCallbackList::get_Count()
extern void EventCallbackList_get_Count_mAC5EFDB3F0C314A1D0CEF370019E7CB7ED090BF4 (void);
// 0x0000020C UnityEngine.UIElements.EventCallbackFunctorBase UnityEngine.UIElements.EventCallbackList::get_Item(System.Int32)
extern void EventCallbackList_get_Item_m4EBBF3D95831065B9B9BADC76ABFA5AE8CF59DBD (void);
// 0x0000020D System.Void UnityEngine.UIElements.EventCallbackList::Clear()
extern void EventCallbackList_Clear_m21819478129C48DA7E1FE0FDDFB4FAFD23755E73 (void);
// 0x0000020E UnityEngine.UIElements.EventCallbackList UnityEngine.UIElements.EventCallbackRegistry::GetCallbackList(UnityEngine.UIElements.EventCallbackList)
extern void EventCallbackRegistry_GetCallbackList_mE29517EC832B864ED1304477F510F84614EDA877 (void);
// 0x0000020F System.Void UnityEngine.UIElements.EventCallbackRegistry::ReleaseCallbackList(UnityEngine.UIElements.EventCallbackList)
extern void EventCallbackRegistry_ReleaseCallbackList_mD62226ED4A6FE104F12CC0CD9CBB831C1039EBD3 (void);
// 0x00000210 System.Void UnityEngine.UIElements.EventCallbackRegistry::.ctor()
extern void EventCallbackRegistry__ctor_m0E6C045647522D2382B9D6BEDBA0C38DE88B7E52 (void);
// 0x00000211 UnityEngine.UIElements.EventCallbackList UnityEngine.UIElements.EventCallbackRegistry::GetCallbackListForWriting()
extern void EventCallbackRegistry_GetCallbackListForWriting_m9182E5121C2260D5A20BE4822268FE44354966B5 (void);
// 0x00000212 UnityEngine.UIElements.EventCallbackList UnityEngine.UIElements.EventCallbackRegistry::GetCallbackListForReading()
extern void EventCallbackRegistry_GetCallbackListForReading_m6D8452BC704C6231E2168FA4BF36CEB35B85720D (void);
// 0x00000213 System.Boolean UnityEngine.UIElements.EventCallbackRegistry::UnregisterCallback(System.Int64,System.Delegate,UnityEngine.UIElements.TrickleDown)
extern void EventCallbackRegistry_UnregisterCallback_m7A3ECB87DB28DFC9A66D510E2E69B9127FD9D4C6 (void);
// 0x00000214 System.Void UnityEngine.UIElements.EventCallbackRegistry::RegisterCallback(UnityEngine.UIElements.EventCallback`1<TEventType>,UnityEngine.UIElements.TrickleDown)
// 0x00000215 System.Boolean UnityEngine.UIElements.EventCallbackRegistry::UnregisterCallback(UnityEngine.UIElements.EventCallback`1<TEventType>,UnityEngine.UIElements.TrickleDown)
// 0x00000216 System.Void UnityEngine.UIElements.EventCallbackRegistry::InvokeCallbacks(UnityEngine.UIElements.EventBase)
extern void EventCallbackRegistry_InvokeCallbacks_mBB7C2EFC91F10355DC1CCE02A5B3689A48CCDC17 (void);
// 0x00000217 System.Boolean UnityEngine.UIElements.EventCallbackRegistry::HasTrickleDownHandlers()
extern void EventCallbackRegistry_HasTrickleDownHandlers_m7EE3D891466544D69D157E956879559BD21551B0 (void);
// 0x00000218 System.Boolean UnityEngine.UIElements.EventCallbackRegistry::HasBubbleHandlers()
extern void EventCallbackRegistry_HasBubbleHandlers_mC6577445AE8E03D5BE439DBA44EF945507893768 (void);
// 0x00000219 System.Void UnityEngine.UIElements.EventCallbackRegistry::.cctor()
extern void EventCallbackRegistry__cctor_mA4455BE6181B7297876DB6B990EAEF8A5D5E1079 (void);
// 0x0000021A System.Void UnityEngine.UIElements.IEventHandler::SendEvent(UnityEngine.UIElements.EventBase)
// 0x0000021B System.Void UnityEngine.UIElements.IEventHandler::HandleEvent(UnityEngine.UIElements.EventBase)
// 0x0000021C System.Void UnityEngine.UIElements.CallbackEventHandler::RegisterCallback(UnityEngine.UIElements.EventCallback`1<TEventType>,UnityEngine.UIElements.TrickleDown)
// 0x0000021D System.Void UnityEngine.UIElements.CallbackEventHandler::UnregisterCallback(UnityEngine.UIElements.EventCallback`1<TEventType>,UnityEngine.UIElements.TrickleDown)
// 0x0000021E System.Void UnityEngine.UIElements.CallbackEventHandler::SendEvent(UnityEngine.UIElements.EventBase)
// 0x0000021F System.Void UnityEngine.UIElements.CallbackEventHandler::HandleEventAtTargetPhase(UnityEngine.UIElements.EventBase)
extern void CallbackEventHandler_HandleEventAtTargetPhase_m45DCCAB32EF380329DFC7E57993765E806022DFC (void);
// 0x00000220 System.Void UnityEngine.UIElements.CallbackEventHandler::HandleEvent(UnityEngine.UIElements.EventBase)
extern void CallbackEventHandler_HandleEvent_m8FFE102B46EA0D73BF8E9EA0E75421A8BAAA5E4E (void);
// 0x00000221 System.Boolean UnityEngine.UIElements.CallbackEventHandler::HasTrickleDownHandlers()
extern void CallbackEventHandler_HasTrickleDownHandlers_m3C9E244D3D1AE1CB35F657B223AF73E66CD6DB01 (void);
// 0x00000222 System.Boolean UnityEngine.UIElements.CallbackEventHandler::HasBubbleUpHandlers()
extern void CallbackEventHandler_HasBubbleUpHandlers_m32B0F8B687026FF7D123695D6E6053A51326460C (void);
// 0x00000223 System.Void UnityEngine.UIElements.CallbackEventHandler::ExecuteDefaultActionAtTarget(UnityEngine.UIElements.EventBase)
extern void CallbackEventHandler_ExecuteDefaultActionAtTarget_mA648038DCB390D259CDF043E8F8F7E1C654C2FC1 (void);
// 0x00000224 System.Void UnityEngine.UIElements.CallbackEventHandler::ExecuteDefaultAction(UnityEngine.UIElements.EventBase)
extern void CallbackEventHandler_ExecuteDefaultAction_mBC1D8F34B8666E08E5A337F309B052F1CEB0797D (void);
// 0x00000225 UnityEngine.UIElements.Focusable UnityEngine.UIElements.FocusEventBase`1::get_relatedTarget()
// 0x00000226 System.Void UnityEngine.UIElements.FocusEventBase`1::set_relatedTarget(UnityEngine.UIElements.Focusable)
// 0x00000227 System.Void UnityEngine.UIElements.FocusEventBase`1::set_direction(UnityEngine.UIElements.FocusChangeDirection)
// 0x00000228 UnityEngine.UIElements.FocusController UnityEngine.UIElements.FocusEventBase`1::get_focusController()
// 0x00000229 System.Void UnityEngine.UIElements.FocusEventBase`1::set_focusController(UnityEngine.UIElements.FocusController)
// 0x0000022A System.Void UnityEngine.UIElements.FocusEventBase`1::set_IsFocusDelegated(System.Boolean)
// 0x0000022B System.Void UnityEngine.UIElements.FocusEventBase`1::Init()
// 0x0000022C System.Void UnityEngine.UIElements.FocusEventBase`1::LocalInit()
// 0x0000022D T UnityEngine.UIElements.FocusEventBase`1::GetPooled(UnityEngine.UIElements.IEventHandler,UnityEngine.UIElements.Focusable,UnityEngine.UIElements.FocusChangeDirection,UnityEngine.UIElements.FocusController,System.Boolean)
// 0x0000022E System.Void UnityEngine.UIElements.FocusEventBase`1::.ctor()
// 0x0000022F System.Void UnityEngine.UIElements.FocusOutEvent::Init()
extern void FocusOutEvent_Init_m26933D10E5E92BEC5CF3C9DF976D603182130C4C (void);
// 0x00000230 System.Void UnityEngine.UIElements.FocusOutEvent::LocalInit()
extern void FocusOutEvent_LocalInit_m8C059742959765CFC806F0F6373F9D19EA0FCBF7 (void);
// 0x00000231 System.Void UnityEngine.UIElements.FocusOutEvent::.ctor()
extern void FocusOutEvent__ctor_m452B50AB82114267C692409B5E490C0266152F31 (void);
// 0x00000232 System.Void UnityEngine.UIElements.BlurEvent::PreDispatch(UnityEngine.UIElements.IPanel)
extern void BlurEvent_PreDispatch_m85F6921E1530D5A930D2A626035CF8FD5AA8DA3C (void);
// 0x00000233 System.Void UnityEngine.UIElements.BlurEvent::.ctor()
extern void BlurEvent__ctor_m4F66EB6D2708636D934EF00E3554AE0DAE54D60A (void);
// 0x00000234 System.Void UnityEngine.UIElements.FocusInEvent::Init()
extern void FocusInEvent_Init_m1F053771080166CBEBD9FE59EED4FA2FFB9DA114 (void);
// 0x00000235 System.Void UnityEngine.UIElements.FocusInEvent::LocalInit()
extern void FocusInEvent_LocalInit_m073ACCFFBD9A8864E0B794FBBB9C4DB3879183EA (void);
// 0x00000236 System.Void UnityEngine.UIElements.FocusInEvent::.ctor()
extern void FocusInEvent__ctor_mFCEACD5BC759A7BD87A44ADF31D18C8173BA3AD5 (void);
// 0x00000237 System.Void UnityEngine.UIElements.FocusEvent::PreDispatch(UnityEngine.UIElements.IPanel)
extern void FocusEvent_PreDispatch_m955791ACE881CC59970791E1D86B73586226BC54 (void);
// 0x00000238 System.Void UnityEngine.UIElements.FocusEvent::.ctor()
extern void FocusEvent__ctor_m535CC2792484AED35AC711CD8606AE7700B933FF (void);
// 0x00000239 System.Boolean UnityEngine.UIElements.IEventDispatchingStrategy::CanDispatchEvent(UnityEngine.UIElements.EventBase)
// 0x0000023A System.Void UnityEngine.UIElements.IEventDispatchingStrategy::DispatchEvent(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.IPanel)
// 0x0000023B System.Void UnityEngine.UIElements.EventDispatchUtilities::PropagateEvent(UnityEngine.UIElements.EventBase)
extern void EventDispatchUtilities_PropagateEvent_mF651424AC323A8C532ED4029080E25F679CEA957 (void);
// 0x0000023C System.Void UnityEngine.UIElements.EventDispatchUtilities::PropagateToIMGUIContainer(UnityEngine.UIElements.VisualElement,UnityEngine.UIElements.EventBase)
extern void EventDispatchUtilities_PropagateToIMGUIContainer_m3941E9148C6DA84024430DB11BBC494456BE896E (void);
// 0x0000023D System.Void UnityEngine.UIElements.EventDispatchUtilities::ExecuteDefaultAction(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.IPanel)
extern void EventDispatchUtilities_ExecuteDefaultAction_mD04659432D2B0A36DFA8801AC41E20F43DD3A705 (void);
// 0x0000023E System.Boolean UnityEngine.UIElements.IMGUIEventDispatchingStrategy::CanDispatchEvent(UnityEngine.UIElements.EventBase)
extern void IMGUIEventDispatchingStrategy_CanDispatchEvent_mF723D5B27372C26EE404E3B48E5A8849E8768BBF (void);
// 0x0000023F System.Void UnityEngine.UIElements.IMGUIEventDispatchingStrategy::DispatchEvent(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.IPanel)
extern void IMGUIEventDispatchingStrategy_DispatchEvent_m497136E3C304EF45F150A883008C09691747A0CF (void);
// 0x00000240 System.Void UnityEngine.UIElements.IMGUIEventDispatchingStrategy::.ctor()
extern void IMGUIEventDispatchingStrategy__ctor_m7EF677A41F2B30F0CB89D46EA549F29BCDD9F07A (void);
// 0x00000241 System.Boolean UnityEngine.UIElements.KeyboardEventDispatchingStrategy::CanDispatchEvent(UnityEngine.UIElements.EventBase)
extern void KeyboardEventDispatchingStrategy_CanDispatchEvent_m7A7494E90861B0FDCAD6C4E3A3E4FD17507A263F (void);
// 0x00000242 System.Void UnityEngine.UIElements.KeyboardEventDispatchingStrategy::DispatchEvent(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.IPanel)
extern void KeyboardEventDispatchingStrategy_DispatchEvent_m7F14F7100E05B90BF061F90A67F055CB20F86307 (void);
// 0x00000243 System.Void UnityEngine.UIElements.KeyboardEventDispatchingStrategy::.ctor()
extern void KeyboardEventDispatchingStrategy__ctor_mCF2A370AED257B24BD2E104ADF18802D53AD2BD3 (void);
// 0x00000244 System.Void UnityEngine.UIElements.KeyboardEventBase`1::set_modifiers(UnityEngine.EventModifiers)
// 0x00000245 System.Void UnityEngine.UIElements.KeyboardEventBase`1::set_character(System.Char)
// 0x00000246 System.Void UnityEngine.UIElements.KeyboardEventBase`1::set_keyCode(UnityEngine.KeyCode)
// 0x00000247 System.Void UnityEngine.UIElements.KeyboardEventBase`1::Init()
// 0x00000248 System.Void UnityEngine.UIElements.KeyboardEventBase`1::LocalInit()
// 0x00000249 T UnityEngine.UIElements.KeyboardEventBase`1::GetPooled(System.Char,UnityEngine.KeyCode,UnityEngine.EventModifiers)
// 0x0000024A T UnityEngine.UIElements.KeyboardEventBase`1::GetPooled(UnityEngine.Event)
// 0x0000024B System.Void UnityEngine.UIElements.KeyboardEventBase`1::.ctor()
// 0x0000024C System.Void UnityEngine.UIElements.KeyDownEvent::.ctor()
extern void KeyDownEvent__ctor_m963F494BFF28D4D8C6278FB9F52E6B13FBDA64C6 (void);
// 0x0000024D System.Void UnityEngine.UIElements.KeyUpEvent::.ctor()
extern void KeyUpEvent__ctor_m22670A0913E634CB6D078C9EC610ECBC92CA6B74 (void);
// 0x0000024E System.Boolean UnityEngine.UIElements.MouseCaptureDispatchingStrategy::CanDispatchEvent(UnityEngine.UIElements.EventBase)
extern void MouseCaptureDispatchingStrategy_CanDispatchEvent_mEE201473460ECEFC34F35617D4F22A6573B4F725 (void);
// 0x0000024F System.Void UnityEngine.UIElements.MouseCaptureDispatchingStrategy::DispatchEvent(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.IPanel)
extern void MouseCaptureDispatchingStrategy_DispatchEvent_m72941E2EDA08614EA097229EE67474178BB10A4E (void);
// 0x00000250 System.Void UnityEngine.UIElements.MouseCaptureDispatchingStrategy::.ctor()
extern void MouseCaptureDispatchingStrategy__ctor_m7180B5A954F9C724CB91245091ADBA0CDD4CB3E7 (void);
// 0x00000251 System.Boolean UnityEngine.UIElements.MouseEventDispatchingStrategy::CanDispatchEvent(UnityEngine.UIElements.EventBase)
extern void MouseEventDispatchingStrategy_CanDispatchEvent_m4CD6519880568496F3208864B69BBF91A3FC3533 (void);
// 0x00000252 System.Void UnityEngine.UIElements.MouseEventDispatchingStrategy::DispatchEvent(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.IPanel)
extern void MouseEventDispatchingStrategy_DispatchEvent_mED8A81DA7CF30AB375876EFE64D607C1DDF3C50A (void);
// 0x00000253 System.Boolean UnityEngine.UIElements.MouseEventDispatchingStrategy::SendEventToTarget(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.BaseVisualElementPanel)
extern void MouseEventDispatchingStrategy_SendEventToTarget_m3CAB06F6F03A269AC25717521D5D9B17119C75FA (void);
// 0x00000254 System.Boolean UnityEngine.UIElements.MouseEventDispatchingStrategy::SendEventToRegularTarget(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.BaseVisualElementPanel)
extern void MouseEventDispatchingStrategy_SendEventToRegularTarget_m8795BF59A222DF150CB2B3BD2423D1A3FB549E05 (void);
// 0x00000255 System.Boolean UnityEngine.UIElements.MouseEventDispatchingStrategy::SendEventToIMGUIContainer(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.BaseVisualElementPanel)
extern void MouseEventDispatchingStrategy_SendEventToIMGUIContainer_m2269978BC713466DF6C30A82A4CC71575FFCD1B8 (void);
// 0x00000256 System.Void UnityEngine.UIElements.MouseEventDispatchingStrategy::SetBestTargetForEvent(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.BaseVisualElementPanel)
extern void MouseEventDispatchingStrategy_SetBestTargetForEvent_m2AA9CEE13BC6764B19E6238607EEBB8033793B57 (void);
// 0x00000257 System.Void UnityEngine.UIElements.MouseEventDispatchingStrategy::UpdateElementUnderMouse(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.BaseVisualElementPanel,UnityEngine.UIElements.VisualElement&)
extern void MouseEventDispatchingStrategy_UpdateElementUnderMouse_m193BC6B2AC9CC96B2143650C40DB5E0230FDD022 (void);
// 0x00000258 System.Boolean UnityEngine.UIElements.MouseEventDispatchingStrategy::IsDone(UnityEngine.UIElements.EventBase)
extern void MouseEventDispatchingStrategy_IsDone_m5095D1C26BDBE95366A6230DC0430DF174FBE543 (void);
// 0x00000259 System.Void UnityEngine.UIElements.MouseEventDispatchingStrategy::.ctor()
extern void MouseEventDispatchingStrategy__ctor_m1B63E69B349E2DB58BDB2C8C4E6F30F54915B450 (void);
// 0x0000025A UnityEngine.EventModifiers UnityEngine.UIElements.IMouseEvent::get_modifiers()
// 0x0000025B UnityEngine.Vector2 UnityEngine.UIElements.IMouseEvent::get_mousePosition()
// 0x0000025C UnityEngine.Vector2 UnityEngine.UIElements.IMouseEvent::get_mouseDelta()
// 0x0000025D System.Int32 UnityEngine.UIElements.IMouseEvent::get_clickCount()
// 0x0000025E System.Int32 UnityEngine.UIElements.IMouseEvent::get_button()
// 0x0000025F System.Int32 UnityEngine.UIElements.IMouseEvent::get_pressedButtons()
// 0x00000260 System.Boolean UnityEngine.UIElements.IMouseEventInternal::get_triggeredByOS()
// 0x00000261 System.Void UnityEngine.UIElements.IMouseEventInternal::set_triggeredByOS(System.Boolean)
// 0x00000262 System.Boolean UnityEngine.UIElements.IMouseEventInternal::get_recomputeTopElementUnderMouse()
// 0x00000263 System.Void UnityEngine.UIElements.IMouseEventInternal::set_recomputeTopElementUnderMouse(System.Boolean)
// 0x00000264 UnityEngine.UIElements.IPointerEvent UnityEngine.UIElements.IMouseEventInternal::get_sourcePointerEvent()
// 0x00000265 System.Void UnityEngine.UIElements.IMouseEventInternal::set_sourcePointerEvent(UnityEngine.UIElements.IPointerEvent)
// 0x00000266 UnityEngine.EventModifiers UnityEngine.UIElements.MouseEventBase`1::get_modifiers()
// 0x00000267 System.Void UnityEngine.UIElements.MouseEventBase`1::set_modifiers(UnityEngine.EventModifiers)
// 0x00000268 UnityEngine.Vector2 UnityEngine.UIElements.MouseEventBase`1::get_mousePosition()
// 0x00000269 System.Void UnityEngine.UIElements.MouseEventBase`1::set_mousePosition(UnityEngine.Vector2)
// 0x0000026A System.Void UnityEngine.UIElements.MouseEventBase`1::set_localMousePosition(UnityEngine.Vector2)
// 0x0000026B UnityEngine.Vector2 UnityEngine.UIElements.MouseEventBase`1::get_mouseDelta()
// 0x0000026C System.Void UnityEngine.UIElements.MouseEventBase`1::set_mouseDelta(UnityEngine.Vector2)
// 0x0000026D System.Int32 UnityEngine.UIElements.MouseEventBase`1::get_clickCount()
// 0x0000026E System.Void UnityEngine.UIElements.MouseEventBase`1::set_clickCount(System.Int32)
// 0x0000026F System.Int32 UnityEngine.UIElements.MouseEventBase`1::get_button()
// 0x00000270 System.Void UnityEngine.UIElements.MouseEventBase`1::set_button(System.Int32)
// 0x00000271 System.Int32 UnityEngine.UIElements.MouseEventBase`1::get_pressedButtons()
// 0x00000272 System.Void UnityEngine.UIElements.MouseEventBase`1::set_pressedButtons(System.Int32)
// 0x00000273 System.Boolean UnityEngine.UIElements.MouseEventBase`1::UnityEngine.UIElements.IMouseEventInternal.get_triggeredByOS()
// 0x00000274 System.Void UnityEngine.UIElements.MouseEventBase`1::UnityEngine.UIElements.IMouseEventInternal.set_triggeredByOS(System.Boolean)
// 0x00000275 System.Boolean UnityEngine.UIElements.MouseEventBase`1::UnityEngine.UIElements.IMouseEventInternal.get_recomputeTopElementUnderMouse()
// 0x00000276 System.Void UnityEngine.UIElements.MouseEventBase`1::UnityEngine.UIElements.IMouseEventInternal.set_recomputeTopElementUnderMouse(System.Boolean)
// 0x00000277 UnityEngine.UIElements.IPointerEvent UnityEngine.UIElements.MouseEventBase`1::UnityEngine.UIElements.IMouseEventInternal.get_sourcePointerEvent()
// 0x00000278 System.Void UnityEngine.UIElements.MouseEventBase`1::UnityEngine.UIElements.IMouseEventInternal.set_sourcePointerEvent(UnityEngine.UIElements.IPointerEvent)
// 0x00000279 System.Void UnityEngine.UIElements.MouseEventBase`1::Init()
// 0x0000027A System.Void UnityEngine.UIElements.MouseEventBase`1::LocalInit()
// 0x0000027B UnityEngine.UIElements.IEventHandler UnityEngine.UIElements.MouseEventBase`1::get_currentTarget()
// 0x0000027C System.Void UnityEngine.UIElements.MouseEventBase`1::set_currentTarget(UnityEngine.UIElements.IEventHandler)
// 0x0000027D System.Void UnityEngine.UIElements.MouseEventBase`1::PreDispatch(UnityEngine.UIElements.IPanel)
// 0x0000027E System.Void UnityEngine.UIElements.MouseEventBase`1::PostDispatch(UnityEngine.UIElements.IPanel)
// 0x0000027F T UnityEngine.UIElements.MouseEventBase`1::GetPooled(UnityEngine.Event)
// 0x00000280 T UnityEngine.UIElements.MouseEventBase`1::GetPooled(UnityEngine.UIElements.IMouseEvent,UnityEngine.Vector2,System.Boolean)
// 0x00000281 T UnityEngine.UIElements.MouseEventBase`1::GetPooled(UnityEngine.UIElements.IMouseEvent)
// 0x00000282 T UnityEngine.UIElements.MouseEventBase`1::GetPooled(UnityEngine.UIElements.IPointerEvent)
// 0x00000283 System.Void UnityEngine.UIElements.MouseEventBase`1::.ctor()
// 0x00000284 UnityEngine.UIElements.MouseDownEvent UnityEngine.UIElements.MouseDownEvent::MakeFromPointerEvent(UnityEngine.UIElements.IPointerEvent)
extern void MouseDownEvent_MakeFromPointerEvent_mE48AC579CD55EA39999785B14AE69F946076A708 (void);
// 0x00000285 UnityEngine.UIElements.MouseDownEvent UnityEngine.UIElements.MouseDownEvent::GetPooled(UnityEngine.UIElements.PointerDownEvent)
extern void MouseDownEvent_GetPooled_m9BD8A2D9A60896F118822E3F682B78915F5D25EB (void);
// 0x00000286 UnityEngine.UIElements.MouseDownEvent UnityEngine.UIElements.MouseDownEvent::GetPooled(UnityEngine.UIElements.PointerMoveEvent)
extern void MouseDownEvent_GetPooled_m10B30120FAD71BBB46E183CF82CA3D8F52121682 (void);
// 0x00000287 System.Void UnityEngine.UIElements.MouseDownEvent::.ctor()
extern void MouseDownEvent__ctor_mB5B7D59B0C30202178B6807248C0976F6D5D8AE0 (void);
// 0x00000288 UnityEngine.UIElements.MouseUpEvent UnityEngine.UIElements.MouseUpEvent::MakeFromPointerEvent(UnityEngine.UIElements.IPointerEvent)
extern void MouseUpEvent_MakeFromPointerEvent_m64AFF722CA1FF6A2014334238EDBA49A6E0A5EEE (void);
// 0x00000289 UnityEngine.UIElements.MouseUpEvent UnityEngine.UIElements.MouseUpEvent::GetPooled(UnityEngine.UIElements.PointerUpEvent)
extern void MouseUpEvent_GetPooled_mA2C004A46C712FDA6D8C1E0585D565F921DC5A65 (void);
// 0x0000028A UnityEngine.UIElements.MouseUpEvent UnityEngine.UIElements.MouseUpEvent::GetPooled(UnityEngine.UIElements.PointerMoveEvent)
extern void MouseUpEvent_GetPooled_m4D65D95BB4C485A39C582E16C190E77649A61554 (void);
// 0x0000028B UnityEngine.UIElements.MouseUpEvent UnityEngine.UIElements.MouseUpEvent::GetPooled(UnityEngine.UIElements.PointerCancelEvent)
extern void MouseUpEvent_GetPooled_m07142003287C30E1F692A7E5600D1BBDC5F5B0B1 (void);
// 0x0000028C System.Void UnityEngine.UIElements.MouseUpEvent::.ctor()
extern void MouseUpEvent__ctor_m9A2EAF1782DF259921562BD899C57DC97C03B732 (void);
// 0x0000028D UnityEngine.UIElements.MouseMoveEvent UnityEngine.UIElements.MouseMoveEvent::GetPooled(UnityEngine.UIElements.PointerMoveEvent)
extern void MouseMoveEvent_GetPooled_mFD5268330561837C739D27276C3503FFFD3D3BC7 (void);
// 0x0000028E System.Void UnityEngine.UIElements.MouseMoveEvent::.ctor()
extern void MouseMoveEvent__ctor_m8338EFE003BE5A9C8AB19FC39B5BD2BFB75F8BFC (void);
// 0x0000028F System.Void UnityEngine.UIElements.ContextClickEvent::.ctor()
extern void ContextClickEvent__ctor_mF146316FB93D2FA563E454E600805009421B7644 (void);
// 0x00000290 System.Void UnityEngine.UIElements.WheelEvent::set_delta(UnityEngine.Vector3)
extern void WheelEvent_set_delta_m4011F334763F8DB0440A93DB11969D5E54CE2941 (void);
// 0x00000291 UnityEngine.UIElements.WheelEvent UnityEngine.UIElements.WheelEvent::GetPooled(UnityEngine.Event)
extern void WheelEvent_GetPooled_mF7F5730BB2E121D607CCAC891424195B50A16D4C (void);
// 0x00000292 UnityEngine.UIElements.WheelEvent UnityEngine.UIElements.WheelEvent::GetPooled(UnityEngine.Vector3,UnityEngine.Vector3)
extern void WheelEvent_GetPooled_m5DD476C736F6CAE30AC11A9CB6D289B3C73C5D1B (void);
// 0x00000293 System.Void UnityEngine.UIElements.WheelEvent::Init()
extern void WheelEvent_Init_m4AC4D0DDD59BB370486E2F537A240490F1AEC8D3 (void);
// 0x00000294 System.Void UnityEngine.UIElements.WheelEvent::LocalInit()
extern void WheelEvent_LocalInit_m5A8D932691191AC77AFB357CFF3FDD03067F6EBF (void);
// 0x00000295 System.Void UnityEngine.UIElements.WheelEvent::.ctor()
extern void WheelEvent__ctor_m349D78D43A6CF8CAACF776D85F3770C8E9277B8B (void);
// 0x00000296 System.Void UnityEngine.UIElements.MouseEnterEvent::Init()
extern void MouseEnterEvent_Init_m8524B7C64446AECB34853348BA917A30FCAF439F (void);
// 0x00000297 System.Void UnityEngine.UIElements.MouseEnterEvent::LocalInit()
extern void MouseEnterEvent_LocalInit_mF63F7A2A6AC88A9DF3E562EAFBEF5171E99E82E7 (void);
// 0x00000298 System.Void UnityEngine.UIElements.MouseEnterEvent::.ctor()
extern void MouseEnterEvent__ctor_m23A8F9F5FE96CFA134DD06FA967C0DC0AE0BB067 (void);
// 0x00000299 System.Void UnityEngine.UIElements.MouseLeaveEvent::Init()
extern void MouseLeaveEvent_Init_m9CA31EAC25EB077BE7B2DB609311F5D64FF6AE9E (void);
// 0x0000029A System.Void UnityEngine.UIElements.MouseLeaveEvent::LocalInit()
extern void MouseLeaveEvent_LocalInit_m66D6950029CDF83E0638F2529B6A260E1F236702 (void);
// 0x0000029B System.Void UnityEngine.UIElements.MouseLeaveEvent::.ctor()
extern void MouseLeaveEvent__ctor_mD4E8784E7DC22BDD039F24121D7BAC0422EF655D (void);
// 0x0000029C System.Void UnityEngine.UIElements.MouseEnterWindowEvent::Init()
extern void MouseEnterWindowEvent_Init_m134110CF9AB641E6C917EC832AACC60E9D37AE9C (void);
// 0x0000029D System.Void UnityEngine.UIElements.MouseEnterWindowEvent::LocalInit()
extern void MouseEnterWindowEvent_LocalInit_mEED8CE36A83E7677BB8F1F383F85891F64B7CB30 (void);
// 0x0000029E System.Void UnityEngine.UIElements.MouseEnterWindowEvent::.ctor()
extern void MouseEnterWindowEvent__ctor_m2891A242FC54ACA0D46E50C0DE0778A85EE44475 (void);
// 0x0000029F System.Void UnityEngine.UIElements.MouseEnterWindowEvent::PostDispatch(UnityEngine.UIElements.IPanel)
extern void MouseEnterWindowEvent_PostDispatch_mFB4A31988A7F52D53D8EF7E680808488D6738D17 (void);
// 0x000002A0 System.Void UnityEngine.UIElements.MouseLeaveWindowEvent::Init()
extern void MouseLeaveWindowEvent_Init_m32D67F36EB72488F4FFF92CB23C76EA58B7C9CC8 (void);
// 0x000002A1 System.Void UnityEngine.UIElements.MouseLeaveWindowEvent::LocalInit()
extern void MouseLeaveWindowEvent_LocalInit_mB65FA9FB7135E44231403341595327C8A4CDA2A7 (void);
// 0x000002A2 System.Void UnityEngine.UIElements.MouseLeaveWindowEvent::.ctor()
extern void MouseLeaveWindowEvent__ctor_mAD5C25072B574D2808C98C277194DC17F6B4DE37 (void);
// 0x000002A3 UnityEngine.UIElements.MouseLeaveWindowEvent UnityEngine.UIElements.MouseLeaveWindowEvent::GetPooled(UnityEngine.Event)
extern void MouseLeaveWindowEvent_GetPooled_m54824BF17E16E0774F232C76F734ADD6C1D6CD8F (void);
// 0x000002A4 System.Void UnityEngine.UIElements.MouseLeaveWindowEvent::PostDispatch(UnityEngine.UIElements.IPanel)
extern void MouseLeaveWindowEvent_PostDispatch_mD51BA80C55554AF97EB1853B81B0135A55787F29 (void);
// 0x000002A5 System.Void UnityEngine.UIElements.MouseOverEvent::.ctor()
extern void MouseOverEvent__ctor_mD3939067D8EC2FC2727F2529E2F3E0E650D0B155 (void);
// 0x000002A6 System.Void UnityEngine.UIElements.MouseOutEvent::.ctor()
extern void MouseOutEvent__ctor_m19ECCBA4CE26D280244B5B29C046D09B0E3C7B24 (void);
// 0x000002A7 System.Void UnityEngine.UIElements.MouseEventsHelper::SendEnterLeave(UnityEngine.UIElements.VisualElement,UnityEngine.UIElements.VisualElement,UnityEngine.UIElements.IMouseEvent,UnityEngine.Vector2)
// 0x000002A8 System.Void UnityEngine.UIElements.MouseEventsHelper::SendMouseOverMouseOut(UnityEngine.UIElements.VisualElement,UnityEngine.UIElements.VisualElement,UnityEngine.UIElements.IMouseEvent,UnityEngine.Vector2)
extern void MouseEventsHelper_SendMouseOverMouseOut_mBF5DEDA49C28F692AC45E6685C676099C54C913E (void);
// 0x000002A9 System.Void UnityEngine.UIElements.PointerEventsHelper::SendEnterLeave(UnityEngine.UIElements.VisualElement,UnityEngine.UIElements.VisualElement,UnityEngine.UIElements.IPointerEvent,UnityEngine.Vector2,System.Int32)
// 0x000002AA System.Void UnityEngine.UIElements.PointerEventsHelper::SendOverOut(UnityEngine.UIElements.VisualElement,UnityEngine.UIElements.VisualElement,UnityEngine.UIElements.IPointerEvent,UnityEngine.Vector2,System.Int32)
extern void PointerEventsHelper_SendOverOut_mF5F6CBCD3D51CB61C761F7B63A10DC8A79C97FC8 (void);
// 0x000002AB System.Void UnityEngine.UIElements.NavigationEventBase`1::.ctor()
// 0x000002AC System.Void UnityEngine.UIElements.NavigationEventBase`1::Init()
// 0x000002AD System.Void UnityEngine.UIElements.NavigationEventBase`1::LocalInit()
// 0x000002AE UnityEngine.UIElements.NavigationMoveEvent/Direction UnityEngine.UIElements.NavigationMoveEvent::DetermineMoveDirection(System.Single,System.Single,System.Single)
extern void NavigationMoveEvent_DetermineMoveDirection_m6AECA115BD7BFE27FA931265382D1D6F4D652B6A (void);
// 0x000002AF System.Void UnityEngine.UIElements.NavigationMoveEvent::set_direction(UnityEngine.UIElements.NavigationMoveEvent/Direction)
extern void NavigationMoveEvent_set_direction_m27926B1045180FCEFD0ED4FBF78C9A6108D746E7 (void);
// 0x000002B0 System.Void UnityEngine.UIElements.NavigationMoveEvent::set_move(UnityEngine.Vector2)
extern void NavigationMoveEvent_set_move_mF6465D371C97E5BB1133BB0631FE0F70197BE458 (void);
// 0x000002B1 UnityEngine.UIElements.NavigationMoveEvent UnityEngine.UIElements.NavigationMoveEvent::GetPooled(UnityEngine.Vector2)
extern void NavigationMoveEvent_GetPooled_m91F6C91C42A6FF60B4CF11A37194F949186BC3C6 (void);
// 0x000002B2 System.Void UnityEngine.UIElements.NavigationMoveEvent::Init()
extern void NavigationMoveEvent_Init_mBA38585EAA9A261F96CDF3C27B537919C7751932 (void);
// 0x000002B3 System.Void UnityEngine.UIElements.NavigationMoveEvent::.ctor()
extern void NavigationMoveEvent__ctor_m91D5298F2D7A072641F446B3AB230141344D3E00 (void);
// 0x000002B4 System.Void UnityEngine.UIElements.NavigationTabEvent::set_direction(UnityEngine.UIElements.NavigationTabEvent/Direction)
extern void NavigationTabEvent_set_direction_mA0F32D4E7144F050FF5F07D5D5535674141EBD5B (void);
// 0x000002B5 UnityEngine.UIElements.NavigationTabEvent/Direction UnityEngine.UIElements.NavigationTabEvent::DetermineMoveDirection(System.Int32)
extern void NavigationTabEvent_DetermineMoveDirection_m23BE84C51FC6148C9762CAE10D6FAB2614161194 (void);
// 0x000002B6 UnityEngine.UIElements.NavigationTabEvent UnityEngine.UIElements.NavigationTabEvent::GetPooled(System.Int32)
extern void NavigationTabEvent_GetPooled_m10A3EC01256C3068E0F17877FAE1FFD9D1B1C90C (void);
// 0x000002B7 System.Void UnityEngine.UIElements.NavigationTabEvent::Init()
extern void NavigationTabEvent_Init_m52098CD181CC55F50D0B51402E609CB1F04C6C66 (void);
// 0x000002B8 System.Void UnityEngine.UIElements.NavigationTabEvent::.ctor()
extern void NavigationTabEvent__ctor_m4FC6E8B351ED8359B2D292979A672E12FDE22C3A (void);
// 0x000002B9 System.Void UnityEngine.UIElements.NavigationCancelEvent::.ctor()
extern void NavigationCancelEvent__ctor_m8B4E74079C21D8A3D98E80D0D93D551274F37384 (void);
// 0x000002BA System.Void UnityEngine.UIElements.NavigationSubmitEvent::.ctor()
extern void NavigationSubmitEvent__ctor_m19EB7E400616AAA55E0CFA85BAA0A64D7FADF9F3 (void);
// 0x000002BB System.Void UnityEngine.UIElements.PanelChangedEventBase`1::set_originPanel(UnityEngine.UIElements.IPanel)
// 0x000002BC System.Void UnityEngine.UIElements.PanelChangedEventBase`1::set_destinationPanel(UnityEngine.UIElements.IPanel)
// 0x000002BD System.Void UnityEngine.UIElements.PanelChangedEventBase`1::Init()
// 0x000002BE System.Void UnityEngine.UIElements.PanelChangedEventBase`1::LocalInit()
// 0x000002BF System.Void UnityEngine.UIElements.PanelChangedEventBase`1::.ctor()
// 0x000002C0 System.Void UnityEngine.UIElements.AttachToPanelEvent::.ctor()
extern void AttachToPanelEvent__ctor_m5E45CAC71DF8EF0795C203C3BE33A9828F9AF59F (void);
// 0x000002C1 System.Void UnityEngine.UIElements.DetachFromPanelEvent::.ctor()
extern void DetachFromPanelEvent__ctor_m12FE85F617BFD1407764B3DCA111450614FD804C (void);
// 0x000002C2 System.Boolean UnityEngine.UIElements.PointerCaptureDispatchingStrategy::CanDispatchEvent(UnityEngine.UIElements.EventBase)
extern void PointerCaptureDispatchingStrategy_CanDispatchEvent_mB40E1856BC671C00F18AA4B79EE6B7FE1232B3CD (void);
// 0x000002C3 System.Void UnityEngine.UIElements.PointerCaptureDispatchingStrategy::DispatchEvent(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.IPanel)
extern void PointerCaptureDispatchingStrategy_DispatchEvent_m733B268E70ED848D4273818CA30896D71043F4C3 (void);
// 0x000002C4 System.Void UnityEngine.UIElements.PointerCaptureDispatchingStrategy::.ctor()
extern void PointerCaptureDispatchingStrategy__ctor_m1779D761C384FDFC52CB6EDD98599F6112038542 (void);
// 0x000002C5 System.Void UnityEngine.UIElements.PointerDeviceState::SavePointerPosition(System.Int32,UnityEngine.Vector2,UnityEngine.UIElements.IPanel)
extern void PointerDeviceState_SavePointerPosition_mEF122393DA3DDDD76B90A294AAD949DCB4CAB326 (void);
// 0x000002C6 System.Void UnityEngine.UIElements.PointerDeviceState::PressButton(System.Int32,System.Int32)
extern void PointerDeviceState_PressButton_m94C835AFA3218D6E0611D5E95CF2CEFBA0695407 (void);
// 0x000002C7 System.Void UnityEngine.UIElements.PointerDeviceState::ReleaseButton(System.Int32,System.Int32)
extern void PointerDeviceState_ReleaseButton_m6362CE66A8893F34B6E3592D2772774F439EEEBD (void);
// 0x000002C8 System.Void UnityEngine.UIElements.PointerDeviceState::ReleaseAllButtons(System.Int32)
extern void PointerDeviceState_ReleaseAllButtons_m7F22F02643003A9787E18E3F391382DAE53F1F9C (void);
// 0x000002C9 UnityEngine.Vector2 UnityEngine.UIElements.PointerDeviceState::GetPointerPosition(System.Int32)
extern void PointerDeviceState_GetPointerPosition_mCDF2E493F70D3D01A0B835EDBA65D7A9438F3873 (void);
// 0x000002CA System.Int32 UnityEngine.UIElements.PointerDeviceState::GetPressedButtons(System.Int32)
extern void PointerDeviceState_GetPressedButtons_m2CB0A826D2D596EEDBE3E9B547E0F889B8B7EA0D (void);
// 0x000002CB System.Boolean UnityEngine.UIElements.PointerDeviceState::HasAdditionalPressedButtons(System.Int32,System.Int32)
extern void PointerDeviceState_HasAdditionalPressedButtons_m040E78C3B5392994F87C02B50795EDDFD8283AEC (void);
// 0x000002CC System.Void UnityEngine.UIElements.PointerDeviceState::.cctor()
extern void PointerDeviceState__cctor_mDB8DEFF9B20C4A507D1193350A57C07784B3EF49 (void);
// 0x000002CD System.Boolean UnityEngine.UIElements.PointerEventDispatchingStrategy::CanDispatchEvent(UnityEngine.UIElements.EventBase)
extern void PointerEventDispatchingStrategy_CanDispatchEvent_m3E6C5C25FE20312F3D8A676B084728D99B1C34DC (void);
// 0x000002CE System.Void UnityEngine.UIElements.PointerEventDispatchingStrategy::DispatchEvent(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.IPanel)
extern void PointerEventDispatchingStrategy_DispatchEvent_mB324E0C0207FF2505AE4C7EC8223F7F14E594D66 (void);
// 0x000002CF System.Void UnityEngine.UIElements.PointerEventDispatchingStrategy::SendEventToTarget(UnityEngine.UIElements.EventBase)
extern void PointerEventDispatchingStrategy_SendEventToTarget_mAE1672FB11C7E88C7EE71994283796A3456D60DC (void);
// 0x000002D0 System.Void UnityEngine.UIElements.PointerEventDispatchingStrategy::SetBestTargetForEvent(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.IPanel)
extern void PointerEventDispatchingStrategy_SetBestTargetForEvent_m04F8CD8E21D260E3DD499B496FE9798185DF99B0 (void);
// 0x000002D1 System.Void UnityEngine.UIElements.PointerEventDispatchingStrategy::UpdateElementUnderPointer(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.IPanel,UnityEngine.UIElements.VisualElement&)
extern void PointerEventDispatchingStrategy_UpdateElementUnderPointer_mFAE2047E4CA53712A0E4DFE69DC1187085CE63C6 (void);
// 0x000002D2 System.Void UnityEngine.UIElements.PointerEventDispatchingStrategy::.ctor()
extern void PointerEventDispatchingStrategy__ctor_mD7E9B783810D57380849CC9B91D0C002A00E1071 (void);
// 0x000002D3 System.String UnityEngine.UIElements.PointerType::GetPointerType(System.Int32)
extern void PointerType_GetPointerType_mC5B68065EA16AC95D5369CF623DC0848AEACE244 (void);
// 0x000002D4 System.Boolean UnityEngine.UIElements.PointerType::IsDirectManipulationDevice(System.String)
extern void PointerType_IsDirectManipulationDevice_m18319821C271B05D7C8F778F57BD2326797555B7 (void);
// 0x000002D5 System.Void UnityEngine.UIElements.PointerType::.cctor()
extern void PointerType__cctor_mE4ED6420F77B13F239FF35D99622A46FF117927C (void);
// 0x000002D6 System.Void UnityEngine.UIElements.PointerId::.cctor()
extern void PointerId__cctor_m78A847AFC9330255BA877654E46EF8A9B7E199E9 (void);
// 0x000002D7 System.Int32 UnityEngine.UIElements.IPointerEvent::get_pointerId()
// 0x000002D8 System.String UnityEngine.UIElements.IPointerEvent::get_pointerType()
// 0x000002D9 System.Boolean UnityEngine.UIElements.IPointerEvent::get_isPrimary()
// 0x000002DA System.Int32 UnityEngine.UIElements.IPointerEvent::get_button()
// 0x000002DB System.Int32 UnityEngine.UIElements.IPointerEvent::get_pressedButtons()
// 0x000002DC UnityEngine.Vector3 UnityEngine.UIElements.IPointerEvent::get_position()
// 0x000002DD UnityEngine.Vector3 UnityEngine.UIElements.IPointerEvent::get_localPosition()
// 0x000002DE UnityEngine.Vector3 UnityEngine.UIElements.IPointerEvent::get_deltaPosition()
// 0x000002DF System.Single UnityEngine.UIElements.IPointerEvent::get_deltaTime()
// 0x000002E0 System.Int32 UnityEngine.UIElements.IPointerEvent::get_clickCount()
// 0x000002E1 System.Single UnityEngine.UIElements.IPointerEvent::get_pressure()
// 0x000002E2 System.Single UnityEngine.UIElements.IPointerEvent::get_tangentialPressure()
// 0x000002E3 System.Single UnityEngine.UIElements.IPointerEvent::get_altitudeAngle()
// 0x000002E4 System.Single UnityEngine.UIElements.IPointerEvent::get_azimuthAngle()
// 0x000002E5 System.Single UnityEngine.UIElements.IPointerEvent::get_twist()
// 0x000002E6 UnityEngine.Vector2 UnityEngine.UIElements.IPointerEvent::get_radius()
// 0x000002E7 UnityEngine.Vector2 UnityEngine.UIElements.IPointerEvent::get_radiusVariance()
// 0x000002E8 UnityEngine.EventModifiers UnityEngine.UIElements.IPointerEvent::get_modifiers()
// 0x000002E9 System.Boolean UnityEngine.UIElements.IPointerEventInternal::get_triggeredByOS()
// 0x000002EA System.Void UnityEngine.UIElements.IPointerEventInternal::set_triggeredByOS(System.Boolean)
// 0x000002EB System.Boolean UnityEngine.UIElements.IPointerEventInternal::get_recomputeTopElementUnderPointer()
// 0x000002EC System.Void UnityEngine.UIElements.IPointerEventInternal::set_recomputeTopElementUnderPointer(System.Boolean)
// 0x000002ED System.Int32 UnityEngine.UIElements.PointerEventBase`1::get_pointerId()
// 0x000002EE System.Void UnityEngine.UIElements.PointerEventBase`1::set_pointerId(System.Int32)
// 0x000002EF System.String UnityEngine.UIElements.PointerEventBase`1::get_pointerType()
// 0x000002F0 System.Void UnityEngine.UIElements.PointerEventBase`1::set_pointerType(System.String)
// 0x000002F1 System.Boolean UnityEngine.UIElements.PointerEventBase`1::get_isPrimary()
// 0x000002F2 System.Void UnityEngine.UIElements.PointerEventBase`1::set_isPrimary(System.Boolean)
// 0x000002F3 System.Int32 UnityEngine.UIElements.PointerEventBase`1::get_button()
// 0x000002F4 System.Void UnityEngine.UIElements.PointerEventBase`1::set_button(System.Int32)
// 0x000002F5 System.Int32 UnityEngine.UIElements.PointerEventBase`1::get_pressedButtons()
// 0x000002F6 System.Void UnityEngine.UIElements.PointerEventBase`1::set_pressedButtons(System.Int32)
// 0x000002F7 UnityEngine.Vector3 UnityEngine.UIElements.PointerEventBase`1::get_position()
// 0x000002F8 System.Void UnityEngine.UIElements.PointerEventBase`1::set_position(UnityEngine.Vector3)
// 0x000002F9 UnityEngine.Vector3 UnityEngine.UIElements.PointerEventBase`1::get_localPosition()
// 0x000002FA System.Void UnityEngine.UIElements.PointerEventBase`1::set_localPosition(UnityEngine.Vector3)
// 0x000002FB UnityEngine.Vector3 UnityEngine.UIElements.PointerEventBase`1::get_deltaPosition()
// 0x000002FC System.Void UnityEngine.UIElements.PointerEventBase`1::set_deltaPosition(UnityEngine.Vector3)
// 0x000002FD System.Single UnityEngine.UIElements.PointerEventBase`1::get_deltaTime()
// 0x000002FE System.Void UnityEngine.UIElements.PointerEventBase`1::set_deltaTime(System.Single)
// 0x000002FF System.Int32 UnityEngine.UIElements.PointerEventBase`1::get_clickCount()
// 0x00000300 System.Void UnityEngine.UIElements.PointerEventBase`1::set_clickCount(System.Int32)
// 0x00000301 System.Single UnityEngine.UIElements.PointerEventBase`1::get_pressure()
// 0x00000302 System.Void UnityEngine.UIElements.PointerEventBase`1::set_pressure(System.Single)
// 0x00000303 System.Single UnityEngine.UIElements.PointerEventBase`1::get_tangentialPressure()
// 0x00000304 System.Void UnityEngine.UIElements.PointerEventBase`1::set_tangentialPressure(System.Single)
// 0x00000305 System.Single UnityEngine.UIElements.PointerEventBase`1::get_altitudeAngle()
// 0x00000306 System.Void UnityEngine.UIElements.PointerEventBase`1::set_altitudeAngle(System.Single)
// 0x00000307 System.Single UnityEngine.UIElements.PointerEventBase`1::get_azimuthAngle()
// 0x00000308 System.Void UnityEngine.UIElements.PointerEventBase`1::set_azimuthAngle(System.Single)
// 0x00000309 System.Single UnityEngine.UIElements.PointerEventBase`1::get_twist()
// 0x0000030A System.Void UnityEngine.UIElements.PointerEventBase`1::set_twist(System.Single)
// 0x0000030B UnityEngine.Vector2 UnityEngine.UIElements.PointerEventBase`1::get_radius()
// 0x0000030C System.Void UnityEngine.UIElements.PointerEventBase`1::set_radius(UnityEngine.Vector2)
// 0x0000030D UnityEngine.Vector2 UnityEngine.UIElements.PointerEventBase`1::get_radiusVariance()
// 0x0000030E System.Void UnityEngine.UIElements.PointerEventBase`1::set_radiusVariance(UnityEngine.Vector2)
// 0x0000030F UnityEngine.EventModifiers UnityEngine.UIElements.PointerEventBase`1::get_modifiers()
// 0x00000310 System.Void UnityEngine.UIElements.PointerEventBase`1::set_modifiers(UnityEngine.EventModifiers)
// 0x00000311 System.Boolean UnityEngine.UIElements.PointerEventBase`1::UnityEngine.UIElements.IPointerEventInternal.get_triggeredByOS()
// 0x00000312 System.Void UnityEngine.UIElements.PointerEventBase`1::UnityEngine.UIElements.IPointerEventInternal.set_triggeredByOS(System.Boolean)
// 0x00000313 System.Boolean UnityEngine.UIElements.PointerEventBase`1::UnityEngine.UIElements.IPointerEventInternal.get_recomputeTopElementUnderPointer()
// 0x00000314 System.Void UnityEngine.UIElements.PointerEventBase`1::UnityEngine.UIElements.IPointerEventInternal.set_recomputeTopElementUnderPointer(System.Boolean)
// 0x00000315 System.Void UnityEngine.UIElements.PointerEventBase`1::Init()
// 0x00000316 System.Void UnityEngine.UIElements.PointerEventBase`1::LocalInit()
// 0x00000317 UnityEngine.UIElements.IEventHandler UnityEngine.UIElements.PointerEventBase`1::get_currentTarget()
// 0x00000318 System.Void UnityEngine.UIElements.PointerEventBase`1::set_currentTarget(UnityEngine.UIElements.IEventHandler)
// 0x00000319 System.Boolean UnityEngine.UIElements.PointerEventBase`1::IsMouse(UnityEngine.Event)
// 0x0000031A T UnityEngine.UIElements.PointerEventBase`1::GetPooled(UnityEngine.Event)
// 0x0000031B T UnityEngine.UIElements.PointerEventBase`1::GetPooled(UnityEngine.UIElements.IPointerEvent,UnityEngine.Vector2,System.Int32)
// 0x0000031C T UnityEngine.UIElements.PointerEventBase`1::GetPooled(UnityEngine.UIElements.IPointerEvent)
// 0x0000031D System.Void UnityEngine.UIElements.PointerEventBase`1::PreDispatch(UnityEngine.UIElements.IPanel)
// 0x0000031E System.Void UnityEngine.UIElements.PointerEventBase`1::PostDispatch(UnityEngine.UIElements.IPanel)
// 0x0000031F System.Void UnityEngine.UIElements.PointerEventBase`1::.ctor()
// 0x00000320 System.Void UnityEngine.UIElements.PointerDownEvent::Init()
extern void PointerDownEvent_Init_mC2FE41D611A632A9859D75C1BDFBC39124338F50 (void);
// 0x00000321 System.Void UnityEngine.UIElements.PointerDownEvent::LocalInit()
extern void PointerDownEvent_LocalInit_m031B53FEBA399B7A308F037D9A235F5B6FB8CADD (void);
// 0x00000322 System.Void UnityEngine.UIElements.PointerDownEvent::.ctor()
extern void PointerDownEvent__ctor_mBB78C62DAE81EB0618149FFFA86C15F88A3523C8 (void);
// 0x00000323 System.Void UnityEngine.UIElements.PointerDownEvent::PostDispatch(UnityEngine.UIElements.IPanel)
extern void PointerDownEvent_PostDispatch_mA039FA50EF9FC8A112D19EFB4FE04E33F8913AE2 (void);
// 0x00000324 System.Void UnityEngine.UIElements.PointerMoveEvent::set_isHandledByDraggable(System.Boolean)
extern void PointerMoveEvent_set_isHandledByDraggable_m5524FBF6C85971663E4DDC39E16039CF08A722BD (void);
// 0x00000325 System.Void UnityEngine.UIElements.PointerMoveEvent::Init()
extern void PointerMoveEvent_Init_m01B48610E00D315AA4335A4555CA9E9A1A98579D (void);
// 0x00000326 System.Void UnityEngine.UIElements.PointerMoveEvent::LocalInit()
extern void PointerMoveEvent_LocalInit_m914823683747F3517ACF28EC28E90AA141F3AA53 (void);
// 0x00000327 System.Void UnityEngine.UIElements.PointerMoveEvent::.ctor()
extern void PointerMoveEvent__ctor_mA5B01F8892A2ACDBADD61B766B3181C58A6BC598 (void);
// 0x00000328 System.Void UnityEngine.UIElements.PointerMoveEvent::PostDispatch(UnityEngine.UIElements.IPanel)
extern void PointerMoveEvent_PostDispatch_m0CAC54B14AFD21EE1777A3CAEA694C83E6D92C4A (void);
// 0x00000329 System.Void UnityEngine.UIElements.PointerStationaryEvent::Init()
extern void PointerStationaryEvent_Init_m2F74912B6F8E47F834B9CD4AB69CCA578793F5FC (void);
// 0x0000032A System.Void UnityEngine.UIElements.PointerStationaryEvent::LocalInit()
extern void PointerStationaryEvent_LocalInit_mFF2BFDA3880337809FAD25D339EAC680F91AB5B1 (void);
// 0x0000032B System.Void UnityEngine.UIElements.PointerStationaryEvent::.ctor()
extern void PointerStationaryEvent__ctor_m6F656BC8B4D581C2B59E14F70C24B9BF62BDC87E (void);
// 0x0000032C System.Void UnityEngine.UIElements.PointerUpEvent::Init()
extern void PointerUpEvent_Init_m6FE64AD9396F7DC5C2EC59A609FFBD840AECDD7D (void);
// 0x0000032D System.Void UnityEngine.UIElements.PointerUpEvent::LocalInit()
extern void PointerUpEvent_LocalInit_m97B6A85A029E0BBBA8DFE8529467019B555AB750 (void);
// 0x0000032E System.Void UnityEngine.UIElements.PointerUpEvent::.ctor()
extern void PointerUpEvent__ctor_m58B8B9A6646DE2979BE8283ED52311EE1131AF4D (void);
// 0x0000032F System.Void UnityEngine.UIElements.PointerUpEvent::PostDispatch(UnityEngine.UIElements.IPanel)
extern void PointerUpEvent_PostDispatch_m9678D83B64EF5E3F73FF6B463BFE22C5E20489F3 (void);
// 0x00000330 System.Void UnityEngine.UIElements.PointerCancelEvent::Init()
extern void PointerCancelEvent_Init_mEE63311CC5F8D54F5456AC358DF8F9320750BCAF (void);
// 0x00000331 System.Void UnityEngine.UIElements.PointerCancelEvent::LocalInit()
extern void PointerCancelEvent_LocalInit_m1E15CD4EB381B595E5207F00907A0E2321D20E5A (void);
// 0x00000332 System.Void UnityEngine.UIElements.PointerCancelEvent::.ctor()
extern void PointerCancelEvent__ctor_mB4F6A7F10076FCFCD62AE01AB4C487BF4F3CA127 (void);
// 0x00000333 System.Void UnityEngine.UIElements.PointerCancelEvent::PostDispatch(UnityEngine.UIElements.IPanel)
extern void PointerCancelEvent_PostDispatch_mE078C677CB449C11715A52784972C212E2786796 (void);
// 0x00000334 UnityEngine.UIElements.ClickEvent UnityEngine.UIElements.ClickEvent::GetPooled(UnityEngine.UIElements.PointerUpEvent,System.Int32)
extern void ClickEvent_GetPooled_mA80F7CA88FB9B3FCED3C0954B5422336B4071AA7 (void);
// 0x00000335 System.Void UnityEngine.UIElements.ClickEvent::.ctor()
extern void ClickEvent__ctor_m550342FBB4A2411720170650462C7C7EE373A021 (void);
// 0x00000336 System.Void UnityEngine.UIElements.PointerEnterEvent::Init()
extern void PointerEnterEvent_Init_mD35F66B52D91FB299C0CE3EECC0833EF94F21FDB (void);
// 0x00000337 System.Void UnityEngine.UIElements.PointerEnterEvent::LocalInit()
extern void PointerEnterEvent_LocalInit_mA6F0CEFF2F20C0AAD04AF836C8FA4F5AE3D4DA9C (void);
// 0x00000338 System.Void UnityEngine.UIElements.PointerEnterEvent::.ctor()
extern void PointerEnterEvent__ctor_mAFF4D46DE8CA5D29C1FDF16EB65722D3BBB4C9AE (void);
// 0x00000339 System.Void UnityEngine.UIElements.PointerLeaveEvent::Init()
extern void PointerLeaveEvent_Init_m134F71D1E7DF9260963030E33CDBC7351D17E5CE (void);
// 0x0000033A System.Void UnityEngine.UIElements.PointerLeaveEvent::LocalInit()
extern void PointerLeaveEvent_LocalInit_m971E9B1E26F762A3C6D415CF539E4A25D7403F92 (void);
// 0x0000033B System.Void UnityEngine.UIElements.PointerLeaveEvent::.ctor()
extern void PointerLeaveEvent__ctor_m5540F6457DC3FBEB69CA94D12758D82628FD3E8E (void);
// 0x0000033C System.Void UnityEngine.UIElements.PointerOverEvent::.ctor()
extern void PointerOverEvent__ctor_mE74C0588B457AB4B1CE6CEE462AF22EA60851950 (void);
// 0x0000033D System.Void UnityEngine.UIElements.PointerOutEvent::.ctor()
extern void PointerOutEvent__ctor_m379ED3D47D480DF021BF63DF3B4717022D806281 (void);
// 0x0000033E System.Void UnityEngine.UIElements.PropagationPaths::.ctor()
extern void PropagationPaths__ctor_m198ECB782CC29620C76003DB37FDFDCFBD85D8CF (void);
// 0x0000033F UnityEngine.UIElements.PropagationPaths UnityEngine.UIElements.PropagationPaths::Copy(UnityEngine.UIElements.PropagationPaths)
extern void PropagationPaths_Copy_m5DC4E96D86F3F4B7BD4C239B494077259E439559 (void);
// 0x00000340 UnityEngine.UIElements.PropagationPaths UnityEngine.UIElements.PropagationPaths::Build(UnityEngine.UIElements.VisualElement,UnityEngine.UIElements.PropagationPaths/Type)
extern void PropagationPaths_Build_m6F092641AB07F3712728F027815F35B64170CFB0 (void);
// 0x00000341 System.Void UnityEngine.UIElements.PropagationPaths::Release()
extern void PropagationPaths_Release_m0C86E97EEA98A2FE425E9469696C37580B203DA9 (void);
// 0x00000342 System.Void UnityEngine.UIElements.PropagationPaths::.cctor()
extern void PropagationPaths__cctor_m57966E948C5347A24ED5C5519616C5AD16F581CE (void);
// 0x00000343 UnityEngine.UIElements.IMGUIEvent UnityEngine.UIElements.IMGUIEvent::GetPooled(UnityEngine.Event)
extern void IMGUIEvent_GetPooled_mEDF82C9920099781130374688D3214AB82243221 (void);
// 0x00000344 System.Void UnityEngine.UIElements.IMGUIEvent::Init()
extern void IMGUIEvent_Init_m7F06C2BE4437F382F7F312D97F40D93711CF0EDB (void);
// 0x00000345 System.Void UnityEngine.UIElements.IMGUIEvent::LocalInit()
extern void IMGUIEvent_LocalInit_m3BE54E2CC99AAA8730109530B91520283A227771 (void);
// 0x00000346 System.Void UnityEngine.UIElements.IMGUIEvent::.ctor()
extern void IMGUIEvent__ctor_m74EBDD247E2CF4C4CB4B32D9E52E9BB2163DDD12 (void);
// 0x00000347 System.Void UnityEngine.UIElements.EventDebuggerLogCall::.ctor(System.Delegate,UnityEngine.UIElements.EventBase)
extern void EventDebuggerLogCall__ctor_m3BECE7E172820A4CC8A888A5C5DF3B394C7A6104 (void);
// 0x00000348 System.Void UnityEngine.UIElements.EventDebuggerLogCall::Dispose()
extern void EventDebuggerLogCall_Dispose_mAC918B4414348292EEE5A48FE003F04283A440BD (void);
// 0x00000349 System.Void UnityEngine.UIElements.EventDebuggerLogIMGUICall::.ctor(UnityEngine.UIElements.EventBase)
extern void EventDebuggerLogIMGUICall__ctor_mEDDEAE9B6D3B7BED69E9C9E0C826B06FA72ABB39 (void);
// 0x0000034A System.Void UnityEngine.UIElements.EventDebuggerLogIMGUICall::Dispose()
extern void EventDebuggerLogIMGUICall_Dispose_mD514BF548D060B95497BA8213F2838CA95511FF4 (void);
// 0x0000034B System.Void UnityEngine.UIElements.EventDebuggerLogExecuteDefaultAction::.ctor(UnityEngine.UIElements.EventBase)
extern void EventDebuggerLogExecuteDefaultAction__ctor_mA0B9522A991D035CA8CD2C1447D00F94BA96CFC6 (void);
// 0x0000034C System.Void UnityEngine.UIElements.EventDebuggerLogExecuteDefaultAction::Dispose()
extern void EventDebuggerLogExecuteDefaultAction_Dispose_m97C7090D369A879F861860F54D4ED40CDD10D7CE (void);
// 0x0000034D System.Void UnityEngine.UIElements.EventDebugger::LogPropagationPaths(UnityEngine.UIElements.EventBase,UnityEngine.UIElements.PropagationPaths)
extern void EventDebugger_LogPropagationPaths_m7C0BCDC9E0A7105852D0E7A668D0E72D91BB32EB (void);
// 0x0000034E System.Void UnityEngine.UIElements.GlobalCallbackRegistry::RegisterListeners(UnityEngine.UIElements.CallbackEventHandler,System.Delegate,UnityEngine.UIElements.TrickleDown)
// 0x0000034F System.Void UnityEngine.UIElements.GlobalCallbackRegistry::UnregisterListeners(UnityEngine.UIElements.CallbackEventHandler,System.Delegate)
// 0x00000350 System.Void UnityEngine.UIElements.Vertex::.cctor()
extern void Vertex__cctor_m1655B6F0C62DD2784C09D744D722C112D582FA9C (void);
// 0x00000351 System.Void UnityEngine.UIElements.TextureId::.ctor(System.Int32)
extern void TextureId__ctor_mF92FD82CFE633466686BE9710BD59CEB9F2F3B93 (void);
// 0x00000352 System.Boolean UnityEngine.UIElements.TextureId::Equals(System.Object)
extern void TextureId_Equals_mFD55BECFABBE801D3CC7CFF6C1AA941EF6CAA483 (void);
// 0x00000353 System.Int32 UnityEngine.UIElements.TextureId::GetHashCode()
extern void TextureId_GetHashCode_mD4EE49739E0E55AAECB0EEFCDF9561B373804A56 (void);
// 0x00000354 System.Boolean UnityEngine.UIElements.TextureId::op_Equality(UnityEngine.UIElements.TextureId,UnityEngine.UIElements.TextureId)
extern void TextureId_op_Equality_m98F8D53632A90B3E8A8A247E912291C28F0D2F7B (void);
// 0x00000355 System.Void UnityEngine.UIElements.TextureId::.cctor()
extern void TextureId__cctor_mB6DA7E590DCFE3AA55F3F4F5FC07E10BBF5EB389 (void);
// 0x00000356 System.Void UnityEngine.UIElements.TextureRegistry::.ctor()
extern void TextureRegistry__ctor_mFD9CB28A5D434AB63FE2192627FD953636B420D6 (void);
// 0x00000357 System.Void UnityEngine.UIElements.TextureRegistry::.cctor()
extern void TextureRegistry__cctor_mCBFF01DB650A23BBBB708467D46E47A1CA78C235 (void);
// 0x00000358 System.Void UnityEngine.UIElements.UIRUtility::Multiply2D(UnityEngine.Quaternion,UnityEngine.Vector2&)
extern void UIRUtility_Multiply2D_mD7CD488D76ABAB2370FF8AD6D39FA171B2347394 (void);
// 0x00000359 System.Void UnityEngine.UIElements.UIRUtility::.cctor()
extern void UIRUtility__cctor_mA19F8A55F66D1EDBA529DF9F1F3352FAEADC9FD4 (void);
// 0x0000035A UnityEngine.Texture2D UnityEngine.UIElements.Background::get_texture()
extern void Background_get_texture_mA63F83DD089DAD7929403E51739C5851550F02A6 (void);
// 0x0000035B UnityEngine.Sprite UnityEngine.UIElements.Background::get_sprite()
extern void Background_get_sprite_m25D7D08C5517DD90FF6AD34E113488EC558820CF (void);
// 0x0000035C UnityEngine.RenderTexture UnityEngine.UIElements.Background::get_renderTexture()
extern void Background_get_renderTexture_mC8CA118E08F1C3821E1AA862C43AAF0DD67E15CF (void);
// 0x0000035D UnityEngine.UIElements.VectorImage UnityEngine.UIElements.Background::get_vectorImage()
extern void Background_get_vectorImage_mBDE387DC6522B639F188559BA8BC158AB76FE01F (void);
// 0x0000035E System.Boolean UnityEngine.UIElements.Background::op_Equality(UnityEngine.UIElements.Background,UnityEngine.UIElements.Background)
extern void Background_op_Equality_m53EED27810C4ACE95F19C04CE1BB4E444D16321E (void);
// 0x0000035F System.Boolean UnityEngine.UIElements.Background::Equals(UnityEngine.UIElements.Background)
extern void Background_Equals_m7C6B2AEAFEBA2A1E80E03DCDB8475DDC72C36122 (void);
// 0x00000360 System.Boolean UnityEngine.UIElements.Background::Equals(System.Object)
extern void Background_Equals_mBA1B1A4595B4840EBC8F31810EC7DF1A2A836079 (void);
// 0x00000361 System.Int32 UnityEngine.UIElements.Background::GetHashCode()
extern void Background_GetHashCode_mBD232D956BBEF57CE19D8AFFB512C391D2CF6F85 (void);
// 0x00000362 System.String UnityEngine.UIElements.Background::ToString()
extern void Background_ToString_m34898FF6F35AF997BFFECD0EEE53C8865D6D826D (void);
// 0x00000363 UnityEngine.UIElements.DisplayStyle UnityEngine.UIElements.ComputedStyle::get_display()
extern void ComputedStyle_get_display_mE329A987B8999CC3B23A1542A5CED1264E65EECB (void);
// 0x00000364 UnityEngine.UIElements.OverflowInternal UnityEngine.UIElements.ComputedStyle::get_overflow()
extern void ComputedStyle_get_overflow_m2B7BBA66004120AD1BBAC02841CA11671FCFD932 (void);
// 0x00000365 UnityEngine.UIElements.Visibility UnityEngine.UIElements.ComputedStyle::get_visibility()
extern void ComputedStyle_get_visibility_m154FC53F0CEF43613FDBCF20043288C6751BEC7E (void);
// 0x00000366 System.Void UnityEngine.UIElements.InlineStyleAccess::.cctor()
extern void InlineStyleAccess__cctor_mA78F8DFD7786897E67F601F29539683D0D289334 (void);
// 0x00000367 System.Single UnityEngine.UIElements.Length::get_value()
extern void Length_get_value_mA4FA93BC4DCDECC2F7924CC670F1F5D8254FEA58 (void);
// 0x00000368 System.Boolean UnityEngine.UIElements.Length::op_Equality(UnityEngine.UIElements.Length,UnityEngine.UIElements.Length)
extern void Length_op_Equality_m0557C187458BA989288104CB71E70A48760BF10F (void);
// 0x00000369 System.Boolean UnityEngine.UIElements.Length::Equals(UnityEngine.UIElements.Length)
extern void Length_Equals_m0A3FD834E46EF5705BE84290C1599F9911086D14 (void);
// 0x0000036A System.Boolean UnityEngine.UIElements.Length::Equals(System.Object)
extern void Length_Equals_m6B542AF4AC1749DCB3043688D7E1F019C0982878 (void);
// 0x0000036B System.Int32 UnityEngine.UIElements.Length::GetHashCode()
extern void Length_GetHashCode_mB085D75326582AF604E67471FC0CDC541ED901FE (void);
// 0x0000036C System.String UnityEngine.UIElements.Length::ToString()
extern void Length_ToString_mDBBF6F21874192E6616439E65660A912213E6403 (void);
// 0x0000036D UnityEngine.UIElements.Cursor UnityEngine.UIElements.StyleCursor::get_value()
extern void StyleCursor_get_value_mCDB0484E3DE7CA4E81906DB4E044078018E04025 (void);
// 0x0000036E UnityEngine.UIElements.StyleKeyword UnityEngine.UIElements.StyleCursor::get_keyword()
extern void StyleCursor_get_keyword_m27F124F0043C04D8F2FCE291BB3694AF7050350C (void);
// 0x0000036F System.Boolean UnityEngine.UIElements.StyleCursor::op_Equality(UnityEngine.UIElements.StyleCursor,UnityEngine.UIElements.StyleCursor)
extern void StyleCursor_op_Equality_mD0DE94E2D8236A07145A0F094242269C0295E976 (void);
// 0x00000370 System.Boolean UnityEngine.UIElements.StyleCursor::Equals(UnityEngine.UIElements.StyleCursor)
extern void StyleCursor_Equals_m297545CF5CA9A0A8E93A6C20ED549C64C12B9D07 (void);
// 0x00000371 System.Boolean UnityEngine.UIElements.StyleCursor::Equals(System.Object)
extern void StyleCursor_Equals_m998BF8547E4DE87B804AE9EF0CFC68A6F2395D0C (void);
// 0x00000372 System.Int32 UnityEngine.UIElements.StyleCursor::GetHashCode()
extern void StyleCursor_GetHashCode_mFE166026315A0B2F9A5E4BD1E8DF1850B0670516 (void);
// 0x00000373 System.String UnityEngine.UIElements.StyleCursor::ToString()
extern void StyleCursor_ToString_mB2BC0AD1C83182CF232257FCA2DAC90654CD6420 (void);
// 0x00000374 UnityEngine.UIElements.TextShadow UnityEngine.UIElements.StyleTextShadow::get_value()
extern void StyleTextShadow_get_value_m59F40FAC3AF65BF3C3D4A6264FB77A16034B3B30 (void);
// 0x00000375 UnityEngine.UIElements.StyleKeyword UnityEngine.UIElements.StyleTextShadow::get_keyword()
extern void StyleTextShadow_get_keyword_m078DD449662B63C2CAC154FA619AAF818306D625 (void);
// 0x00000376 System.Boolean UnityEngine.UIElements.StyleTextShadow::op_Equality(UnityEngine.UIElements.StyleTextShadow,UnityEngine.UIElements.StyleTextShadow)
extern void StyleTextShadow_op_Equality_m067CD4AB9F967C71E1E6C52A511E52DC8362DABE (void);
// 0x00000377 System.Boolean UnityEngine.UIElements.StyleTextShadow::Equals(UnityEngine.UIElements.StyleTextShadow)
extern void StyleTextShadow_Equals_m43B1662CE1E1D635B6463C3AF9C2346FD80A0ECE (void);
// 0x00000378 System.Boolean UnityEngine.UIElements.StyleTextShadow::Equals(System.Object)
extern void StyleTextShadow_Equals_m655B1C34E98BBDE996BF056620B77836EACC2747 (void);
// 0x00000379 System.Int32 UnityEngine.UIElements.StyleTextShadow::GetHashCode()
extern void StyleTextShadow_GetHashCode_mE50EE505A874E19D1A51DDF5E1427C590BB288CE (void);
// 0x0000037A System.String UnityEngine.UIElements.StyleTextShadow::ToString()
extern void StyleTextShadow_ToString_mC67AE6434EA0C4C5FBA8E528DDA547404396491E (void);
// 0x0000037B T UnityEngine.UIElements.IStyleValue`1::get_value()
// 0x0000037C UnityEngine.UIElements.StyleKeyword UnityEngine.UIElements.IStyleValue`1::get_keyword()
// 0x0000037D System.String UnityEngine.UIElements.StyleValueExtensions::DebugString(UnityEngine.UIElements.IStyleValue`1<T>)
// 0x0000037E UnityEngine.UIElements.DisplayStyle UnityEngine.UIElements.IResolvedStyle::get_display()
// 0x0000037F UnityEngine.UIElements.Visibility UnityEngine.UIElements.IResolvedStyle::get_visibility()
// 0x00000380 System.Boolean UnityEngine.UIElements.InheritedData::op_Equality(UnityEngine.UIElements.InheritedData,UnityEngine.UIElements.InheritedData)
extern void InheritedData_op_Equality_m5DC984B2DFB780C53A9B8F0ECBECC81E51A18861 (void);
// 0x00000381 System.Boolean UnityEngine.UIElements.InheritedData::Equals(UnityEngine.UIElements.InheritedData)
extern void InheritedData_Equals_mFEF649CA9E856BE9B039C5539226490A9549FAC4 (void);
// 0x00000382 System.Boolean UnityEngine.UIElements.InheritedData::Equals(System.Object)
extern void InheritedData_Equals_m5F46861C98C2FADF8983C2C31FE08A76CE8B2C69 (void);
// 0x00000383 System.Int32 UnityEngine.UIElements.InheritedData::GetHashCode()
extern void InheritedData_GetHashCode_mE4AECCEF2E7FF6250B76E05761A10401D1E439C9 (void);
// 0x00000384 System.Boolean UnityEngine.UIElements.NonInheritedData::op_Equality(UnityEngine.UIElements.NonInheritedData,UnityEngine.UIElements.NonInheritedData)
extern void NonInheritedData_op_Equality_mF596F87B3E941AA2F0CD2EB6C511CA31B3BCA2C3 (void);
// 0x00000385 System.Boolean UnityEngine.UIElements.NonInheritedData::Equals(UnityEngine.UIElements.NonInheritedData)
extern void NonInheritedData_Equals_m39B2CDB94DFD4DECE0E3C77747722AB6C6F1097A (void);
// 0x00000386 System.Boolean UnityEngine.UIElements.NonInheritedData::Equals(System.Object)
extern void NonInheritedData_Equals_m158B81483FB00F11CB97F118431287F8D8A2A98A (void);
// 0x00000387 System.Int32 UnityEngine.UIElements.NonInheritedData::GetHashCode()
extern void NonInheritedData_GetHashCode_mD2FEDB6E3046B69DFE32E2496E716EFD6CAD07B6 (void);
// 0x00000388 System.Void UnityEngine.UIElements.StyleComplexSelector::set_rule(UnityEngine.UIElements.StyleRule)
extern void StyleComplexSelector_set_rule_mE8DE1FA572559977BE9857645C171A5D1883DEAC (void);
// 0x00000389 UnityEngine.UIElements.StyleSelector[] UnityEngine.UIElements.StyleComplexSelector::get_selectors()
extern void StyleComplexSelector_get_selectors_m04AE9E0724CE27B029EF8F4D2FAA97F1FF15CDC2 (void);
// 0x0000038A System.Void UnityEngine.UIElements.StyleComplexSelector::CachePseudoStateMasks()
extern void StyleComplexSelector_CachePseudoStateMasks_mBE29909B530D3DF9024535A9B0445A33C2ABFA25 (void);
// 0x0000038B System.String UnityEngine.UIElements.StyleComplexSelector::ToString()
extern void StyleComplexSelector_ToString_m9A3DC5E013326576FC23D50B781A8056EE9BDFDA (void);
// 0x0000038C System.Void UnityEngine.UIElements.StyleComplexSelector::.ctor()
extern void StyleComplexSelector__ctor_m291768F0C11ECB4392ECAF00B8F3E8CAB72F968C (void);
// 0x0000038D System.Void UnityEngine.UIElements.StyleComplexSelector/PseudoStateData::.ctor(UnityEngine.UIElements.PseudoStates,System.Boolean)
extern void PseudoStateData__ctor_mD77BDDC6D0ECE8A1EBE71B116F2D77A8B1735876 (void);
// 0x0000038E System.Void UnityEngine.UIElements.StyleComplexSelector/<>c::.cctor()
extern void U3CU3Ec__cctor_m3E4D9A585BF6478839DCDAFB26225AA314E198BF (void);
// 0x0000038F System.Void UnityEngine.UIElements.StyleComplexSelector/<>c::.ctor()
extern void U3CU3Ec__ctor_m0C0A65A8A998FF3B107D77FD576798686BC2E742 (void);
// 0x00000390 System.String UnityEngine.UIElements.StyleComplexSelector/<>c::<ToString>b__20_0(UnityEngine.UIElements.StyleSelector)
extern void U3CU3Ec_U3CToStringU3Eb__20_0_mD190016F2D8D3D1431648CF3782646C9103512E6 (void);
// 0x00000391 System.String UnityEngine.UIElements.StyleProperty::get_name()
extern void StyleProperty_get_name_m7091CAF496080C6CD9502BA215473D826FDE38FB (void);
// 0x00000392 UnityEngine.UIElements.StyleValueHandle[] UnityEngine.UIElements.StyleProperty::get_values()
extern void StyleProperty_get_values_m8D4D186536D66DE457CEEC0A57B184ED7B320B04 (void);
// 0x00000393 System.Void UnityEngine.UIElements.StyleProperty::.ctor()
extern void StyleProperty__ctor_m04F7DA0EC0390D24075A0C8F42BCE52143670AAE (void);
// 0x00000394 UnityEngine.UIElements.StyleProperty[] UnityEngine.UIElements.StyleRule::get_properties()
extern void StyleRule_get_properties_m360C5AB98331E30BC76BFD3FED9E10B88D9DE1A3 (void);
// 0x00000395 System.Void UnityEngine.UIElements.StyleRule::.ctor()
extern void StyleRule__ctor_m5D61507BC4C51F99765AF4BE406BD071D26C605B (void);
// 0x00000396 UnityEngine.UIElements.StyleSelectorPart[] UnityEngine.UIElements.StyleSelector::get_parts()
extern void StyleSelector_get_parts_mAD4EAC10E3A8D83643C622B45D154B97A54CAC2F (void);
// 0x00000397 System.String UnityEngine.UIElements.StyleSelector::ToString()
extern void StyleSelector_ToString_mF8502C0B445607E9CC8996184D6043A47B051F93 (void);
// 0x00000398 System.Void UnityEngine.UIElements.StyleSelector::.ctor()
extern void StyleSelector__ctor_m657CF5A16B757124A0E0D442F6126B1C0B0BE97C (void);
// 0x00000399 System.Void UnityEngine.UIElements.StyleSelector/<>c::.cctor()
extern void U3CU3Ec__cctor_mF5D0AF27E000B2D5D193DFAA84C1137A6016B988 (void);
// 0x0000039A System.Void UnityEngine.UIElements.StyleSelector/<>c::.ctor()
extern void U3CU3Ec__ctor_m6CE4E8C6C16C95AB51FF4395D182E95F8162C6F8 (void);
// 0x0000039B System.String UnityEngine.UIElements.StyleSelector/<>c::<ToString>b__10_0(UnityEngine.UIElements.StyleSelectorPart)
extern void U3CU3Ec_U3CToStringU3Eb__10_0_m55DE96EEBD33909F083884838E20B7F52DE173EF (void);
// 0x0000039C System.String UnityEngine.UIElements.StyleSelectorPart::get_value()
extern void StyleSelectorPart_get_value_mC5880776B847BF72D168AE26CC614FB0CAE096CF (void);
// 0x0000039D UnityEngine.UIElements.StyleSelectorType UnityEngine.UIElements.StyleSelectorPart::get_type()
extern void StyleSelectorPart_get_type_mFF8CF0B054E6E86BCC9E3C9364DFEF10413CE778 (void);
// 0x0000039E System.String UnityEngine.UIElements.StyleSelectorPart::ToString()
extern void StyleSelectorPart_ToString_m2AB93F36C675B33468B38DF6635A15C384569BB5 (void);
// 0x0000039F UnityEngine.UIElements.StyleRule[] UnityEngine.UIElements.StyleSheet::get_rules()
extern void StyleSheet_get_rules_mA38EE7699F5134ED6D72988E0621B266655671F3 (void);
// 0x000003A0 System.Void UnityEngine.UIElements.StyleSheet::set_rules(UnityEngine.UIElements.StyleRule[])
extern void StyleSheet_set_rules_m7982BAEC18F14E5487AC4E448DD633E9089D2388 (void);
// 0x000003A1 UnityEngine.UIElements.StyleComplexSelector[] UnityEngine.UIElements.StyleSheet::get_complexSelectors()
extern void StyleSheet_get_complexSelectors_mF3F471AF0DBC1A865BAA5F25117493AACB8F9BD1 (void);
// 0x000003A2 System.Void UnityEngine.UIElements.StyleSheet::set_complexSelectors(UnityEngine.UIElements.StyleComplexSelector[])
extern void StyleSheet_set_complexSelectors_mBEBA02FBD093594F7E451D685D4622BC3156B496 (void);
// 0x000003A3 System.Collections.Generic.List`1<UnityEngine.UIElements.StyleSheet> UnityEngine.UIElements.StyleSheet::get_flattenedRecursiveImports()
extern void StyleSheet_get_flattenedRecursiveImports_m52062BE875B643D729FCDBC32F223716C2051E80 (void);
// 0x000003A4 System.Int32 UnityEngine.UIElements.StyleSheet::get_contentHash()
extern void StyleSheet_get_contentHash_mABF3123BD0B38CE123466ADBA1E0FE6B413CA88F (void);
// 0x000003A5 System.Void UnityEngine.UIElements.StyleSheet::set_contentHash(System.Int32)
extern void StyleSheet_set_contentHash_m973A7761712F5913141B56507B0D4C8D8E022925 (void);
// 0x000003A6 System.Boolean UnityEngine.UIElements.StyleSheet::TryCheckAccess(T[],UnityEngine.UIElements.StyleValueType,UnityEngine.UIElements.StyleValueHandle,T&)
// 0x000003A7 T UnityEngine.UIElements.StyleSheet::CheckAccess(T[],UnityEngine.UIElements.StyleValueType,UnityEngine.UIElements.StyleValueHandle)
// 0x000003A8 System.Void UnityEngine.UIElements.StyleSheet::OnEnable()
extern void StyleSheet_OnEnable_mD8437C4BCC06EEA50ECDC0C26ED71D82EE355324 (void);
// 0x000003A9 System.Void UnityEngine.UIElements.StyleSheet::FlattenImportedStyleSheetsRecursive()
extern void StyleSheet_FlattenImportedStyleSheetsRecursive_m180C294BB2C1FAF4EAF122529CD4958EA1491B40 (void);
// 0x000003AA System.Void UnityEngine.UIElements.StyleSheet::FlattenImportedStyleSheetsRecursive(UnityEngine.UIElements.StyleSheet)
extern void StyleSheet_FlattenImportedStyleSheetsRecursive_mD2D021D9B7402BE4B3AAB9950A9C58006CA2C63C (void);
// 0x000003AB System.Void UnityEngine.UIElements.StyleSheet::SetupReferences()
extern void StyleSheet_SetupReferences_mADC28D5FFF0040B43F97EF0B79FF325A061FA88B (void);
// 0x000003AC UnityEngine.UIElements.StyleValueKeyword UnityEngine.UIElements.StyleSheet::ReadKeyword(UnityEngine.UIElements.StyleValueHandle)
extern void StyleSheet_ReadKeyword_mD9F5EB148E9E72B5BAD8F9C6C3447CD4C08E3EA4 (void);
// 0x000003AD System.Single UnityEngine.UIElements.StyleSheet::ReadFloat(UnityEngine.UIElements.StyleValueHandle)
extern void StyleSheet_ReadFloat_m0E478A2862A7B9C88C25BA5BB5685CA603DC082F (void);
// 0x000003AE System.Boolean UnityEngine.UIElements.StyleSheet::TryReadFloat(UnityEngine.UIElements.StyleValueHandle,System.Single&)
extern void StyleSheet_TryReadFloat_mBA445A1F15F4957A7C1282A079EA1E426DA886AB (void);
// 0x000003AF UnityEngine.UIElements.StyleSheets.Dimension UnityEngine.UIElements.StyleSheet::ReadDimension(UnityEngine.UIElements.StyleValueHandle)
extern void StyleSheet_ReadDimension_mEAD5425B4B58B305CA63A1150DB6725790B14B53 (void);
// 0x000003B0 System.Boolean UnityEngine.UIElements.StyleSheet::TryReadDimension(UnityEngine.UIElements.StyleValueHandle,UnityEngine.UIElements.StyleSheets.Dimension&)
extern void StyleSheet_TryReadDimension_m0522518E13718FEB56FD2C430E2D293C296D7128 (void);
// 0x000003B1 UnityEngine.Color UnityEngine.UIElements.StyleSheet::ReadColor(UnityEngine.UIElements.StyleValueHandle)
extern void StyleSheet_ReadColor_m2717A9FC48D9EDE4D3B812DF4B4020208377AF48 (void);
// 0x000003B2 System.Boolean UnityEngine.UIElements.StyleSheet::TryReadColor(UnityEngine.UIElements.StyleValueHandle,UnityEngine.Color&)
extern void StyleSheet_TryReadColor_m0F53AAC2E5DDE43664A18BF878193F69EF47E6FB (void);
// 0x000003B3 System.String UnityEngine.UIElements.StyleSheet::ReadString(UnityEngine.UIElements.StyleValueHandle)
extern void StyleSheet_ReadString_m6394085BD1461792D1595F63698C97C048563C1A (void);
// 0x000003B4 System.Boolean UnityEngine.UIElements.StyleSheet::TryReadString(UnityEngine.UIElements.StyleValueHandle,System.String&)
extern void StyleSheet_TryReadString_mC5BBEA9D0C86A277D400D4426BCE8E0645404C4E (void);
// 0x000003B5 System.String UnityEngine.UIElements.StyleSheet::ReadEnum(UnityEngine.UIElements.StyleValueHandle)
extern void StyleSheet_ReadEnum_m3535D16E7702A3B25361ED5704E55DB7E2274B66 (void);
// 0x000003B6 System.Boolean UnityEngine.UIElements.StyleSheet::TryReadEnum(UnityEngine.UIElements.StyleValueHandle,System.String&)
extern void StyleSheet_TryReadEnum_mA97B26BA7F2E839EF476AB3DB60254E79AB66D8E (void);
// 0x000003B7 System.String UnityEngine.UIElements.StyleSheet::ReadVariable(UnityEngine.UIElements.StyleValueHandle)
extern void StyleSheet_ReadVariable_mE0EE06FC3FD544D26A0700C0AFD86A8F80EC209C (void);
// 0x000003B8 System.Boolean UnityEngine.UIElements.StyleSheet::TryReadVariable(UnityEngine.UIElements.StyleValueHandle,System.String&)
extern void StyleSheet_TryReadVariable_m555D60F34A91463BD84CC899FA6BC0E4125F5432 (void);
// 0x000003B9 System.String UnityEngine.UIElements.StyleSheet::ReadResourcePath(UnityEngine.UIElements.StyleValueHandle)
extern void StyleSheet_ReadResourcePath_m69CA2A4FD5249865892F8790EF31A4756005DAE7 (void);
// 0x000003BA System.Boolean UnityEngine.UIElements.StyleSheet::TryReadResourcePath(UnityEngine.UIElements.StyleValueHandle,System.String&)
extern void StyleSheet_TryReadResourcePath_m7FBD81E064DBF740C4C578DB8821DD90FAA22E0A (void);
// 0x000003BB UnityEngine.Object UnityEngine.UIElements.StyleSheet::ReadAssetReference(UnityEngine.UIElements.StyleValueHandle)
extern void StyleSheet_ReadAssetReference_m86EA09C5837BAB83BB17219865593DFD30AC022D (void);
// 0x000003BC System.String UnityEngine.UIElements.StyleSheet::ReadMissingAssetReferenceUrl(UnityEngine.UIElements.StyleValueHandle)
extern void StyleSheet_ReadMissingAssetReferenceUrl_m997E2F7776AC68D6AD7672FA971FB93BFBA726F3 (void);
// 0x000003BD System.Boolean UnityEngine.UIElements.StyleSheet::TryReadAssetReference(UnityEngine.UIElements.StyleValueHandle,UnityEngine.Object&)
extern void StyleSheet_TryReadAssetReference_mA8DC14EF5C4664F54B27C8F0B1E86A8BA55FD3FE (void);
// 0x000003BE UnityEngine.UIElements.StyleValueFunction UnityEngine.UIElements.StyleSheet::ReadFunction(UnityEngine.UIElements.StyleValueHandle)
extern void StyleSheet_ReadFunction_m92D814776478D42ADDF0F7622C992D2802F4E46E (void);
// 0x000003BF System.String UnityEngine.UIElements.StyleSheet::ReadFunctionName(UnityEngine.UIElements.StyleValueHandle)
extern void StyleSheet_ReadFunctionName_m619B3F158232C7D12D7E99FD5BF142981ACBF06E (void);
// 0x000003C0 UnityEngine.UIElements.StyleSheets.ScalableImage UnityEngine.UIElements.StyleSheet::ReadScalableImage(UnityEngine.UIElements.StyleValueHandle)
extern void StyleSheet_ReadScalableImage_m7123BD46952D239C68054CBFAD88B2AA7556262C (void);
// 0x000003C1 System.Boolean UnityEngine.UIElements.StyleSheet::CustomStartsWith(System.String,System.String)
extern void StyleSheet_CustomStartsWith_m9AD3CD4F440040E1C96CBDE3D86A5EA33BD3E0F8 (void);
// 0x000003C2 System.Void UnityEngine.UIElements.StyleSheet::.ctor()
extern void StyleSheet__ctor_m1992F2C24446A5EBC7C1704D94407F2839F95958 (void);
// 0x000003C3 System.Void UnityEngine.UIElements.StyleSheet::.cctor()
extern void StyleSheet__cctor_m4576DD0F7DB03B9466279BD2ABD988E5E865E05F (void);
// 0x000003C4 System.String UnityEngine.UIElements.StyleValueFunctionExtension::ToUssString(UnityEngine.UIElements.StyleValueFunction)
extern void StyleValueFunctionExtension_ToUssString_mA91506CA02796317BD8999E4407F5ECF8A88F7C3 (void);
// 0x000003C5 UnityEngine.UIElements.StyleValueType UnityEngine.UIElements.StyleValueHandle::get_valueType()
extern void StyleValueHandle_get_valueType_m1558B95DF39F3A05AEF5DC6BEFE4E059875224C2 (void);
// 0x000003C6 System.Int32 UnityEngine.UIElements.StyleVariable::GetHashCode()
extern void StyleVariable_GetHashCode_m2F5FA0FB885DCAE3B7CA807A6E604BA0082CF3E5 (void);
// 0x000003C7 System.Void UnityEngine.UIElements.StyleVariableContext::.ctor()
extern void StyleVariableContext__ctor_m032BC520EE67A00219262BB037D18C964BE2DD8E (void);
// 0x000003C8 System.Void UnityEngine.UIElements.StyleVariableContext::.cctor()
extern void StyleVariableContext__cctor_m328D0C088D9AD9B6F3ACAAAA17136C331AB0807A (void);
// 0x000003C9 System.Void UnityEngine.UIElements.StyleVariableResolver::.ctor()
extern void StyleVariableResolver__ctor_m5C7408A89F629148F3FE4C8BD0C3B7DF5CEE1FE2 (void);
// 0x000003CA System.Void UnityEngine.UIElements.StyleVariableResolver::.cctor()
extern void StyleVariableResolver__cctor_mBE1B7CBA1B4AEE240500E2EE54E54069CE7140DE (void);
// 0x000003CB System.Void UnityEngine.UIElements.VectorImage::.ctor()
extern void VectorImage__ctor_m251E60994B3C28AF64A0D342DE6095B38B0B40E2 (void);
// 0x000003CC System.Void UnityEngine.UIElements.UIR.Shaders::.cctor()
extern void Shaders__cctor_m8E159AD77943C545775EB48C599A242C0EA25B0B (void);
// 0x000003CD System.String UnityEngine.UIElements.UIR.BMPAlloc::ToString()
extern void BMPAlloc_ToString_m16DC97FAA0713B099B2CA7699BC21E782FDC7678 (void);
// 0x000003CE System.Void UnityEngine.UIElements.UIR.BMPAlloc::.cctor()
extern void BMPAlloc__cctor_m43F3C18ECA6CA3CED775D6ED7A20ED203D986C33 (void);
// 0x000003CF System.Void UnityEngine.UIElements.UIR.RenderChainCommand::.cctor()
extern void RenderChainCommand__cctor_mD13194072A3D48F644FD0832DD1FAE126142CF4D (void);
// 0x000003D0 System.Void UnityEngine.UIElements.StyleSheets.Dimension::.ctor(System.Single,UnityEngine.UIElements.StyleSheets.Dimension/Unit)
extern void Dimension__ctor_m13BD618D7718C8FE3C95E7BA5EF17222C1FBCF78 (void);
// 0x000003D1 System.Boolean UnityEngine.UIElements.StyleSheets.Dimension::op_Equality(UnityEngine.UIElements.StyleSheets.Dimension,UnityEngine.UIElements.StyleSheets.Dimension)
extern void Dimension_op_Equality_mB07D273DBBD886ADCE15D1C8C4F147B1CD2A57BC (void);
// 0x000003D2 System.Boolean UnityEngine.UIElements.StyleSheets.Dimension::Equals(UnityEngine.UIElements.StyleSheets.Dimension)
extern void Dimension_Equals_mE6B999E10285F2200D0E522350147B6BB3DB17DB (void);
// 0x000003D3 System.Boolean UnityEngine.UIElements.StyleSheets.Dimension::Equals(System.Object)
extern void Dimension_Equals_m5F96DD2B749ADFEA0121C356EA9F10ECAA00209E (void);
// 0x000003D4 System.Int32 UnityEngine.UIElements.StyleSheets.Dimension::GetHashCode()
extern void Dimension_GetHashCode_mE16AB0959628076394D1C36B9CD6296CFFBF7514 (void);
// 0x000003D5 System.String UnityEngine.UIElements.StyleSheets.Dimension::ToString()
extern void Dimension_ToString_m21AFB1E0F1309E0C34EBCA99CCA5EEA8BC1FDD23 (void);
// 0x000003D6 System.String UnityEngine.UIElements.StyleSheets.ScalableImage::ToString()
extern void ScalableImage_ToString_m3FD9CFD4108EFD369F9E76BEE26A87F20E884B38 (void);
// 0x000003D7 System.Void UnityEngine.UIElements.StyleSheets.StylePropertyReader::.ctor()
extern void StylePropertyReader__ctor_m557B18FA6CD452BBF33C8FB7304CBECF469BDFF1 (void);
// 0x000003D8 System.Void UnityEngine.UIElements.StyleSheets.StylePropertyReader::.cctor()
extern void StylePropertyReader__cctor_m1DDED9762262E229985292A153B2D65771D38E34 (void);
// 0x000003D9 System.Void UnityEngine.UIElements.StyleSheets.StylePropertyReader/GetCursorIdFunction::.ctor(System.Object,System.IntPtr)
extern void GetCursorIdFunction__ctor_m4E90BE7B24D363FD8A7F9D66298A122D0C35E203 (void);
// 0x000003DA System.Int32 UnityEngine.UIElements.StyleSheets.StylePropertyReader/GetCursorIdFunction::Invoke(UnityEngine.UIElements.StyleSheet,UnityEngine.UIElements.StyleValueHandle)
extern void GetCursorIdFunction_Invoke_mFAD030F3307AC20F421738B63B969D8F5141BAE2 (void);
// 0x000003DB System.Boolean UnityEngine.UIElements.StyleSheets.StyleSheetExtensions::IsVarFunction(UnityEngine.UIElements.StyleValueHandle)
extern void StyleSheetExtensions_IsVarFunction_m6F2E26E5B109946B3D51E481F9B983A5CDFC3695 (void);
// 0x000003DC UnityEngine.UIElements.StyleSheets.StyleValue UnityEngine.UIElements.StyleSheets.StyleValue::Create(UnityEngine.UIElements.StyleSheets.StylePropertyId)
extern void StyleValue_Create_m858F005877A63C5B100171A63B70C01AF422CEBE (void);
// 0x000003DD UnityEngine.UIElements.StyleSheets.StyleValue UnityEngine.UIElements.StyleSheets.StyleValue::Create(UnityEngine.UIElements.StyleSheets.StylePropertyId,UnityEngine.UIElements.StyleKeyword)
extern void StyleValue_Create_mE54DBC632FE0D61A3E1E78018C4C0C5EBACBF34B (void);
// 0x000003DE UnityEngine.UIElements.StyleSheets.StyleValue UnityEngine.UIElements.StyleSheets.StyleValue::Create(UnityEngine.UIElements.StyleSheets.StylePropertyId,System.Single)
extern void StyleValue_Create_mA14F9FC0902434EEC9E01E82A47BB257882D873F (void);
// 0x000003DF UnityEngine.UIElements.StyleSheets.StyleValue UnityEngine.UIElements.StyleSheets.StyleValue::Create(UnityEngine.UIElements.StyleSheets.StylePropertyId,System.Int32)
extern void StyleValue_Create_mABCE314A6CFA9F91DC1DAC5AF038222FAC9E8E07 (void);
// 0x000003E0 UnityEngine.UIElements.StyleSheets.StyleValue UnityEngine.UIElements.StyleSheets.StyleValue::Create(UnityEngine.UIElements.StyleSheets.StylePropertyId,UnityEngine.Color)
extern void StyleValue_Create_m6865DDB84313E47D25CD3BD61EDC5FC3FE73095A (void);
// 0x000003E1 System.Void UnityEngine.UIElements.StyleSheets.BaseStyleMatcher::.ctor()
extern void BaseStyleMatcher__ctor_m53402D706292CBDBB1F127DCAF3DCA487A33F95E (void);
// 0x000003E2 System.Void UnityEngine.UIElements.StyleSheets.StylePropertyValueMatcher::.ctor()
extern void StylePropertyValueMatcher__ctor_m6F1BE9953157356D061F9D2EFD2BABEFF156A1A5 (void);
// 0x000003E3 System.Void UnityEngine.UIElements.StyleSheets.Syntax.StyleSyntaxParser::.ctor()
extern void StyleSyntaxParser__ctor_mA217E8B0D5642F7A944AEDBCB0A4C04758776A73 (void);
static Il2CppMethodPointer s_methodPointers[995] = 
{
	EmbeddedAttribute__ctor_m35649EE3B9671A19785552230116420086304147,
	IsReadOnlyAttribute__ctor_mA9A8E58FB04548467EBD2CB7907AE0B94A770E29,
	ClickDetector_get_s_DoubleClickTime_m0F9BBCF5920D2D67BB6E3098233016CC6A9607BC,
	ClickDetector_StartClickTracking_m0BF023CF553A59753D881A89127E2CDF17A32930,
	ClickDetector_SendClickEvent_mA685627EEFA411331A7D67DC7965E8856060F0A9,
	ClickDetector_CancelClickTracking_mF399CE2F19E40E2182350F45C27429C3D53E22B4,
	ClickDetector_ProcessEvent_m9F5E295A0C61982BF18E912900BD6993884E1035,
	ClickDetector__cctor_mBA504C797063E6FD44FD3EB84432DDEB11A9A2A1,
	ButtonClickStatus_Reset_m41A20C7A1F938EF9818A481DF11AA97D97E337EC,
	Cursor_get_texture_mB0B9D7B2D91E1035B27E05742D5CFAFC6E35D7B0,
	Cursor_get_hotspot_m64A89A4010D9037EE97CE02AF70C80B7CCA8DE84,
	Cursor_get_defaultCursorId_m78BEDF5FAB1CF3E17784CAC1F1A62622B8B32F54,
	Cursor_Equals_m97AA23240C606F7A0FCB6DAE1AFF7A46879AA6D6,
	Cursor_Equals_mA3A02D884C1AE5C4FE6EE98EFE4A1AA83F4EBB21,
	Cursor_GetHashCode_m7B79CE5374C05CACBAB2E07C1652F6AD590212ED,
	Cursor_op_Equality_m300C3570B44FC8A99D8D2535F62A2060AD53EE53,
	Cursor_ToString_mD424F81BE23CCE5136FC4960563778689B151833,
	EventDispatcherGate__ctor_mD718DC5ECF3A6990B671179A426E65F90CC3A319,
	EventDispatcherGate_Dispose_mA0793129F4766892329859A6E302937105667152,
	EventDispatcherGate_Equals_mFDAEDA595E240127DC97FFE152FDB462464688C4,
	EventDispatcherGate_Equals_mB0458E71B92D036951E926355B979A38DEBCEAC6,
	EventDispatcherGate_GetHashCode_mA36AC6A55B840FA03FECCF56E3E5D66E4D3D4148,
	EventDispatcher_get_pointerState_mA675C72BDE1A673E104ECFD96FADBD3BC13D6F70,
	EventDispatcher_get_dispatchImmediately_mBD3D55762F81F440182F23109509585E988A655A,
	EventDispatcher_Dispatch_mEB5607C872C77F6A4F47A3E0798CB4B2779D6B2B,
	EventDispatcher_CloseGate_m7A57D81737E4B475788112F16D11692D72E84C38,
	EventDispatcher_OpenGate_mDD6FCDF015D4201CBEF5D869F85C278B4AA6F542,
	EventDispatcher_ProcessEventQueue_m35DBA2C05D70BD851AE542AE20BABE0C79014B09,
	EventDispatcher_ProcessEvent_mCBD6A882A7381AB372302C0B18B555EF3DAE6A8B,
	EventDispatcher_ApplyDispatchingStrategies_m2A3E4C99B36D3FBD950F1ADFC56EAB7FF5C60971,
	EventDispatcher__cctor_m2F89AEF49348CE0D08A2C13310784D8B6236B05A,
	NULL,
	Focusable_get_focusable_mA3BF33F025B1AE6F0E8E220E58DE6BDC1FDAB310,
	Focusable_get_tabIndex_mB8299F9106AA1B50FD651FDF64BD51AB4739F78B,
	Focusable_get_delegatesFocus_mD840ED62D32B55FC515E0005894A77461138E596,
	Focusable_get_canGrabFocus_m1DD7773DC0E9FBFB974798FADE855DA478F0DDFB,
	Focusable_Focus_mAF200A29C8799725EFC936792943AC5E908F5BB0,
	Focusable_Blur_mD8EAE7355B4DCDB4C1FB630256A6A4901B9EA880,
	Focusable_GetFocusDelegate_m3BFF0CF505A6ABD4489926DB38F95F5976DD069B,
	Focusable_GetFirstFocusableChild_m879859314A494503C12811E40ACE51C018DE001B,
	FocusChangeDirection_get_unspecified_mB6539EF9E8F9F8E354F55ABDBBBBC4C9F921CACC,
	FocusChangeDirection_get_none_m702BB27310D1EA0511E7CD4FB0B9515D331BA53A,
	FocusChangeDirection_get_lastValue_mF67FF11312EC1CDB50948F86C1A683BFB58F1A13,
	FocusChangeDirection__ctor_mF243D8E15FE0671129149DCA8555FCF7D58FFEAF,
	FocusChangeDirection_op_Implicit_m438839D193CB93D1376BC58E2846AEBF016C3EFE,
	FocusChangeDirection_System_IDisposable_Dispose_m8047EBA61A0A684E21353BC537114880949E9022,
	FocusChangeDirection_Dispose_m825DE917594C05C5808E6BD59B74466EF901EE44,
	FocusChangeDirection_ApplyTo_m4FC13F3E93D929D4FB2ED185A6B18750BD60DC33,
	FocusChangeDirection__cctor_m6A0201289A7CB4B6B05406A494228FBB1DA7E08B,
	NULL,
	NULL,
	FocusController_get_focusRing_m4F1F97ACCF6AABC41A33130C6FE0B4CCADC24FED,
	FocusController_IsFocused_mE39F652794F63E05C4E058CC4D5DA7CAD1562E89,
	FocusController_GetLeafFocusedElement_mAD6C9E5DAD9BF161AADFF12FA93B2D3750ACEA3D,
	FocusController_SetFocusToLastFocusedElement_m26CDB0A41E45E0EC7CC1A20DB57AD29B5CA60A0F,
	FocusController_BlurLastFocusedElement_m28627F4A6375718A5453C6757790C5055458067F,
	FocusController_DoFocusChange_m3E6D899B8A7C21B20346514763E2F9EC1A49C2DF,
	FocusController_AboutToReleaseFocus_mE77836E22D7D76FA7CF4405B05F24C827D6FFE07,
	FocusController_ReleaseFocus_m012B8E2F60D7223D4435F1B64B0CA128671630CA,
	FocusController_AboutToGrabFocus_m625ABD4C834E4BAD9977D0A244A06C8EE2F41DAB,
	FocusController_GrabFocus_m33DF8F9054BD4AACD3B863C1E396C6BC17E0567D,
	FocusController_SwitchFocus_m23B5554A489547A337768C6813A85F53C132A543,
	FocusController_SwitchFocus_m7FDD963260CA15ABC695F32FD655B96D7581FD21,
	FocusController_SwitchFocusOnEvent_mFA7FC7B2C42FEE01FE80C3C88FEB43B0AED64BFE,
	FocusController_get_imguiKeyboardControl_mBE7CB44518FCA881F216C44C4495AF31B27F64B9,
	FocusController_set_imguiKeyboardControl_mFA1DE58DC2F23604F24B86A66C773BD10849DFAA,
	FocusController_SyncIMGUIFocus_m0076B10EA65A939BFFCE54FD55AB5E4D054FACBF,
	IMGUIContainer_get_onGUIHandler_mE8916A7AA27757E097C9880526CCE55B1361444D,
	IMGUIContainer_get_guiState_mB925B5A4A9F71D6FA5562B2AEBF87194DE035ED2,
	IMGUIContainer_get_lastWorldClip_m559BC7B8AC19A0E9EFBFE1818D2B0FFCF95088AF,
	IMGUIContainer_get_cache_mDF4F3F6C76DEB7DACCE68A061534B7D683FE1069,
	IMGUIContainer_get_layoutMeasuredWidth_m3218A2834EEDF43812093AD4AAB271604642786D,
	IMGUIContainer_get_layoutMeasuredHeight_mE9DE1B8DD1203F85DDB0F50F57502A18A2D384E6,
	IMGUIContainer_get_contextType_mEED3AA9B355FBF46948D9CA19EB97AC6F01ABF29,
	IMGUIContainer_get_focusOnlyIfHasFocusableControls_m1A4C1DDB09520D386617676965A094D201F0FC5B,
	IMGUIContainer__cctor_mA0DAED497F1CB5CB63C694D6AACED331D8D2DEEB,
	IMGUIContainer_SaveGlobals_m2F7109F670586228D47A82BF97B8E82337CAAB85,
	IMGUIContainer_RestoreGlobals_m502765489B54E97FC770B5A3F685DFD07D161999,
	IMGUIContainer_DoOnGUI_m1974D60CE778967E391748F655C7436B26739B22,
	IMGUIContainer_MarkDirtyLayout_m41F18251C98328413347C8723F4DB1B363981E5F,
	IMGUIContainer_SendEventToIMGUI_m04C1240B4C85A8D0D21EBB8EAE1FEAF9A2512FDE,
	IMGUIContainer_SendEventToIMGUIRaw_m1CF195260874023183303567A7290C5CCAC4734C,
	IMGUIContainer_VerifyBounds_m0BF476D805D2288A7409A7FE745E86939B899942,
	IMGUIContainer_IsContainerCapturingTheMouse_mD1F324F84B607E41B818560D7FFF13E432E65CE2,
	IMGUIContainer_IsLocalEvent_mE1750D8C9145641C95C3C1BD9A6453EF5A5A3D01,
	IMGUIContainer_IsEventInsideLocalWindow_m59D338511C72D45AAC58761D2702E08C2A504E63,
	IMGUIContainer_HandleIMGUIEvent_m8AE2543F9F24AE851F39E216BDB63DBDFA1D00D7,
	IMGUIContainer_HandleIMGUIEvent_mA00CF4168AE43D49DCCAA1E2E581191BE2729F35,
	IMGUIContainer_HandleIMGUIEvent_m0AA59C0E7F82185E42597792A9D58C0B1DAF9014,
	IMGUIContainer_GetCurrentClipRect_mB7F3F57A55C200782574787593C7331055684F87,
	IMGUIContainer_GetCurrentTransformAndClip_m3EFCE53D64C0546E11B5F41D3FB259FF7EAD98D5,
	IMGUIContainer_Dispose_m7EAEBFC44197E554D040C15BFFF029F2D159FBD7,
	IMGUIContainer_Dispose_m6585C1777076DD61B513B23F02EC39F4CED07C4C,
	IMGUIContainer_U3CDoOnGUIU3Eb__55_0_m7B609E2BBF96D93484F1A18875E617E01E48B8BC,
	MouseCaptureController_HasMouseCapture_m9760F1E89C054D37CC2C819C30C02219EC51B53C,
	MouseCaptureController_CaptureMouse_mFD566FC54CFDDE4D7C23C2CE6CAF0C55BA87DCB6,
	MouseCaptureController_ReleaseMouse_m85961EA94DC96AF6FB4600DF153B18857FE55F3B,
	MouseCaptureController__cctor_mADF0597882A51411BCA5E0A48063DF60FE3A3DE9,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	RepaintData_get_currentOffset_mA1CF953FC14565CC923AD638AE8766B6EB288B34,
	RepaintData_set_repaintEvent_m017C75D49486B04AB55CBBE44474DB785DCB1EBA,
	HierarchyEvent__ctor_m786CC2E0FB91181FFDA27187EE28139678D3AB58,
	HierarchyEvent_Invoke_m0E35EB540F1C21463F878C41559A729C9FF77139,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	BaseVisualElementPanel_Dispose_m6C4F04D1A1DCCC642F73FA2CB7BD02808FEA1FDD,
	BaseVisualElementPanel_Dispose_m9474549B916298CAD9F8340BDC3BED82B991B668,
	NULL,
	NULL,
	BaseVisualElementPanel_get_scale_mC96D823764B70A190360976F325C9D428C30F764,
	BaseVisualElementPanel_set_pixelsPerPoint_m8F4E48021048241523B133D3F60AF2273587241A,
	BaseVisualElementPanel_get_scaledPixelsPerPoint_mD1138DFAAF4DB674D78EF7C28421808DFC4A60B8,
	BaseVisualElementPanel_get_sortingPriority_mB571FBE28BCD5C6985C1BF6424D0FC9D99B57BC0,
	BaseVisualElementPanel_get_duringLayoutPhase_m29E7AA00103718DF6E84688201C1851BF0590F6E,
	NULL,
	NULL,
	BaseVisualElementPanel_get_repaintData_m8C0EB53A84D72681A5F64DB7D7138DEBDF79B907,
	NULL,
	NULL,
	BaseVisualElementPanel_SendEvent_mE90F7BA962A358F4AC6F841B3700ACD004EC5600,
	NULL,
	NULL,
	NULL,
	BaseVisualElementPanel_get_disposed_m44D50828E8ABCBD3F4B02AAAF1814D07F6DAA345,
	BaseVisualElementPanel_set_disposed_mF2065052DC7234B7934AA0ABD7F3DDA6712956B3,
	BaseVisualElementPanel_GetTopElementUnderPointer_m1A8CBAC45A893CA9F04F99D018D289083C96B559,
	BaseVisualElementPanel_RecomputeTopElementUnderPointer_mDDFB8233390967E80E95EB962162CCD8E3135B94,
	BaseVisualElementPanel_ClearCachedElementUnderPointer_m4DBDFB43E4AF4C3D5953C4B47B05A297B2B67E97,
	BaseVisualElementPanel_CommitElementUnderPointers_m30230955A9B99A1B2B7F2412C43201B29A516246,
	BaseVisualElementPanel_InvokeBeforeUpdate_mE3525D9C553612F37858C3DB252EAD954C68E8CA,
	LoadResourceFunction__ctor_m0F9587876DB13EB88030C36455300685EA758D30,
	LoadResourceFunction_Invoke_m597E0E01088C806293BF63BD853EDB0FFF5ACB69,
	TimeMsFunction__ctor_mA7148B9CE14C60C09E624C8FF95C7CE0F72E4AAF,
	TimeMsFunction_Invoke_m767F92DD36939414D0B5AAF07578B244093322F1,
	GetViewDataDictionary__ctor_mAB64BAB68A196B3D542A19A494E4F556AD258E6B,
	GetViewDataDictionary_Invoke_mD60DC6A289655094AA28931217FD78036D4E6D1F,
	SavePersistentViewData__ctor_mE59E51B854E93B9985A9C05F13DA47EC97EE2D13,
	SavePersistentViewData_Invoke_mB08932768F7A80E931327779BF40E70AFE887611,
	Panel_get_visualTree_mB2346C6D7BF2CCA720A3439ECFB2217EAE487730,
	Panel_get_dispatcher_m0B3FE190F0E1ADA939DE90A467137336D9095613,
	Panel_get_timerEventScheduler_m85B4D5BBF66F9F816BE3740549A085495BA2844B,
	Panel_get_scheduler_mEB6147CBCB3F82DCFEF418C11D07DE12C94FAB52,
	Panel_get_ownerObject_m9BFDEF2F68F4E81D60039B9A09A1D77549D95ADC,
	Panel_get_contextType_m4592156375BE89F7962C8F34F5DA2907C469F781,
	Panel_get_focusController_mC3C8E03BBD6E411FD6DF506A5A5FDAC187E6C3B8,
	Panel_get_IMGUIEventInterests_m331B2B7A88A756B47B6B752F33F6BE4384517BEB,
	Panel_Focus_m648524C6386D4FCC1A8ED4CF6A0F36C2B9E8C48C,
	Panel_Blur_m0E7521CF78827E9BB15D9FED307EF01FC8955601,
	Panel_get_name_mA801AF49D8609FBB3B07047D8D6F61E17321D97E,
	Panel_get_TimeSinceStartup_mD5C764851154DFF6101A959C2D145E914EEABAF6,
	Panel_get_IMGUIContainersCount_m780ADFFAB6763A905C0D50179C7E16A51E91A80E,
	Panel_get_rootIMGUIContainer_m19EDFB767FF2FC6CDA39F8683405A630389963EF,
	Panel_get_version_mB1575E2DC4705B34BF72DF96D0A56DC6CBC6D0F2,
	Panel_TimeSinceStartupMs_mA7302F2BDBFA020E9BE4B8378E392FD151DE7F74,
	Panel_DefaultTimeSinceStartupMs_m9BEB61FEFF46DAA66BFD9E8CFF3AA4C61AFE31D4,
	Panel_PickAll_mDC969CBC7DC5218C630D5C9C247F21E4748C183F,
	Panel_PerformPick_m586CA5285C8F1306D562D07BF608F54628F8786B,
	Panel_Pick_m97178E46F1CCA67276FB9C4AD4FEEFE04F854B38,
	Panel_ValidateLayout_m2F6611613CC1F3B4F6CAACFAC04BA76E1F31A744,
	Panel_UpdateForRepaint_m66F4FBCADA00FE2EA676D316210E5F667279A833,
	Panel_Repaint_m8E1FF84D8B3BED705EA472BDA3FE14182056EE49,
	Panel_OnVersionChanged_m924923A41ECD84D03160C55210AB5C425A715376,
	Panel__cctor_mE231B9FFE7B056C25D00C200D501BCD860390EE0,
	BaseRuntimePanel_get_selectableGameObject_m2E4236700CCA6D969AB605140EB19A821C13C06D,
	BaseRuntimePanel_set_selectableGameObject_m9ACAE61722BC9B4CB94A8D4D2205FD567314B731,
	BaseRuntimePanel_add_destroyed_mB314BB1911A52AFF1B07E63CC0EB7229F7B47551,
	BaseRuntimePanel_remove_destroyed_mE8D90F08FEADEE30957023301032013AF568894B,
	BaseRuntimePanel_get_drawToCameras_m81B2EFDBB9E380E8541D30E40C75C624C51A3E1F,
	BaseRuntimePanel_get_targetDisplay_m969C6CBB80B6A7CEB843FDFF0E1B550219D507CB,
	BaseRuntimePanel_get_screenToPanelSpace_m868A9D47CB9FF5786F10AC937BEF10680FA3770A,
	BaseRuntimePanel_ScreenToPanel_m7FCB64A28984294854D016E25F8579C37BBABE6E,
	BaseRuntimePanel_ScreenToPanel_mBD9FE72AF98435E9C7FED9A545401BB2B1626F58,
	BaseRuntimePanel_AssignPanelToComponents_m460CEED1BE4EA8FB4D5C13DC3EB9C20229379B62,
	BaseRuntimePanel__cctor_mDBA4F993E25A36125BB1C9B071373FE14EA04989,
	U3CU3Ec__cctor_mFF3A19C910FD2ECD868BFCA869E7A2DE6BB27D1A,
	U3CU3Ec__ctor_mC4C1E775016D1A6FB529350E9FD126375426BCC9,
	U3CU3Ec_U3C_cctorU3Eb__36_0_m2416285E934D715C2DA88E63220EC21B6BEFF211,
	NULL,
	PointerCaptureHelper_GetStateFor_m5D42640113AFF9AA1D80FFD97045220F8EFA32AF,
	PointerCaptureHelper_HasPointerCapture_m9A28C223A9F5A8240EC5925729F164FD3EB3B9E9,
	PointerCaptureHelper_CapturePointer_m2BB09CA5A4D89C0E1C804E2D5DC0F829838B7660,
	PointerCaptureHelper_ReleasePointer_m910C9893619D5809B69D5FE8A76741F4FD30ABFF,
	PointerCaptureHelper_GetCapturingElement_m5BEFCC83FABC55CEA3DD4AED99807A310DBCC720,
	PointerCaptureHelper_ReleasePointer_m7B13B02182935DC9960A336680E58A4C930B1198,
	PointerCaptureHelper_ActivateCompatibilityMouseEvents_m4AB492162DCC884007307DCC3D2C0DF71EB713F8,
	PointerCaptureHelper_PreventCompatibilityMouseEvents_m327E2C2B84B8F171819384DDFD5511775725BC58,
	PointerCaptureHelper_ShouldSendCompatibilityMouseEvents_m6549DB7737673EAB222390A5E7BB3D7F2A40A456,
	PointerCaptureHelper_ProcessPointerCapture_m64D286EDBD2D21F619B7EABB4C16FE931FECE854,
	PointerDispatchState_GetCapturingElement_mB247250AA9F1A1CA1ED50EB0F67D6D27CBE36409,
	PointerDispatchState_HasPointerCapture_m68E6406587A571D645B13C718F0CCCF2D16E64C1,
	PointerDispatchState_CapturePointer_mE6DBA11E5D3C84DA1878181F7D5E1FC2DE52CDE0,
	PointerDispatchState_ReleasePointer_m883A2568DAAC88EC5ADAC51BA91923BA4259FB60,
	PointerDispatchState_ReleasePointer_mB4415D2639C107DED4CE22BF87DA0B3599F37FC3,
	PointerDispatchState_ProcessPointerCapture_mF62860D5D2B863B460383A90AC534BD7BC1E503C,
	PointerDispatchState_ActivateCompatibilityMouseEvents_m06BDE68275511A6A5AAA7071CE690CCDA1231C0B,
	PointerDispatchState_PreventCompatibilityMouseEvents_m1AEC8D2673CB99BEE674E7C41FC233359F09C0F4,
	PointerDispatchState_ShouldSendCompatibilityMouseEvents_m8E3B674A0253A02696052101986B72FC0FA980DB,
	NULL,
	NULL,
	ScheduledItem_set_startMs_m6842F7126F6A114BC1D0069131B774C8D819CCDE,
	ScheduledItem__ctor_m756F18760E06D20D65B9E31BE6B187CA34425551,
	ScheduledItem_ResetStartTime_mB99EC01A8CE8FF074BAB5E46675E6A53EABD5CF8,
	ScheduledItem_OnItemUnscheduled_mF3738B5D249F7C3FDB949ADBE93AF97464655748,
	ScheduledItem__cctor_mD5F57B2AB9A6FD7DD8AA2AD61C52DA4EC3022F91,
	U3CU3Ec__cctor_mC60D9667AFDB517D1E71AEB3A1DDF740E988301D,
	U3CU3Ec__ctor_m4241F9DB8E37E7CECCDEEA3406FFDA8EF57A6A4F,
	U3CU3Ec_U3C_cctorU3Eb__25_0_m99215A05B153711A7FD22F9A0FD8BF1EC71F10C3,
	U3CU3Ec_U3C_cctorU3Eb__25_1_m84BEA02ED1C405C59E4A69413CE5362EF2ED90CB,
	TimerEventScheduler_Schedule_m646D29C19E0E4B88279F5A18DB0030263D852A11,
	TimerEventScheduler_RemovedScheduledItemAt_m90ADCFB291028D1EA23BC521DEF0DDE534BEBB2D,
	TimerEventScheduler_Unschedule_m0CFD128FFC0E0106F4721D59D21943BCAD69FE19,
	TimerEventScheduler_PrivateUnSchedule_m12C1AD493BA6C9CEEC9C28DC7C463238A04661E9,
	TimerEventScheduler__ctor_mF63D9637F967224988089244834C3B5CA3968E81,
	TextShadow_Equals_m9F22E055311CEF3A21E4AB2B3BF66D67F61C7918,
	TextShadow_Equals_m293B417AFF54CEAF53B45AB850ABF8659F828165,
	TextShadow_GetHashCode_m12B9A1BF70F328130924AAA64C5405233FFD8050,
	TextShadow_op_Equality_m03809E137A2951ED4164421E72FB060FED09207C,
	TextShadow_ToString_mB02E43753C499E391F39F01C20084E8AA251BE7B,
	UIElementsPackageUtility__cctor_m33D967855FCD0B3B13E34FA175E5E569DFD07F6A,
	UIElementsRuntimeUtility_add_onCreatePanel_mBC5FE203D52F506AACB17DB3BF6FB7D70DCA6C26,
	UIElementsRuntimeUtility_remove_onCreatePanel_m890B1702B239817C18DCA3267FC0E4A3711F38E5,
	UIElementsRuntimeUtility__cctor_m939E07004D08E7142D53B77151F61ACA735ABF13,
	UIElementsRuntimeUtility_RepaintOverlayPanels_m6D76DE142375920666B28618B12651B7A4CDAC5C,
	UIElementsRuntimeUtility_RepaintOverlayPanel_m73DB3F8A9AB93065C6C5F5A6E7C3AE75B087C4EE,
	UIElementsRuntimeUtility_get_activeEventSystem_mB553CD0C404232075D7D464B820178CD4395FB60,
	UIElementsRuntimeUtility_set_activeEventSystem_mADEA322BB28902A549098C400A808AB5567E99C3,
	UIElementsRuntimeUtility_RegisterEventSystem_mC891BB0DE95040D0443CF37DA2BE88FA530EFBCD,
	UIElementsRuntimeUtility_UnregisterEventSystem_m2FEC8D77B57F3FCAFE04C4017A3F48623AD99147,
	UIElementsRuntimeUtility_GetSortedPlayerPanels_m94938DF53D3B8A41892B12295D786B6DB336AE5F,
	UIElementsRuntimeUtility_SortPanels_m37C97CC304F594C53C1D60F596251D5668AD48EE,
	U3CU3Ec__cctor_m68BAB78A0C4600E269BC0706BB751D3CEF9F08D0,
	U3CU3Ec__ctor_m979877505A27D176787C097A0BB892BD21D65FDE,
	U3CU3Ec_U3CSortPanelsU3Eb__43_0_mB0C5A4B7F1CD9700B696CA7D9B8422CFBAAB2332,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	UIEventRegistration__cctor_mFD7B1CB72ED798E586C3C36D229F8477BBE1A4F0,
	UIEventRegistration_RegisterUIElementSystem_mA03AC93A6BA67C277466234518C7C9C4444D1694,
	UIEventRegistration_TakeCapture_mA619C455ACC7F479AF17A9AF2221F4713AD37C84,
	UIEventRegistration_ReleaseCapture_mCB9497D68888E7A264DC7F9AA5989D0C276AB4E8,
	UIEventRegistration_EndContainerGUIFromException_mE9F7538B7D0CC32C2D3FB92C6024D73D6FEDCB7B,
	UIEventRegistration_ProcessEvent_m4E686D1E3C90ADEE581CEA536437269EF85D3435,
	UIEventRegistration_CleanupRoots_mBC0B207BBB9954E6914DDA84E560953948380E4C,
	UIEventRegistration_MakeCurrentIMGUIContainerDirty_mB332BE310D3C69A42BADECF4EB75252753EA472C,
	U3CU3Ec__cctor_m39CD29EF2AAA2DE5A62DD2A5B42052386A16F8DC,
	U3CU3Ec__ctor_m8173E517B38C5D4665E58BE36F01E1AED62A9BBA,
	U3CU3Ec_U3C_cctorU3Eb__1_0_m1276BB1D8BE532589C69B9EF7FF6F46950CB2FFF,
	U3CU3Ec_U3C_cctorU3Eb__1_1_mE27A9FAE95C7D8556DF476FC672CE8656C30F68D,
	U3CU3Ec_U3C_cctorU3Eb__1_2_mC9EB4AFC634837113778B826633482A993AE25F6,
	U3CU3Ec_U3C_cctorU3Eb__1_3_mE25A61ED9B86A7BF471F2971C9C10E18CA189785,
	U3CU3Ec_U3C_cctorU3Eb__1_4_m0B10AA421E0CE4476EEE7AF813AE5632C0C52824,
	U3CU3Ec_U3C_cctorU3Eb__1_5_mA465B970669D77B7B5BB638A32D6C927DF7EA030,
	UIElementsUtility__ctor_m7B909BD0BC62D88CC3F453F71C3E98C72823FCF5,
	UIElementsUtility_UnityEngine_UIElements_IUIElementsUtility_MakeCurrentIMGUIContainerDirty_mE2662C98FF9702421C9729DB1DA934B6517A4B6B,
	UIElementsUtility_UnityEngine_UIElements_IUIElementsUtility_TakeCapture_mEC113CAA67F6EA16F9017CC523731F04A532A4CC,
	UIElementsUtility_UnityEngine_UIElements_IUIElementsUtility_ReleaseCapture_m34B950938F1006FD7DFEA7E23AAB2DCAB1FD5447,
	UIElementsUtility_UnityEngine_UIElements_IUIElementsUtility_ProcessEvent_m5BD45422AE537AE7058FA78E2CD6429A99ADE8A2,
	UIElementsUtility_UnityEngine_UIElements_IUIElementsUtility_CleanupRoots_m40CDABEF3CF3F206E5324C4BF37F81FA21DA04AE,
	UIElementsUtility_UnityEngine_UIElements_IUIElementsUtility_EndContainerGUIFromException_m034AD89EC020D1072B20555A24C3D453A7837DE5,
	UIElementsUtility_RemoveCachedPanel_mEF6C58EA19A301A524A4442F6405A4DFBC1794AE,
	UIElementsUtility_BeginContainerGUI_m5783968AA983119AEDBFAD6BD6079829FAEAFCB1,
	UIElementsUtility_EndContainerGUI_m946871CB9D25AC18D6184F310F5F4668653CE828,
	UIElementsUtility_CreateEvent_m7A51F79B29D5324A89E5569B46DAA3AE50ADE47D,
	UIElementsUtility_CreateEvent_mA60531DDC5A989C3275CF93EB627150E3CEB3A74,
	UIElementsUtility_DoDispatch_mEDAD415A4F5F82C78923CE68FF526AEDB0E3E9DD,
	UIElementsUtility_GetAllPanels_m3ADEC830E8AD51FAB21608B34F7D974CF1BB2C73,
	UIElementsUtility_GetPanelsIterator_m7F8B7AF85117D366681C02F0AAE74D9D176F470E,
	UIElementsUtility__cctor_mF292D98B5BC608EE666F2571EB833949490FE9DE,
	VisualElementListPool_Get_m2E8B0CCB6C110C9B817A734738C588407305F11A,
	VisualElementListPool_Release_m4E9C1625C6852CAE8C11F5390AC6972F3DB57C53,
	VisualElementListPool__cctor_m4C69F99404448E1A81EA4B119CFC35AA8282154E,
	NULL,
	NULL,
	NULL,
	VisualElement_get_isCompositeRoot_m889DC20180458B9CCA010BC204D6AFB1D03C437E,
	VisualElement_get_focusController_mAC0559C7F4549ADFDF342C4062B5A22242F1B098,
	VisualElement_get_isLayoutManual_mB50AE7DC815D10B9FF46E331F0304E9FAFDF2149,
	VisualElement_get_layout_mDAE3AD984D0CE9D7B4F92518051D2060EA928E79,
	VisualElement_get_isBoundingBoxDirty_m0A2C105391965AF78B2B456B2C92CEF569CE74D5,
	VisualElement_set_isBoundingBoxDirty_mC7088003B6CF7829D9508828DBF85B1E749459AD,
	VisualElement_get_isWorldBoundingBoxDirty_m8B726BAC627506AF9D68E52BDE1E76B99162B9BC,
	VisualElement_set_isWorldBoundingBoxDirty_m459A1315B443D5200AE1D8199121E8B265E2BFF7,
	VisualElement_get_boundingBox_m9738D6C756683E78721C3048E3E59FFAD354CE6F,
	VisualElement_get_worldBoundingBox_m82BAFF4780B0D9D902B527358F243141ABC7F1ED,
	VisualElement_get_boundingBoxInParentSpace_m0E278A8F1E5F9121DD8B9A5AD9AF5C7A185113EC,
	VisualElement_UpdateBoundingBox_m27F9996B7AF1EB566CFA60735FE6AAC11CBF8E5F,
	VisualElement_UpdateWorldBoundingBox_m62DADBD4F85C83F6DDA0D81C63DC1BEF14C8C182,
	VisualElement_get_worldBound_mC221843EE8E209555CAC96D4F99C93B17DC4057D,
	VisualElement_get_rect_m4E4FDC471C507245F3E552D45A32A6A7A92A4480,
	VisualElement_get_isWorldTransformDirty_m4C8DE186B4C0F27424E9F0D88B92D88483EDCEAA,
	VisualElement_set_isWorldTransformDirty_m32730E4295A6A4E6FEFD384DB9D91C8EB67827C8,
	VisualElement_get_isWorldTransformInverseDirty_m2B2001D300C6423AE04DE2EDC633AADF7D1FB423,
	VisualElement_set_isWorldTransformInverseDirty_m175871A577D104D7C9380B9C1A078515813163A8,
	VisualElement_get_worldTransform_m2328FC02A3E7FA5483DF43E90F91E566F728B1D9,
	VisualElement_get_worldTransformRef_m9960B2E350D4327C1E6173D59D8FC91507402F37,
	VisualElement_get_worldTransformInverse_m692FAAB9BC3E9351A10C5229786BF6EB6AC34A46,
	VisualElement_UpdateWorldTransform_m7522C78C8ECA1D6C68D540A070ABD033925CA1FE,
	VisualElement_UpdateWorldTransformInverse_m82FBF5BC23EE81DAC94B4CE3B4D5EE1DE21577EB,
	VisualElement_get_pseudoStates_mF0B31C86C3CF44C4FA2F42F7641DAF33C9F4B736,
	VisualElement_get_pickingMode_m941A6399B8BC544A8C516A157EE677369FD2D5F8,
	VisualElement_get_yogaNode_m5CA07AF1958F42E7831FA71C571449B659290A93,
	VisualElement_get_computedStyle_m1B4DA56E8F0A56EE2FF03AD1020DC803A01CF4C8,
	VisualElement_SendEvent_mE8299D39D5A55DDDB5C079CAD8A265F2E46BD958,
	VisualElement_IncrementVersion_mB583875ADC5D9BD3DC7CAA49722BBFD617A16477,
	VisualElement_get_enabledInHierarchy_mA94B8F82641FD0CEBA18B9BA27FCA33F14F8FD97,
	VisualElement_get_visible_mAB6E36F62562D0577D2F62E68EAAF101F279DBAC,
	VisualElement_ContainsPoint_m282678268DA39084B61AB2EC601EC79071AE9C31,
	VisualElement_get_hierarchy_m4B2AD83FE8FA93302B534E4EF77E356901F1A90A,
	VisualElement_get_disableClipping_m7AEDB8630B1E94831BC3EA00228EA58B348B1A38,
	VisualElement_ShouldClip_m4003A9EA0539E41681D50ABF24AC714A5737D179,
	VisualElement_get_elementPanel_mC3F8CF4D43D0C5841CCCB92D5A95398065B7282C,
	VisualElement_get_panel_m8362331515135E7044CECFED9260FAA1EBD53E43,
	VisualElement_get_contentContainer_m9AEB8A806ED94BA748041BB3421E1C22B0D0897B,
	VisualElement_FindCommonAncestor_mB165E7F21BC9C527E596783A072BFC01812CA884,
	VisualElement_RetargetElement_m123AA4EF0C544681D449BEA23D4046048F9B47CA,
	VisualElement_get_positionWithLayout_mD14565DE33EEB2AD579D1ED8B18DB657A22DBB06,
	VisualElement_get_matrixWithLayout_mE83663BFD6474B8E7DD4600C19B67792E3B91C91,
	VisualElement_TransformAlignedRect_mE59EDF0EA19E62964E8E536214CE187C7C5A4615,
	VisualElement_TransformAlignedRect_m5C0CAC1A54F2609BB47CC13B668E1D8F1612DB5D,
	VisualElement_OrderMinMaxRect_mB35FA4EDEC667B393914818AE2926691FCC87052,
	VisualElement_MultiplyMatrix44Point2_mA3E8672F4224D072A40F21FE425C5777B631F0DF,
	VisualElement_MultiplyVector2_m998F0401A4D7B338A355EF5944A9EA8B496197A0,
	VisualElement_MultiplyMatrix34_m3E6174DBB758ED4EC69BA129A97367472F79415D,
	VisualElement_get_schedule_mF41FC0F87DBDA94CBE816C8341159956E4E0065F,
	VisualElement_UnityEngine_UIElements_IVisualElementScheduler_Execute_m2ED6DE1F4D45B758506009167CDDE0AD35CCCBA0,
	VisualElement_get_resolvedStyle_mA04F20686F08336054580BABA585416DE1D2071F,
	VisualElement_UnityEngine_UIElements_IResolvedStyle_get_display_m647045B0AA08BBB6121BA4D8F8866388222893E6,
	VisualElement_UnityEngine_UIElements_IResolvedStyle_get_visibility_mDF08FC3BF23AA2F766AE117AD1B8952ACA223825,
	VisualElement__cctor_m44215ACB2EE76BE1FC750838A9595AF230284049,
	Hierarchy_get_parent_m95543CF2F0974BC89228441F8789764F6F10F502,
	Hierarchy_get_childCount_m53DC6BD1E3F83390D53D5DF31EEBB68EA533DE56,
	Hierarchy_get_Item_mC13B7FAA90B9AB3295560406C5223DB80046D6FA,
	Hierarchy_Equals_mD61D088EAA5FF9E5EB5FC51C8443890382D342F0,
	Hierarchy_Equals_m4E001F4C66AF4D844E883AAE5BF761684695116D,
	Hierarchy_GetHashCode_m07B0319B25E28C4473DD6F864553DDCC17EBD515,
	Hierarchy_op_Equality_m643B32353437693227839E357274B0926FF44F78,
	BaseVisualElementScheduledItem_get_element_m68B5219A07633C6019E97AC594E8099269B2BB8C,
	BaseVisualElementScheduledItem_set_element_m3E1A847EAFF3AF3C249BB51B5ED1DA9E51247880,
	BaseVisualElementScheduledItem__ctor_mA49382DB1A844E129F3A372A2E0BC91F45DE88C1,
	BaseVisualElementScheduledItem_OnItemUnscheduled_m11212547146BD9846DE362BCD06BA2FD11262CDA,
	BaseVisualElementScheduledItem_Resume_m37F2B94DD6013D79EEB85342EFA2CE231AAC66D3,
	BaseVisualElementScheduledItem_OnPanelActivate_mCF07693CC148404E8E7CE12C90FA01720284C2A0,
	BaseVisualElementScheduledItem_OnPanelDeactivate_m226B026AEF6EBAB6B4BF8414EB26110D7E6F4691,
	BaseVisualElementScheduledItem_CanBeActivated_mE36E839682A6C323B5624EBB8368D4FAC64F5FC0,
	NULL,
	SimpleScheduledItem__ctor_m53D11B49106C5F3DEB9FAF325C00180F1C2EAEBA,
	VisualElementExtensions_WorldToLocal_m817AA6D587FA9723DB4F3580FBCD095DD7720595,
	VisualElementFocusChangeDirection_get_left_mA7F353435BEAE57EAFEBA75B86564432C03F085C,
	VisualElementFocusChangeDirection_get_right_mD9B70FCE433CA74E5361FE74F7AA6A01B1248342,
	VisualElementFocusChangeDirection__ctor_mB497716BA2D8949EB060C21B154334919C967A87,
	VisualElementFocusChangeDirection__cctor_m075F66411EF46E9F51C1145568E4F87C0B18F553,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	VisualElementPanelActivator_get_isActive_mFA4041CC2963E5D2D88C63EA3836F496E2576398,
	VisualElementPanelActivator_set_isActive_m729B25C8EAD4377C752D04390FD2AB9B38529E75,
	VisualElementPanelActivator_get_isDetaching_m2ED9B5DF7F9063215CD2F691C57FAAC16DD19CC5,
	VisualElementPanelActivator_set_isDetaching_mD4CAC44FA31DC700177A11C4292D98241FD6AB79,
	VisualElementPanelActivator__ctor_m6253EC6859136187CA2311B57401E1166D2B9084,
	VisualElementPanelActivator_SetActive_mEF62F79FC0D6B79A461EE131AB29E8285F5C8ADF,
	VisualElementPanelActivator_SendActivation_mD4E51A6DCFF15A9DE50145C568F4232020B00B74,
	VisualElementPanelActivator_SendDeactivation_m40975D6281CF92F8CDC8C1C66E710774480B45CF,
	VisualElementPanelActivator_OnEnter_mAC503F7299D01BBEA727C19CDC54B86363A0E95D,
	VisualElementPanelActivator_OnLeave_mE1768C69309EDBA85179252CB5C3949EC08D2620,
	VisualTreeUpdater_UpdateVisualTreePhase_m1D07B623D69CC03ED552CD0942C6B20C2E235897,
	VisualTreeUpdater_OnVersionChanged_mE8F69561A928E2801617B577AA92BC5E1210B865,
	UpdaterArray_get_Item_mAFAF068DEE331E50496982E388FFF67A74092740,
	UpdaterArray_get_Item_mFC61CA9A14C4F1C014BBBA565459E9377AE40AFD,
	NULL,
	NULL,
	NULL,
	Foldout__cctor_m94EAEF439C0FB19DE1B027EFD668ECB295364DE4,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	PointerCaptureOutEvent__ctor_m5C154DE31521FA590359379C0367B2AA46F5D48E,
	PointerCaptureEvent__ctor_m2CD51742C0BCA6263D6E35BA5BB1EED232860591,
	NULL,
	NULL,
	MouseCaptureOutEvent__ctor_m28FC2BF08FB9814BEEC4D554AD18E6585DD2D0D0,
	MouseCaptureEvent__ctor_m3007A7F43189519CA0AAC3EE6F61699C5FFF23C3,
	CommandEventDispatchingStrategy_CanDispatchEvent_mFFC01C287248E1F67B9C0A04C94299B4B57C1BAB,
	CommandEventDispatchingStrategy_DispatchEvent_m48BF91D717276E712355D42B8BF2ED080D478171,
	CommandEventDispatchingStrategy__ctor_mE1E6A29BD4B8D1BAD45112A5DE390FC73C3C5EBE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	ValidateCommandEvent__ctor_mEF115FFA17BFA6106E67AC22F4C289227C5504C8,
	ExecuteCommandEvent__ctor_mD48281641BE52D713AB8C7BF394EEDD2DC4B3920,
	DefaultDispatchingStrategy_CanDispatchEvent_m6ACEF0B7C67A07E3093395E7D7E21F57533545E1,
	DefaultDispatchingStrategy_DispatchEvent_m569EFC07ED703BB47D1E1F6C2780FBEAE3E201F8,
	DefaultDispatchingStrategy__ctor_m52B8F90BFA65578FAAD432D902EF5C1DEBFABD33,
	ElementUnderPointer_GetTopElementUnderPointer_m2B196EE08260E01BBF81112D831FE29477120EB7,
	ElementUnderPointer_GetTopElementUnderPointer_mD1D1C5A3C264654C9CB19666CC1097408E49D139,
	ElementUnderPointer_GetEventPointerPosition_m50EF3CA06C044065574907AC9CB8A2FB1F64EFD8,
	ElementUnderPointer_SetTemporaryElementUnderPointer_mE9F63DDCF4AAF65877DDCAFEB94C69A002ADB017,
	ElementUnderPointer_SetElementUnderPointer_mEEB043B3F851939AFAB31A493C2742C316B3094B,
	ElementUnderPointer_SetElementUnderPointer_m28C80675B9B5A7FD92D56A5E99CC40C90E66E68E,
	ElementUnderPointer_CommitElementUnderPointers_m6FA3E7B972629EAB789D1902406D99F0096A4D4E,
	EventBase_RegisterEventType_mACD00E065C77D62FCB73159B71E915D3A7D247F0,
	EventBase_get_eventTypeId_mE3958C191E09FA1710A197348124ECBD0F34FF1D,
	EventBase_get_timestamp_mBE46F8C2C0B85FFD1D4B7B6CDA21C2C82FCDBCC4,
	EventBase_set_timestamp_mE56824EA2FF801EEAECC91C532FC730AD6DC73D8,
	EventBase_get_eventId_m59ED33B729E24BF0C7D55303D11B70538B007912,
	EventBase_set_eventId_m93D08BAA45F62D212E4564E5D0CC8AACA418F03F,
	EventBase_set_triggerEventId_m6E2574EA72F69317B99C74A6478B7576F024EAAA,
	EventBase_SetTriggerEventId_m2637F8FFBE2A30700DFE12378DB5AAFCF5D8F6C2,
	EventBase_get_propagation_m55C0F2EB5B86D1911DC9513AA65F97359A114F3F,
	EventBase_set_propagation_mAC9E99EE268E3A5D1715739AA03FA014B460F0D7,
	EventBase_get_path_m7F34D8626F0314CD14C3FC1307B0E87B7981E5D2,
	EventBase_set_path_m6C6416464FE0FAAA9DF37C9C1FD34C01818EE3ED,
	EventBase_get_lifeCycleStatus_mE2FE4D023CBF3092A11B6358D700D8E5AA34DF7A,
	EventBase_set_lifeCycleStatus_m00DCC6852FB999F743D06C1F3B9F94268543F87E,
	EventBase_PreDispatch_m99F93BCF0242E70AF5FEB7749014CA3D2E71E4DF,
	EventBase_PreDispatch_mE7A4322A35B89AA39D47A7EF08A0FF2FF1EC53C0,
	EventBase_PostDispatch_mDF67FEC7415D902731D588DD0A628B12991F51F2,
	EventBase_PostDispatch_mE19DE5735A3325E50E2BB51949ECA45D1074CA67,
	EventBase_get_bubbles_mD57DAA916C9A595F207F9B38B04D7AABC2528469,
	EventBase_get_tricklesDown_m1C0915991B8756E0C40F0DB2D471DAE945ECBC1F,
	EventBase_get_leafTarget_mA5FB9DF6EAB0F7186D19BBE28F5CC8DC832FD2AB,
	EventBase_set_leafTarget_m86D05832A47FCE780426807CA7293970C4875EE1,
	EventBase_get_target_m9EF112412E3EDCC34273873C1800A83F08A251D3,
	EventBase_set_target_m0DB62F906DB05078428D06B8FCBD8D393D23294B,
	EventBase_get_skipElements_mEE50112B390E7AA109B098D7AF379A2A947A6900,
	EventBase_Skip_m4CD7DF38D443353E17777495F355EB1895D26745,
	EventBase_get_isPropagationStopped_m4856E14BCD1287019DE0A487D15809586A8B11E9,
	EventBase_set_isPropagationStopped_m20B06E7376B943FBD0F95D20EB33AF4DB562C580,
	EventBase_StopPropagation_m6BABC2698D9BEE8E9044B58DB65363591C26EBDF,
	EventBase_get_isImmediatePropagationStopped_mF6A1A67BAA11F4EC486346252211FBDA4078091D,
	EventBase_set_isImmediatePropagationStopped_mA19F0FDE98B7C761E9C36428BA8219D30A2AC452,
	EventBase_StopImmediatePropagation_m008E632FCE3DEF14249F7E6AFCC76F35011C55FD,
	EventBase_get_isDefaultPrevented_mCE6C63CA42AE3EB7197F8B145BB305CC617AB674,
	EventBase_set_isDefaultPrevented_m7F299A8200B34FD5467C212DF78E222EC1AC0BBF,
	EventBase_PreventDefault_m4B240A9D61D80226E2FD28F60128F74084810848,
	EventBase_get_propagationPhase_mC3F6691B2E84AB5C0942A6C4F478D6A45FF784E8,
	EventBase_set_propagationPhase_m906F58ECDF1F529BA3B198451B00FCE2133F9731,
	EventBase_get_currentTarget_m53E8F94F987823E5065FC53AEC0C87B1ADF1C9DD,
	EventBase_set_currentTarget_m7ABD5BA0A703839B542F757AD6084F168301C776,
	EventBase_get_dispatch_m83094094F27EF0942E73F1EDF712878A729E51A1,
	EventBase_set_dispatch_m210C16B1DCD976CB965336FA666EEDDAEA7EB26F,
	EventBase_MarkReceivedByDispatcher_mCD5AECF121EE4DF722BEB64828DC14EF34E1C8C3,
	EventBase_get_dispatched_m6EBAE7263103466C265ED51CC63253EFF9CE097F,
	EventBase_set_dispatched_mB36266C96B1D5DACB25FBFC7E1F2AE99A11E7110,
	EventBase_get_processed_m691D8CBBCEA051DF7C1F46376243E0A2542CF763,
	EventBase_set_processed_mC772D21D94B8447A2D56741270A4637BF4CF5A8D,
	EventBase_get_processedByFocusController_mBC615641CAF2264434CB5C4D8EFF2BB2E2844213,
	EventBase_set_processedByFocusController_m275D4E3D33CBF66F6F330DAA69FE2BB45C3414BC,
	EventBase_get_stopDispatch_m3DA4402031FDECC0416B84830B76CFC1F0341A4D,
	EventBase_set_stopDispatch_m205E6F1247BCE14D3C5DBDEEFDE14EB9311CC2F9,
	EventBase_get_propagateToIMGUI_m28F31AD863BD73D46440D974EEB4CAEF2CA0FA2E,
	EventBase_set_propagateToIMGUI_mBED8533FA995A78CC9C8F9843909B26A00BFCD00,
	EventBase_get_imguiEventIsValid_mB285F9A66AA61AE7DA585B45ED8DD767403F7F64,
	EventBase_set_imguiEventIsValid_m1401EA7452C2B4BE7936932A3D469B3D86FDA6C1,
	EventBase_get_imguiEvent_m810A49C5C6373AE3723CBE252BE2298A5BBF090C,
	EventBase_set_imguiEvent_mC4D6A8E08A41E53F774E6A736C77F2AA1DADDF1C,
	EventBase_get_originalMousePosition_mD40FA45A685D281A1A03AB38B40390D27ADACD04,
	EventBase_set_originalMousePosition_m0065AA01464C8AED3B2D8E03069E9E1EDC06E46B,
	EventBase_Init_m8E736BE6A717A7DE7894AD42F4681A783A2D8D72,
	EventBase_LocalInit_m712BDEA793FC6D0547EF6D0D4465FB748678B7DA,
	EventBase__ctor_mF95C69400D2505F84C3CC1460ABEFA906CF3D82D,
	EventBase_get_pooled_m06BB533163C3D0B89FBAF5308948CF38B2ED4358,
	EventBase_set_pooled_m131A347E2ECB46EC42FF8BE356E54F8663A665B9,
	NULL,
	NULL,
	EventBase__cctor_m0DC5F1D9A04D67BE6DF1D8096C366841B1FC1CB1,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	EventCallbackFunctorBase_get_phase_m26681E62F951BBC9D3A0D929267BBA16ABDC8176,
	EventCallbackFunctorBase_set_phase_mA803DEEE131EE6DF5B13E624AE692CEE3EFD2680,
	EventCallbackFunctorBase__ctor_m7FA913AEEDECA07F4A79AA3873CDFD017B258BB5,
	NULL,
	NULL,
	EventCallbackFunctorBase_PhaseMatches_m76E4574A745A89B67CA6DDCB2A50560636FEA7FF,
	NULL,
	NULL,
	NULL,
	EventCallbackListPool_Get_mC25881B07E43CDD608C1E55B9879E450CB4C1FBB,
	EventCallbackListPool_Release_m24B2350E963E879BF75D314AA547990C772C490E,
	EventCallbackListPool__ctor_m2D083694479DC5C05B9370627D9384BD07D53DCB,
	EventCallbackList_get_trickleDownCallbackCount_mDA5D744D0015687CE22269F43C215EB2973F46A2,
	EventCallbackList_set_trickleDownCallbackCount_mD35C97D3F730BA23738A8CB68BCE42398A3E3FBD,
	EventCallbackList_get_bubbleUpCallbackCount_m781703B980F67C081CEA743E87580675B481CBB4,
	EventCallbackList_set_bubbleUpCallbackCount_m75C48F15BA4E2966F999C230CD4D2F9658602D47,
	EventCallbackList__ctor_m987EB24DB79D6FFFDAD1D5E5FD5DAEB28361C552,
	EventCallbackList__ctor_m648517F07107158FA5415FB65EED192397094894,
	EventCallbackList_Contains_mDD0301728E02A3336E211CF0B8CD9CD26BC49828,
	EventCallbackList_Find_m75710F3FEBF84AF3C3A09CB8C3615C942536AED2,
	EventCallbackList_Remove_m92C09F39132042C72B52C98621CFFA843CC237EC,
	EventCallbackList_Add_m63BF0F96927693DA0B5CCFA1CF61CCFCA50CFABA,
	EventCallbackList_AddRange_mB8297D2A3ECAE1B6252541AC2114CF02641B0141,
	EventCallbackList_get_Count_mAC5EFDB3F0C314A1D0CEF370019E7CB7ED090BF4,
	EventCallbackList_get_Item_m4EBBF3D95831065B9B9BADC76ABFA5AE8CF59DBD,
	EventCallbackList_Clear_m21819478129C48DA7E1FE0FDDFB4FAFD23755E73,
	EventCallbackRegistry_GetCallbackList_mE29517EC832B864ED1304477F510F84614EDA877,
	EventCallbackRegistry_ReleaseCallbackList_mD62226ED4A6FE104F12CC0CD9CBB831C1039EBD3,
	EventCallbackRegistry__ctor_m0E6C045647522D2382B9D6BEDBA0C38DE88B7E52,
	EventCallbackRegistry_GetCallbackListForWriting_m9182E5121C2260D5A20BE4822268FE44354966B5,
	EventCallbackRegistry_GetCallbackListForReading_m6D8452BC704C6231E2168FA4BF36CEB35B85720D,
	EventCallbackRegistry_UnregisterCallback_m7A3ECB87DB28DFC9A66D510E2E69B9127FD9D4C6,
	NULL,
	NULL,
	EventCallbackRegistry_InvokeCallbacks_mBB7C2EFC91F10355DC1CCE02A5B3689A48CCDC17,
	EventCallbackRegistry_HasTrickleDownHandlers_m7EE3D891466544D69D157E956879559BD21551B0,
	EventCallbackRegistry_HasBubbleHandlers_mC6577445AE8E03D5BE439DBA44EF945507893768,
	EventCallbackRegistry__cctor_mA4455BE6181B7297876DB6B990EAEF8A5D5E1079,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	CallbackEventHandler_HandleEventAtTargetPhase_m45DCCAB32EF380329DFC7E57993765E806022DFC,
	CallbackEventHandler_HandleEvent_m8FFE102B46EA0D73BF8E9EA0E75421A8BAAA5E4E,
	CallbackEventHandler_HasTrickleDownHandlers_m3C9E244D3D1AE1CB35F657B223AF73E66CD6DB01,
	CallbackEventHandler_HasBubbleUpHandlers_m32B0F8B687026FF7D123695D6E6053A51326460C,
	CallbackEventHandler_ExecuteDefaultActionAtTarget_mA648038DCB390D259CDF043E8F8F7E1C654C2FC1,
	CallbackEventHandler_ExecuteDefaultAction_mBC1D8F34B8666E08E5A337F309B052F1CEB0797D,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	FocusOutEvent_Init_m26933D10E5E92BEC5CF3C9DF976D603182130C4C,
	FocusOutEvent_LocalInit_m8C059742959765CFC806F0F6373F9D19EA0FCBF7,
	FocusOutEvent__ctor_m452B50AB82114267C692409B5E490C0266152F31,
	BlurEvent_PreDispatch_m85F6921E1530D5A930D2A626035CF8FD5AA8DA3C,
	BlurEvent__ctor_m4F66EB6D2708636D934EF00E3554AE0DAE54D60A,
	FocusInEvent_Init_m1F053771080166CBEBD9FE59EED4FA2FFB9DA114,
	FocusInEvent_LocalInit_m073ACCFFBD9A8864E0B794FBBB9C4DB3879183EA,
	FocusInEvent__ctor_mFCEACD5BC759A7BD87A44ADF31D18C8173BA3AD5,
	FocusEvent_PreDispatch_m955791ACE881CC59970791E1D86B73586226BC54,
	FocusEvent__ctor_m535CC2792484AED35AC711CD8606AE7700B933FF,
	NULL,
	NULL,
	EventDispatchUtilities_PropagateEvent_mF651424AC323A8C532ED4029080E25F679CEA957,
	EventDispatchUtilities_PropagateToIMGUIContainer_m3941E9148C6DA84024430DB11BBC494456BE896E,
	EventDispatchUtilities_ExecuteDefaultAction_mD04659432D2B0A36DFA8801AC41E20F43DD3A705,
	IMGUIEventDispatchingStrategy_CanDispatchEvent_mF723D5B27372C26EE404E3B48E5A8849E8768BBF,
	IMGUIEventDispatchingStrategy_DispatchEvent_m497136E3C304EF45F150A883008C09691747A0CF,
	IMGUIEventDispatchingStrategy__ctor_m7EF677A41F2B30F0CB89D46EA549F29BCDD9F07A,
	KeyboardEventDispatchingStrategy_CanDispatchEvent_m7A7494E90861B0FDCAD6C4E3A3E4FD17507A263F,
	KeyboardEventDispatchingStrategy_DispatchEvent_m7F14F7100E05B90BF061F90A67F055CB20F86307,
	KeyboardEventDispatchingStrategy__ctor_mCF2A370AED257B24BD2E104ADF18802D53AD2BD3,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	KeyDownEvent__ctor_m963F494BFF28D4D8C6278FB9F52E6B13FBDA64C6,
	KeyUpEvent__ctor_m22670A0913E634CB6D078C9EC610ECBC92CA6B74,
	MouseCaptureDispatchingStrategy_CanDispatchEvent_mEE201473460ECEFC34F35617D4F22A6573B4F725,
	MouseCaptureDispatchingStrategy_DispatchEvent_m72941E2EDA08614EA097229EE67474178BB10A4E,
	MouseCaptureDispatchingStrategy__ctor_m7180B5A954F9C724CB91245091ADBA0CDD4CB3E7,
	MouseEventDispatchingStrategy_CanDispatchEvent_m4CD6519880568496F3208864B69BBF91A3FC3533,
	MouseEventDispatchingStrategy_DispatchEvent_mED8A81DA7CF30AB375876EFE64D607C1DDF3C50A,
	MouseEventDispatchingStrategy_SendEventToTarget_m3CAB06F6F03A269AC25717521D5D9B17119C75FA,
	MouseEventDispatchingStrategy_SendEventToRegularTarget_m8795BF59A222DF150CB2B3BD2423D1A3FB549E05,
	MouseEventDispatchingStrategy_SendEventToIMGUIContainer_m2269978BC713466DF6C30A82A4CC71575FFCD1B8,
	MouseEventDispatchingStrategy_SetBestTargetForEvent_m2AA9CEE13BC6764B19E6238607EEBB8033793B57,
	MouseEventDispatchingStrategy_UpdateElementUnderMouse_m193BC6B2AC9CC96B2143650C40DB5E0230FDD022,
	MouseEventDispatchingStrategy_IsDone_m5095D1C26BDBE95366A6230DC0430DF174FBE543,
	MouseEventDispatchingStrategy__ctor_m1B63E69B349E2DB58BDB2C8C4E6F30F54915B450,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	MouseDownEvent_MakeFromPointerEvent_mE48AC579CD55EA39999785B14AE69F946076A708,
	MouseDownEvent_GetPooled_m9BD8A2D9A60896F118822E3F682B78915F5D25EB,
	MouseDownEvent_GetPooled_m10B30120FAD71BBB46E183CF82CA3D8F52121682,
	MouseDownEvent__ctor_mB5B7D59B0C30202178B6807248C0976F6D5D8AE0,
	MouseUpEvent_MakeFromPointerEvent_m64AFF722CA1FF6A2014334238EDBA49A6E0A5EEE,
	MouseUpEvent_GetPooled_mA2C004A46C712FDA6D8C1E0585D565F921DC5A65,
	MouseUpEvent_GetPooled_m4D65D95BB4C485A39C582E16C190E77649A61554,
	MouseUpEvent_GetPooled_m07142003287C30E1F692A7E5600D1BBDC5F5B0B1,
	MouseUpEvent__ctor_m9A2EAF1782DF259921562BD899C57DC97C03B732,
	MouseMoveEvent_GetPooled_mFD5268330561837C739D27276C3503FFFD3D3BC7,
	MouseMoveEvent__ctor_m8338EFE003BE5A9C8AB19FC39B5BD2BFB75F8BFC,
	ContextClickEvent__ctor_mF146316FB93D2FA563E454E600805009421B7644,
	WheelEvent_set_delta_m4011F334763F8DB0440A93DB11969D5E54CE2941,
	WheelEvent_GetPooled_mF7F5730BB2E121D607CCAC891424195B50A16D4C,
	WheelEvent_GetPooled_m5DD476C736F6CAE30AC11A9CB6D289B3C73C5D1B,
	WheelEvent_Init_m4AC4D0DDD59BB370486E2F537A240490F1AEC8D3,
	WheelEvent_LocalInit_m5A8D932691191AC77AFB357CFF3FDD03067F6EBF,
	WheelEvent__ctor_m349D78D43A6CF8CAACF776D85F3770C8E9277B8B,
	MouseEnterEvent_Init_m8524B7C64446AECB34853348BA917A30FCAF439F,
	MouseEnterEvent_LocalInit_mF63F7A2A6AC88A9DF3E562EAFBEF5171E99E82E7,
	MouseEnterEvent__ctor_m23A8F9F5FE96CFA134DD06FA967C0DC0AE0BB067,
	MouseLeaveEvent_Init_m9CA31EAC25EB077BE7B2DB609311F5D64FF6AE9E,
	MouseLeaveEvent_LocalInit_m66D6950029CDF83E0638F2529B6A260E1F236702,
	MouseLeaveEvent__ctor_mD4E8784E7DC22BDD039F24121D7BAC0422EF655D,
	MouseEnterWindowEvent_Init_m134110CF9AB641E6C917EC832AACC60E9D37AE9C,
	MouseEnterWindowEvent_LocalInit_mEED8CE36A83E7677BB8F1F383F85891F64B7CB30,
	MouseEnterWindowEvent__ctor_m2891A242FC54ACA0D46E50C0DE0778A85EE44475,
	MouseEnterWindowEvent_PostDispatch_mFB4A31988A7F52D53D8EF7E680808488D6738D17,
	MouseLeaveWindowEvent_Init_m32D67F36EB72488F4FFF92CB23C76EA58B7C9CC8,
	MouseLeaveWindowEvent_LocalInit_mB65FA9FB7135E44231403341595327C8A4CDA2A7,
	MouseLeaveWindowEvent__ctor_mAD5C25072B574D2808C98C277194DC17F6B4DE37,
	MouseLeaveWindowEvent_GetPooled_m54824BF17E16E0774F232C76F734ADD6C1D6CD8F,
	MouseLeaveWindowEvent_PostDispatch_mD51BA80C55554AF97EB1853B81B0135A55787F29,
	MouseOverEvent__ctor_mD3939067D8EC2FC2727F2529E2F3E0E650D0B155,
	MouseOutEvent__ctor_m19ECCBA4CE26D280244B5B29C046D09B0E3C7B24,
	NULL,
	MouseEventsHelper_SendMouseOverMouseOut_mBF5DEDA49C28F692AC45E6685C676099C54C913E,
	NULL,
	PointerEventsHelper_SendOverOut_mF5F6CBCD3D51CB61C761F7B63A10DC8A79C97FC8,
	NULL,
	NULL,
	NULL,
	NavigationMoveEvent_DetermineMoveDirection_m6AECA115BD7BFE27FA931265382D1D6F4D652B6A,
	NavigationMoveEvent_set_direction_m27926B1045180FCEFD0ED4FBF78C9A6108D746E7,
	NavigationMoveEvent_set_move_mF6465D371C97E5BB1133BB0631FE0F70197BE458,
	NavigationMoveEvent_GetPooled_m91F6C91C42A6FF60B4CF11A37194F949186BC3C6,
	NavigationMoveEvent_Init_mBA38585EAA9A261F96CDF3C27B537919C7751932,
	NavigationMoveEvent__ctor_m91D5298F2D7A072641F446B3AB230141344D3E00,
	NavigationTabEvent_set_direction_mA0F32D4E7144F050FF5F07D5D5535674141EBD5B,
	NavigationTabEvent_DetermineMoveDirection_m23BE84C51FC6148C9762CAE10D6FAB2614161194,
	NavigationTabEvent_GetPooled_m10A3EC01256C3068E0F17877FAE1FFD9D1B1C90C,
	NavigationTabEvent_Init_m52098CD181CC55F50D0B51402E609CB1F04C6C66,
	NavigationTabEvent__ctor_m4FC6E8B351ED8359B2D292979A672E12FDE22C3A,
	NavigationCancelEvent__ctor_m8B4E74079C21D8A3D98E80D0D93D551274F37384,
	NavigationSubmitEvent__ctor_m19EB7E400616AAA55E0CFA85BAA0A64D7FADF9F3,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	AttachToPanelEvent__ctor_m5E45CAC71DF8EF0795C203C3BE33A9828F9AF59F,
	DetachFromPanelEvent__ctor_m12FE85F617BFD1407764B3DCA111450614FD804C,
	PointerCaptureDispatchingStrategy_CanDispatchEvent_mB40E1856BC671C00F18AA4B79EE6B7FE1232B3CD,
	PointerCaptureDispatchingStrategy_DispatchEvent_m733B268E70ED848D4273818CA30896D71043F4C3,
	PointerCaptureDispatchingStrategy__ctor_m1779D761C384FDFC52CB6EDD98599F6112038542,
	PointerDeviceState_SavePointerPosition_mEF122393DA3DDDD76B90A294AAD949DCB4CAB326,
	PointerDeviceState_PressButton_m94C835AFA3218D6E0611D5E95CF2CEFBA0695407,
	PointerDeviceState_ReleaseButton_m6362CE66A8893F34B6E3592D2772774F439EEEBD,
	PointerDeviceState_ReleaseAllButtons_m7F22F02643003A9787E18E3F391382DAE53F1F9C,
	PointerDeviceState_GetPointerPosition_mCDF2E493F70D3D01A0B835EDBA65D7A9438F3873,
	PointerDeviceState_GetPressedButtons_m2CB0A826D2D596EEDBE3E9B547E0F889B8B7EA0D,
	PointerDeviceState_HasAdditionalPressedButtons_m040E78C3B5392994F87C02B50795EDDFD8283AEC,
	PointerDeviceState__cctor_mDB8DEFF9B20C4A507D1193350A57C07784B3EF49,
	PointerEventDispatchingStrategy_CanDispatchEvent_m3E6C5C25FE20312F3D8A676B084728D99B1C34DC,
	PointerEventDispatchingStrategy_DispatchEvent_mB324E0C0207FF2505AE4C7EC8223F7F14E594D66,
	PointerEventDispatchingStrategy_SendEventToTarget_mAE1672FB11C7E88C7EE71994283796A3456D60DC,
	PointerEventDispatchingStrategy_SetBestTargetForEvent_m04F8CD8E21D260E3DD499B496FE9798185DF99B0,
	PointerEventDispatchingStrategy_UpdateElementUnderPointer_mFAE2047E4CA53712A0E4DFE69DC1187085CE63C6,
	PointerEventDispatchingStrategy__ctor_mD7E9B783810D57380849CC9B91D0C002A00E1071,
	PointerType_GetPointerType_mC5B68065EA16AC95D5369CF623DC0848AEACE244,
	PointerType_IsDirectManipulationDevice_m18319821C271B05D7C8F778F57BD2326797555B7,
	PointerType__cctor_mE4ED6420F77B13F239FF35D99622A46FF117927C,
	PointerId__cctor_m78A847AFC9330255BA877654E46EF8A9B7E199E9,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	PointerDownEvent_Init_mC2FE41D611A632A9859D75C1BDFBC39124338F50,
	PointerDownEvent_LocalInit_m031B53FEBA399B7A308F037D9A235F5B6FB8CADD,
	PointerDownEvent__ctor_mBB78C62DAE81EB0618149FFFA86C15F88A3523C8,
	PointerDownEvent_PostDispatch_mA039FA50EF9FC8A112D19EFB4FE04E33F8913AE2,
	PointerMoveEvent_set_isHandledByDraggable_m5524FBF6C85971663E4DDC39E16039CF08A722BD,
	PointerMoveEvent_Init_m01B48610E00D315AA4335A4555CA9E9A1A98579D,
	PointerMoveEvent_LocalInit_m914823683747F3517ACF28EC28E90AA141F3AA53,
	PointerMoveEvent__ctor_mA5B01F8892A2ACDBADD61B766B3181C58A6BC598,
	PointerMoveEvent_PostDispatch_m0CAC54B14AFD21EE1777A3CAEA694C83E6D92C4A,
	PointerStationaryEvent_Init_m2F74912B6F8E47F834B9CD4AB69CCA578793F5FC,
	PointerStationaryEvent_LocalInit_mFF2BFDA3880337809FAD25D339EAC680F91AB5B1,
	PointerStationaryEvent__ctor_m6F656BC8B4D581C2B59E14F70C24B9BF62BDC87E,
	PointerUpEvent_Init_m6FE64AD9396F7DC5C2EC59A609FFBD840AECDD7D,
	PointerUpEvent_LocalInit_m97B6A85A029E0BBBA8DFE8529467019B555AB750,
	PointerUpEvent__ctor_m58B8B9A6646DE2979BE8283ED52311EE1131AF4D,
	PointerUpEvent_PostDispatch_m9678D83B64EF5E3F73FF6B463BFE22C5E20489F3,
	PointerCancelEvent_Init_mEE63311CC5F8D54F5456AC358DF8F9320750BCAF,
	PointerCancelEvent_LocalInit_m1E15CD4EB381B595E5207F00907A0E2321D20E5A,
	PointerCancelEvent__ctor_mB4F6A7F10076FCFCD62AE01AB4C487BF4F3CA127,
	PointerCancelEvent_PostDispatch_mE078C677CB449C11715A52784972C212E2786796,
	ClickEvent_GetPooled_mA80F7CA88FB9B3FCED3C0954B5422336B4071AA7,
	ClickEvent__ctor_m550342FBB4A2411720170650462C7C7EE373A021,
	PointerEnterEvent_Init_mD35F66B52D91FB299C0CE3EECC0833EF94F21FDB,
	PointerEnterEvent_LocalInit_mA6F0CEFF2F20C0AAD04AF836C8FA4F5AE3D4DA9C,
	PointerEnterEvent__ctor_mAFF4D46DE8CA5D29C1FDF16EB65722D3BBB4C9AE,
	PointerLeaveEvent_Init_m134F71D1E7DF9260963030E33CDBC7351D17E5CE,
	PointerLeaveEvent_LocalInit_m971E9B1E26F762A3C6D415CF539E4A25D7403F92,
	PointerLeaveEvent__ctor_m5540F6457DC3FBEB69CA94D12758D82628FD3E8E,
	PointerOverEvent__ctor_mE74C0588B457AB4B1CE6CEE462AF22EA60851950,
	PointerOutEvent__ctor_m379ED3D47D480DF021BF63DF3B4717022D806281,
	PropagationPaths__ctor_m198ECB782CC29620C76003DB37FDFDCFBD85D8CF,
	PropagationPaths_Copy_m5DC4E96D86F3F4B7BD4C239B494077259E439559,
	PropagationPaths_Build_m6F092641AB07F3712728F027815F35B64170CFB0,
	PropagationPaths_Release_m0C86E97EEA98A2FE425E9469696C37580B203DA9,
	PropagationPaths__cctor_m57966E948C5347A24ED5C5519616C5AD16F581CE,
	IMGUIEvent_GetPooled_mEDF82C9920099781130374688D3214AB82243221,
	IMGUIEvent_Init_m7F06C2BE4437F382F7F312D97F40D93711CF0EDB,
	IMGUIEvent_LocalInit_m3BE54E2CC99AAA8730109530B91520283A227771,
	IMGUIEvent__ctor_m74EBDD247E2CF4C4CB4B32D9E52E9BB2163DDD12,
	EventDebuggerLogCall__ctor_m3BECE7E172820A4CC8A888A5C5DF3B394C7A6104,
	EventDebuggerLogCall_Dispose_mAC918B4414348292EEE5A48FE003F04283A440BD,
	EventDebuggerLogIMGUICall__ctor_mEDDEAE9B6D3B7BED69E9C9E0C826B06FA72ABB39,
	EventDebuggerLogIMGUICall_Dispose_mD514BF548D060B95497BA8213F2838CA95511FF4,
	EventDebuggerLogExecuteDefaultAction__ctor_mA0B9522A991D035CA8CD2C1447D00F94BA96CFC6,
	EventDebuggerLogExecuteDefaultAction_Dispose_m97C7090D369A879F861860F54D4ED40CDD10D7CE,
	EventDebugger_LogPropagationPaths_m7C0BCDC9E0A7105852D0E7A668D0E72D91BB32EB,
	NULL,
	NULL,
	Vertex__cctor_m1655B6F0C62DD2784C09D744D722C112D582FA9C,
	TextureId__ctor_mF92FD82CFE633466686BE9710BD59CEB9F2F3B93,
	TextureId_Equals_mFD55BECFABBE801D3CC7CFF6C1AA941EF6CAA483,
	TextureId_GetHashCode_mD4EE49739E0E55AAECB0EEFCDF9561B373804A56,
	TextureId_op_Equality_m98F8D53632A90B3E8A8A247E912291C28F0D2F7B,
	TextureId__cctor_mB6DA7E590DCFE3AA55F3F4F5FC07E10BBF5EB389,
	TextureRegistry__ctor_mFD9CB28A5D434AB63FE2192627FD953636B420D6,
	TextureRegistry__cctor_mCBFF01DB650A23BBBB708467D46E47A1CA78C235,
	UIRUtility_Multiply2D_mD7CD488D76ABAB2370FF8AD6D39FA171B2347394,
	UIRUtility__cctor_mA19F8A55F66D1EDBA529DF9F1F3352FAEADC9FD4,
	Background_get_texture_mA63F83DD089DAD7929403E51739C5851550F02A6,
	Background_get_sprite_m25D7D08C5517DD90FF6AD34E113488EC558820CF,
	Background_get_renderTexture_mC8CA118E08F1C3821E1AA862C43AAF0DD67E15CF,
	Background_get_vectorImage_mBDE387DC6522B639F188559BA8BC158AB76FE01F,
	Background_op_Equality_m53EED27810C4ACE95F19C04CE1BB4E444D16321E,
	Background_Equals_m7C6B2AEAFEBA2A1E80E03DCDB8475DDC72C36122,
	Background_Equals_mBA1B1A4595B4840EBC8F31810EC7DF1A2A836079,
	Background_GetHashCode_mBD232D956BBEF57CE19D8AFFB512C391D2CF6F85,
	Background_ToString_m34898FF6F35AF997BFFECD0EEE53C8865D6D826D,
	ComputedStyle_get_display_mE329A987B8999CC3B23A1542A5CED1264E65EECB,
	ComputedStyle_get_overflow_m2B7BBA66004120AD1BBAC02841CA11671FCFD932,
	ComputedStyle_get_visibility_m154FC53F0CEF43613FDBCF20043288C6751BEC7E,
	InlineStyleAccess__cctor_mA78F8DFD7786897E67F601F29539683D0D289334,
	Length_get_value_mA4FA93BC4DCDECC2F7924CC670F1F5D8254FEA58,
	Length_op_Equality_m0557C187458BA989288104CB71E70A48760BF10F,
	Length_Equals_m0A3FD834E46EF5705BE84290C1599F9911086D14,
	Length_Equals_m6B542AF4AC1749DCB3043688D7E1F019C0982878,
	Length_GetHashCode_mB085D75326582AF604E67471FC0CDC541ED901FE,
	Length_ToString_mDBBF6F21874192E6616439E65660A912213E6403,
	StyleCursor_get_value_mCDB0484E3DE7CA4E81906DB4E044078018E04025,
	StyleCursor_get_keyword_m27F124F0043C04D8F2FCE291BB3694AF7050350C,
	StyleCursor_op_Equality_mD0DE94E2D8236A07145A0F094242269C0295E976,
	StyleCursor_Equals_m297545CF5CA9A0A8E93A6C20ED549C64C12B9D07,
	StyleCursor_Equals_m998BF8547E4DE87B804AE9EF0CFC68A6F2395D0C,
	StyleCursor_GetHashCode_mFE166026315A0B2F9A5E4BD1E8DF1850B0670516,
	StyleCursor_ToString_mB2BC0AD1C83182CF232257FCA2DAC90654CD6420,
	StyleTextShadow_get_value_m59F40FAC3AF65BF3C3D4A6264FB77A16034B3B30,
	StyleTextShadow_get_keyword_m078DD449662B63C2CAC154FA619AAF818306D625,
	StyleTextShadow_op_Equality_m067CD4AB9F967C71E1E6C52A511E52DC8362DABE,
	StyleTextShadow_Equals_m43B1662CE1E1D635B6463C3AF9C2346FD80A0ECE,
	StyleTextShadow_Equals_m655B1C34E98BBDE996BF056620B77836EACC2747,
	StyleTextShadow_GetHashCode_mE50EE505A874E19D1A51DDF5E1427C590BB288CE,
	StyleTextShadow_ToString_mC67AE6434EA0C4C5FBA8E528DDA547404396491E,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	InheritedData_op_Equality_m5DC984B2DFB780C53A9B8F0ECBECC81E51A18861,
	InheritedData_Equals_mFEF649CA9E856BE9B039C5539226490A9549FAC4,
	InheritedData_Equals_m5F46861C98C2FADF8983C2C31FE08A76CE8B2C69,
	InheritedData_GetHashCode_mE4AECCEF2E7FF6250B76E05761A10401D1E439C9,
	NonInheritedData_op_Equality_mF596F87B3E941AA2F0CD2EB6C511CA31B3BCA2C3,
	NonInheritedData_Equals_m39B2CDB94DFD4DECE0E3C77747722AB6C6F1097A,
	NonInheritedData_Equals_m158B81483FB00F11CB97F118431287F8D8A2A98A,
	NonInheritedData_GetHashCode_mD2FEDB6E3046B69DFE32E2496E716EFD6CAD07B6,
	StyleComplexSelector_set_rule_mE8DE1FA572559977BE9857645C171A5D1883DEAC,
	StyleComplexSelector_get_selectors_m04AE9E0724CE27B029EF8F4D2FAA97F1FF15CDC2,
	StyleComplexSelector_CachePseudoStateMasks_mBE29909B530D3DF9024535A9B0445A33C2ABFA25,
	StyleComplexSelector_ToString_m9A3DC5E013326576FC23D50B781A8056EE9BDFDA,
	StyleComplexSelector__ctor_m291768F0C11ECB4392ECAF00B8F3E8CAB72F968C,
	PseudoStateData__ctor_mD77BDDC6D0ECE8A1EBE71B116F2D77A8B1735876,
	U3CU3Ec__cctor_m3E4D9A585BF6478839DCDAFB26225AA314E198BF,
	U3CU3Ec__ctor_m0C0A65A8A998FF3B107D77FD576798686BC2E742,
	U3CU3Ec_U3CToStringU3Eb__20_0_mD190016F2D8D3D1431648CF3782646C9103512E6,
	StyleProperty_get_name_m7091CAF496080C6CD9502BA215473D826FDE38FB,
	StyleProperty_get_values_m8D4D186536D66DE457CEEC0A57B184ED7B320B04,
	StyleProperty__ctor_m04F7DA0EC0390D24075A0C8F42BCE52143670AAE,
	StyleRule_get_properties_m360C5AB98331E30BC76BFD3FED9E10B88D9DE1A3,
	StyleRule__ctor_m5D61507BC4C51F99765AF4BE406BD071D26C605B,
	StyleSelector_get_parts_mAD4EAC10E3A8D83643C622B45D154B97A54CAC2F,
	StyleSelector_ToString_mF8502C0B445607E9CC8996184D6043A47B051F93,
	StyleSelector__ctor_m657CF5A16B757124A0E0D442F6126B1C0B0BE97C,
	U3CU3Ec__cctor_mF5D0AF27E000B2D5D193DFAA84C1137A6016B988,
	U3CU3Ec__ctor_m6CE4E8C6C16C95AB51FF4395D182E95F8162C6F8,
	U3CU3Ec_U3CToStringU3Eb__10_0_m55DE96EEBD33909F083884838E20B7F52DE173EF,
	StyleSelectorPart_get_value_mC5880776B847BF72D168AE26CC614FB0CAE096CF,
	StyleSelectorPart_get_type_mFF8CF0B054E6E86BCC9E3C9364DFEF10413CE778,
	StyleSelectorPart_ToString_m2AB93F36C675B33468B38DF6635A15C384569BB5,
	StyleSheet_get_rules_mA38EE7699F5134ED6D72988E0621B266655671F3,
	StyleSheet_set_rules_m7982BAEC18F14E5487AC4E448DD633E9089D2388,
	StyleSheet_get_complexSelectors_mF3F471AF0DBC1A865BAA5F25117493AACB8F9BD1,
	StyleSheet_set_complexSelectors_mBEBA02FBD093594F7E451D685D4622BC3156B496,
	StyleSheet_get_flattenedRecursiveImports_m52062BE875B643D729FCDBC32F223716C2051E80,
	StyleSheet_get_contentHash_mABF3123BD0B38CE123466ADBA1E0FE6B413CA88F,
	StyleSheet_set_contentHash_m973A7761712F5913141B56507B0D4C8D8E022925,
	NULL,
	NULL,
	StyleSheet_OnEnable_mD8437C4BCC06EEA50ECDC0C26ED71D82EE355324,
	StyleSheet_FlattenImportedStyleSheetsRecursive_m180C294BB2C1FAF4EAF122529CD4958EA1491B40,
	StyleSheet_FlattenImportedStyleSheetsRecursive_mD2D021D9B7402BE4B3AAB9950A9C58006CA2C63C,
	StyleSheet_SetupReferences_mADC28D5FFF0040B43F97EF0B79FF325A061FA88B,
	StyleSheet_ReadKeyword_mD9F5EB148E9E72B5BAD8F9C6C3447CD4C08E3EA4,
	StyleSheet_ReadFloat_m0E478A2862A7B9C88C25BA5BB5685CA603DC082F,
	StyleSheet_TryReadFloat_mBA445A1F15F4957A7C1282A079EA1E426DA886AB,
	StyleSheet_ReadDimension_mEAD5425B4B58B305CA63A1150DB6725790B14B53,
	StyleSheet_TryReadDimension_m0522518E13718FEB56FD2C430E2D293C296D7128,
	StyleSheet_ReadColor_m2717A9FC48D9EDE4D3B812DF4B4020208377AF48,
	StyleSheet_TryReadColor_m0F53AAC2E5DDE43664A18BF878193F69EF47E6FB,
	StyleSheet_ReadString_m6394085BD1461792D1595F63698C97C048563C1A,
	StyleSheet_TryReadString_mC5BBEA9D0C86A277D400D4426BCE8E0645404C4E,
	StyleSheet_ReadEnum_m3535D16E7702A3B25361ED5704E55DB7E2274B66,
	StyleSheet_TryReadEnum_mA97B26BA7F2E839EF476AB3DB60254E79AB66D8E,
	StyleSheet_ReadVariable_mE0EE06FC3FD544D26A0700C0AFD86A8F80EC209C,
	StyleSheet_TryReadVariable_m555D60F34A91463BD84CC899FA6BC0E4125F5432,
	StyleSheet_ReadResourcePath_m69CA2A4FD5249865892F8790EF31A4756005DAE7,
	StyleSheet_TryReadResourcePath_m7FBD81E064DBF740C4C578DB8821DD90FAA22E0A,
	StyleSheet_ReadAssetReference_m86EA09C5837BAB83BB17219865593DFD30AC022D,
	StyleSheet_ReadMissingAssetReferenceUrl_m997E2F7776AC68D6AD7672FA971FB93BFBA726F3,
	StyleSheet_TryReadAssetReference_mA8DC14EF5C4664F54B27C8F0B1E86A8BA55FD3FE,
	StyleSheet_ReadFunction_m92D814776478D42ADDF0F7622C992D2802F4E46E,
	StyleSheet_ReadFunctionName_m619B3F158232C7D12D7E99FD5BF142981ACBF06E,
	StyleSheet_ReadScalableImage_m7123BD46952D239C68054CBFAD88B2AA7556262C,
	StyleSheet_CustomStartsWith_m9AD3CD4F440040E1C96CBDE3D86A5EA33BD3E0F8,
	StyleSheet__ctor_m1992F2C24446A5EBC7C1704D94407F2839F95958,
	StyleSheet__cctor_m4576DD0F7DB03B9466279BD2ABD988E5E865E05F,
	StyleValueFunctionExtension_ToUssString_mA91506CA02796317BD8999E4407F5ECF8A88F7C3,
	StyleValueHandle_get_valueType_m1558B95DF39F3A05AEF5DC6BEFE4E059875224C2,
	StyleVariable_GetHashCode_m2F5FA0FB885DCAE3B7CA807A6E604BA0082CF3E5,
	StyleVariableContext__ctor_m032BC520EE67A00219262BB037D18C964BE2DD8E,
	StyleVariableContext__cctor_m328D0C088D9AD9B6F3ACAAAA17136C331AB0807A,
	StyleVariableResolver__ctor_m5C7408A89F629148F3FE4C8BD0C3B7DF5CEE1FE2,
	StyleVariableResolver__cctor_mBE1B7CBA1B4AEE240500E2EE54E54069CE7140DE,
	VectorImage__ctor_m251E60994B3C28AF64A0D342DE6095B38B0B40E2,
	Shaders__cctor_m8E159AD77943C545775EB48C599A242C0EA25B0B,
	BMPAlloc_ToString_m16DC97FAA0713B099B2CA7699BC21E782FDC7678,
	BMPAlloc__cctor_m43F3C18ECA6CA3CED775D6ED7A20ED203D986C33,
	RenderChainCommand__cctor_mD13194072A3D48F644FD0832DD1FAE126142CF4D,
	Dimension__ctor_m13BD618D7718C8FE3C95E7BA5EF17222C1FBCF78,
	Dimension_op_Equality_mB07D273DBBD886ADCE15D1C8C4F147B1CD2A57BC,
	Dimension_Equals_mE6B999E10285F2200D0E522350147B6BB3DB17DB,
	Dimension_Equals_m5F96DD2B749ADFEA0121C356EA9F10ECAA00209E,
	Dimension_GetHashCode_mE16AB0959628076394D1C36B9CD6296CFFBF7514,
	Dimension_ToString_m21AFB1E0F1309E0C34EBCA99CCA5EEA8BC1FDD23,
	ScalableImage_ToString_m3FD9CFD4108EFD369F9E76BEE26A87F20E884B38,
	StylePropertyReader__ctor_m557B18FA6CD452BBF33C8FB7304CBECF469BDFF1,
	StylePropertyReader__cctor_m1DDED9762262E229985292A153B2D65771D38E34,
	GetCursorIdFunction__ctor_m4E90BE7B24D363FD8A7F9D66298A122D0C35E203,
	GetCursorIdFunction_Invoke_mFAD030F3307AC20F421738B63B969D8F5141BAE2,
	StyleSheetExtensions_IsVarFunction_m6F2E26E5B109946B3D51E481F9B983A5CDFC3695,
	StyleValue_Create_m858F005877A63C5B100171A63B70C01AF422CEBE,
	StyleValue_Create_mE54DBC632FE0D61A3E1E78018C4C0C5EBACBF34B,
	StyleValue_Create_mA14F9FC0902434EEC9E01E82A47BB257882D873F,
	StyleValue_Create_mABCE314A6CFA9F91DC1DAC5AF038222FAC9E8E07,
	StyleValue_Create_m6865DDB84313E47D25CD3BD61EDC5FC3FE73095A,
	BaseStyleMatcher__ctor_m53402D706292CBDBB1F127DCAF3DCA487A33F95E,
	StylePropertyValueMatcher__ctor_m6F1BE9953157356D061F9D2EFD2BABEFF156A1A5,
	StyleSyntaxParser__ctor_mA217E8B0D5642F7A944AEDBCB0A4C04758776A73,
};
extern void Cursor_get_texture_mB0B9D7B2D91E1035B27E05742D5CFAFC6E35D7B0_AdjustorThunk (void);
extern void Cursor_get_hotspot_m64A89A4010D9037EE97CE02AF70C80B7CCA8DE84_AdjustorThunk (void);
extern void Cursor_get_defaultCursorId_m78BEDF5FAB1CF3E17784CAC1F1A62622B8B32F54_AdjustorThunk (void);
extern void Cursor_Equals_m97AA23240C606F7A0FCB6DAE1AFF7A46879AA6D6_AdjustorThunk (void);
extern void Cursor_Equals_mA3A02D884C1AE5C4FE6EE98EFE4A1AA83F4EBB21_AdjustorThunk (void);
extern void Cursor_GetHashCode_m7B79CE5374C05CACBAB2E07C1652F6AD590212ED_AdjustorThunk (void);
extern void Cursor_ToString_mD424F81BE23CCE5136FC4960563778689B151833_AdjustorThunk (void);
extern void EventDispatcherGate__ctor_mD718DC5ECF3A6990B671179A426E65F90CC3A319_AdjustorThunk (void);
extern void EventDispatcherGate_Dispose_mA0793129F4766892329859A6E302937105667152_AdjustorThunk (void);
extern void EventDispatcherGate_Equals_mFDAEDA595E240127DC97FFE152FDB462464688C4_AdjustorThunk (void);
extern void EventDispatcherGate_Equals_mB0458E71B92D036951E926355B979A38DEBCEAC6_AdjustorThunk (void);
extern void EventDispatcherGate_GetHashCode_mA36AC6A55B840FA03FECCF56E3E5D66E4D3D4148_AdjustorThunk (void);
extern void TextShadow_Equals_m9F22E055311CEF3A21E4AB2B3BF66D67F61C7918_AdjustorThunk (void);
extern void TextShadow_Equals_m293B417AFF54CEAF53B45AB850ABF8659F828165_AdjustorThunk (void);
extern void TextShadow_GetHashCode_m12B9A1BF70F328130924AAA64C5405233FFD8050_AdjustorThunk (void);
extern void TextShadow_ToString_mB02E43753C499E391F39F01C20084E8AA251BE7B_AdjustorThunk (void);
extern void Hierarchy_get_parent_m95543CF2F0974BC89228441F8789764F6F10F502_AdjustorThunk (void);
extern void Hierarchy_get_childCount_m53DC6BD1E3F83390D53D5DF31EEBB68EA533DE56_AdjustorThunk (void);
extern void Hierarchy_get_Item_mC13B7FAA90B9AB3295560406C5223DB80046D6FA_AdjustorThunk (void);
extern void Hierarchy_Equals_mD61D088EAA5FF9E5EB5FC51C8443890382D342F0_AdjustorThunk (void);
extern void Hierarchy_Equals_m4E001F4C66AF4D844E883AAE5BF761684695116D_AdjustorThunk (void);
extern void Hierarchy_GetHashCode_m07B0319B25E28C4473DD6F864553DDCC17EBD515_AdjustorThunk (void);
extern void EventDebuggerLogCall__ctor_m3BECE7E172820A4CC8A888A5C5DF3B394C7A6104_AdjustorThunk (void);
extern void EventDebuggerLogCall_Dispose_mAC918B4414348292EEE5A48FE003F04283A440BD_AdjustorThunk (void);
extern void EventDebuggerLogIMGUICall__ctor_mEDDEAE9B6D3B7BED69E9C9E0C826B06FA72ABB39_AdjustorThunk (void);
extern void EventDebuggerLogIMGUICall_Dispose_mD514BF548D060B95497BA8213F2838CA95511FF4_AdjustorThunk (void);
extern void EventDebuggerLogExecuteDefaultAction__ctor_mA0B9522A991D035CA8CD2C1447D00F94BA96CFC6_AdjustorThunk (void);
extern void EventDebuggerLogExecuteDefaultAction_Dispose_m97C7090D369A879F861860F54D4ED40CDD10D7CE_AdjustorThunk (void);
extern void TextureId__ctor_mF92FD82CFE633466686BE9710BD59CEB9F2F3B93_AdjustorThunk (void);
extern void TextureId_Equals_mFD55BECFABBE801D3CC7CFF6C1AA941EF6CAA483_AdjustorThunk (void);
extern void TextureId_GetHashCode_mD4EE49739E0E55AAECB0EEFCDF9561B373804A56_AdjustorThunk (void);
extern void Background_get_texture_mA63F83DD089DAD7929403E51739C5851550F02A6_AdjustorThunk (void);
extern void Background_get_sprite_m25D7D08C5517DD90FF6AD34E113488EC558820CF_AdjustorThunk (void);
extern void Background_get_renderTexture_mC8CA118E08F1C3821E1AA862C43AAF0DD67E15CF_AdjustorThunk (void);
extern void Background_get_vectorImage_mBDE387DC6522B639F188559BA8BC158AB76FE01F_AdjustorThunk (void);
extern void Background_Equals_m7C6B2AEAFEBA2A1E80E03DCDB8475DDC72C36122_AdjustorThunk (void);
extern void Background_Equals_mBA1B1A4595B4840EBC8F31810EC7DF1A2A836079_AdjustorThunk (void);
extern void Background_GetHashCode_mBD232D956BBEF57CE19D8AFFB512C391D2CF6F85_AdjustorThunk (void);
extern void Background_ToString_m34898FF6F35AF997BFFECD0EEE53C8865D6D826D_AdjustorThunk (void);
extern void Length_get_value_mA4FA93BC4DCDECC2F7924CC670F1F5D8254FEA58_AdjustorThunk (void);
extern void Length_Equals_m0A3FD834E46EF5705BE84290C1599F9911086D14_AdjustorThunk (void);
extern void Length_Equals_m6B542AF4AC1749DCB3043688D7E1F019C0982878_AdjustorThunk (void);
extern void Length_GetHashCode_mB085D75326582AF604E67471FC0CDC541ED901FE_AdjustorThunk (void);
extern void Length_ToString_mDBBF6F21874192E6616439E65660A912213E6403_AdjustorThunk (void);
extern void StyleCursor_get_value_mCDB0484E3DE7CA4E81906DB4E044078018E04025_AdjustorThunk (void);
extern void StyleCursor_get_keyword_m27F124F0043C04D8F2FCE291BB3694AF7050350C_AdjustorThunk (void);
extern void StyleCursor_Equals_m297545CF5CA9A0A8E93A6C20ED549C64C12B9D07_AdjustorThunk (void);
extern void StyleCursor_Equals_m998BF8547E4DE87B804AE9EF0CFC68A6F2395D0C_AdjustorThunk (void);
extern void StyleCursor_GetHashCode_mFE166026315A0B2F9A5E4BD1E8DF1850B0670516_AdjustorThunk (void);
extern void StyleCursor_ToString_mB2BC0AD1C83182CF232257FCA2DAC90654CD6420_AdjustorThunk (void);
extern void StyleTextShadow_get_value_m59F40FAC3AF65BF3C3D4A6264FB77A16034B3B30_AdjustorThunk (void);
extern void StyleTextShadow_get_keyword_m078DD449662B63C2CAC154FA619AAF818306D625_AdjustorThunk (void);
extern void StyleTextShadow_Equals_m43B1662CE1E1D635B6463C3AF9C2346FD80A0ECE_AdjustorThunk (void);
extern void StyleTextShadow_Equals_m655B1C34E98BBDE996BF056620B77836EACC2747_AdjustorThunk (void);
extern void StyleTextShadow_GetHashCode_mE50EE505A874E19D1A51DDF5E1427C590BB288CE_AdjustorThunk (void);
extern void StyleTextShadow_ToString_mC67AE6434EA0C4C5FBA8E528DDA547404396491E_AdjustorThunk (void);
extern void InheritedData_Equals_mFEF649CA9E856BE9B039C5539226490A9549FAC4_AdjustorThunk (void);
extern void InheritedData_Equals_m5F46861C98C2FADF8983C2C31FE08A76CE8B2C69_AdjustorThunk (void);
extern void InheritedData_GetHashCode_mE4AECCEF2E7FF6250B76E05761A10401D1E439C9_AdjustorThunk (void);
extern void NonInheritedData_Equals_m39B2CDB94DFD4DECE0E3C77747722AB6C6F1097A_AdjustorThunk (void);
extern void NonInheritedData_Equals_m158B81483FB00F11CB97F118431287F8D8A2A98A_AdjustorThunk (void);
extern void NonInheritedData_GetHashCode_mD2FEDB6E3046B69DFE32E2496E716EFD6CAD07B6_AdjustorThunk (void);
extern void PseudoStateData__ctor_mD77BDDC6D0ECE8A1EBE71B116F2D77A8B1735876_AdjustorThunk (void);
extern void StyleSelectorPart_get_value_mC5880776B847BF72D168AE26CC614FB0CAE096CF_AdjustorThunk (void);
extern void StyleSelectorPart_get_type_mFF8CF0B054E6E86BCC9E3C9364DFEF10413CE778_AdjustorThunk (void);
extern void StyleSelectorPart_ToString_m2AB93F36C675B33468B38DF6635A15C384569BB5_AdjustorThunk (void);
extern void StyleValueHandle_get_valueType_m1558B95DF39F3A05AEF5DC6BEFE4E059875224C2_AdjustorThunk (void);
extern void StyleVariable_GetHashCode_m2F5FA0FB885DCAE3B7CA807A6E604BA0082CF3E5_AdjustorThunk (void);
extern void BMPAlloc_ToString_m16DC97FAA0713B099B2CA7699BC21E782FDC7678_AdjustorThunk (void);
extern void Dimension__ctor_m13BD618D7718C8FE3C95E7BA5EF17222C1FBCF78_AdjustorThunk (void);
extern void Dimension_Equals_mE6B999E10285F2200D0E522350147B6BB3DB17DB_AdjustorThunk (void);
extern void Dimension_Equals_m5F96DD2B749ADFEA0121C356EA9F10ECAA00209E_AdjustorThunk (void);
extern void Dimension_GetHashCode_mE16AB0959628076394D1C36B9CD6296CFFBF7514_AdjustorThunk (void);
extern void Dimension_ToString_m21AFB1E0F1309E0C34EBCA99CCA5EEA8BC1FDD23_AdjustorThunk (void);
extern void ScalableImage_ToString_m3FD9CFD4108EFD369F9E76BEE26A87F20E884B38_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[75] = 
{
	{ 0x0600000A, Cursor_get_texture_mB0B9D7B2D91E1035B27E05742D5CFAFC6E35D7B0_AdjustorThunk },
	{ 0x0600000B, Cursor_get_hotspot_m64A89A4010D9037EE97CE02AF70C80B7CCA8DE84_AdjustorThunk },
	{ 0x0600000C, Cursor_get_defaultCursorId_m78BEDF5FAB1CF3E17784CAC1F1A62622B8B32F54_AdjustorThunk },
	{ 0x0600000D, Cursor_Equals_m97AA23240C606F7A0FCB6DAE1AFF7A46879AA6D6_AdjustorThunk },
	{ 0x0600000E, Cursor_Equals_mA3A02D884C1AE5C4FE6EE98EFE4A1AA83F4EBB21_AdjustorThunk },
	{ 0x0600000F, Cursor_GetHashCode_m7B79CE5374C05CACBAB2E07C1652F6AD590212ED_AdjustorThunk },
	{ 0x06000011, Cursor_ToString_mD424F81BE23CCE5136FC4960563778689B151833_AdjustorThunk },
	{ 0x06000012, EventDispatcherGate__ctor_mD718DC5ECF3A6990B671179A426E65F90CC3A319_AdjustorThunk },
	{ 0x06000013, EventDispatcherGate_Dispose_mA0793129F4766892329859A6E302937105667152_AdjustorThunk },
	{ 0x06000014, EventDispatcherGate_Equals_mFDAEDA595E240127DC97FFE152FDB462464688C4_AdjustorThunk },
	{ 0x06000015, EventDispatcherGate_Equals_mB0458E71B92D036951E926355B979A38DEBCEAC6_AdjustorThunk },
	{ 0x06000016, EventDispatcherGate_GetHashCode_mA36AC6A55B840FA03FECCF56E3E5D66E4D3D4148_AdjustorThunk },
	{ 0x060000E2, TextShadow_Equals_m9F22E055311CEF3A21E4AB2B3BF66D67F61C7918_AdjustorThunk },
	{ 0x060000E3, TextShadow_Equals_m293B417AFF54CEAF53B45AB850ABF8659F828165_AdjustorThunk },
	{ 0x060000E4, TextShadow_GetHashCode_m12B9A1BF70F328130924AAA64C5405233FFD8050_AdjustorThunk },
	{ 0x060000E6, TextShadow_ToString_mB02E43753C499E391F39F01C20084E8AA251BE7B_AdjustorThunk },
	{ 0x06000159, Hierarchy_get_parent_m95543CF2F0974BC89228441F8789764F6F10F502_AdjustorThunk },
	{ 0x0600015A, Hierarchy_get_childCount_m53DC6BD1E3F83390D53D5DF31EEBB68EA533DE56_AdjustorThunk },
	{ 0x0600015B, Hierarchy_get_Item_mC13B7FAA90B9AB3295560406C5223DB80046D6FA_AdjustorThunk },
	{ 0x0600015C, Hierarchy_Equals_mD61D088EAA5FF9E5EB5FC51C8443890382D342F0_AdjustorThunk },
	{ 0x0600015D, Hierarchy_Equals_m4E001F4C66AF4D844E883AAE5BF761684695116D_AdjustorThunk },
	{ 0x0600015E, Hierarchy_GetHashCode_m07B0319B25E28C4473DD6F864553DDCC17EBD515_AdjustorThunk },
	{ 0x06000347, EventDebuggerLogCall__ctor_m3BECE7E172820A4CC8A888A5C5DF3B394C7A6104_AdjustorThunk },
	{ 0x06000348, EventDebuggerLogCall_Dispose_mAC918B4414348292EEE5A48FE003F04283A440BD_AdjustorThunk },
	{ 0x06000349, EventDebuggerLogIMGUICall__ctor_mEDDEAE9B6D3B7BED69E9C9E0C826B06FA72ABB39_AdjustorThunk },
	{ 0x0600034A, EventDebuggerLogIMGUICall_Dispose_mD514BF548D060B95497BA8213F2838CA95511FF4_AdjustorThunk },
	{ 0x0600034B, EventDebuggerLogExecuteDefaultAction__ctor_mA0B9522A991D035CA8CD2C1447D00F94BA96CFC6_AdjustorThunk },
	{ 0x0600034C, EventDebuggerLogExecuteDefaultAction_Dispose_m97C7090D369A879F861860F54D4ED40CDD10D7CE_AdjustorThunk },
	{ 0x06000351, TextureId__ctor_mF92FD82CFE633466686BE9710BD59CEB9F2F3B93_AdjustorThunk },
	{ 0x06000352, TextureId_Equals_mFD55BECFABBE801D3CC7CFF6C1AA941EF6CAA483_AdjustorThunk },
	{ 0x06000353, TextureId_GetHashCode_mD4EE49739E0E55AAECB0EEFCDF9561B373804A56_AdjustorThunk },
	{ 0x0600035A, Background_get_texture_mA63F83DD089DAD7929403E51739C5851550F02A6_AdjustorThunk },
	{ 0x0600035B, Background_get_sprite_m25D7D08C5517DD90FF6AD34E113488EC558820CF_AdjustorThunk },
	{ 0x0600035C, Background_get_renderTexture_mC8CA118E08F1C3821E1AA862C43AAF0DD67E15CF_AdjustorThunk },
	{ 0x0600035D, Background_get_vectorImage_mBDE387DC6522B639F188559BA8BC158AB76FE01F_AdjustorThunk },
	{ 0x0600035F, Background_Equals_m7C6B2AEAFEBA2A1E80E03DCDB8475DDC72C36122_AdjustorThunk },
	{ 0x06000360, Background_Equals_mBA1B1A4595B4840EBC8F31810EC7DF1A2A836079_AdjustorThunk },
	{ 0x06000361, Background_GetHashCode_mBD232D956BBEF57CE19D8AFFB512C391D2CF6F85_AdjustorThunk },
	{ 0x06000362, Background_ToString_m34898FF6F35AF997BFFECD0EEE53C8865D6D826D_AdjustorThunk },
	{ 0x06000367, Length_get_value_mA4FA93BC4DCDECC2F7924CC670F1F5D8254FEA58_AdjustorThunk },
	{ 0x06000369, Length_Equals_m0A3FD834E46EF5705BE84290C1599F9911086D14_AdjustorThunk },
	{ 0x0600036A, Length_Equals_m6B542AF4AC1749DCB3043688D7E1F019C0982878_AdjustorThunk },
	{ 0x0600036B, Length_GetHashCode_mB085D75326582AF604E67471FC0CDC541ED901FE_AdjustorThunk },
	{ 0x0600036C, Length_ToString_mDBBF6F21874192E6616439E65660A912213E6403_AdjustorThunk },
	{ 0x0600036D, StyleCursor_get_value_mCDB0484E3DE7CA4E81906DB4E044078018E04025_AdjustorThunk },
	{ 0x0600036E, StyleCursor_get_keyword_m27F124F0043C04D8F2FCE291BB3694AF7050350C_AdjustorThunk },
	{ 0x06000370, StyleCursor_Equals_m297545CF5CA9A0A8E93A6C20ED549C64C12B9D07_AdjustorThunk },
	{ 0x06000371, StyleCursor_Equals_m998BF8547E4DE87B804AE9EF0CFC68A6F2395D0C_AdjustorThunk },
	{ 0x06000372, StyleCursor_GetHashCode_mFE166026315A0B2F9A5E4BD1E8DF1850B0670516_AdjustorThunk },
	{ 0x06000373, StyleCursor_ToString_mB2BC0AD1C83182CF232257FCA2DAC90654CD6420_AdjustorThunk },
	{ 0x06000374, StyleTextShadow_get_value_m59F40FAC3AF65BF3C3D4A6264FB77A16034B3B30_AdjustorThunk },
	{ 0x06000375, StyleTextShadow_get_keyword_m078DD449662B63C2CAC154FA619AAF818306D625_AdjustorThunk },
	{ 0x06000377, StyleTextShadow_Equals_m43B1662CE1E1D635B6463C3AF9C2346FD80A0ECE_AdjustorThunk },
	{ 0x06000378, StyleTextShadow_Equals_m655B1C34E98BBDE996BF056620B77836EACC2747_AdjustorThunk },
	{ 0x06000379, StyleTextShadow_GetHashCode_mE50EE505A874E19D1A51DDF5E1427C590BB288CE_AdjustorThunk },
	{ 0x0600037A, StyleTextShadow_ToString_mC67AE6434EA0C4C5FBA8E528DDA547404396491E_AdjustorThunk },
	{ 0x06000381, InheritedData_Equals_mFEF649CA9E856BE9B039C5539226490A9549FAC4_AdjustorThunk },
	{ 0x06000382, InheritedData_Equals_m5F46861C98C2FADF8983C2C31FE08A76CE8B2C69_AdjustorThunk },
	{ 0x06000383, InheritedData_GetHashCode_mE4AECCEF2E7FF6250B76E05761A10401D1E439C9_AdjustorThunk },
	{ 0x06000385, NonInheritedData_Equals_m39B2CDB94DFD4DECE0E3C77747722AB6C6F1097A_AdjustorThunk },
	{ 0x06000386, NonInheritedData_Equals_m158B81483FB00F11CB97F118431287F8D8A2A98A_AdjustorThunk },
	{ 0x06000387, NonInheritedData_GetHashCode_mD2FEDB6E3046B69DFE32E2496E716EFD6CAD07B6_AdjustorThunk },
	{ 0x0600038D, PseudoStateData__ctor_mD77BDDC6D0ECE8A1EBE71B116F2D77A8B1735876_AdjustorThunk },
	{ 0x0600039C, StyleSelectorPart_get_value_mC5880776B847BF72D168AE26CC614FB0CAE096CF_AdjustorThunk },
	{ 0x0600039D, StyleSelectorPart_get_type_mFF8CF0B054E6E86BCC9E3C9364DFEF10413CE778_AdjustorThunk },
	{ 0x0600039E, StyleSelectorPart_ToString_m2AB93F36C675B33468B38DF6635A15C384569BB5_AdjustorThunk },
	{ 0x060003C5, StyleValueHandle_get_valueType_m1558B95DF39F3A05AEF5DC6BEFE4E059875224C2_AdjustorThunk },
	{ 0x060003C6, StyleVariable_GetHashCode_m2F5FA0FB885DCAE3B7CA807A6E604BA0082CF3E5_AdjustorThunk },
	{ 0x060003CD, BMPAlloc_ToString_m16DC97FAA0713B099B2CA7699BC21E782FDC7678_AdjustorThunk },
	{ 0x060003D0, Dimension__ctor_m13BD618D7718C8FE3C95E7BA5EF17222C1FBCF78_AdjustorThunk },
	{ 0x060003D2, Dimension_Equals_mE6B999E10285F2200D0E522350147B6BB3DB17DB_AdjustorThunk },
	{ 0x060003D3, Dimension_Equals_m5F96DD2B749ADFEA0121C356EA9F10ECAA00209E_AdjustorThunk },
	{ 0x060003D4, Dimension_GetHashCode_mE16AB0959628076394D1C36B9CD6296CFFBF7514_AdjustorThunk },
	{ 0x060003D5, Dimension_ToString_m21AFB1E0F1309E0C34EBCA99CCA5EEA8BC1FDD23_AdjustorThunk },
	{ 0x060003D6, ScalableImage_ToString_m3FD9CFD4108EFD369F9E76BEE26A87F20E884B38_AdjustorThunk },
};
static const int32_t s_InvokerIndices[995] = 
{
	3277,
	3277,
	5053,
	2580,
	2580,
	2580,
	2580,
	5090,
	3277,
	3207,
	3269,
	3188,
	2180,
	2117,
	3188,
	4439,
	3207,
	2580,
	3277,
	2131,
	2180,
	3188,
	3207,
	3235,
	732,
	3277,
	3277,
	3277,
	1409,
	737,
	5090,
	3207,
	3235,
	3188,
	3235,
	3235,
	3277,
	3277,
	3207,
	4861,
	5060,
	5060,
	5060,
	2562,
	4791,
	3277,
	3277,
	1409,
	5090,
	924,
	924,
	3207,
	2180,
	3207,
	3277,
	3277,
	2580,
	735,
	735,
	735,
	488,
	1412,
	737,
	1951,
	3188,
	2562,
	701,
	3207,
	3207,
	3225,
	3207,
	3239,
	3239,
	3188,
	3235,
	5090,
	3277,
	3277,
	63,
	3277,
	630,
	630,
	2180,
	3235,
	2180,
	2180,
	1003,
	626,
	174,
	3225,
	3932,
	3277,
	2602,
	3277,
	4916,
	4980,
	4980,
	5090,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	3202,
	2580,
	1407,
	1404,
	3207,
	3207,
	3188,
	3207,
	3154,
	3207,
	3188,
	3207,
	3207,
	3277,
	2602,
	2580,
	3277,
	3239,
	2606,
	3239,
	3239,
	3235,
	3188,
	1404,
	3207,
	3207,
	3207,
	1404,
	3207,
	3188,
	1959,
	3235,
	2602,
	1945,
	930,
	2580,
	3277,
	3277,
	1407,
	574,
	1407,
	3189,
	1407,
	3207,
	1407,
	3277,
	3207,
	3207,
	3207,
	3207,
	3207,
	3188,
	3207,
	3154,
	3277,
	3277,
	3207,
	5060,
	3188,
	3207,
	3188,
	5054,
	5054,
	4066,
	4066,
	1959,
	3277,
	3277,
	2580,
	1404,
	5090,
	3207,
	2580,
	2580,
	2580,
	3235,
	3188,
	3207,
	2385,
	410,
	2580,
	5090,
	5090,
	3277,
	2385,
	2580,
	4861,
	4484,
	4614,
	4614,
	4382,
	4614,
	4614,
	4614,
	4486,
	4614,
	1945,
	999,
	1404,
	2562,
	1404,
	2562,
	2562,
	2562,
	2180,
	2580,
	2580,
	2563,
	3277,
	3277,
	3277,
	5090,
	5090,
	3277,
	3235,
	3235,
	2580,
	2159,
	2580,
	2180,
	3277,
	2180,
	2230,
	3188,
	4506,
	3207,
	5090,
	4980,
	4980,
	5090,
	5090,
	4980,
	5060,
	4980,
	4980,
	4980,
	5060,
	5090,
	5090,
	3277,
	838,
	3235,
	3235,
	604,
	3235,
	2180,
	3235,
	5090,
	4980,
	5090,
	5090,
	4916,
	4466,
	5090,
	5090,
	5090,
	3277,
	3277,
	3277,
	980,
	3277,
	2180,
	3277,
	3277,
	3235,
	3235,
	3235,
	604,
	3235,
	2180,
	4976,
	4225,
	4620,
	4861,
	4382,
	4916,
	4614,
	5021,
	5090,
	4857,
	4980,
	5090,
	-1,
	-1,
	-1,
	3235,
	3207,
	3235,
	3225,
	3235,
	2602,
	3235,
	2602,
	3225,
	3225,
	3225,
	3277,
	3277,
	3225,
	3225,
	3235,
	2602,
	3235,
	2602,
	3202,
	3127,
	3127,
	3277,
	3277,
	3188,
	3188,
	3207,
	3207,
	2580,
	2562,
	3235,
	3235,
	2240,
	3361,
	3235,
	3235,
	3207,
	3207,
	3207,
	1951,
	1951,
	3271,
	3202,
	2502,
	4581,
	4970,
	4551,
	4551,
	4162,
	3207,
	1951,
	3207,
	3188,
	3188,
	5090,
	3207,
	3188,
	1945,
	2319,
	2180,
	3188,
	4518,
	3207,
	2580,
	2580,
	3277,
	3277,
	3277,
	3277,
	3235,
	-1,
	1409,
	4553,
	5060,
	5060,
	2562,
	5090,
	1951,
	3207,
	3235,
	3277,
	3277,
	3235,
	2602,
	3235,
	2602,
	2580,
	2602,
	3277,
	3277,
	2580,
	2580,
	2562,
	1404,
	1945,
	1945,
	3218,
	3277,
	1404,
	5090,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	3277,
	3277,
	-1,
	-1,
	3277,
	3277,
	2180,
	1409,
	3277,
	-1,
	-1,
	-1,
	-1,
	-1,
	3277,
	3277,
	2180,
	1409,
	3277,
	551,
	1945,
	2383,
	1409,
	1409,
	737,
	2580,
	5054,
	3189,
	3189,
	2563,
	3189,
	2563,
	2563,
	2563,
	3188,
	2562,
	3207,
	2580,
	3188,
	2562,
	3277,
	2580,
	3277,
	2580,
	3235,
	3235,
	3207,
	2580,
	3207,
	2580,
	3207,
	2180,
	3235,
	2602,
	3277,
	3235,
	2602,
	3277,
	3235,
	2602,
	3277,
	3188,
	2562,
	3207,
	2580,
	3235,
	2602,
	3277,
	3235,
	2602,
	3235,
	2602,
	3235,
	2602,
	3235,
	2602,
	3235,
	2602,
	3235,
	2602,
	3207,
	2580,
	3269,
	2636,
	3277,
	3277,
	3277,
	3235,
	2602,
	3277,
	3277,
	5090,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	3188,
	2562,
	2562,
	2580,
	609,
	2180,
	-1,
	-1,
	-1,
	1951,
	2580,
	3277,
	3188,
	2562,
	3188,
	2562,
	3277,
	2580,
	609,
	560,
	609,
	2580,
	2580,
	3188,
	1945,
	3277,
	4861,
	4980,
	3277,
	3207,
	3207,
	609,
	-1,
	-1,
	2580,
	3235,
	3235,
	5090,
	2580,
	2580,
	-1,
	-1,
	2580,
	2580,
	2580,
	3235,
	3235,
	2580,
	2580,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	3277,
	3277,
	3277,
	2580,
	3277,
	3277,
	3277,
	3277,
	2580,
	3277,
	2180,
	1409,
	4980,
	4619,
	4619,
	2180,
	1409,
	3277,
	2180,
	1409,
	3277,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	3277,
	3277,
	2180,
	1409,
	3277,
	2180,
	1409,
	4486,
	4486,
	4486,
	4619,
	4222,
	4916,
	3277,
	3188,
	3269,
	3269,
	3188,
	3188,
	3188,
	3235,
	2602,
	3235,
	2602,
	3207,
	2580,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	4861,
	4861,
	4861,
	3277,
	4861,
	4861,
	4861,
	4861,
	3277,
	4861,
	3277,
	3277,
	2638,
	4861,
	4396,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	2580,
	3277,
	3277,
	3277,
	4861,
	2580,
	3277,
	3277,
	-1,
	3939,
	-1,
	3666,
	-1,
	-1,
	-1,
	4011,
	2562,
	2636,
	4869,
	3277,
	3277,
	2562,
	4787,
	4857,
	3277,
	3277,
	3277,
	3277,
	-1,
	-1,
	-1,
	-1,
	-1,
	3277,
	3277,
	2180,
	1409,
	3277,
	4199,
	4593,
	4593,
	4976,
	4951,
	4787,
	4465,
	5090,
	2180,
	1409,
	4980,
	4619,
	4222,
	3277,
	4857,
	4916,
	5090,
	5090,
	3188,
	3207,
	3235,
	3188,
	3188,
	3271,
	3271,
	3271,
	3239,
	3188,
	3239,
	3239,
	3239,
	3239,
	3239,
	3269,
	3269,
	3188,
	3235,
	2602,
	3235,
	2602,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	3277,
	3277,
	3277,
	2580,
	2602,
	3277,
	3277,
	3277,
	2580,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	2580,
	3277,
	3277,
	3277,
	2580,
	4382,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	4861,
	4382,
	3277,
	5090,
	4861,
	3277,
	3277,
	3277,
	1409,
	3277,
	2580,
	3277,
	2580,
	3277,
	4619,
	-1,
	-1,
	5090,
	2562,
	2180,
	3188,
	4507,
	5090,
	3277,
	5090,
	4632,
	5090,
	3207,
	3207,
	3207,
	3207,
	4433,
	2102,
	2180,
	3188,
	3207,
	3188,
	3188,
	3188,
	5090,
	3239,
	4476,
	2169,
	2180,
	3188,
	3207,
	3142,
	3188,
	4501,
	2213,
	2180,
	3188,
	3207,
	3257,
	3188,
	4502,
	2216,
	2180,
	3188,
	3207,
	-1,
	-1,
	-1,
	3188,
	3188,
	4449,
	2147,
	2180,
	3188,
	4480,
	2179,
	2180,
	3188,
	2580,
	3207,
	3277,
	3207,
	3277,
	1270,
	5090,
	3277,
	1951,
	3207,
	3207,
	3277,
	3207,
	3277,
	3207,
	3207,
	3277,
	5090,
	3277,
	1955,
	3207,
	3188,
	3207,
	3207,
	2580,
	3207,
	2580,
	3207,
	3188,
	2562,
	-1,
	-1,
	3277,
	3277,
	2580,
	3277,
	1788,
	2337,
	1025,
	1598,
	1025,
	1577,
	1025,
	1956,
	1025,
	1956,
	1025,
	1956,
	1025,
	1956,
	1025,
	1956,
	1956,
	1025,
	1788,
	1956,
	2328,
	4486,
	3277,
	5090,
	4857,
	3188,
	3188,
	3277,
	5090,
	3277,
	5090,
	3277,
	5090,
	3207,
	5090,
	5090,
	1437,
	4442,
	2124,
	2180,
	3188,
	3207,
	3207,
	3277,
	5090,
	1407,
	840,
	4921,
	4946,
	4534,
	4535,
	4534,
	4533,
	3277,
	3277,
	3277,
};
static const Il2CppTokenRangePair s_rgctxIndices[20] = 
{
	{ 0x02000019, { 0, 12 } },
	{ 0x02000049, { 12, 6 } },
	{ 0x0200005D, { 18, 8 } },
	{ 0x02000060, { 26, 4 } },
	{ 0x02000065, { 30, 7 } },
	{ 0x0200006D, { 37, 8 } },
	{ 0x02000070, { 45, 4 } },
	{ 0x02000078, { 59, 10 } },
	{ 0x02000083, { 69, 9 } },
	{ 0x0200008B, { 78, 17 } },
	{ 0x02000099, { 111, 4 } },
	{ 0x020000A0, { 115, 6 } },
	{ 0x020000AA, { 121, 30 } },
	{ 0x06000214, { 49, 4 } },
	{ 0x06000215, { 53, 2 } },
	{ 0x0600021C, { 55, 2 } },
	{ 0x0600021D, { 57, 2 } },
	{ 0x060002A7, { 95, 8 } },
	{ 0x060002A9, { 103, 8 } },
	{ 0x0600037D, { 151, 2 } },
};
extern const uint32_t g_rgctx_ObjectPool_1_Get_mD4E00A21AE8656D5BB66F0135D2ACA40514CE5F8;
extern const uint32_t g_rgctx_ObjectPool_1_Size_m12BFADB8F1267D62615D6350B48F1DD011F40D1C;
extern const uint32_t g_rgctx_Stack_1_t32FC4F75F12B50DEB4CB0C989C5CFC124885CFAB;
extern const uint32_t g_rgctx_Stack_1__ctor_mB8CB43CE69ECD22979EC545471A9A852AB5121F4;
extern const uint32_t g_rgctx_ObjectPool_1_set_maxSize_mF82FDF7061BB3D3B51D9CE674AB39E818AF9E53B;
extern const uint32_t g_rgctx_Stack_1_get_Count_m09CC48E7AEF84EF8B3F09095A7F551EE85664045;
extern const uint32_t g_rgctx_Stack_1_Pop_m82811E9D5C3BE6DFC74434A7666E031D3E44C4CD;
extern const uint32_t g_rgctx_Activator_CreateInstance_TisT_t2D6BF933FD559BF61FD1B9EE26AEF996A59CB5A3_mDA47CA764FF76C09A0C5AE7D4F315E61E5D3EB28;
extern const uint32_t g_rgctx_Stack_1_Peek_m7D5D4DA45D2D9FA59AE6E54F026D2FBDCEC15F94;
extern const uint32_t g_rgctx_T_t2D6BF933FD559BF61FD1B9EE26AEF996A59CB5A3;
extern const uint32_t g_rgctx_ObjectPool_1_get_maxSize_mB32B527CAD57766024779047884C530FBB3B33A7;
extern const uint32_t g_rgctx_Stack_1_Push_m4A1ACA9879053EAED7D885B6B4322C54D0B17ED9;
extern const uint32_t g_rgctx_ObjectListPool_1_tB80B484FAB262054B6ACCD0C0529A5D61381C155;
extern const uint32_t g_rgctx_ObjectPool_1_Get_m0A8BF050BF03EB49AD0A44D81215E160FACA422D;
extern const uint32_t g_rgctx_List_1_Clear_m88C39DA729BD5FDD4134119E45B24887754D0ACD;
extern const uint32_t g_rgctx_ObjectPool_1_Release_m80C91B7CDF8C1917CCA75019E6A6BCB8A3F5645E;
extern const uint32_t g_rgctx_ObjectPool_1_t20748A729B50B909BA9D6012FEF0070E8ECE3497;
extern const uint32_t g_rgctx_ObjectPool_1__ctor_m6C66F6D1144EFDBB53A180B41F9B4B642FCDC426;
extern const uint32_t g_rgctx_EventBase_1_Init_mBF5BEC243E45F2AB5940315E299FA6F228562E80;
extern const uint32_t g_rgctx_PointerCaptureEventBase_1_LocalInit_m60EF79E046E27EC87236C548E599508A84010217;
extern const uint32_t g_rgctx_PointerCaptureEventBase_1_set_relatedTarget_m314728B78747BA17AC765AE2C69361D086358B3A;
extern const uint32_t g_rgctx_PointerCaptureEventBase_1_set_pointerId_m4FC0FFC1ED6E88C26075111F54D1426DFA12F03B;
extern const uint32_t g_rgctx_EventBase_1_GetPooled_m8876DF47BBE542D740BED27A3E0E68F078DB2A76;
extern const uint32_t g_rgctx_EventBase_1_t6457E19BB00236C5B23691428FA248E81E4EADC4;
extern const uint32_t g_rgctx_T_t8535C9B0D92B62AE5FF31C5303E0656F852087D4;
extern const uint32_t g_rgctx_EventBase_1__ctor_m213B35C7ABC1499CF9DC9D03670D3C5858180489;
extern const uint32_t g_rgctx_PointerCaptureEventBase_1_Init_mAC97A1A77176ABC7A9D432C5404BE678C0E66182;
extern const uint32_t g_rgctx_PointerCaptureEventBase_1__ctor_m9336BEFC32B8833A7F307BE479A2D21D08662A30;
extern const uint32_t g_rgctx_PointerCaptureEventBase_1_tC41113BA54E5ADA49834D7609A5B2A896E1FD525;
extern const uint32_t g_rgctx_EventBase_1_t203A32F19BDB784E47DB2067E9694DCCA6B67048;
extern const uint32_t g_rgctx_EventBase_1_Init_mAA87E28B405649BC87E4D33D2902FDB8266CFD7E;
extern const uint32_t g_rgctx_CommandEventBase_1_LocalInit_mEB6A120453F0C0DC4D74308C8F374683AD408DBE;
extern const uint32_t g_rgctx_CommandEventBase_1_set_commandName_mB73697DFB67431E5323A76A659D297973236E30E;
extern const uint32_t g_rgctx_EventBase_1_GetPooled_m4B2B2E3D8E67AE908C5DE12ED3B36731B6A9AF77;
extern const uint32_t g_rgctx_EventBase_1_tE7210CB56F034ABE1392BB95A7B3A59FF52799C4;
extern const uint32_t g_rgctx_T_tC260869E8EAD8D265312BBBB6F4DB55551FD58B9;
extern const uint32_t g_rgctx_EventBase_1__ctor_mB4986C42DED8F0648FF2F443F12184553CA1E6F7;
extern const uint32_t g_rgctx_EventBase_1_t85872ED5DF53701F16B88B46493026879F116EF1;
extern const uint32_t g_rgctx_ObjectPool_1_Get_m1CF9D9A5D043382CE5ED2851B91A21772896B2EF;
extern const uint32_t g_rgctx_T_t09E5F6E09D32726BB8D79125BB28A33761915987;
extern const uint32_t g_rgctx_EventBase_1_GetPooled_m172FA3C51CBB7C8390CE9ABE44048B736B7D69D5;
extern const uint32_t g_rgctx_ObjectPool_1_Release_mE69E9C5893FA2BD05A33865C203CD27A12BC348F;
extern const uint32_t g_rgctx_EventBase_1_ReleasePooled_mA896C4A29DDC7D53E1065C9454559C2426F97FAC;
extern const uint32_t g_rgctx_ObjectPool_1_t0790B18D2D27DFAAEC282DDE6F74F3CDECCA76BC;
extern const uint32_t g_rgctx_ObjectPool_1__ctor_m8B9496E7058FAD3D12C14333F96223AF863C423B;
extern const uint32_t g_rgctx_EventBase_1_TypeId_m1D0C75CBA3AB693DE19F1D9CAF3338872290CAF0;
extern const uint32_t g_rgctx_EventBase_1_t313533154E6E93F6497F048DBE96068AEEE1DDAE;
extern const uint32_t g_rgctx_TEventType_t69A3D7836F9E375CCD6A702870A06D30A416E24D;
extern const uint32_t g_rgctx_EventCallback_1_Invoke_m12E79316A72648F3F1CC2545728BD592709E6296;
extern const uint32_t g_rgctx_EventBase_1_TypeId_m7D884F78D7BCB153F60E90BA5F523ED4254E463A;
extern const uint32_t g_rgctx_EventBase_1_t4F915B7905A1D1CC13A34A51D02F049ECD09B3AE;
extern const uint32_t g_rgctx_EventCallbackFunctor_1_tD3305176875D0B4FCD1AC4B05513E1ACD18085B0;
extern const uint32_t g_rgctx_EventCallbackFunctor_1__ctor_m8915D717BD26D12ED0A141A22D969E0131B7F060;
extern const uint32_t g_rgctx_EventBase_1_TypeId_m22CE8C395FD8F12FFBD9595593B89E46CC43A19B;
extern const uint32_t g_rgctx_EventBase_1_t7EFDC33CD2EDECB18CFE2E5FFAD4BEA06F1837A2;
extern const uint32_t g_rgctx_EventCallbackRegistry_RegisterCallback_TisTEventType_t12845C3C6FA1A82B62C32A0120A68EABCCD7F13E_m56DED5E75E3F8CC4CC19658FDCFBB3A71E6054D5;
extern const uint32_t g_rgctx_GlobalCallbackRegistry_RegisterListeners_TisTEventType_t12845C3C6FA1A82B62C32A0120A68EABCCD7F13E_m18C47C6B57D65A409E1A1BEB185F7043770E7342;
extern const uint32_t g_rgctx_EventCallbackRegistry_UnregisterCallback_TisTEventType_t6776ECF676AF68912232CAA1BAD5F8F6F3CBB06E_mFA99B88AB2EC9BDF3CF807AECC80DF81F2E7150C;
extern const uint32_t g_rgctx_GlobalCallbackRegistry_UnregisterListeners_TisTEventType_t6776ECF676AF68912232CAA1BAD5F8F6F3CBB06E_mD2652687849CB7F6F212CDA8983F32CBA14FA4D4;
extern const uint32_t g_rgctx_EventBase_1_Init_mE05F50C2BBF829FFE96DAF96B6D1351BD25E7FFD;
extern const uint32_t g_rgctx_FocusEventBase_1_LocalInit_mE44BD6111C99E66F0ACAA4190D5C3334EF1800B6;
extern const uint32_t g_rgctx_FocusEventBase_1_set_relatedTarget_m3C103A5C96444F2738A347F9E4D28EA6579C1EE3;
extern const uint32_t g_rgctx_FocusEventBase_1_set_direction_m1F9431682A09FE8D572C23570487156C6D3F37BB;
extern const uint32_t g_rgctx_FocusEventBase_1_set_focusController_m09C92BD27013E440F9553B2ABB3AC89462C5819C;
extern const uint32_t g_rgctx_EventBase_1_GetPooled_m6BD04B5CD3079668D1D9ADDE043742FD33598206;
extern const uint32_t g_rgctx_EventBase_1_t65D0F347B15F25E944F4FC22130011596030AACB;
extern const uint32_t g_rgctx_T_t8731638D62ACCC18985B561124986B261F2B14A7;
extern const uint32_t g_rgctx_FocusEventBase_1_set_IsFocusDelegated_mEA0EBA8350E9202B90C08E27009DD34F123CAD54;
extern const uint32_t g_rgctx_EventBase_1__ctor_m0429B388C3F411AE6601338656491BFEC509D280;
extern const uint32_t g_rgctx_EventBase_1_Init_m0466BBAE69ACC788D00BA7317451902EA2E0A9FF;
extern const uint32_t g_rgctx_KeyboardEventBase_1_LocalInit_m97773A56A96EFB936ADB0FA213DDA5813A82FDC7;
extern const uint32_t g_rgctx_KeyboardEventBase_1_set_modifiers_mA592422D2E33E1A80C30D0AD4E5FC364AC694AA7;
extern const uint32_t g_rgctx_KeyboardEventBase_1_set_character_mE9EE3DCECCD8CB8FF6E1D5760EF1FFB69FDAA234;
extern const uint32_t g_rgctx_KeyboardEventBase_1_set_keyCode_mDF7C6FFA13B5113FCF8322DA0255A1BA67CBB148;
extern const uint32_t g_rgctx_EventBase_1_GetPooled_mBD95F532A611CF899CBD7048A5DD98BD6B21B440;
extern const uint32_t g_rgctx_EventBase_1_t3E01DAD1CB84DF75E5FC306C277449C3AB161345;
extern const uint32_t g_rgctx_T_t32FB52120CAD62363EBE21A7262B9C888000E06B;
extern const uint32_t g_rgctx_EventBase_1__ctor_m6D223DEB7B49A115B31668A8C0A7AA551C2F2426;
extern const uint32_t g_rgctx_EventBase_1_Init_mEF8114D08879482FD1F2A36988AFDD14DE7E7B6A;
extern const uint32_t g_rgctx_MouseEventBase_1_LocalInit_mD09561F3A1C610FC8CF040B4BB36AEE014D06892;
extern const uint32_t g_rgctx_MouseEventBase_1_set_modifiers_m19A5F19C1794F5BD340D1AA9176B1B3AEB8C6B73;
extern const uint32_t g_rgctx_MouseEventBase_1_set_mousePosition_m376E6FA766B1DD371FC29FED258CE0456A96245D;
extern const uint32_t g_rgctx_MouseEventBase_1_set_localMousePosition_mCCC30D95DAC3A9506A2D8084035A517829BAA409;
extern const uint32_t g_rgctx_MouseEventBase_1_set_mouseDelta_mEDF5B928E76D2D176EB4E1E2A21C243D3D3840B3;
extern const uint32_t g_rgctx_MouseEventBase_1_set_clickCount_m6CF0C85C8F83EA131BA1B7F926BC98C1852C5E13;
extern const uint32_t g_rgctx_MouseEventBase_1_set_button_mD62899821C3646E062AB447AF65D6A200437F6CF;
extern const uint32_t g_rgctx_MouseEventBase_1_set_pressedButtons_mFD301EBDA6049A30A74D2D1418CABE363F856AE2;
extern const uint32_t g_rgctx_MouseEventBase_1_get_mousePosition_m5DBDF77FB82E222AE861F634BF2117AB81399E23;
extern const uint32_t g_rgctx_EventBase_1_GetPooled_mE2AE12BC4EB4B0E4C462D5376D8F1E30A86DCB56;
extern const uint32_t g_rgctx_EventBase_1_t383AC048500A3B8B6719A5A7ED6748D75E2C5C35;
extern const uint32_t g_rgctx_T_t7CC0367081BFC2D053B9514BBF74F5106DF921F2;
extern const uint32_t g_rgctx_MouseEventBase_1_GetPooled_mDFA5830B2BF8D24BCE7BC897719DED58C74228B2;
extern const uint32_t g_rgctx_MouseEventBase_1_tAA5C57CCE7BC8A74E18A006F699EA3407EB04688;
extern const uint32_t g_rgctx_EventBase_1_GetPooled_m9E5C2A10CA5C011389DA42328C97273514101A29;
extern const uint32_t g_rgctx_EventBase_1__ctor_m6C9C0997A14A9E38C7C2B3BD59C6F7B13F34294B;
extern const uint32_t g_rgctx_MouseEventBase_1_GetPooled_m954DBEC1A3FFF62E222C58A0BCB2E5AC56388D40;
extern const uint32_t g_rgctx_MouseEventBase_1_t5A4C0CADBEE0AC14E9F0D51457D2615AD39238C4;
extern const uint32_t g_rgctx_EventBase_1_tB4C74A3D5EEB5895EC4C4798E328A20E3332A023;
extern const uint32_t g_rgctx_TLeaveEvent_tA4CDC258585075BF48E539CA895B50F0BABBF4FC;
extern const uint32_t g_rgctx_MouseEventBase_1_GetPooled_m063E0D68D221A1EEA4003B6C4DFB095B55715622;
extern const uint32_t g_rgctx_MouseEventBase_1_tDE1D4CB9F7C181FCFAF063F3D60D98E2F42BF5A0;
extern const uint32_t g_rgctx_EventBase_1_tFDBD94C374A5B4775B6243169D6839137334DDBA;
extern const uint32_t g_rgctx_TEnterEvent_t2BCBEFD131DADB567D45A6CBAD319E761A260499;
extern const uint32_t g_rgctx_PointerEventBase_1_GetPooled_mC50F14F3BA552EF1FCABCF9D04B97892A32E15B7;
extern const uint32_t g_rgctx_PointerEventBase_1_t5739835A6614C59A162ACDD96B610550E53AA50F;
extern const uint32_t g_rgctx_EventBase_1_t2A25F9CE14B60566F7E4A9D1228FBFD5E2320FD6;
extern const uint32_t g_rgctx_TLeaveEvent_tA6103640ED01B0FEA3FAFD2A563F6542ED99F8A9;
extern const uint32_t g_rgctx_PointerEventBase_1_GetPooled_m29513C99DB9C03E6F9872EAB27050E3C3473DCE4;
extern const uint32_t g_rgctx_PointerEventBase_1_t8A24BA79335BEC06A42F41B7C16863D4AC651629;
extern const uint32_t g_rgctx_EventBase_1_tE9C645D4667C90B70DDB55C4002BB16E65C363FC;
extern const uint32_t g_rgctx_TEnterEvent_tE1913CA3143B8A95D413A693E6AE513494D0C0A5;
extern const uint32_t g_rgctx_EventBase_1__ctor_mECDAED1F64739008CE0A8EC0CE4D038536225CA7;
extern const uint32_t g_rgctx_EventBase_1_t9FF9C40F0048234A4C9EC811F4DDB0F68581F52D;
extern const uint32_t g_rgctx_NavigationEventBase_1_LocalInit_m4DC0B185D2BC1AC89FE91B9A69D6FE852C60B0C0;
extern const uint32_t g_rgctx_EventBase_1_Init_mCBFE2EA0C2DCAC405B7E7075002DF718AC6C69DC;
extern const uint32_t g_rgctx_EventBase_1_Init_m1738FA9107B9A4ABEB8C33D6741A8021C18B42F9;
extern const uint32_t g_rgctx_PanelChangedEventBase_1_LocalInit_m62D8CA852FC19F6284F75A9E056985B15683BA72;
extern const uint32_t g_rgctx_PanelChangedEventBase_1_set_originPanel_m21ECEB1CDBDE270E3259C2AB89A8DF1C10536123;
extern const uint32_t g_rgctx_PanelChangedEventBase_1_set_destinationPanel_mE287A246A07DA364BBE89877FDDCC2CD2767BB82;
extern const uint32_t g_rgctx_EventBase_1__ctor_m2AC884CCD6876B3E31A7F70F084D27F13A853F4A;
extern const uint32_t g_rgctx_EventBase_1_tFBE98C43A3BA4CA97E1D8B0964B48DB744C48EA8;
extern const uint32_t g_rgctx_EventBase_1_Init_mA90308064FA6E6E528EC727C1BC793804EC03D08;
extern const uint32_t g_rgctx_PointerEventBase_1_LocalInit_mB88A8FCCF38B1B7DB32FA6AABB217C8936240A43;
extern const uint32_t g_rgctx_PointerEventBase_1_set_pointerId_m9446DA8435932AFAEB7046A1F9608667800D912A;
extern const uint32_t g_rgctx_PointerEventBase_1_set_pointerType_m9042376C876511BFCCD4B8050711B230F0EA1AE5;
extern const uint32_t g_rgctx_PointerEventBase_1_set_isPrimary_m0D473E4B4483B922503E780AE919C8B60C0BC2B4;
extern const uint32_t g_rgctx_PointerEventBase_1_set_button_m61E6416D50A7618C108C55FAB374836FEC3CAF69;
extern const uint32_t g_rgctx_PointerEventBase_1_set_pressedButtons_m22A325F8A9A690F13487EA8F92FB61B84C070C4A;
extern const uint32_t g_rgctx_PointerEventBase_1_set_position_m1424C5BF598290CFFC9632950A2C5DB6223D9B08;
extern const uint32_t g_rgctx_PointerEventBase_1_set_localPosition_m1B3380916CA6BDC0C14DCA3A9260805B914B7141;
extern const uint32_t g_rgctx_PointerEventBase_1_set_deltaPosition_mAD72D5DDF75F2BFA9CF9B3B5E0274BCA1F67F4BF;
extern const uint32_t g_rgctx_PointerEventBase_1_set_deltaTime_mD45B37B3212F3248AFA767B350867AC80ABF6EB6;
extern const uint32_t g_rgctx_PointerEventBase_1_set_clickCount_m08B36375D64C3B3F8A80926C3CC1FCA9F332824D;
extern const uint32_t g_rgctx_PointerEventBase_1_set_pressure_mCC106FE01F7239242CB9B24C73E6619D61947CE9;
extern const uint32_t g_rgctx_PointerEventBase_1_set_tangentialPressure_m1E6C3EBD18266FB7AFDD5C0517D8132C938F811F;
extern const uint32_t g_rgctx_PointerEventBase_1_set_altitudeAngle_mEDD08829937ADBF8AB5CFD7630C1208F97182720;
extern const uint32_t g_rgctx_PointerEventBase_1_set_azimuthAngle_m50F155716A0935C0A3F4071CA80A53696F6CFF11;
extern const uint32_t g_rgctx_PointerEventBase_1_set_twist_m3B677B538F45630C3B8C1538C6ECBDCBCF2C582D;
extern const uint32_t g_rgctx_PointerEventBase_1_set_radius_m4516119F79A03EFEC2B0E9FB4B4BA944586301C3;
extern const uint32_t g_rgctx_PointerEventBase_1_set_radiusVariance_mDA5183514D1D80A06CF8451893F2270767854D9F;
extern const uint32_t g_rgctx_PointerEventBase_1_set_modifiers_m468AB8E6FB41CD5DAF0C91EDBAA70879DB5FF60F;
extern const uint32_t g_rgctx_PointerEventBase_1_get_position_mD382CB3E972355E4942D7499CB1AEF1C7D0D4549;
extern const uint32_t g_rgctx_EventBase_1_GetPooled_mF02BB421E71F7F9099C4BBABCBB491795C6E1D47;
extern const uint32_t g_rgctx_EventBase_1_t05AB6780F4F2BF76EE9626A872B703617E6E1648;
extern const uint32_t g_rgctx_PointerEventBase_1_IsMouse_m9032DD03EAD701B5E60C69C618E27B5C2620AE99;
extern const uint32_t g_rgctx_PointerEventBase_1_t4FF68240353CF5853D4480CE8144054642E4C906;
extern const uint32_t g_rgctx_T_tD6694D5E7C00498DE2E9B9AC85E9D6EFD837DC09;
extern const uint32_t g_rgctx_PointerEventBase_1_get_pointerId_mF3068A21A538471192726D090EABCB78E61AD592;
extern const uint32_t g_rgctx_PointerEventBase_1_get_pressedButtons_m6D0658AD097AB41D6F6776BC61CCCD4D5C71699C;
extern const uint32_t g_rgctx_PointerEventBase_1_GetPooled_m9D971E03C3C391C0142C07CC5A8A2E8B646C787C;
extern const uint32_t g_rgctx_EventBase_1__ctor_m7C77873C0450257FBFCBB9EFE5900D32A09F77A2;
extern const uint32_t g_rgctx_IStyleValue_1_t9BEE16A05A95E3307A8BA204B1C0397C67752A21;
extern const uint32_t g_rgctx_T_t32E4508B9A8BEBD334F1E8712DC4E4C9EFD7FA57;
static const Il2CppRGCTXDefinition s_rgctxValues[153] = 
{
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_ObjectPool_1_Get_mD4E00A21AE8656D5BB66F0135D2ACA40514CE5F8 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_ObjectPool_1_Size_m12BFADB8F1267D62615D6350B48F1DD011F40D1C },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_Stack_1_t32FC4F75F12B50DEB4CB0C989C5CFC124885CFAB },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_Stack_1__ctor_mB8CB43CE69ECD22979EC545471A9A852AB5121F4 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_ObjectPool_1_set_maxSize_mF82FDF7061BB3D3B51D9CE674AB39E818AF9E53B },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_Stack_1_get_Count_m09CC48E7AEF84EF8B3F09095A7F551EE85664045 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_Stack_1_Pop_m82811E9D5C3BE6DFC74434A7666E031D3E44C4CD },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_Activator_CreateInstance_TisT_t2D6BF933FD559BF61FD1B9EE26AEF996A59CB5A3_mDA47CA764FF76C09A0C5AE7D4F315E61E5D3EB28 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_Stack_1_Peek_m7D5D4DA45D2D9FA59AE6E54F026D2FBDCEC15F94 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_T_t2D6BF933FD559BF61FD1B9EE26AEF996A59CB5A3 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_ObjectPool_1_get_maxSize_mB32B527CAD57766024779047884C530FBB3B33A7 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_Stack_1_Push_m4A1ACA9879053EAED7D885B6B4322C54D0B17ED9 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_ObjectListPool_1_tB80B484FAB262054B6ACCD0C0529A5D61381C155 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_ObjectPool_1_Get_m0A8BF050BF03EB49AD0A44D81215E160FACA422D },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_List_1_Clear_m88C39DA729BD5FDD4134119E45B24887754D0ACD },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_ObjectPool_1_Release_m80C91B7CDF8C1917CCA75019E6A6BCB8A3F5645E },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_ObjectPool_1_t20748A729B50B909BA9D6012FEF0070E8ECE3497 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_ObjectPool_1__ctor_m6C66F6D1144EFDBB53A180B41F9B4B642FCDC426 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_Init_mBF5BEC243E45F2AB5940315E299FA6F228562E80 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerCaptureEventBase_1_LocalInit_m60EF79E046E27EC87236C548E599508A84010217 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerCaptureEventBase_1_set_relatedTarget_m314728B78747BA17AC765AE2C69361D086358B3A },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerCaptureEventBase_1_set_pointerId_m4FC0FFC1ED6E88C26075111F54D1426DFA12F03B },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_GetPooled_m8876DF47BBE542D740BED27A3E0E68F078DB2A76 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_t6457E19BB00236C5B23691428FA248E81E4EADC4 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_T_t8535C9B0D92B62AE5FF31C5303E0656F852087D4 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1__ctor_m213B35C7ABC1499CF9DC9D03670D3C5858180489 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerCaptureEventBase_1_Init_mAC97A1A77176ABC7A9D432C5404BE678C0E66182 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerCaptureEventBase_1__ctor_m9336BEFC32B8833A7F307BE479A2D21D08662A30 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerCaptureEventBase_1_tC41113BA54E5ADA49834D7609A5B2A896E1FD525 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_t203A32F19BDB784E47DB2067E9694DCCA6B67048 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_Init_mAA87E28B405649BC87E4D33D2902FDB8266CFD7E },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_CommandEventBase_1_LocalInit_mEB6A120453F0C0DC4D74308C8F374683AD408DBE },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_CommandEventBase_1_set_commandName_mB73697DFB67431E5323A76A659D297973236E30E },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_GetPooled_m4B2B2E3D8E67AE908C5DE12ED3B36731B6A9AF77 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_tE7210CB56F034ABE1392BB95A7B3A59FF52799C4 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_T_tC260869E8EAD8D265312BBBB6F4DB55551FD58B9 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1__ctor_mB4986C42DED8F0648FF2F443F12184553CA1E6F7 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_t85872ED5DF53701F16B88B46493026879F116EF1 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_ObjectPool_1_Get_m1CF9D9A5D043382CE5ED2851B91A21772896B2EF },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_T_t09E5F6E09D32726BB8D79125BB28A33761915987 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_GetPooled_m172FA3C51CBB7C8390CE9ABE44048B736B7D69D5 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_ObjectPool_1_Release_mE69E9C5893FA2BD05A33865C203CD27A12BC348F },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_ReleasePooled_mA896C4A29DDC7D53E1065C9454559C2426F97FAC },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_ObjectPool_1_t0790B18D2D27DFAAEC282DDE6F74F3CDECCA76BC },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_ObjectPool_1__ctor_m8B9496E7058FAD3D12C14333F96223AF863C423B },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_TypeId_m1D0C75CBA3AB693DE19F1D9CAF3338872290CAF0 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_t313533154E6E93F6497F048DBE96068AEEE1DDAE },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_TEventType_t69A3D7836F9E375CCD6A702870A06D30A416E24D },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventCallback_1_Invoke_m12E79316A72648F3F1CC2545728BD592709E6296 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_TypeId_m7D884F78D7BCB153F60E90BA5F523ED4254E463A },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_t4F915B7905A1D1CC13A34A51D02F049ECD09B3AE },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventCallbackFunctor_1_tD3305176875D0B4FCD1AC4B05513E1ACD18085B0 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventCallbackFunctor_1__ctor_m8915D717BD26D12ED0A141A22D969E0131B7F060 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_TypeId_m22CE8C395FD8F12FFBD9595593B89E46CC43A19B },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_t7EFDC33CD2EDECB18CFE2E5FFAD4BEA06F1837A2 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventCallbackRegistry_RegisterCallback_TisTEventType_t12845C3C6FA1A82B62C32A0120A68EABCCD7F13E_m56DED5E75E3F8CC4CC19658FDCFBB3A71E6054D5 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_GlobalCallbackRegistry_RegisterListeners_TisTEventType_t12845C3C6FA1A82B62C32A0120A68EABCCD7F13E_m18C47C6B57D65A409E1A1BEB185F7043770E7342 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventCallbackRegistry_UnregisterCallback_TisTEventType_t6776ECF676AF68912232CAA1BAD5F8F6F3CBB06E_mFA99B88AB2EC9BDF3CF807AECC80DF81F2E7150C },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_GlobalCallbackRegistry_UnregisterListeners_TisTEventType_t6776ECF676AF68912232CAA1BAD5F8F6F3CBB06E_mD2652687849CB7F6F212CDA8983F32CBA14FA4D4 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_Init_mE05F50C2BBF829FFE96DAF96B6D1351BD25E7FFD },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_FocusEventBase_1_LocalInit_mE44BD6111C99E66F0ACAA4190D5C3334EF1800B6 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_FocusEventBase_1_set_relatedTarget_m3C103A5C96444F2738A347F9E4D28EA6579C1EE3 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_FocusEventBase_1_set_direction_m1F9431682A09FE8D572C23570487156C6D3F37BB },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_FocusEventBase_1_set_focusController_m09C92BD27013E440F9553B2ABB3AC89462C5819C },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_GetPooled_m6BD04B5CD3079668D1D9ADDE043742FD33598206 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_t65D0F347B15F25E944F4FC22130011596030AACB },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_T_t8731638D62ACCC18985B561124986B261F2B14A7 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_FocusEventBase_1_set_IsFocusDelegated_mEA0EBA8350E9202B90C08E27009DD34F123CAD54 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1__ctor_m0429B388C3F411AE6601338656491BFEC509D280 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_Init_m0466BBAE69ACC788D00BA7317451902EA2E0A9FF },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_KeyboardEventBase_1_LocalInit_m97773A56A96EFB936ADB0FA213DDA5813A82FDC7 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_KeyboardEventBase_1_set_modifiers_mA592422D2E33E1A80C30D0AD4E5FC364AC694AA7 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_KeyboardEventBase_1_set_character_mE9EE3DCECCD8CB8FF6E1D5760EF1FFB69FDAA234 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_KeyboardEventBase_1_set_keyCode_mDF7C6FFA13B5113FCF8322DA0255A1BA67CBB148 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_GetPooled_mBD95F532A611CF899CBD7048A5DD98BD6B21B440 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_t3E01DAD1CB84DF75E5FC306C277449C3AB161345 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_T_t32FB52120CAD62363EBE21A7262B9C888000E06B },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1__ctor_m6D223DEB7B49A115B31668A8C0A7AA551C2F2426 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_Init_mEF8114D08879482FD1F2A36988AFDD14DE7E7B6A },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_MouseEventBase_1_LocalInit_mD09561F3A1C610FC8CF040B4BB36AEE014D06892 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_MouseEventBase_1_set_modifiers_m19A5F19C1794F5BD340D1AA9176B1B3AEB8C6B73 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_MouseEventBase_1_set_mousePosition_m376E6FA766B1DD371FC29FED258CE0456A96245D },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_MouseEventBase_1_set_localMousePosition_mCCC30D95DAC3A9506A2D8084035A517829BAA409 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_MouseEventBase_1_set_mouseDelta_mEDF5B928E76D2D176EB4E1E2A21C243D3D3840B3 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_MouseEventBase_1_set_clickCount_m6CF0C85C8F83EA131BA1B7F926BC98C1852C5E13 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_MouseEventBase_1_set_button_mD62899821C3646E062AB447AF65D6A200437F6CF },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_MouseEventBase_1_set_pressedButtons_mFD301EBDA6049A30A74D2D1418CABE363F856AE2 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_MouseEventBase_1_get_mousePosition_m5DBDF77FB82E222AE861F634BF2117AB81399E23 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_GetPooled_mE2AE12BC4EB4B0E4C462D5376D8F1E30A86DCB56 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_t383AC048500A3B8B6719A5A7ED6748D75E2C5C35 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_T_t7CC0367081BFC2D053B9514BBF74F5106DF921F2 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_MouseEventBase_1_GetPooled_mDFA5830B2BF8D24BCE7BC897719DED58C74228B2 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_MouseEventBase_1_tAA5C57CCE7BC8A74E18A006F699EA3407EB04688 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_GetPooled_m9E5C2A10CA5C011389DA42328C97273514101A29 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1__ctor_m6C9C0997A14A9E38C7C2B3BD59C6F7B13F34294B },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_MouseEventBase_1_GetPooled_m954DBEC1A3FFF62E222C58A0BCB2E5AC56388D40 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_MouseEventBase_1_t5A4C0CADBEE0AC14E9F0D51457D2615AD39238C4 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_tB4C74A3D5EEB5895EC4C4798E328A20E3332A023 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_TLeaveEvent_tA4CDC258585075BF48E539CA895B50F0BABBF4FC },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_MouseEventBase_1_GetPooled_m063E0D68D221A1EEA4003B6C4DFB095B55715622 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_MouseEventBase_1_tDE1D4CB9F7C181FCFAF063F3D60D98E2F42BF5A0 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_tFDBD94C374A5B4775B6243169D6839137334DDBA },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_TEnterEvent_t2BCBEFD131DADB567D45A6CBAD319E761A260499 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_GetPooled_mC50F14F3BA552EF1FCABCF9D04B97892A32E15B7 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_t5739835A6614C59A162ACDD96B610550E53AA50F },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_t2A25F9CE14B60566F7E4A9D1228FBFD5E2320FD6 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_TLeaveEvent_tA6103640ED01B0FEA3FAFD2A563F6542ED99F8A9 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_GetPooled_m29513C99DB9C03E6F9872EAB27050E3C3473DCE4 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_t8A24BA79335BEC06A42F41B7C16863D4AC651629 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_tE9C645D4667C90B70DDB55C4002BB16E65C363FC },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_TEnterEvent_tE1913CA3143B8A95D413A693E6AE513494D0C0A5 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1__ctor_mECDAED1F64739008CE0A8EC0CE4D038536225CA7 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_t9FF9C40F0048234A4C9EC811F4DDB0F68581F52D },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_NavigationEventBase_1_LocalInit_m4DC0B185D2BC1AC89FE91B9A69D6FE852C60B0C0 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_Init_mCBFE2EA0C2DCAC405B7E7075002DF718AC6C69DC },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_Init_m1738FA9107B9A4ABEB8C33D6741A8021C18B42F9 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PanelChangedEventBase_1_LocalInit_m62D8CA852FC19F6284F75A9E056985B15683BA72 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PanelChangedEventBase_1_set_originPanel_m21ECEB1CDBDE270E3259C2AB89A8DF1C10536123 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PanelChangedEventBase_1_set_destinationPanel_mE287A246A07DA364BBE89877FDDCC2CD2767BB82 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1__ctor_m2AC884CCD6876B3E31A7F70F084D27F13A853F4A },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_tFBE98C43A3BA4CA97E1D8B0964B48DB744C48EA8 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_Init_mA90308064FA6E6E528EC727C1BC793804EC03D08 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_LocalInit_mB88A8FCCF38B1B7DB32FA6AABB217C8936240A43 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_set_pointerId_m9446DA8435932AFAEB7046A1F9608667800D912A },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_set_pointerType_m9042376C876511BFCCD4B8050711B230F0EA1AE5 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_set_isPrimary_m0D473E4B4483B922503E780AE919C8B60C0BC2B4 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_set_button_m61E6416D50A7618C108C55FAB374836FEC3CAF69 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_set_pressedButtons_m22A325F8A9A690F13487EA8F92FB61B84C070C4A },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_set_position_m1424C5BF598290CFFC9632950A2C5DB6223D9B08 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_set_localPosition_m1B3380916CA6BDC0C14DCA3A9260805B914B7141 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_set_deltaPosition_mAD72D5DDF75F2BFA9CF9B3B5E0274BCA1F67F4BF },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_set_deltaTime_mD45B37B3212F3248AFA767B350867AC80ABF6EB6 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_set_clickCount_m08B36375D64C3B3F8A80926C3CC1FCA9F332824D },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_set_pressure_mCC106FE01F7239242CB9B24C73E6619D61947CE9 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_set_tangentialPressure_m1E6C3EBD18266FB7AFDD5C0517D8132C938F811F },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_set_altitudeAngle_mEDD08829937ADBF8AB5CFD7630C1208F97182720 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_set_azimuthAngle_m50F155716A0935C0A3F4071CA80A53696F6CFF11 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_set_twist_m3B677B538F45630C3B8C1538C6ECBDCBCF2C582D },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_set_radius_m4516119F79A03EFEC2B0E9FB4B4BA944586301C3 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_set_radiusVariance_mDA5183514D1D80A06CF8451893F2270767854D9F },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_set_modifiers_m468AB8E6FB41CD5DAF0C91EDBAA70879DB5FF60F },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_get_position_mD382CB3E972355E4942D7499CB1AEF1C7D0D4549 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_GetPooled_mF02BB421E71F7F9099C4BBABCBB491795C6E1D47 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1_t05AB6780F4F2BF76EE9626A872B703617E6E1648 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_IsMouse_m9032DD03EAD701B5E60C69C618E27B5C2620AE99 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_t4FF68240353CF5853D4480CE8144054642E4C906 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_T_tD6694D5E7C00498DE2E9B9AC85E9D6EFD837DC09 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_get_pointerId_mF3068A21A538471192726D090EABCB78E61AD592 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_get_pressedButtons_m6D0658AD097AB41D6F6776BC61CCCD4D5C71699C },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_PointerEventBase_1_GetPooled_m9D971E03C3C391C0142C07CC5A8A2E8B646C787C },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_EventBase_1__ctor_m7C77873C0450257FBFCBB9EFE5900D32A09F77A2 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_IStyleValue_1_t9BEE16A05A95E3307A8BA204B1C0397C67752A21 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_T_t32E4508B9A8BEBD334F1E8712DC4E4C9EFD7FA57 },
};
extern const CustomAttributesCacheGenerator g_UnityEngine_UIElementsModule_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_UnityEngine_UIElementsModule_CodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_UIElementsModule_CodeGenModule = 
{
	"UnityEngine.UIElementsModule.dll",
	995,
	s_methodPointers,
	75,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	20,
	s_rgctxIndices,
	153,
	s_rgctxValues,
	NULL,
	g_UnityEngine_UIElementsModule_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
