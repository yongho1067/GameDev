﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void Microsoft.CodeAnalysis.EmbeddedAttribute::.ctor()
extern void EmbeddedAttribute__ctor_m3F1A0F751C498444248AA864896027EFF3D11614 (void);
// 0x00000002 System.Void System.Runtime.CompilerServices.IsReadOnlyAttribute::.ctor()
extern void IsReadOnlyAttribute__ctor_m9040E090B861BCC28C3BCFEB7D7E21326F067CA9 (void);
// 0x00000003 System.Void CinemachineCameraOffset::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore/Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachineCameraOffset_PostPipelineStageCallback_m214222457A0BD96712F898260D4D5F9757C1D736 (void);
// 0x00000004 System.Void CinemachineCameraOffset::.ctor()
extern void CinemachineCameraOffset__ctor_mBA995110079C215F7AB8FF6DF54C37231C3B5728 (void);
// 0x00000005 System.Void CinemachineRecomposer::Reset()
extern void CinemachineRecomposer_Reset_m88525BE6F6B1DF4ABC2E58CCD4E5C95C3ED79A27 (void);
// 0x00000006 System.Void CinemachineRecomposer::OnValidate()
extern void CinemachineRecomposer_OnValidate_m9BD3BC5317D1374AEC17027D208741B5A8F62678 (void);
// 0x00000007 System.Void CinemachineRecomposer::PrePipelineMutateCameraStateCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CameraState&,System.Single)
extern void CinemachineRecomposer_PrePipelineMutateCameraStateCallback_mDE48BF5922B0CB07EEC0EDA9E1E77D86FF57C203 (void);
// 0x00000008 System.Void CinemachineRecomposer::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore/Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachineRecomposer_PostPipelineStageCallback_mE0BE4A9CF309A03D03861E086ED513AEDC9C3078 (void);
// 0x00000009 System.Void CinemachineRecomposer::.ctor()
extern void CinemachineRecomposer__ctor_mA94BEB1150CFE4D50C588D2F5C166B268D7B1362 (void);
// 0x0000000A System.Void CinemachineTouchInputMapper::Start()
extern void CinemachineTouchInputMapper_Start_m3AC349B75F081ACCDA532FBFD15F6C4DC5FA7BCC (void);
// 0x0000000B System.Single CinemachineTouchInputMapper::GetInputAxis(System.String)
extern void CinemachineTouchInputMapper_GetInputAxis_mC7DB7FBF8CA101DD4F25DC42253932CAFA2F1413 (void);
// 0x0000000C System.Void CinemachineTouchInputMapper::.ctor()
extern void CinemachineTouchInputMapper__ctor_mCE60215EA756B6CC9CDE11A6A29355961C35FCFE (void);
// 0x0000000D System.Void CinemachineMixer::OnPlayableDestroy(UnityEngine.Playables.Playable)
extern void CinemachineMixer_OnPlayableDestroy_m15D0D97BC182EEA1A886B55A440F3F37FA1B427B (void);
// 0x0000000E System.Void CinemachineMixer::PrepareFrame(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData)
extern void CinemachineMixer_PrepareFrame_mEDA03F2B9CB7AB571903D7BE4CAFA9340020B617 (void);
// 0x0000000F System.Void CinemachineMixer::ProcessFrame(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData,System.Object)
extern void CinemachineMixer_ProcessFrame_m34F7C76AC1EB8C4027CD23D54C8A0DF74788076C (void);
// 0x00000010 System.Single CinemachineMixer::GetDeltaTime(System.Single)
extern void CinemachineMixer_GetDeltaTime_mAFED8F9148B137A18BB77BBA34B10DC79E4EDBAC (void);
// 0x00000011 System.Void CinemachineMixer::.ctor()
extern void CinemachineMixer__ctor_m65687FEE5BF1A97442CCA217DC7E688AF110508A (void);
// 0x00000012 System.Void CinemachineMixer/MasterDirectorDelegate::.ctor(System.Object,System.IntPtr)
extern void MasterDirectorDelegate__ctor_mFC5DB393BD8432B57F3EA9E183CD4D224AD4E5B3 (void);
// 0x00000013 UnityEngine.Playables.PlayableDirector CinemachineMixer/MasterDirectorDelegate::Invoke()
extern void MasterDirectorDelegate_Invoke_mE703899DFD92246C6411D29992C32024398EB999 (void);
// 0x00000014 System.IAsyncResult CinemachineMixer/MasterDirectorDelegate::BeginInvoke(System.AsyncCallback,System.Object)
extern void MasterDirectorDelegate_BeginInvoke_m67EDBDBF4F3B3BDA4AF8FDF03D0C43F6DB657E9E (void);
// 0x00000015 UnityEngine.Playables.PlayableDirector CinemachineMixer/MasterDirectorDelegate::EndInvoke(System.IAsyncResult)
extern void MasterDirectorDelegate_EndInvoke_m0DEA9513CDDF240BD9616179C047000F1C5552C3 (void);
// 0x00000016 UnityEngine.Playables.Playable CinemachineShot::CreatePlayable(UnityEngine.Playables.PlayableGraph,UnityEngine.GameObject)
extern void CinemachineShot_CreatePlayable_mEEA36A48B4C1B0AE73DD4E6DB5BB67EDD5CC9FBF (void);
// 0x00000017 System.Void CinemachineShot::GatherProperties(UnityEngine.Playables.PlayableDirector,UnityEngine.Timeline.IPropertyCollector)
extern void CinemachineShot_GatherProperties_mD35DE60059D05AA13705B3AA45C1A2D3FD82E2A2 (void);
// 0x00000018 System.Void CinemachineShot::.ctor()
extern void CinemachineShot__ctor_m4E0ED8E81339A16B4BBE6833D2891A59F1868F04 (void);
// 0x00000019 System.Boolean CinemachineShotPlayable::get_IsValid()
extern void CinemachineShotPlayable_get_IsValid_m783EFC14C1B6E0C331E8BE1FB97BF73E5C0FB085 (void);
// 0x0000001A System.Void CinemachineShotPlayable::.ctor()
extern void CinemachineShotPlayable__ctor_m5831073991E80621F1FD0DAE1862F4B47D4FEC58 (void);
// 0x0000001B UnityEngine.Playables.Playable CinemachineTrack::CreateTrackMixer(UnityEngine.Playables.PlayableGraph,UnityEngine.GameObject,System.Int32)
extern void CinemachineTrack_CreateTrackMixer_mC9AD3E7B72FDAF3BF9ECBFE57BDD75880F7A4346 (void);
// 0x0000001C System.Void CinemachineTrack::.ctor()
extern void CinemachineTrack__ctor_m346DCFF5C3E9A01315B9C4F59625F3FFAC3DDBDA (void);
// 0x0000001D System.Void Cinemachine.Cinemachine3rdPersonAim::OnValidate()
extern void Cinemachine3rdPersonAim_OnValidate_m1DB2920E91BF684D7E934BC0136839D7ABF49C09 (void);
// 0x0000001E System.Void Cinemachine.Cinemachine3rdPersonAim::Reset()
extern void Cinemachine3rdPersonAim_Reset_m76AF226247A9F0C4CCDDF0200876BC01859A17DA (void);
// 0x0000001F System.Boolean Cinemachine.Cinemachine3rdPersonAim::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void Cinemachine3rdPersonAim_OnTransitionFromCamera_mB60FDBDAEC3D755C4BC8FF8EB9DB5A8226FE5144 (void);
// 0x00000020 System.Void Cinemachine.Cinemachine3rdPersonAim::DrawReticle(Cinemachine.CinemachineBrain)
extern void Cinemachine3rdPersonAim_DrawReticle_m4B256A71AFE3F96910662DEE45FC49FD1BAACD50 (void);
// 0x00000021 UnityEngine.Vector3 Cinemachine.Cinemachine3rdPersonAim::GetLookAtPoint(UnityEngine.Vector3)
extern void Cinemachine3rdPersonAim_GetLookAtPoint_m920FEA216F7AF2AF10154BF104CED04D900A89E4 (void);
// 0x00000022 System.Void Cinemachine.Cinemachine3rdPersonAim::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore/Stage,Cinemachine.CameraState&,System.Single)
extern void Cinemachine3rdPersonAim_PostPipelineStageCallback_m431D6A5A151FC73D58E2BB5C843C4A9D785AED82 (void);
// 0x00000023 System.Void Cinemachine.Cinemachine3rdPersonAim::.ctor()
extern void Cinemachine3rdPersonAim__ctor_m3FD0201C504BF089A48A2A2054B8CD3F85DB46EF (void);
// 0x00000024 System.String Cinemachine.CinemachineBlendListCamera::get_Description()
extern void CinemachineBlendListCamera_get_Description_m5C6D715F0F62C76E72B28C22E29B85A99F44FB8A (void);
// 0x00000025 System.Void Cinemachine.CinemachineBlendListCamera::Reset()
extern void CinemachineBlendListCamera_Reset_mA706C0FB4CC7FD7FCAF338BDA534A803539B6BEA (void);
// 0x00000026 System.Void Cinemachine.CinemachineBlendListCamera::set_LiveChild(Cinemachine.ICinemachineCamera)
extern void CinemachineBlendListCamera_set_LiveChild_m06CBC3CB11F541FA72E4F5189DA3CDAD2F93A12D (void);
// 0x00000027 Cinemachine.ICinemachineCamera Cinemachine.CinemachineBlendListCamera::get_LiveChild()
extern void CinemachineBlendListCamera_get_LiveChild_mC110B712B11C6D0D8BEE7CF35511A88932FB374B (void);
// 0x00000028 System.Boolean Cinemachine.CinemachineBlendListCamera::IsLiveChild(Cinemachine.ICinemachineCamera,System.Boolean)
extern void CinemachineBlendListCamera_IsLiveChild_m01E481F15D50EDA15D50F7698A8D4270E9A6DF2D (void);
// 0x00000029 Cinemachine.CameraState Cinemachine.CinemachineBlendListCamera::get_State()
extern void CinemachineBlendListCamera_get_State_m0F2CC117E1188ED5E61F263A3F96C99152603997 (void);
// 0x0000002A UnityEngine.Transform Cinemachine.CinemachineBlendListCamera::get_LookAt()
extern void CinemachineBlendListCamera_get_LookAt_m4987B243A6841944D9CC1DCEEB208D75DD472D8F (void);
// 0x0000002B System.Void Cinemachine.CinemachineBlendListCamera::set_LookAt(UnityEngine.Transform)
extern void CinemachineBlendListCamera_set_LookAt_m89A121D81D3A5A9AB901C2490C8582E19D56720B (void);
// 0x0000002C UnityEngine.Transform Cinemachine.CinemachineBlendListCamera::get_Follow()
extern void CinemachineBlendListCamera_get_Follow_m4C77B0D9285FF0E0BDE6672AA97CBFEA8F779EAE (void);
// 0x0000002D System.Void Cinemachine.CinemachineBlendListCamera::set_Follow(UnityEngine.Transform)
extern void CinemachineBlendListCamera_set_Follow_m11AC198E828F34AA47C3DEDEE0255BB52155E4F3 (void);
// 0x0000002E System.Void Cinemachine.CinemachineBlendListCamera::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineBlendListCamera_OnTargetObjectWarped_m064D8A1708A9EC3A8C3781CDDEAE0DD19F26C226 (void);
// 0x0000002F System.Void Cinemachine.CinemachineBlendListCamera::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineBlendListCamera_ForceCameraPosition_m8353DC410D5F9C28E6BD4A6E795E8B02C2AD102F (void);
// 0x00000030 System.Void Cinemachine.CinemachineBlendListCamera::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void CinemachineBlendListCamera_OnTransitionFromCamera_m0A4B32A2C54128881A91D1AC80C83EA626FF6403 (void);
// 0x00000031 Cinemachine.ICinemachineCamera Cinemachine.CinemachineBlendListCamera::get_TransitioningFrom()
extern void CinemachineBlendListCamera_get_TransitioningFrom_mD6696F8110804BEA7C73ECE7815C01349DA80ADD (void);
// 0x00000032 System.Void Cinemachine.CinemachineBlendListCamera::set_TransitioningFrom(Cinemachine.ICinemachineCamera)
extern void CinemachineBlendListCamera_set_TransitioningFrom_mAD76B896D15BE8EC438A9527249DC62FD696EE0D (void);
// 0x00000033 System.Void Cinemachine.CinemachineBlendListCamera::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
extern void CinemachineBlendListCamera_InternalUpdateCameraState_m58770001B7B5AC14E824882B59611938B64B289D (void);
// 0x00000034 System.Void Cinemachine.CinemachineBlendListCamera::OnEnable()
extern void CinemachineBlendListCamera_OnEnable_m64064AC70DFF2427499FE68274AC45E753D556CA (void);
// 0x00000035 System.Void Cinemachine.CinemachineBlendListCamera::OnDisable()
extern void CinemachineBlendListCamera_OnDisable_m46FCC8C90F9233ED5528545F728D23B8AEC439FA (void);
// 0x00000036 System.Void Cinemachine.CinemachineBlendListCamera::OnTransformChildrenChanged()
extern void CinemachineBlendListCamera_OnTransformChildrenChanged_m08CB2CA52EDFE41199C966A34F478C3D85425EC2 (void);
// 0x00000037 System.Void Cinemachine.CinemachineBlendListCamera::OnGuiHandler()
extern void CinemachineBlendListCamera_OnGuiHandler_m58B69E2CCF7FA61E5DD1934735E6873DCF379FD0 (void);
// 0x00000038 Cinemachine.CinemachineVirtualCameraBase[] Cinemachine.CinemachineBlendListCamera::get_ChildCameras()
extern void CinemachineBlendListCamera_get_ChildCameras_m85978F41F7E12760B36BE29F70107684A229295D (void);
// 0x00000039 System.Boolean Cinemachine.CinemachineBlendListCamera::get_IsBlending()
extern void CinemachineBlendListCamera_get_IsBlending_m0BAA4ACB2EBA83796F4E210F8E870329676F4708 (void);
// 0x0000003A System.Void Cinemachine.CinemachineBlendListCamera::InvalidateListOfChildren()
extern void CinemachineBlendListCamera_InvalidateListOfChildren_m1A851A8A2A3D12271AEBCB7CB52D014AEB6920ED (void);
// 0x0000003B System.Void Cinemachine.CinemachineBlendListCamera::UpdateListOfChildren()
extern void CinemachineBlendListCamera_UpdateListOfChildren_m78195EDC229BA08AB69C876F0574217BFAFCEBB5 (void);
// 0x0000003C System.Void Cinemachine.CinemachineBlendListCamera::ValidateInstructions()
extern void CinemachineBlendListCamera_ValidateInstructions_m39EE271A6D34B62732B978205EBF6681B6657ECC (void);
// 0x0000003D System.Void Cinemachine.CinemachineBlendListCamera::AdvanceCurrentInstruction(System.Single)
extern void CinemachineBlendListCamera_AdvanceCurrentInstruction_m6AE0D5A3A44F65265B9C461AAA1C577D80527DDF (void);
// 0x0000003E System.Void Cinemachine.CinemachineBlendListCamera::.ctor()
extern void CinemachineBlendListCamera__ctor_m415640A76DED96AA7D39819787BACBC3220728C5 (void);
// 0x0000003F UnityEngine.Camera Cinemachine.CinemachineBrain::get_OutputCamera()
extern void CinemachineBrain_get_OutputCamera_m53C6A01A6715756C5A1B80FB403453B3CB28DF84 (void);
// 0x00000040 Cinemachine.ICinemachineCamera Cinemachine.CinemachineBrain::get_SoloCamera()
extern void CinemachineBrain_get_SoloCamera_mEAD650442E6D40F860F2668FD0BFEA14495B1F48 (void);
// 0x00000041 System.Void Cinemachine.CinemachineBrain::set_SoloCamera(Cinemachine.ICinemachineCamera)
extern void CinemachineBrain_set_SoloCamera_mCDFED6D67E47D86163AAB3B63A60BB335586FC58 (void);
// 0x00000042 UnityEngine.Color Cinemachine.CinemachineBrain::GetSoloGUIColor()
extern void CinemachineBrain_GetSoloGUIColor_m1EDE8585C43B473EDAA59D61D558D83F356E45F8 (void);
// 0x00000043 UnityEngine.Vector3 Cinemachine.CinemachineBrain::get_DefaultWorldUp()
extern void CinemachineBrain_get_DefaultWorldUp_mA052F23DFC679E1E0E15B2466ECB3799B656CBA4 (void);
// 0x00000044 System.Void Cinemachine.CinemachineBrain::OnEnable()
extern void CinemachineBrain_OnEnable_m444560E00F8FE814A13A5C18076C4ECFE09A9C12 (void);
// 0x00000045 System.Void Cinemachine.CinemachineBrain::OnDisable()
extern void CinemachineBrain_OnDisable_mD0002ADB05DE5396E8782571436DC874A098FC1E (void);
// 0x00000046 System.Void Cinemachine.CinemachineBrain::OnSceneLoaded(UnityEngine.SceneManagement.Scene,UnityEngine.SceneManagement.LoadSceneMode)
extern void CinemachineBrain_OnSceneLoaded_mA0F14A6DD8BC5E68243E6879425E49935DBF7900 (void);
// 0x00000047 System.Void Cinemachine.CinemachineBrain::OnSceneUnloaded(UnityEngine.SceneManagement.Scene)
extern void CinemachineBrain_OnSceneUnloaded_m623A93AF5BB2A7967B0DB47A564EBE856CFC8204 (void);
// 0x00000048 System.Void Cinemachine.CinemachineBrain::Start()
extern void CinemachineBrain_Start_m851FA02E684EC0C99687B63CAA12F595C5625BF8 (void);
// 0x00000049 System.Void Cinemachine.CinemachineBrain::OnGuiHandler()
extern void CinemachineBrain_OnGuiHandler_m8EBDE5B960F8BD057B3ACEBAB75AC10492B798D8 (void);
// 0x0000004A System.Collections.IEnumerator Cinemachine.CinemachineBrain::AfterPhysics()
extern void CinemachineBrain_AfterPhysics_mAD691C1010D2426873FE5A5463646DDB307B4410 (void);
// 0x0000004B System.Void Cinemachine.CinemachineBrain::LateUpdate()
extern void CinemachineBrain_LateUpdate_mE2D66C0664D1B0552A07D508C9D08C6167A0F1CD (void);
// 0x0000004C System.Void Cinemachine.CinemachineBrain::ManualUpdate()
extern void CinemachineBrain_ManualUpdate_m8D7A7301585B6A15E708BEA2E148B1C7F2F7A487 (void);
// 0x0000004D System.Single Cinemachine.CinemachineBrain::GetEffectiveDeltaTime(System.Boolean)
extern void CinemachineBrain_GetEffectiveDeltaTime_m27D6E0AC28FA42C74DD804AB942F0D496D55379B (void);
// 0x0000004E System.Void Cinemachine.CinemachineBrain::UpdateVirtualCameras(Cinemachine.CinemachineCore/UpdateFilter,System.Single)
extern void CinemachineBrain_UpdateVirtualCameras_mCA6172FE9872138FF4D2B3867EE7AB5BE6D47F89 (void);
// 0x0000004F Cinemachine.ICinemachineCamera Cinemachine.CinemachineBrain::get_ActiveVirtualCamera()
extern void CinemachineBrain_get_ActiveVirtualCamera_m9111F4A789B4CCE529CDDE345F8B690EFEC2C63B (void);
// 0x00000050 Cinemachine.ICinemachineCamera Cinemachine.CinemachineBrain::DeepCamBFromBlend(Cinemachine.CinemachineBlend)
extern void CinemachineBrain_DeepCamBFromBlend_m982D9725A5164F9EBF00366A2D49745179A60A46 (void);
// 0x00000051 System.Boolean Cinemachine.CinemachineBrain::get_IsBlending()
extern void CinemachineBrain_get_IsBlending_mA7662615642DEFD6893E2D6872A78CEA253474B2 (void);
// 0x00000052 Cinemachine.CinemachineBlend Cinemachine.CinemachineBrain::get_ActiveBlend()
extern void CinemachineBrain_get_ActiveBlend_m03CD7DFA8C5D537BEB972918C6F4D2BB2FDB7F15 (void);
// 0x00000053 System.Int32 Cinemachine.CinemachineBrain::GetBrainFrame(System.Int32)
extern void CinemachineBrain_GetBrainFrame_m993AEAFCA2ACA814C76097EFF86FE895258861A5 (void);
// 0x00000054 System.Int32 Cinemachine.CinemachineBrain::SetCameraOverride(System.Int32,Cinemachine.ICinemachineCamera,Cinemachine.ICinemachineCamera,System.Single,System.Single)
extern void CinemachineBrain_SetCameraOverride_m9B06A2796330BE39B59E4DD8E1A40EDCDA969967 (void);
// 0x00000055 System.Void Cinemachine.CinemachineBrain::ReleaseCameraOverride(System.Int32)
extern void CinemachineBrain_ReleaseCameraOverride_m83F54FD0A6837603DDCE2090AC3FDD0A0BAE30DF (void);
// 0x00000056 System.Void Cinemachine.CinemachineBrain::ProcessActiveCamera(System.Single)
extern void CinemachineBrain_ProcessActiveCamera_m094A1972B629F11EB580679FEFD78076769180FF (void);
// 0x00000057 System.Void Cinemachine.CinemachineBrain::UpdateFrame0(System.Single)
extern void CinemachineBrain_UpdateFrame0_m8FD42266AA4C2CCE09B842A5BA7362126585858B (void);
// 0x00000058 System.Void Cinemachine.CinemachineBrain::ComputeCurrentBlend(Cinemachine.CinemachineBlend&,System.Int32)
extern void CinemachineBrain_ComputeCurrentBlend_m296BA72649974D928612AFC717D7446C028F3858 (void);
// 0x00000059 System.Boolean Cinemachine.CinemachineBrain::IsLive(Cinemachine.ICinemachineCamera,System.Boolean)
extern void CinemachineBrain_IsLive_mF74210376333DD9865A075E561E6E3DDED510FB2 (void);
// 0x0000005A Cinemachine.CameraState Cinemachine.CinemachineBrain::get_CurrentCameraState()
extern void CinemachineBrain_get_CurrentCameraState_mBC8B24EFB25ADD71E4E007CDD351ED790FA76243 (void);
// 0x0000005B System.Void Cinemachine.CinemachineBrain::set_CurrentCameraState(Cinemachine.CameraState)
extern void CinemachineBrain_set_CurrentCameraState_m2624A063E4A16EDCC8E1F8FFB93E96F74E98882B (void);
// 0x0000005C Cinemachine.ICinemachineCamera Cinemachine.CinemachineBrain::TopCameraFromPriorityQueue()
extern void CinemachineBrain_TopCameraFromPriorityQueue_m81361016B63A4BF68BA4D85452BAE8647B90E9EF (void);
// 0x0000005D Cinemachine.CinemachineBlendDefinition Cinemachine.CinemachineBrain::LookupBlend(Cinemachine.ICinemachineCamera,Cinemachine.ICinemachineCamera)
extern void CinemachineBrain_LookupBlend_mEBAE63022CC081EAF26489C7BBEC2492F32B7FDD (void);
// 0x0000005E System.Void Cinemachine.CinemachineBrain::PushStateToUnityCamera(Cinemachine.CameraState&)
extern void CinemachineBrain_PushStateToUnityCamera_m7261800DC4671AD0B91DCACFBCD1B1DAD6B144B3 (void);
// 0x0000005F System.Void Cinemachine.CinemachineBrain::.ctor()
extern void CinemachineBrain__ctor_m86D8371115D9B5138648C75C3135396823DD43EE (void);
// 0x00000060 System.Void Cinemachine.CinemachineBrain::.cctor()
extern void CinemachineBrain__cctor_mECCA7F7ABF8660A2BAB11A39B29D9923D2361DD8 (void);
// 0x00000061 System.Void Cinemachine.CinemachineBrain/BrainEvent::.ctor()
extern void BrainEvent__ctor_m648F7E949F40D8EAB7019FAED3ECE88D8CAF05D7 (void);
// 0x00000062 System.Void Cinemachine.CinemachineBrain/VcamActivatedEvent::.ctor()
extern void VcamActivatedEvent__ctor_mA99C1BA22F69EE75141BFFBB810E1230DCFA15E6 (void);
// 0x00000063 System.Boolean Cinemachine.CinemachineBrain/BrainFrame::get_Active()
extern void BrainFrame_get_Active_mD8AA67B2ACCA6591C9DA9A495850D2145C5B0712 (void);
// 0x00000064 System.Void Cinemachine.CinemachineBrain/BrainFrame::.ctor()
extern void BrainFrame__ctor_mA060413F10EA79721B2D2A33D99DC1D3282831A6 (void);
// 0x00000065 System.Void Cinemachine.CinemachineBrain/<AfterPhysics>d__33::.ctor(System.Int32)
extern void U3CAfterPhysicsU3Ed__33__ctor_m24D6754D2DAB3DF174EEE38B2A0B6E6E5D5A5DD2 (void);
// 0x00000066 System.Void Cinemachine.CinemachineBrain/<AfterPhysics>d__33::System.IDisposable.Dispose()
extern void U3CAfterPhysicsU3Ed__33_System_IDisposable_Dispose_mDCB6F829946F1B34F28228BC74725898C5EE8FCD (void);
// 0x00000067 System.Boolean Cinemachine.CinemachineBrain/<AfterPhysics>d__33::MoveNext()
extern void U3CAfterPhysicsU3Ed__33_MoveNext_mDA6F02ED5AF41DC0E1B1AD753F8AAE8F06B9B28A (void);
// 0x00000068 System.Object Cinemachine.CinemachineBrain/<AfterPhysics>d__33::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAfterPhysicsU3Ed__33_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mBDD4A0F001AD9DD0F2AB2F992A82F77B770FF837 (void);
// 0x00000069 System.Void Cinemachine.CinemachineBrain/<AfterPhysics>d__33::System.Collections.IEnumerator.Reset()
extern void U3CAfterPhysicsU3Ed__33_System_Collections_IEnumerator_Reset_mAA45376E2089E38B00E97B3A6B9F00F2A495B435 (void);
// 0x0000006A System.Object Cinemachine.CinemachineBrain/<AfterPhysics>d__33::System.Collections.IEnumerator.get_Current()
extern void U3CAfterPhysicsU3Ed__33_System_Collections_IEnumerator_get_Current_m266F0F6B25D7EAA07E9A5A65D99178B51EE354EA (void);
// 0x0000006B System.String Cinemachine.CinemachineClearShot::get_Description()
extern void CinemachineClearShot_get_Description_m7AF5F30369B2273697549B4E458FD3D7FE7AE694 (void);
// 0x0000006C System.Void Cinemachine.CinemachineClearShot::set_LiveChild(Cinemachine.ICinemachineCamera)
extern void CinemachineClearShot_set_LiveChild_m51685341391760EC4E1053AC1555A39A06185B1E (void);
// 0x0000006D Cinemachine.ICinemachineCamera Cinemachine.CinemachineClearShot::get_LiveChild()
extern void CinemachineClearShot_get_LiveChild_m0E247D53C258CE36DBF28944CD0AD8A47344C4A2 (void);
// 0x0000006E Cinemachine.CameraState Cinemachine.CinemachineClearShot::get_State()
extern void CinemachineClearShot_get_State_m5596F81F599D82C8FE6A5383E95D3DF4F803EF7A (void);
// 0x0000006F System.Boolean Cinemachine.CinemachineClearShot::IsLiveChild(Cinemachine.ICinemachineCamera,System.Boolean)
extern void CinemachineClearShot_IsLiveChild_m27778431D3DC199BD4A07283966ABC71F323942E (void);
// 0x00000070 UnityEngine.Transform Cinemachine.CinemachineClearShot::get_LookAt()
extern void CinemachineClearShot_get_LookAt_mACAC39B62BB18C014CB0EE0829D37854DEEF1547 (void);
// 0x00000071 System.Void Cinemachine.CinemachineClearShot::set_LookAt(UnityEngine.Transform)
extern void CinemachineClearShot_set_LookAt_mE444F2137C96A179F9A0DCCACC9D5BEC30C075D4 (void);
// 0x00000072 UnityEngine.Transform Cinemachine.CinemachineClearShot::get_Follow()
extern void CinemachineClearShot_get_Follow_mCBA54E3955A8DEBD46828F16EAE00AA2B8678C56 (void);
// 0x00000073 System.Void Cinemachine.CinemachineClearShot::set_Follow(UnityEngine.Transform)
extern void CinemachineClearShot_set_Follow_mA1A33A5BF458CB7FE8CE965EA59F8F5335128BDE (void);
// 0x00000074 System.Void Cinemachine.CinemachineClearShot::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineClearShot_OnTargetObjectWarped_mFA9A79ADB2FA4A94D6FD73CBF32B38DBA4E34F7D (void);
// 0x00000075 System.Void Cinemachine.CinemachineClearShot::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineClearShot_ForceCameraPosition_m64A96229F7CD5AFC4C163184CABDE5ACED9A027B (void);
// 0x00000076 System.Void Cinemachine.CinemachineClearShot::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
extern void CinemachineClearShot_InternalUpdateCameraState_m0E642E1D33C0F0BB0628E439A78574B381F08B29 (void);
// 0x00000077 System.Void Cinemachine.CinemachineClearShot::OnEnable()
extern void CinemachineClearShot_OnEnable_m6FD19FC685EFF8D2432861E8B6FBDDA02A954220 (void);
// 0x00000078 System.Void Cinemachine.CinemachineClearShot::OnDisable()
extern void CinemachineClearShot_OnDisable_mC02AEC329D9BDB5D6ADFF762B38DD7260C6780F5 (void);
// 0x00000079 System.Void Cinemachine.CinemachineClearShot::OnTransformChildrenChanged()
extern void CinemachineClearShot_OnTransformChildrenChanged_mF8891487D72C8C87FDE3AF59FC308492AFD719EA (void);
// 0x0000007A System.Void Cinemachine.CinemachineClearShot::OnGuiHandler()
extern void CinemachineClearShot_OnGuiHandler_m62267DB468A7AB10E6834C1EAC49A795349E59FA (void);
// 0x0000007B System.Boolean Cinemachine.CinemachineClearShot::get_IsBlending()
extern void CinemachineClearShot_get_IsBlending_mA2F2B1313AB3374D1D1287D67992D756C42587DA (void);
// 0x0000007C Cinemachine.CinemachineVirtualCameraBase[] Cinemachine.CinemachineClearShot::get_ChildCameras()
extern void CinemachineClearShot_get_ChildCameras_m1F32604733AC3601B4843C072342F408CE19C5B6 (void);
// 0x0000007D System.Void Cinemachine.CinemachineClearShot::InvalidateListOfChildren()
extern void CinemachineClearShot_InvalidateListOfChildren_mB0CD028BA2D3286D654F260940BBC2234A7038EB (void);
// 0x0000007E System.Void Cinemachine.CinemachineClearShot::ResetRandomization()
extern void CinemachineClearShot_ResetRandomization_m1876DCD195CD2865599F23957CBCCF07F9557109 (void);
// 0x0000007F System.Void Cinemachine.CinemachineClearShot::UpdateListOfChildren()
extern void CinemachineClearShot_UpdateListOfChildren_m37DF613332B66C99EF46A5D338356B90A1D0894E (void);
// 0x00000080 Cinemachine.ICinemachineCamera Cinemachine.CinemachineClearShot::ChooseCurrentCamera(UnityEngine.Vector3)
extern void CinemachineClearShot_ChooseCurrentCamera_m678A067854D8A908119247136EA38448E98C7F22 (void);
// 0x00000081 Cinemachine.CinemachineVirtualCameraBase[] Cinemachine.CinemachineClearShot::Randomize(Cinemachine.CinemachineVirtualCameraBase[])
extern void CinemachineClearShot_Randomize_m8B9933410E1461B3C79A0CE6C332868954306FC7 (void);
// 0x00000082 Cinemachine.CinemachineBlendDefinition Cinemachine.CinemachineClearShot::LookupBlend(Cinemachine.ICinemachineCamera,Cinemachine.ICinemachineCamera)
extern void CinemachineClearShot_LookupBlend_mEC42F1C07A25A4D873D61AB6F6CB6C26491E4D83 (void);
// 0x00000083 System.Void Cinemachine.CinemachineClearShot::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void CinemachineClearShot_OnTransitionFromCamera_mEA5216EB1E80B4DC87F35CEE0646FAF2216BFA9B (void);
// 0x00000084 Cinemachine.ICinemachineCamera Cinemachine.CinemachineClearShot::get_TransitioningFrom()
extern void CinemachineClearShot_get_TransitioningFrom_m9C6A21D455B4DF835AB81F4FC5B929AF8E6228C8 (void);
// 0x00000085 System.Void Cinemachine.CinemachineClearShot::set_TransitioningFrom(Cinemachine.ICinemachineCamera)
extern void CinemachineClearShot_set_TransitioningFrom_mBB426F06C8C9E05C7DDBCD76C6001071AB80CA3B (void);
// 0x00000086 System.Void Cinemachine.CinemachineClearShot::.ctor()
extern void CinemachineClearShot__ctor_m5E1633DD8F3F1811A0F4CB5335B4098A691C16BA (void);
// 0x00000087 System.Void Cinemachine.CinemachineClearShot/<>c::.cctor()
extern void U3CU3Ec__cctor_m9685B944F64D38F8A51929E1DCF7714D96EE5C6E (void);
// 0x00000088 System.Void Cinemachine.CinemachineClearShot/<>c::.ctor()
extern void U3CU3Ec__ctor_m02E5C011A18650E911D7DE28902B36407425A1DA (void);
// 0x00000089 System.Int32 Cinemachine.CinemachineClearShot/<>c::<Randomize>b__47_0(Cinemachine.CinemachineClearShot/Pair,Cinemachine.CinemachineClearShot/Pair)
extern void U3CU3Ec_U3CRandomizeU3Eb__47_0_m11EDFFF61087041AA23E34C5AE7D01B6976118F9 (void);
// 0x0000008A System.Boolean Cinemachine.CinemachineCollider::IsTargetObscured(Cinemachine.ICinemachineCamera)
extern void CinemachineCollider_IsTargetObscured_m728B54117D657C72C3A45B15D097376B916AD081 (void);
// 0x0000008B System.Boolean Cinemachine.CinemachineCollider::CameraWasDisplaced(Cinemachine.ICinemachineCamera)
extern void CinemachineCollider_CameraWasDisplaced_mE3C7D73AC6F29D59A945EB4B6E1DFF1A407D7069 (void);
// 0x0000008C System.Single Cinemachine.CinemachineCollider::GetCameraDisplacementDistance(Cinemachine.ICinemachineCamera)
extern void CinemachineCollider_GetCameraDisplacementDistance_m97DED641EC9ECB65AFAE1E0687AF9DF5A7A073BC (void);
// 0x0000008D System.Void Cinemachine.CinemachineCollider::OnValidate()
extern void CinemachineCollider_OnValidate_mDFCD2F62D4D4C8487A1041106507A47134048FF0 (void);
// 0x0000008E System.Void Cinemachine.CinemachineCollider::OnDestroy()
extern void CinemachineCollider_OnDestroy_m5CCC19D44E691B93F05BA2CFAF07B48D2EFA9091 (void);
// 0x0000008F System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector3>> Cinemachine.CinemachineCollider::get_DebugPaths()
extern void CinemachineCollider_get_DebugPaths_m10FD1111E853455483AAF675CDBB7ACCF6E967EC (void);
// 0x00000090 System.Single Cinemachine.CinemachineCollider::GetMaxDampTime()
extern void CinemachineCollider_GetMaxDampTime_m7D8E44771355BC2FD8C428861A42C21A7B90695A (void);
// 0x00000091 System.Void Cinemachine.CinemachineCollider::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore/Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachineCollider_PostPipelineStageCallback_m91F23EE95689CCBCF63C89951CE9A4EE726F59CC (void);
// 0x00000092 UnityEngine.Vector3 Cinemachine.CinemachineCollider::PreserveLineOfSight(Cinemachine.CameraState&,Cinemachine.CinemachineCollider/VcamExtraState&)
extern void CinemachineCollider_PreserveLineOfSight_m55F8D760D87EE4365569DF0360F33E960DE3DB46 (void);
// 0x00000093 UnityEngine.Vector3 Cinemachine.CinemachineCollider::PullCameraInFrontOfNearestObstacle(UnityEngine.Vector3,UnityEngine.Vector3,System.Int32,UnityEngine.RaycastHit&)
extern void CinemachineCollider_PullCameraInFrontOfNearestObstacle_m831839A6F16DC4AEE8B11341B5752D0E1402BCDE (void);
// 0x00000094 UnityEngine.Vector3 Cinemachine.CinemachineCollider::PushCameraBack(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.RaycastHit,UnityEngine.Vector3,UnityEngine.Plane,System.Single,System.Int32,Cinemachine.CinemachineCollider/VcamExtraState&)
extern void CinemachineCollider_PushCameraBack_mEA413F0258A0E497FF47208E7C38D607A3E95772 (void);
// 0x00000095 System.Boolean Cinemachine.CinemachineCollider::GetWalkingDirection(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.RaycastHit,UnityEngine.Vector3&)
extern void CinemachineCollider_GetWalkingDirection_mD0BA4C78DA9671058C3E0DF9AC27661882685D1B (void);
// 0x00000096 System.Single Cinemachine.CinemachineCollider::GetPushBackDistance(UnityEngine.Ray,UnityEngine.Plane,System.Single,UnityEngine.Vector3)
extern void CinemachineCollider_GetPushBackDistance_m8467D939C839D655437168AE18EBA9469EFE71B8 (void);
// 0x00000097 System.Single Cinemachine.CinemachineCollider::ClampRayToBounds(UnityEngine.Ray,System.Single,UnityEngine.Bounds)
extern void CinemachineCollider_ClampRayToBounds_mDE4466A0D48B3C73C69C92A9BB69ECE3E703FA0E (void);
// 0x00000098 System.Void Cinemachine.CinemachineCollider::DestroyCollider()
extern void CinemachineCollider_DestroyCollider_m9E697592872A9B4F2C5D5096CBFAA54882CEC800 (void);
// 0x00000099 UnityEngine.Vector3 Cinemachine.CinemachineCollider::RespectCameraRadius(UnityEngine.Vector3,Cinemachine.CameraState&)
extern void CinemachineCollider_RespectCameraRadius_m06B1B729256E1787E9FAE46241267FA08E299D4A (void);
// 0x0000009A System.Boolean Cinemachine.CinemachineCollider::CheckForTargetObstructions(Cinemachine.CameraState)
extern void CinemachineCollider_CheckForTargetObstructions_m525473EF0F2669CD7B83EAA3CE790B11B632D63B (void);
// 0x0000009B System.Boolean Cinemachine.CinemachineCollider::IsTargetOffscreen(Cinemachine.CameraState)
extern void CinemachineCollider_IsTargetOffscreen_mEBE97ED4E2F75864D24A6E055BE9133E71732E2C (void);
// 0x0000009C System.Void Cinemachine.CinemachineCollider::.ctor()
extern void CinemachineCollider__ctor_m3543A3A2E03D8A030138D79AAEC58065C03D2994 (void);
// 0x0000009D System.Void Cinemachine.CinemachineCollider/VcamExtraState::AddPointToDebugPath(UnityEngine.Vector3)
extern void VcamExtraState_AddPointToDebugPath_mFF718D5B8D9DACD1A94BAFB458A028241E0FC95B (void);
// 0x0000009E System.Single Cinemachine.CinemachineCollider/VcamExtraState::ApplyDistanceSmoothing(System.Single,System.Single)
extern void VcamExtraState_ApplyDistanceSmoothing_mB2490C4B28326713F8FAECEEBC239B46BDBB853C (void);
// 0x0000009F System.Void Cinemachine.CinemachineCollider/VcamExtraState::UpdateDistanceSmoothing(System.Single,System.Single)
extern void VcamExtraState_UpdateDistanceSmoothing_m75C77A914C361D02C7C0F9B73A874D309EC124B8 (void);
// 0x000000A0 System.Void Cinemachine.CinemachineCollider/VcamExtraState::ResetDistanceSmoothing(System.Single)
extern void VcamExtraState_ResetDistanceSmoothing_m9DA2E009ED1BBFD18F811B5A1E0DF1BE9D91342C (void);
// 0x000000A1 System.Void Cinemachine.CinemachineCollider/VcamExtraState::.ctor()
extern void VcamExtraState__ctor_mAD425FDD74968E2F744178F85B1C9F5FA2FA875F (void);
// 0x000000A2 System.Boolean Cinemachine.CinemachineConfiner::CameraWasDisplaced(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineConfiner_CameraWasDisplaced_m83D1EF33F9ED6B52144AB0D3218D2126512B408F (void);
// 0x000000A3 System.Single Cinemachine.CinemachineConfiner::GetCameraDisplacementDistance(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineConfiner_GetCameraDisplacementDistance_mAE964ADE185900F3A1963C8F6008C10F6E9E6975 (void);
// 0x000000A4 System.Void Cinemachine.CinemachineConfiner::OnValidate()
extern void CinemachineConfiner_OnValidate_mD463ED5B94F6B858300D99F45438D5F0FBD949DE (void);
// 0x000000A5 System.Void Cinemachine.CinemachineConfiner::ConnectToVcam(System.Boolean)
extern void CinemachineConfiner_ConnectToVcam_m3DF3703EBA5E402116E0B99FA7F7B7FFDB58497C (void);
// 0x000000A6 System.Boolean Cinemachine.CinemachineConfiner::get_IsValid()
extern void CinemachineConfiner_get_IsValid_m87C7AC9111017572EEACBF7B38926E5A10F81EF5 (void);
// 0x000000A7 System.Single Cinemachine.CinemachineConfiner::GetMaxDampTime()
extern void CinemachineConfiner_GetMaxDampTime_m445F5B5483E8A1058DB72F4376C34FA5B66275A7 (void);
// 0x000000A8 System.Void Cinemachine.CinemachineConfiner::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore/Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachineConfiner_PostPipelineStageCallback_m042478453BC335A0410635B429516D39992E2BDE (void);
// 0x000000A9 System.Void Cinemachine.CinemachineConfiner::InvalidatePathCache()
extern void CinemachineConfiner_InvalidatePathCache_m1C66E34112C65B4CDACC628AD8D7F8C90F45706B (void);
// 0x000000AA System.Boolean Cinemachine.CinemachineConfiner::ValidatePathCache()
extern void CinemachineConfiner_ValidatePathCache_m249EEFABC4DDAD7D8CBAC54CE0C7F5CF2BF90CBE (void);
// 0x000000AB UnityEngine.Vector3 Cinemachine.CinemachineConfiner::ConfinePoint(UnityEngine.Vector3)
extern void CinemachineConfiner_ConfinePoint_m7AE2FFDCD682C31954A51D4F0401FCC00642660A (void);
// 0x000000AC UnityEngine.Vector3 Cinemachine.CinemachineConfiner::ConfineScreenEdges(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CameraState&)
extern void CinemachineConfiner_ConfineScreenEdges_m3EF25363525ACDADF5D9A7AFFBD5805A4B9908FA (void);
// 0x000000AD System.Void Cinemachine.CinemachineConfiner::.ctor()
extern void CinemachineConfiner__ctor_m51000A5BAF0EEDF46F862CB2C77BCBDF41035C68 (void);
// 0x000000AE System.Void Cinemachine.CinemachineConfiner/VcamExtraState::.ctor()
extern void VcamExtraState__ctor_m0EE1BF4E53FB8E8DFF70446D1A47286397ED89FD (void);
// 0x000000AF System.Void Cinemachine.CinemachineConfiner2D::InvalidateCache()
extern void CinemachineConfiner2D_InvalidateCache_mFDB874DEB9EF79A9BD50704538C6BBB3BC8C6DB3 (void);
// 0x000000B0 System.Boolean Cinemachine.CinemachineConfiner2D::ValidateCache(System.Single)
extern void CinemachineConfiner2D_ValidateCache_m80AC2A2077A30BAAE5A91097BE37B681410A8B0F (void);
// 0x000000B1 System.Void Cinemachine.CinemachineConfiner2D::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore/Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachineConfiner2D_PostPipelineStageCallback_mA43AF7C159E632A9839540D8662D18DFCDE73D7A (void);
// 0x000000B2 System.Single Cinemachine.CinemachineConfiner2D::CalculateHalfFrustumHeight(Cinemachine.CameraState&,System.Single&)
extern void CinemachineConfiner2D_CalculateHalfFrustumHeight_mDDE47FAE3C3F2353008872F77D39FF651AA1A878 (void);
// 0x000000B3 System.Void Cinemachine.CinemachineConfiner2D::OnValidate()
extern void CinemachineConfiner2D_OnValidate_m6A0CD8665FF1FDB4AF2AE8F74B6CBC4BD2EAA975 (void);
// 0x000000B4 System.Void Cinemachine.CinemachineConfiner2D::Reset()
extern void CinemachineConfiner2D_Reset_mAA5D5DC189C57A96F8858ADB7C67DC9DBAC9286F (void);
// 0x000000B5 System.Void Cinemachine.CinemachineConfiner2D::.ctor()
extern void CinemachineConfiner2D__ctor_mA19C91BD9ED4615AFDC73AFFC750E1A13B89A4A2 (void);
// 0x000000B6 System.Void Cinemachine.CinemachineConfiner2D/VcamExtraState::.ctor()
extern void VcamExtraState__ctor_m4230EE9C068362D2954AC73B33FF8B627D023268 (void);
// 0x000000B7 System.Void Cinemachine.CinemachineConfiner2D/ShapeCache::Invalidate()
extern void ShapeCache_Invalidate_m0AA1A789129A6F496BDB42C9914A48A80D0BB222 (void);
// 0x000000B8 System.Boolean Cinemachine.CinemachineConfiner2D/ShapeCache::ValidateCache(UnityEngine.Collider2D,System.Single,System.Single,System.Boolean&)
extern void ShapeCache_ValidateCache_mA040BB9D38360821A0D577FAA9520E12917B126C (void);
// 0x000000B9 System.Boolean Cinemachine.CinemachineConfiner2D/ShapeCache::IsValid(UnityEngine.Collider2D&,System.Single&,System.Single&)
extern void ShapeCache_IsValid_mD14BF34734A81849A719899A4F29ED241C21E25B (void);
// 0x000000BA System.Void Cinemachine.CinemachineConfiner2D/ShapeCache::CalculateDeltaTransformationMatrix()
extern void ShapeCache_CalculateDeltaTransformationMatrix_m11C29D7572FAF3F20A15F7144F6D46E8A909E114 (void);
// 0x000000BB System.Void Cinemachine.CinemachineDollyCart::FixedUpdate()
extern void CinemachineDollyCart_FixedUpdate_m4D0344645368A13DE5E1902FD2409FD75EF64622 (void);
// 0x000000BC System.Void Cinemachine.CinemachineDollyCart::Update()
extern void CinemachineDollyCart_Update_m7245871A1EF878D2225D3278616830FFDEA94632 (void);
// 0x000000BD System.Void Cinemachine.CinemachineDollyCart::LateUpdate()
extern void CinemachineDollyCart_LateUpdate_m31652825AA7DF3A37F1FF45F7987A41FF15EB629 (void);
// 0x000000BE System.Void Cinemachine.CinemachineDollyCart::SetCartPosition(System.Single)
extern void CinemachineDollyCart_SetCartPosition_mF463212396484570037D81562ED14A21ECFD746F (void);
// 0x000000BF System.Void Cinemachine.CinemachineDollyCart::.ctor()
extern void CinemachineDollyCart__ctor_m10FE44DB9AC13A98B146DF4DAAE74E0B642E5068 (void);
// 0x000000C0 Cinemachine.CameraState Cinemachine.CinemachineExternalCamera::get_State()
extern void CinemachineExternalCamera_get_State_mC19729B5B332F8A68ACFF3A3AA3594610B52D7FE (void);
// 0x000000C1 UnityEngine.Transform Cinemachine.CinemachineExternalCamera::get_LookAt()
extern void CinemachineExternalCamera_get_LookAt_m4BBF19283ED8933F78E0A0947D31E21952029ED4 (void);
// 0x000000C2 System.Void Cinemachine.CinemachineExternalCamera::set_LookAt(UnityEngine.Transform)
extern void CinemachineExternalCamera_set_LookAt_m6B06EE0A2DF54EBCACFB4AF2FDFA7CE1FBA6956D (void);
// 0x000000C3 UnityEngine.Transform Cinemachine.CinemachineExternalCamera::get_Follow()
extern void CinemachineExternalCamera_get_Follow_m8FD9C12520C69C131111698EA1C532595B2F795A (void);
// 0x000000C4 System.Void Cinemachine.CinemachineExternalCamera::set_Follow(UnityEngine.Transform)
extern void CinemachineExternalCamera_set_Follow_mE72DB58A3B9A095A004E9A11F5A13E07DB40DB8E (void);
// 0x000000C5 System.Void Cinemachine.CinemachineExternalCamera::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
extern void CinemachineExternalCamera_InternalUpdateCameraState_m51FFCDE49F3209EF2A25426838FE54BEA17736C9 (void);
// 0x000000C6 System.Void Cinemachine.CinemachineExternalCamera::.ctor()
extern void CinemachineExternalCamera__ctor_m3F3ABDD19589BAA8C55855E465E86F94B7C21DA8 (void);
// 0x000000C7 System.Void Cinemachine.CinemachineFollowZoom::OnValidate()
extern void CinemachineFollowZoom_OnValidate_mC3D5E5866F335052F48BD2B6AA47859E9AE291DB (void);
// 0x000000C8 System.Single Cinemachine.CinemachineFollowZoom::GetMaxDampTime()
extern void CinemachineFollowZoom_GetMaxDampTime_m7FCFDC2095BEE662F4AC60386D268C2224984F66 (void);
// 0x000000C9 System.Void Cinemachine.CinemachineFollowZoom::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore/Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachineFollowZoom_PostPipelineStageCallback_m584E4DE4F681FE16D996E5D6FBE4A17F2FF5B4B3 (void);
// 0x000000CA System.Void Cinemachine.CinemachineFollowZoom::.ctor()
extern void CinemachineFollowZoom__ctor_mB268F9C261AF80E1B1B8CBD60F439C7CBA594E43 (void);
// 0x000000CB System.Void Cinemachine.CinemachineFollowZoom/VcamExtraState::.ctor()
extern void VcamExtraState__ctor_m765B777C8201B5A5D21FB547AA0215538E7CD976 (void);
// 0x000000CC System.Void Cinemachine.CinemachineFreeLook::OnValidate()
extern void CinemachineFreeLook_OnValidate_mE135CB8F257CA150B766E7490EDB6617686C1FC8 (void);
// 0x000000CD Cinemachine.CinemachineVirtualCamera Cinemachine.CinemachineFreeLook::GetRig(System.Int32)
extern void CinemachineFreeLook_GetRig_mD0E1903ADCEA69937E23407FC0837F5EED5F7D2B (void);
// 0x000000CE System.String[] Cinemachine.CinemachineFreeLook::get_RigNames()
extern void CinemachineFreeLook_get_RigNames_m28ACE9396AC7E90228CF3E5AFB579391AEC91B26 (void);
// 0x000000CF System.Void Cinemachine.CinemachineFreeLook::OnEnable()
extern void CinemachineFreeLook_OnEnable_mF37DBE66B28EFDB12E5EB7E2FECDE8D387E4EA64 (void);
// 0x000000D0 System.Void Cinemachine.CinemachineFreeLook::UpdateInputAxisProvider()
extern void CinemachineFreeLook_UpdateInputAxisProvider_mD39FCA17EFAEAF3B386FAB2D171614DBE6878BE4 (void);
// 0x000000D1 System.Void Cinemachine.CinemachineFreeLook::OnDestroy()
extern void CinemachineFreeLook_OnDestroy_mE5A0B7181DD0B540EA62AA950FFB709B6FE37881 (void);
// 0x000000D2 System.Void Cinemachine.CinemachineFreeLook::OnTransformChildrenChanged()
extern void CinemachineFreeLook_OnTransformChildrenChanged_m736136F5AEFE8FCEE9AE92AC05BC9F99FBD77021 (void);
// 0x000000D3 System.Void Cinemachine.CinemachineFreeLook::Reset()
extern void CinemachineFreeLook_Reset_mD2D2A20865B0566F643B934832120872678945C4 (void);
// 0x000000D4 System.Boolean Cinemachine.CinemachineFreeLook::get_PreviousStateIsValid()
extern void CinemachineFreeLook_get_PreviousStateIsValid_m5401DE3AB054991B6A5FE6234347ECE270585DE1 (void);
// 0x000000D5 System.Void Cinemachine.CinemachineFreeLook::set_PreviousStateIsValid(System.Boolean)
extern void CinemachineFreeLook_set_PreviousStateIsValid_m55D8DBBB19BE26486ED23321D4F636209A4EADD3 (void);
// 0x000000D6 Cinemachine.CameraState Cinemachine.CinemachineFreeLook::get_State()
extern void CinemachineFreeLook_get_State_mC1F5503F677EFDBE8F7C13AB4861A85289B11851 (void);
// 0x000000D7 UnityEngine.Transform Cinemachine.CinemachineFreeLook::get_LookAt()
extern void CinemachineFreeLook_get_LookAt_mDC4E1C325D8ABCE90EA23927B556A1CEDCE2E466 (void);
// 0x000000D8 System.Void Cinemachine.CinemachineFreeLook::set_LookAt(UnityEngine.Transform)
extern void CinemachineFreeLook_set_LookAt_m6469D5D82E61E12547F31B056318A02901320ED9 (void);
// 0x000000D9 UnityEngine.Transform Cinemachine.CinemachineFreeLook::get_Follow()
extern void CinemachineFreeLook_get_Follow_mAE291B3D732A26FB2F8303A21E5B02C7B0F71AD5 (void);
// 0x000000DA System.Void Cinemachine.CinemachineFreeLook::set_Follow(UnityEngine.Transform)
extern void CinemachineFreeLook_set_Follow_m60B250844E32FA860F71485B30FC96E6DFC39C12 (void);
// 0x000000DB System.Boolean Cinemachine.CinemachineFreeLook::IsLiveChild(Cinemachine.ICinemachineCamera,System.Boolean)
extern void CinemachineFreeLook_IsLiveChild_mE77CF2865D9484DBC51179C160279DE1A2AB75A0 (void);
// 0x000000DC System.Void Cinemachine.CinemachineFreeLook::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineFreeLook_OnTargetObjectWarped_m9538B8833BA2618E0DFFB92D2D5E21EBE2F6F378 (void);
// 0x000000DD System.Void Cinemachine.CinemachineFreeLook::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineFreeLook_ForceCameraPosition_m61E084EAFA63BD5901D9471DBECA196063CD2BCF (void);
// 0x000000DE System.Void Cinemachine.CinemachineFreeLook::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
extern void CinemachineFreeLook_InternalUpdateCameraState_m4BEF8106D7C7379527BED810D348A1AEE7B456E4 (void);
// 0x000000DF System.Void Cinemachine.CinemachineFreeLook::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void CinemachineFreeLook_OnTransitionFromCamera_m7A5C9529C4641C09776A3F5B87B9A8D698C3DE6D (void);
// 0x000000E0 System.Single Cinemachine.CinemachineFreeLook::GetYAxisClosestValue(UnityEngine.Vector3,UnityEngine.Vector3)
extern void CinemachineFreeLook_GetYAxisClosestValue_m0305399E0E68EE0A9FA2F56EFAE695517C79F584 (void);
// 0x000000E1 System.Void Cinemachine.CinemachineFreeLook::InvalidateRigCache()
extern void CinemachineFreeLook_InvalidateRigCache_m55DF47CBD6057175CBC0513574054639D51D6C7E (void);
// 0x000000E2 System.Void Cinemachine.CinemachineFreeLook::DestroyRigs()
extern void CinemachineFreeLook_DestroyRigs_m46892877143B854CDA899600B23F789F092FFA79 (void);
// 0x000000E3 Cinemachine.CinemachineVirtualCamera[] Cinemachine.CinemachineFreeLook::CreateRigs(Cinemachine.CinemachineVirtualCamera[])
extern void CinemachineFreeLook_CreateRigs_m1B4A9DC51DCE61E3B384B49E75E94FEA50B865E6 (void);
// 0x000000E4 System.Void Cinemachine.CinemachineFreeLook::UpdateRigCache()
extern void CinemachineFreeLook_UpdateRigCache_m1D9A5655874FB2B2BFF82C8B4CAE75B804A9D458 (void);
// 0x000000E5 System.Int32 Cinemachine.CinemachineFreeLook::LocateExistingRigs(System.String[],System.Boolean)
extern void CinemachineFreeLook_LocateExistingRigs_mFA72C01A434055FF70E58504CBE649C3A19A935E (void);
// 0x000000E6 System.Single Cinemachine.CinemachineFreeLook::get_CachedXAxisHeading()
extern void CinemachineFreeLook_get_CachedXAxisHeading_m7B1719BF031EED297D56A9DB32C2F63C018CB636 (void);
// 0x000000E7 System.Void Cinemachine.CinemachineFreeLook::set_CachedXAxisHeading(System.Single)
extern void CinemachineFreeLook_set_CachedXAxisHeading_m11AEDBEB4865CFECA9235C8D3320B45DE0EC56C1 (void);
// 0x000000E8 System.Single Cinemachine.CinemachineFreeLook::UpdateXAxisHeading(Cinemachine.CinemachineOrbitalTransposer,System.Single,UnityEngine.Vector3)
extern void CinemachineFreeLook_UpdateXAxisHeading_mC7FB1633258C9ADCBE6D379B3865D1DFCB696088 (void);
// 0x000000E9 System.Void Cinemachine.CinemachineFreeLook::PushSettingsToRigs()
extern void CinemachineFreeLook_PushSettingsToRigs_mEEA5AE1B6B7E64CD3E52DAD1F020AF52C2D5C030 (void);
// 0x000000EA System.Single Cinemachine.CinemachineFreeLook::GetYAxisValue()
extern void CinemachineFreeLook_GetYAxisValue_m82E8DA8F7257DEA0BFBFCC41FDB2E214907A9C88 (void);
// 0x000000EB Cinemachine.CameraState Cinemachine.CinemachineFreeLook::CalculateNewState(UnityEngine.Vector3,System.Single)
extern void CinemachineFreeLook_CalculateNewState_mDEC0D03EDD0F2C9521E25A5E6FCFBE66049E3869 (void);
// 0x000000EC UnityEngine.Vector3 Cinemachine.CinemachineFreeLook::GetLocalPositionForCameraFromInput(System.Single)
extern void CinemachineFreeLook_GetLocalPositionForCameraFromInput_m30BECF828556595138D0AE9908D6009E5BB0E7EE (void);
// 0x000000ED System.Void Cinemachine.CinemachineFreeLook::UpdateCachedSpline()
extern void CinemachineFreeLook_UpdateCachedSpline_m1275143847991676F4E0F292FC8CFCD0CE89E382 (void);
// 0x000000EE System.Void Cinemachine.CinemachineFreeLook::.ctor()
extern void CinemachineFreeLook__ctor_m04F403D8675C975D63009E36A843B28BBD0DDE3E (void);
// 0x000000EF System.Void Cinemachine.CinemachineFreeLook/Orbit::.ctor(System.Single,System.Single)
extern void Orbit__ctor_mBDC642CE7F3E574E43895420FD0343C3199FC85A (void);
// 0x000000F0 System.Void Cinemachine.CinemachineFreeLook/CreateRigDelegate::.ctor(System.Object,System.IntPtr)
extern void CreateRigDelegate__ctor_m4DD0C7DBDBDA591D52EA8F0328BAB450BFCF51C2 (void);
// 0x000000F1 Cinemachine.CinemachineVirtualCamera Cinemachine.CinemachineFreeLook/CreateRigDelegate::Invoke(Cinemachine.CinemachineFreeLook,System.String,Cinemachine.CinemachineVirtualCamera)
extern void CreateRigDelegate_Invoke_mAD1425DD908EFF6A0D37E425A6A2503EB0C0D6F9 (void);
// 0x000000F2 System.IAsyncResult Cinemachine.CinemachineFreeLook/CreateRigDelegate::BeginInvoke(Cinemachine.CinemachineFreeLook,System.String,Cinemachine.CinemachineVirtualCamera,System.AsyncCallback,System.Object)
extern void CreateRigDelegate_BeginInvoke_m3026592E9652091C21A95142D9C9840AAE61EBAD (void);
// 0x000000F3 Cinemachine.CinemachineVirtualCamera Cinemachine.CinemachineFreeLook/CreateRigDelegate::EndInvoke(System.IAsyncResult)
extern void CreateRigDelegate_EndInvoke_mDDDCBA482E40537F256E8B0F686EA019C7FC42F7 (void);
// 0x000000F4 System.Void Cinemachine.CinemachineFreeLook/DestroyRigDelegate::.ctor(System.Object,System.IntPtr)
extern void DestroyRigDelegate__ctor_m6B51E8D805DD7A663BE724FC16D490F5D0D05D69 (void);
// 0x000000F5 System.Void Cinemachine.CinemachineFreeLook/DestroyRigDelegate::Invoke(UnityEngine.GameObject)
extern void DestroyRigDelegate_Invoke_mE9C9FD19BE4FD0204687FA43F0C771C3C77E11C6 (void);
// 0x000000F6 System.IAsyncResult Cinemachine.CinemachineFreeLook/DestroyRigDelegate::BeginInvoke(UnityEngine.GameObject,System.AsyncCallback,System.Object)
extern void DestroyRigDelegate_BeginInvoke_mC12BBE33DEEA306A7AE1FFD1E961069DCC252BE5 (void);
// 0x000000F7 System.Void Cinemachine.CinemachineFreeLook/DestroyRigDelegate::EndInvoke(System.IAsyncResult)
extern void DestroyRigDelegate_EndInvoke_mE037D325234815525A86DF33050DE927EFCD8F22 (void);
// 0x000000F8 System.Single Cinemachine.CinemachineMixingCamera::GetWeight(System.Int32)
extern void CinemachineMixingCamera_GetWeight_mC56767C284E7B6C5441789F5D7022B9EC93342E6 (void);
// 0x000000F9 System.Void Cinemachine.CinemachineMixingCamera::SetWeight(System.Int32,System.Single)
extern void CinemachineMixingCamera_SetWeight_mD8CB5271CD81FB934D08D156797DF143BD58DA7A (void);
// 0x000000FA System.Single Cinemachine.CinemachineMixingCamera::GetWeight(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineMixingCamera_GetWeight_mD30103E9B0B8B54EEAB6A07179BE0688B8A18C6B (void);
// 0x000000FB System.Void Cinemachine.CinemachineMixingCamera::SetWeight(Cinemachine.CinemachineVirtualCameraBase,System.Single)
extern void CinemachineMixingCamera_SetWeight_mB1C14E27249BB10421D396CCFEF41D8E18A7CDB3 (void);
// 0x000000FC System.Void Cinemachine.CinemachineMixingCamera::set_LiveChild(Cinemachine.ICinemachineCamera)
extern void CinemachineMixingCamera_set_LiveChild_m2CAA747551619F08D9AF611F73E8740655A64296 (void);
// 0x000000FD Cinemachine.ICinemachineCamera Cinemachine.CinemachineMixingCamera::get_LiveChild()
extern void CinemachineMixingCamera_get_LiveChild_m3D4BAA0AB4486CFA6DEF9EAC84CAAD32FA78EA95 (void);
// 0x000000FE Cinemachine.CameraState Cinemachine.CinemachineMixingCamera::get_State()
extern void CinemachineMixingCamera_get_State_m58D60DAFE877B686344651AF345BA29EB84CA8CC (void);
// 0x000000FF UnityEngine.Transform Cinemachine.CinemachineMixingCamera::get_LookAt()
extern void CinemachineMixingCamera_get_LookAt_m455A20326F89344D9D2B005BEDED109EB439088B (void);
// 0x00000100 System.Void Cinemachine.CinemachineMixingCamera::set_LookAt(UnityEngine.Transform)
extern void CinemachineMixingCamera_set_LookAt_m93815AF154ABAC9FF37C7EE237BDFDABFC1CAFB3 (void);
// 0x00000101 UnityEngine.Transform Cinemachine.CinemachineMixingCamera::get_Follow()
extern void CinemachineMixingCamera_get_Follow_m8CCF58027181B96B84CB8EFD681D072E585FBA8E (void);
// 0x00000102 System.Void Cinemachine.CinemachineMixingCamera::set_Follow(UnityEngine.Transform)
extern void CinemachineMixingCamera_set_Follow_m1ECE7574D20C273C49204FE5B775EC85B2605210 (void);
// 0x00000103 System.Void Cinemachine.CinemachineMixingCamera::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineMixingCamera_OnTargetObjectWarped_mADD9E1BD4142606182E1E3BC9F9D204A981ED905 (void);
// 0x00000104 System.Void Cinemachine.CinemachineMixingCamera::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineMixingCamera_ForceCameraPosition_mF1729BA8B700A249B80DE3EF66451DD422AEFD98 (void);
// 0x00000105 System.Void Cinemachine.CinemachineMixingCamera::OnEnable()
extern void CinemachineMixingCamera_OnEnable_mB327FAC23649E787522822C97B2BAAA8B0B01011 (void);
// 0x00000106 System.Void Cinemachine.CinemachineMixingCamera::OnTransformChildrenChanged()
extern void CinemachineMixingCamera_OnTransformChildrenChanged_m78AE7E56D39CB09C2A55DB891DCE4C0D405B3A3B (void);
// 0x00000107 System.Void Cinemachine.CinemachineMixingCamera::OnValidate()
extern void CinemachineMixingCamera_OnValidate_m66D4D52438E5171467EDA22E164B64BA590AA6E5 (void);
// 0x00000108 System.Boolean Cinemachine.CinemachineMixingCamera::IsLiveChild(Cinemachine.ICinemachineCamera,System.Boolean)
extern void CinemachineMixingCamera_IsLiveChild_m4E66C3C7A8A5F20C26E4E8519D3590E86F328613 (void);
// 0x00000109 Cinemachine.CinemachineVirtualCameraBase[] Cinemachine.CinemachineMixingCamera::get_ChildCameras()
extern void CinemachineMixingCamera_get_ChildCameras_m17AAB894A5692CADB6B886AE1823D0007895FB53 (void);
// 0x0000010A System.Void Cinemachine.CinemachineMixingCamera::InvalidateListOfChildren()
extern void CinemachineMixingCamera_InvalidateListOfChildren_m18EC553FC321BD26E1FDEE748A9D6398EC7F6B3D (void);
// 0x0000010B System.Void Cinemachine.CinemachineMixingCamera::ValidateListOfChildren()
extern void CinemachineMixingCamera_ValidateListOfChildren_m0592C962C4CF7089FE842F109D0CD3476410B5CB (void);
// 0x0000010C System.Void Cinemachine.CinemachineMixingCamera::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void CinemachineMixingCamera_OnTransitionFromCamera_mA2504937FEC4E030494B431DB73A8FB2801E40CC (void);
// 0x0000010D System.Void Cinemachine.CinemachineMixingCamera::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
extern void CinemachineMixingCamera_InternalUpdateCameraState_m95CC38FD924BF718EF4DC7E94B6259E348129112 (void);
// 0x0000010E System.Void Cinemachine.CinemachineMixingCamera::.ctor()
extern void CinemachineMixingCamera__ctor_m5EDF2B338827BF9600E05C360499BB6C8C06E04F (void);
// 0x0000010F System.Single Cinemachine.CinemachinePath::get_MinPos()
extern void CinemachinePath_get_MinPos_m44196276E27917CFAA83FCB6805385F0F49B68E6 (void);
// 0x00000110 System.Single Cinemachine.CinemachinePath::get_MaxPos()
extern void CinemachinePath_get_MaxPos_m19CBE9ADEA5F1C8153554117E936EE73430A1B7A (void);
// 0x00000111 System.Boolean Cinemachine.CinemachinePath::get_Looped()
extern void CinemachinePath_get_Looped_mDC5688C64BEAD83BB772379AF6A94B3D69724F5E (void);
// 0x00000112 System.Void Cinemachine.CinemachinePath::Reset()
extern void CinemachinePath_Reset_mDBB3432FB87DC834F93DC9FFE56204F059186030 (void);
// 0x00000113 System.Int32 Cinemachine.CinemachinePath::get_DistanceCacheSampleStepsPerSegment()
extern void CinemachinePath_get_DistanceCacheSampleStepsPerSegment_m040784C32B8D4D2D119AB9C189B7761FEAE717AD (void);
// 0x00000114 System.Single Cinemachine.CinemachinePath::GetBoundingIndices(System.Single,System.Int32&,System.Int32&)
extern void CinemachinePath_GetBoundingIndices_m907FB06C7E158858C9828D4228AC5317A500B107 (void);
// 0x00000115 UnityEngine.Vector3 Cinemachine.CinemachinePath::EvaluatePosition(System.Single)
extern void CinemachinePath_EvaluatePosition_m748123187AAE027319421C5A040783252BA333EB (void);
// 0x00000116 UnityEngine.Vector3 Cinemachine.CinemachinePath::EvaluateTangent(System.Single)
extern void CinemachinePath_EvaluateTangent_m58EFD2AF91AACB4716EF1142DA729FE99A3C4680 (void);
// 0x00000117 UnityEngine.Quaternion Cinemachine.CinemachinePath::EvaluateOrientation(System.Single)
extern void CinemachinePath_EvaluateOrientation_mC2FC02F92747630BBBC1CAF8E388A50D9701C610 (void);
// 0x00000118 System.Void Cinemachine.CinemachinePath::OnValidate()
extern void CinemachinePath_OnValidate_mA799B5C87BE67DD6CD5A94ED498AB1313E7247A5 (void);
// 0x00000119 System.Void Cinemachine.CinemachinePath::.ctor()
extern void CinemachinePath__ctor_m29E35B45E4AF67EC3D12CED0F10D7C9014115765 (void);
// 0x0000011A System.Void Cinemachine.CinemachinePipeline::.ctor()
extern void CinemachinePipeline__ctor_mA25F961124A6357A5F945EED40D0FBD495840695 (void);
// 0x0000011B System.Void Cinemachine.CinemachinePixelPerfect::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore/Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachinePixelPerfect_PostPipelineStageCallback_mD4F59744645E787D73375AE345486512EF2C284A (void);
// 0x0000011C System.Void Cinemachine.CinemachinePixelPerfect::.ctor()
extern void CinemachinePixelPerfect__ctor_m3AFA2D3FFAB18B940EE356FD8FE96724CBCFD987 (void);
// 0x0000011D System.Single Cinemachine.CinemachineSmoothPath::get_MinPos()
extern void CinemachineSmoothPath_get_MinPos_m6E0E2A097F67A6B10D6CAC35922DA832B7192598 (void);
// 0x0000011E System.Single Cinemachine.CinemachineSmoothPath::get_MaxPos()
extern void CinemachineSmoothPath_get_MaxPos_m47FAC15FD184422858C94D12FB59C0DF68196B9A (void);
// 0x0000011F System.Boolean Cinemachine.CinemachineSmoothPath::get_Looped()
extern void CinemachineSmoothPath_get_Looped_m581212992BAC29DDBA308B93A7E078EA7757BEFB (void);
// 0x00000120 System.Int32 Cinemachine.CinemachineSmoothPath::get_DistanceCacheSampleStepsPerSegment()
extern void CinemachineSmoothPath_get_DistanceCacheSampleStepsPerSegment_m1B87916ED182DE5DF0033DFD586A9205E087C8EA (void);
// 0x00000121 System.Void Cinemachine.CinemachineSmoothPath::OnValidate()
extern void CinemachineSmoothPath_OnValidate_m0D0A65B796AA7D6014FF0FC2B2171EA5DB0DD422 (void);
// 0x00000122 System.Void Cinemachine.CinemachineSmoothPath::Reset()
extern void CinemachineSmoothPath_Reset_m667726E5707A48BA067A7A7133857087FDC4058E (void);
// 0x00000123 System.Void Cinemachine.CinemachineSmoothPath::InvalidateDistanceCache()
extern void CinemachineSmoothPath_InvalidateDistanceCache_mC7B4228D400267E0F50D1F8E65696DFE40D28F55 (void);
// 0x00000124 System.Void Cinemachine.CinemachineSmoothPath::UpdateControlPoints()
extern void CinemachineSmoothPath_UpdateControlPoints_m2F8ADDDCC7E141ED441095D92EA8723A6C2380D6 (void);
// 0x00000125 System.Single Cinemachine.CinemachineSmoothPath::GetBoundingIndices(System.Single,System.Int32&,System.Int32&)
extern void CinemachineSmoothPath_GetBoundingIndices_mE692833D63163F7B69AD841A2EA29D7F4A9BE752 (void);
// 0x00000126 UnityEngine.Vector3 Cinemachine.CinemachineSmoothPath::EvaluatePosition(System.Single)
extern void CinemachineSmoothPath_EvaluatePosition_mCCAABE1DD14E499B981C439C9F30C68F21A66100 (void);
// 0x00000127 UnityEngine.Vector3 Cinemachine.CinemachineSmoothPath::EvaluateTangent(System.Single)
extern void CinemachineSmoothPath_EvaluateTangent_m0D0D59143BB5132ABD5433E90817F44B302C6B26 (void);
// 0x00000128 UnityEngine.Quaternion Cinemachine.CinemachineSmoothPath::EvaluateOrientation(System.Single)
extern void CinemachineSmoothPath_EvaluateOrientation_mEC5A8EA90524DE4125735E85D9FCC5080D8B065B (void);
// 0x00000129 UnityEngine.Quaternion Cinemachine.CinemachineSmoothPath::RollAroundForward(System.Single)
extern void CinemachineSmoothPath_RollAroundForward_m6D915BAFDE9ECFAC37C521C4F662D68134417065 (void);
// 0x0000012A System.Void Cinemachine.CinemachineSmoothPath::.ctor()
extern void CinemachineSmoothPath__ctor_m45C209574B2FCAE3239F335EF383D4D513DB7623 (void);
// 0x0000012B UnityEngine.Vector4 Cinemachine.CinemachineSmoothPath/Waypoint::get_AsVector4()
extern void Waypoint_get_AsVector4_m9CB420052E5FB5EA1681133222C5EB982BEA6BAC (void);
// 0x0000012C Cinemachine.CinemachineSmoothPath/Waypoint Cinemachine.CinemachineSmoothPath/Waypoint::FromVector4(UnityEngine.Vector4)
extern void Waypoint_FromVector4_m1F859E37CBC871BC98DC89550A1C6B264E46FB2A (void);
// 0x0000012D System.String Cinemachine.CinemachineStateDrivenCamera::get_Description()
extern void CinemachineStateDrivenCamera_get_Description_m721AB0951987E2034EA458440177C8EF9528CAD5 (void);
// 0x0000012E System.Void Cinemachine.CinemachineStateDrivenCamera::set_LiveChild(Cinemachine.ICinemachineCamera)
extern void CinemachineStateDrivenCamera_set_LiveChild_m58CFBD5BCD7718A20DB92DFCB57407A51DB967AE (void);
// 0x0000012F Cinemachine.ICinemachineCamera Cinemachine.CinemachineStateDrivenCamera::get_LiveChild()
extern void CinemachineStateDrivenCamera_get_LiveChild_m4FE60C58C46FDB216A5B65BE67166D2715711A3A (void);
// 0x00000130 System.Boolean Cinemachine.CinemachineStateDrivenCamera::IsLiveChild(Cinemachine.ICinemachineCamera,System.Boolean)
extern void CinemachineStateDrivenCamera_IsLiveChild_mDB2DC4068402D3D55B40D792828EBB8C32A083E3 (void);
// 0x00000131 Cinemachine.CameraState Cinemachine.CinemachineStateDrivenCamera::get_State()
extern void CinemachineStateDrivenCamera_get_State_m5A79A831DF33719426266F8DC14CE7BC74DAD1A7 (void);
// 0x00000132 UnityEngine.Transform Cinemachine.CinemachineStateDrivenCamera::get_LookAt()
extern void CinemachineStateDrivenCamera_get_LookAt_m8DC447924D0D74AFE9F9EE6528A4A71640720560 (void);
// 0x00000133 System.Void Cinemachine.CinemachineStateDrivenCamera::set_LookAt(UnityEngine.Transform)
extern void CinemachineStateDrivenCamera_set_LookAt_m58802064EE2F513FCB7FFCA3FF421BA36CA340ED (void);
// 0x00000134 UnityEngine.Transform Cinemachine.CinemachineStateDrivenCamera::get_Follow()
extern void CinemachineStateDrivenCamera_get_Follow_m7B3B9088B452F0AC4803FEA6C0B21BE0359E6517 (void);
// 0x00000135 System.Void Cinemachine.CinemachineStateDrivenCamera::set_Follow(UnityEngine.Transform)
extern void CinemachineStateDrivenCamera_set_Follow_mDFD75630E23CC129D727B564643EE86C58314284 (void);
// 0x00000136 System.Void Cinemachine.CinemachineStateDrivenCamera::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineStateDrivenCamera_OnTargetObjectWarped_mF70391759212BE63CEB7FB51B0A45B93157A14D8 (void);
// 0x00000137 System.Void Cinemachine.CinemachineStateDrivenCamera::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineStateDrivenCamera_ForceCameraPosition_m29A24C9E4E02555029FD1FC6912BB3D54A35B156 (void);
// 0x00000138 System.Void Cinemachine.CinemachineStateDrivenCamera::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void CinemachineStateDrivenCamera_OnTransitionFromCamera_mEBE4A9F7099581DD5988F7D06E19056C906DEA19 (void);
// 0x00000139 Cinemachine.ICinemachineCamera Cinemachine.CinemachineStateDrivenCamera::get_TransitioningFrom()
extern void CinemachineStateDrivenCamera_get_TransitioningFrom_m6D611FD16354DACC78A99F2B8E3CC13327CCF104 (void);
// 0x0000013A System.Void Cinemachine.CinemachineStateDrivenCamera::set_TransitioningFrom(Cinemachine.ICinemachineCamera)
extern void CinemachineStateDrivenCamera_set_TransitioningFrom_mC376F532563E04695BD810AFB8FF63589AD82B5C (void);
// 0x0000013B System.Void Cinemachine.CinemachineStateDrivenCamera::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
extern void CinemachineStateDrivenCamera_InternalUpdateCameraState_m15DA964B37A1A8B67ACC8D3429089D1948F3FD92 (void);
// 0x0000013C System.Void Cinemachine.CinemachineStateDrivenCamera::OnEnable()
extern void CinemachineStateDrivenCamera_OnEnable_m73592A142BE908F77B0AA271DAB6D3931F0985AB (void);
// 0x0000013D System.Void Cinemachine.CinemachineStateDrivenCamera::OnDisable()
extern void CinemachineStateDrivenCamera_OnDisable_m0A9782361F2D03D44648E382D7CF8C43BB9C30A0 (void);
// 0x0000013E System.Void Cinemachine.CinemachineStateDrivenCamera::OnTransformChildrenChanged()
extern void CinemachineStateDrivenCamera_OnTransformChildrenChanged_mC0E38B870F9476DB6863BCB16D18C36B9BBFFECD (void);
// 0x0000013F System.Void Cinemachine.CinemachineStateDrivenCamera::OnGuiHandler()
extern void CinemachineStateDrivenCamera_OnGuiHandler_mDB24B0B122B8F3CF847139FDC147B7F3CBFE3F05 (void);
// 0x00000140 Cinemachine.CinemachineVirtualCameraBase[] Cinemachine.CinemachineStateDrivenCamera::get_ChildCameras()
extern void CinemachineStateDrivenCamera_get_ChildCameras_m4C9CBF7126E384CDBBB2AAFE86108F43A2DF6E52 (void);
// 0x00000141 System.Boolean Cinemachine.CinemachineStateDrivenCamera::get_IsBlending()
extern void CinemachineStateDrivenCamera_get_IsBlending_mD0DC02C494368EF1946180D261E072CC70A859C5 (void);
// 0x00000142 System.Int32 Cinemachine.CinemachineStateDrivenCamera::CreateFakeHash(System.Int32,UnityEngine.AnimationClip)
extern void CinemachineStateDrivenCamera_CreateFakeHash_m1B5D689454467E54101D56E7FC1096E4E709B80F (void);
// 0x00000143 System.Int32 Cinemachine.CinemachineStateDrivenCamera::LookupFakeHash(System.Int32,UnityEngine.AnimationClip)
extern void CinemachineStateDrivenCamera_LookupFakeHash_m06759C84A0584A1F9F290C5E58DFB0FF0AE4BD5B (void);
// 0x00000144 System.Void Cinemachine.CinemachineStateDrivenCamera::InvalidateListOfChildren()
extern void CinemachineStateDrivenCamera_InvalidateListOfChildren_m09761689924E32C52613DFE05E80CD9D7FC3AA0E (void);
// 0x00000145 System.Void Cinemachine.CinemachineStateDrivenCamera::UpdateListOfChildren()
extern void CinemachineStateDrivenCamera_UpdateListOfChildren_mBA707781DC4090145A34A24903B7F08FD0875AF8 (void);
// 0x00000146 System.Void Cinemachine.CinemachineStateDrivenCamera::ValidateInstructions()
extern void CinemachineStateDrivenCamera_ValidateInstructions_m3283C4B0462AC49AAFDBF8020BFCD8E296E7542B (void);
// 0x00000147 Cinemachine.CinemachineVirtualCameraBase Cinemachine.CinemachineStateDrivenCamera::ChooseCurrentCamera()
extern void CinemachineStateDrivenCamera_ChooseCurrentCamera_m3D70AE6707397EEE221D01F8B25119B2BC7A370F (void);
// 0x00000148 System.Int32 Cinemachine.CinemachineStateDrivenCamera::GetClipHash(System.Int32,System.Collections.Generic.List`1<UnityEngine.AnimatorClipInfo>)
extern void CinemachineStateDrivenCamera_GetClipHash_mAD02DF3C8A12333C4D93FF1DA54D30B4DF2178CA (void);
// 0x00000149 Cinemachine.CinemachineBlendDefinition Cinemachine.CinemachineStateDrivenCamera::LookupBlend(Cinemachine.ICinemachineCamera,Cinemachine.ICinemachineCamera)
extern void CinemachineStateDrivenCamera_LookupBlend_mD0B7CD5CF181EDDABF0EFE90C829DC5DF5262C41 (void);
// 0x0000014A System.Void Cinemachine.CinemachineStateDrivenCamera::.ctor()
extern void CinemachineStateDrivenCamera__ctor_mB23005EB5EC0817BDFE10B9A1F0865DA83D3CBFE (void);
// 0x0000014B System.Void Cinemachine.CinemachineStateDrivenCamera/ParentHash::.ctor(System.Int32,System.Int32)
extern void ParentHash__ctor_mFD2F0C557399C8A6C3798E3CDC0EB58B5E82A094 (void);
// 0x0000014C System.Void Cinemachine.CinemachineStoryboard::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore/Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachineStoryboard_PostPipelineStageCallback_mCABE6FCDDBC249650661E7F9E4879D456950332B (void);
// 0x0000014D System.Void Cinemachine.CinemachineStoryboard::ConnectToVcam(System.Boolean)
extern void CinemachineStoryboard_ConnectToVcam_m8C550061C8C0F5CF8AA3D57DFCDC41C103FDF66D (void);
// 0x0000014E System.String Cinemachine.CinemachineStoryboard::get_CanvasName()
extern void CinemachineStoryboard_get_CanvasName_m7B8D386FB493150485E1D44C62A7096F2F657C5F (void);
// 0x0000014F System.Void Cinemachine.CinemachineStoryboard::CameraUpdatedCallback(Cinemachine.CinemachineBrain)
extern void CinemachineStoryboard_CameraUpdatedCallback_m234F18B313AD4C89E918AC2F4239FFE79E2C47CD (void);
// 0x00000150 Cinemachine.CinemachineStoryboard/CanvasInfo Cinemachine.CinemachineStoryboard::LocateMyCanvas(Cinemachine.CinemachineBrain,System.Boolean)
extern void CinemachineStoryboard_LocateMyCanvas_mCCD4AE8516711F4F7947F1403DEC3BD31879C6B6 (void);
// 0x00000151 System.Void Cinemachine.CinemachineStoryboard::CreateCanvas(Cinemachine.CinemachineStoryboard/CanvasInfo)
extern void CinemachineStoryboard_CreateCanvas_m8646630AFE1182FFF350AE7277070C881913905E (void);
// 0x00000152 System.Void Cinemachine.CinemachineStoryboard::DestroyCanvas()
extern void CinemachineStoryboard_DestroyCanvas_mDAE4469DDC233DADBC9940C3C50BE2F0AE15E7A7 (void);
// 0x00000153 System.Void Cinemachine.CinemachineStoryboard::PlaceImage(Cinemachine.CinemachineStoryboard/CanvasInfo,System.Single)
extern void CinemachineStoryboard_PlaceImage_m2B8471FE0B239D371527BB2670785AB6B86108AF (void);
// 0x00000154 System.Void Cinemachine.CinemachineStoryboard::StaticBlendingHandler(Cinemachine.CinemachineBrain)
extern void CinemachineStoryboard_StaticBlendingHandler_mB063E4C83DB301BC5F947A7E6E7830C40EE663B1 (void);
// 0x00000155 System.Void Cinemachine.CinemachineStoryboard::InitializeModule()
extern void CinemachineStoryboard_InitializeModule_m6F699FC72AEB7184BE2AEFF42BB6FC6794D44EB7 (void);
// 0x00000156 System.Void Cinemachine.CinemachineStoryboard::.ctor()
extern void CinemachineStoryboard__ctor_m5B6932E31A0425FB1C6EFDE4CC048CEC1F0B89ED (void);
// 0x00000157 System.Void Cinemachine.CinemachineStoryboard/CanvasInfo::.ctor()
extern void CanvasInfo__ctor_mD8E59D1746FD1DC9B497D9668DE2FACB016738DE (void);
// 0x00000158 UnityEngine.Transform Cinemachine.ICinemachineTargetGroup::get_Transform()
// 0x00000159 UnityEngine.Bounds Cinemachine.ICinemachineTargetGroup::get_BoundingBox()
// 0x0000015A UnityEngine.BoundingSphere Cinemachine.ICinemachineTargetGroup::get_Sphere()
// 0x0000015B System.Boolean Cinemachine.ICinemachineTargetGroup::get_IsEmpty()
// 0x0000015C UnityEngine.Bounds Cinemachine.ICinemachineTargetGroup::GetViewSpaceBoundingBox(UnityEngine.Matrix4x4)
// 0x0000015D System.Void Cinemachine.ICinemachineTargetGroup::GetViewSpaceAngularBounds(UnityEngine.Matrix4x4,UnityEngine.Vector2&,UnityEngine.Vector2&,UnityEngine.Vector2&)
// 0x0000015E UnityEngine.Transform Cinemachine.CinemachineTargetGroup::get_Transform()
extern void CinemachineTargetGroup_get_Transform_mADEBFE4BA9AF2FDC94C7302B1872D93B40F31586 (void);
// 0x0000015F UnityEngine.Bounds Cinemachine.CinemachineTargetGroup::get_BoundingBox()
extern void CinemachineTargetGroup_get_BoundingBox_mF6801A2838567BE9DE910D45D9BF05A760646933 (void);
// 0x00000160 System.Void Cinemachine.CinemachineTargetGroup::set_BoundingBox(UnityEngine.Bounds)
extern void CinemachineTargetGroup_set_BoundingBox_m4E6C1E1267D257AEDBA80318354B60A655D1097C (void);
// 0x00000161 UnityEngine.BoundingSphere Cinemachine.CinemachineTargetGroup::get_Sphere()
extern void CinemachineTargetGroup_get_Sphere_m3548B36218DC82389D27BAF6410BD34C1BBE75E8 (void);
// 0x00000162 System.Boolean Cinemachine.CinemachineTargetGroup::get_IsEmpty()
extern void CinemachineTargetGroup_get_IsEmpty_mA2CEE80C159101E17390EAE7A9F1E7F60ECA227C (void);
// 0x00000163 System.Void Cinemachine.CinemachineTargetGroup::AddMember(UnityEngine.Transform,System.Single,System.Single)
extern void CinemachineTargetGroup_AddMember_mDE00B3D9AB65CBAA2649A911C546D0D00170D67C (void);
// 0x00000164 System.Void Cinemachine.CinemachineTargetGroup::RemoveMember(UnityEngine.Transform)
extern void CinemachineTargetGroup_RemoveMember_mBAB8FD54B83FC8749A6709F8573FFB9B78A17E08 (void);
// 0x00000165 System.Int32 Cinemachine.CinemachineTargetGroup::FindMember(UnityEngine.Transform)
extern void CinemachineTargetGroup_FindMember_mD60C186B1844C2FF84E3B10D0F5952A89CCD614D (void);
// 0x00000166 UnityEngine.BoundingSphere Cinemachine.CinemachineTargetGroup::GetWeightedBoundsForMember(System.Int32)
extern void CinemachineTargetGroup_GetWeightedBoundsForMember_m879BB7436547F7658E13FE9D4B1E9831BF6983CE (void);
// 0x00000167 UnityEngine.Bounds Cinemachine.CinemachineTargetGroup::GetViewSpaceBoundingBox(UnityEngine.Matrix4x4)
extern void CinemachineTargetGroup_GetViewSpaceBoundingBox_m419CDD33E962D72D728E5351BE524B4887284BA0 (void);
// 0x00000168 UnityEngine.BoundingSphere Cinemachine.CinemachineTargetGroup::WeightedMemberBounds(Cinemachine.CinemachineTargetGroup/Target,UnityEngine.Vector3,System.Single)
extern void CinemachineTargetGroup_WeightedMemberBounds_mCBA0F61AABF001E2088F03BC99CF3200FC7C7CCA (void);
// 0x00000169 System.Void Cinemachine.CinemachineTargetGroup::DoUpdate()
extern void CinemachineTargetGroup_DoUpdate_m298B1536B6884019681B7DA4E50000ECE3B63D8E (void);
// 0x0000016A UnityEngine.BoundingSphere Cinemachine.CinemachineTargetGroup::CalculateBoundingSphere(System.Single)
extern void CinemachineTargetGroup_CalculateBoundingSphere_m0051F81C12A7F464D8E38E032A461C13BA483E36 (void);
// 0x0000016B UnityEngine.Vector3 Cinemachine.CinemachineTargetGroup::CalculateAveragePosition(System.Single&)
extern void CinemachineTargetGroup_CalculateAveragePosition_mF78C3AF8AAD414B79ECA6B7995BD8CEF3B51F88C (void);
// 0x0000016C UnityEngine.Quaternion Cinemachine.CinemachineTargetGroup::CalculateAverageOrientation()
extern void CinemachineTargetGroup_CalculateAverageOrientation_m4112A1C8E182CA4C8C5642F908A59FD21732E7F8 (void);
// 0x0000016D UnityEngine.Bounds Cinemachine.CinemachineTargetGroup::CalculateBoundingBox(UnityEngine.Vector3,System.Single)
extern void CinemachineTargetGroup_CalculateBoundingBox_m8FC29A766DAA5EA8D9D770A70C3BA3F33BCF9C45 (void);
// 0x0000016E System.Void Cinemachine.CinemachineTargetGroup::OnValidate()
extern void CinemachineTargetGroup_OnValidate_m00BCA97645EBF6D84D566D10ADADE897E573D300 (void);
// 0x0000016F System.Void Cinemachine.CinemachineTargetGroup::FixedUpdate()
extern void CinemachineTargetGroup_FixedUpdate_m51E54F0F8EB6C01A45EA6ADC82929B9D63A7D1C6 (void);
// 0x00000170 System.Void Cinemachine.CinemachineTargetGroup::Update()
extern void CinemachineTargetGroup_Update_m6CF5BB9923882A14E2EB426056BE160EDCB781D9 (void);
// 0x00000171 System.Void Cinemachine.CinemachineTargetGroup::LateUpdate()
extern void CinemachineTargetGroup_LateUpdate_m320382F4ADE5662C7F06D81ED7505FF0FDAE41B5 (void);
// 0x00000172 System.Void Cinemachine.CinemachineTargetGroup::GetViewSpaceAngularBounds(UnityEngine.Matrix4x4,UnityEngine.Vector2&,UnityEngine.Vector2&,UnityEngine.Vector2&)
extern void CinemachineTargetGroup_GetViewSpaceAngularBounds_mBCCF672D0664D37BA01D432B888F37A7665361BD (void);
// 0x00000173 System.Void Cinemachine.CinemachineTargetGroup::.ctor()
extern void CinemachineTargetGroup__ctor_m59C958FBF749CEEA369DDF27BAA3E9216CA99399 (void);
// 0x00000174 Cinemachine.CameraState Cinemachine.CinemachineVirtualCamera::get_State()
extern void CinemachineVirtualCamera_get_State_mF61B23491D389A88595DD95EB27E44EE09F3D40C (void);
// 0x00000175 UnityEngine.Transform Cinemachine.CinemachineVirtualCamera::get_LookAt()
extern void CinemachineVirtualCamera_get_LookAt_m7FA8E1F163BBB41806692C120B1A3531872E9173 (void);
// 0x00000176 System.Void Cinemachine.CinemachineVirtualCamera::set_LookAt(UnityEngine.Transform)
extern void CinemachineVirtualCamera_set_LookAt_m16EAA4A1653EAE5AC3490E2B2653E9C15856B199 (void);
// 0x00000177 UnityEngine.Transform Cinemachine.CinemachineVirtualCamera::get_Follow()
extern void CinemachineVirtualCamera_get_Follow_m2D4644BF8364F8EC6366E86D0E628AF7FBA8884D (void);
// 0x00000178 System.Void Cinemachine.CinemachineVirtualCamera::set_Follow(UnityEngine.Transform)
extern void CinemachineVirtualCamera_set_Follow_mBC7DE30C2BF4E62258116D9AA8F300A1468D0410 (void);
// 0x00000179 System.Single Cinemachine.CinemachineVirtualCamera::GetMaxDampTime()
extern void CinemachineVirtualCamera_GetMaxDampTime_m401AE8ABB66092E3E93BCADF35D846D5E44DAD16 (void);
// 0x0000017A System.Void Cinemachine.CinemachineVirtualCamera::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
extern void CinemachineVirtualCamera_InternalUpdateCameraState_m0A8D802327119F624F26C694E6341B34D38B1057 (void);
// 0x0000017B System.Void Cinemachine.CinemachineVirtualCamera::OnEnable()
extern void CinemachineVirtualCamera_OnEnable_m05A075F14A81B8DF7362BADC9B3F5B195F912CE1 (void);
// 0x0000017C System.Void Cinemachine.CinemachineVirtualCamera::OnDestroy()
extern void CinemachineVirtualCamera_OnDestroy_m69759804B4988BF64EF56B3F32DFC63BC4C5D533 (void);
// 0x0000017D System.Void Cinemachine.CinemachineVirtualCamera::OnValidate()
extern void CinemachineVirtualCamera_OnValidate_m6B4FF3C2AD8B3992E2E6759D1D72388EF013F4C5 (void);
// 0x0000017E System.Void Cinemachine.CinemachineVirtualCamera::OnTransformChildrenChanged()
extern void CinemachineVirtualCamera_OnTransformChildrenChanged_mF04206FB649F578387FF1B5E2690862861730775 (void);
// 0x0000017F System.Void Cinemachine.CinemachineVirtualCamera::Reset()
extern void CinemachineVirtualCamera_Reset_mB1C37515D1DF02DDC6EBECAC6F5E8EC2DAAA0990 (void);
// 0x00000180 System.Void Cinemachine.CinemachineVirtualCamera::DestroyPipeline()
extern void CinemachineVirtualCamera_DestroyPipeline_mBF0ACCB0E14994F96A0DA4F766E9DC4CD65298E4 (void);
// 0x00000181 UnityEngine.Transform Cinemachine.CinemachineVirtualCamera::CreatePipeline(Cinemachine.CinemachineVirtualCamera)
extern void CinemachineVirtualCamera_CreatePipeline_mFE25AD716DEA1E9468F5963DAA0252E300D1EA8D (void);
// 0x00000182 System.Void Cinemachine.CinemachineVirtualCamera::InvalidateComponentPipeline()
extern void CinemachineVirtualCamera_InvalidateComponentPipeline_m74BC28C9508EA3673CD8DA028883B069A94F652C (void);
// 0x00000183 UnityEngine.Transform Cinemachine.CinemachineVirtualCamera::GetComponentOwner()
extern void CinemachineVirtualCamera_GetComponentOwner_m8901A99D0106ADD7B9DF483D5A899E07C6B55DF4 (void);
// 0x00000184 Cinemachine.CinemachineComponentBase[] Cinemachine.CinemachineVirtualCamera::GetComponentPipeline()
extern void CinemachineVirtualCamera_GetComponentPipeline_mD2C278143444B6D6CC40EE5DC5AA5B7259C67296 (void);
// 0x00000185 Cinemachine.CinemachineComponentBase Cinemachine.CinemachineVirtualCamera::GetCinemachineComponent(Cinemachine.CinemachineCore/Stage)
extern void CinemachineVirtualCamera_GetCinemachineComponent_m9FA6F90B033903CAFFD1149E0A58A06313FDC7F3 (void);
// 0x00000186 T Cinemachine.CinemachineVirtualCamera::GetCinemachineComponent()
// 0x00000187 T Cinemachine.CinemachineVirtualCamera::AddCinemachineComponent()
// 0x00000188 System.Void Cinemachine.CinemachineVirtualCamera::DestroyCinemachineComponent()
// 0x00000189 System.Boolean Cinemachine.CinemachineVirtualCamera::get_UserIsDragging()
extern void CinemachineVirtualCamera_get_UserIsDragging_mCC9BCC63272BBC50DD6C1C930A1E162F2E7FB118 (void);
// 0x0000018A System.Void Cinemachine.CinemachineVirtualCamera::set_UserIsDragging(System.Boolean)
extern void CinemachineVirtualCamera_set_UserIsDragging_mA66BB2778AD5A2D17230207CC6FE1A5055764E51 (void);
// 0x0000018B System.Void Cinemachine.CinemachineVirtualCamera::UpdateComponentPipeline()
extern void CinemachineVirtualCamera_UpdateComponentPipeline_m40B9D8AFC178A45C7FEE7A5E151D9232E05201AA (void);
// 0x0000018C System.Void Cinemachine.CinemachineVirtualCamera::SetFlagsForHiddenChild(UnityEngine.GameObject)
extern void CinemachineVirtualCamera_SetFlagsForHiddenChild_m0B6CC9E477DF3FDC4A4C85B397DBC02987B8FFFF (void);
// 0x0000018D Cinemachine.CameraState Cinemachine.CinemachineVirtualCamera::CalculateNewState(UnityEngine.Vector3,System.Single)
extern void CinemachineVirtualCamera_CalculateNewState_mDC69D1DC2332963E4EE05DC6B3278483DDB7E271 (void);
// 0x0000018E System.Void Cinemachine.CinemachineVirtualCamera::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineVirtualCamera_OnTargetObjectWarped_m97A56F2EF2CAB7C830FE81D8DAF69D70302F3087 (void);
// 0x0000018F System.Void Cinemachine.CinemachineVirtualCamera::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineVirtualCamera_ForceCameraPosition_mA54274F343A60C2D8B5D0918B113F8D52A9C096F (void);
// 0x00000190 System.Void Cinemachine.CinemachineVirtualCamera::SetStateRawPosition(UnityEngine.Vector3)
extern void CinemachineVirtualCamera_SetStateRawPosition_mC33AAABD638BAF99907C51E241D339706F2A6591 (void);
// 0x00000191 System.Void Cinemachine.CinemachineVirtualCamera::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void CinemachineVirtualCamera_OnTransitionFromCamera_m621F8E4CE89A6CD4C718BAE9127944BBBE8A8C39 (void);
// 0x00000192 System.Void Cinemachine.CinemachineVirtualCamera::.ctor()
extern void CinemachineVirtualCamera__ctor_mE54D1FBAC8B30DADC6D1A1FF4E7526BEF47AA9D3 (void);
// 0x00000193 System.Void Cinemachine.CinemachineVirtualCamera/CreatePipelineDelegate::.ctor(System.Object,System.IntPtr)
extern void CreatePipelineDelegate__ctor_mF51B89DEB4EAE7A714B49CA9BF703B8541D419A0 (void);
// 0x00000194 UnityEngine.Transform Cinemachine.CinemachineVirtualCamera/CreatePipelineDelegate::Invoke(Cinemachine.CinemachineVirtualCamera,System.String,Cinemachine.CinemachineComponentBase[])
extern void CreatePipelineDelegate_Invoke_mF25FE1D09EC7FB09C0E0EDF766B2A19BF31080E5 (void);
// 0x00000195 System.IAsyncResult Cinemachine.CinemachineVirtualCamera/CreatePipelineDelegate::BeginInvoke(Cinemachine.CinemachineVirtualCamera,System.String,Cinemachine.CinemachineComponentBase[],System.AsyncCallback,System.Object)
extern void CreatePipelineDelegate_BeginInvoke_m354E9436E905807B4CCD0ACB6528D067E014E638 (void);
// 0x00000196 UnityEngine.Transform Cinemachine.CinemachineVirtualCamera/CreatePipelineDelegate::EndInvoke(System.IAsyncResult)
extern void CreatePipelineDelegate_EndInvoke_m038BA53E61623D2190CBCCD6649F230C29CE89F0 (void);
// 0x00000197 System.Void Cinemachine.CinemachineVirtualCamera/DestroyPipelineDelegate::.ctor(System.Object,System.IntPtr)
extern void DestroyPipelineDelegate__ctor_m3D90BC04CC0ADE49A4EE6503D20E7AB776F7A6AA (void);
// 0x00000198 System.Void Cinemachine.CinemachineVirtualCamera/DestroyPipelineDelegate::Invoke(UnityEngine.GameObject)
extern void DestroyPipelineDelegate_Invoke_m900F828AF1A5259B1D8606DB45BD14D4CB3274E1 (void);
// 0x00000199 System.IAsyncResult Cinemachine.CinemachineVirtualCamera/DestroyPipelineDelegate::BeginInvoke(UnityEngine.GameObject,System.AsyncCallback,System.Object)
extern void DestroyPipelineDelegate_BeginInvoke_m5E9E8B1CCB62A8EA334567CE88741B5356DE062B (void);
// 0x0000019A System.Void Cinemachine.CinemachineVirtualCamera/DestroyPipelineDelegate::EndInvoke(System.IAsyncResult)
extern void DestroyPipelineDelegate_EndInvoke_mD018624F272E6D61432DF250DFCDAD7DC2B53BBB (void);
// 0x0000019B System.Void Cinemachine.CinemachineVirtualCamera/<>c::.cctor()
extern void U3CU3Ec__cctor_m575A5E831C9D536CC3AF82E75EBEE29E76D43C89 (void);
// 0x0000019C System.Void Cinemachine.CinemachineVirtualCamera/<>c::.ctor()
extern void U3CU3Ec__ctor_mFB7EABDE6BB8BDE667A9786AC0176017ADEC9AF3 (void);
// 0x0000019D System.Int32 Cinemachine.CinemachineVirtualCamera/<>c::<UpdateComponentPipeline>b__41_0(Cinemachine.CinemachineComponentBase,Cinemachine.CinemachineComponentBase)
extern void U3CU3Ec_U3CUpdateComponentPipelineU3Eb__41_0_mCE45F92D28AB75075C2C97D20DBDAF56CB6D1FA3 (void);
// 0x0000019E System.Void Cinemachine.Cinemachine3rdPersonFollow::OnValidate()
extern void Cinemachine3rdPersonFollow_OnValidate_mD52752FC1E0022C921AE0857A427EA108096BA83 (void);
// 0x0000019F System.Void Cinemachine.Cinemachine3rdPersonFollow::Reset()
extern void Cinemachine3rdPersonFollow_Reset_m7B9D8F5575FCA0073A412D0147A5949A72D4D39B (void);
// 0x000001A0 System.Void Cinemachine.Cinemachine3rdPersonFollow::OnDestroy()
extern void Cinemachine3rdPersonFollow_OnDestroy_mEADA974793E9164F5B5214D7B61648B8425660FC (void);
// 0x000001A1 System.Boolean Cinemachine.Cinemachine3rdPersonFollow::get_IsValid()
extern void Cinemachine3rdPersonFollow_get_IsValid_mA7AB0949602C57690E5DA8A590D80112BAB000DA (void);
// 0x000001A2 Cinemachine.CinemachineCore/Stage Cinemachine.Cinemachine3rdPersonFollow::get_Stage()
extern void Cinemachine3rdPersonFollow_get_Stage_m1859D4E263C07EACAD8C3C899D327FC85761FFC2 (void);
// 0x000001A3 System.Single Cinemachine.Cinemachine3rdPersonFollow::GetMaxDampTime()
extern void Cinemachine3rdPersonFollow_GetMaxDampTime_m98EDF505AFFC8235F306E91EB8C2B1A867A4B641 (void);
// 0x000001A4 System.Void Cinemachine.Cinemachine3rdPersonFollow::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void Cinemachine3rdPersonFollow_MutateCameraState_m8EF4ADD2CE87316458D9B4D365FF587EDEE26C4F (void);
// 0x000001A5 System.Void Cinemachine.Cinemachine3rdPersonFollow::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void Cinemachine3rdPersonFollow_OnTargetObjectWarped_m81363B414B8D9AD371FB074CC6C5AC08D7E126AD (void);
// 0x000001A6 System.Void Cinemachine.Cinemachine3rdPersonFollow::PositionCamera(Cinemachine.CameraState&,System.Single)
extern void Cinemachine3rdPersonFollow_PositionCamera_mD6357591900C0D7F3740BCE6FB061F1287630B21 (void);
// 0x000001A7 System.Void Cinemachine.Cinemachine3rdPersonFollow::GetRigPositions(UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void Cinemachine3rdPersonFollow_GetRigPositions_m0B350EE139BBE08CEC35AC25DE11BB0D76B9F8E5 (void);
// 0x000001A8 UnityEngine.Quaternion Cinemachine.Cinemachine3rdPersonFollow::GetHeading(UnityEngine.Vector3,UnityEngine.Vector3)
extern void Cinemachine3rdPersonFollow_GetHeading_m7D65BE2D2EE002F8B65C41D90FAB4FFC89DFAB0E (void);
// 0x000001A9 System.Void Cinemachine.Cinemachine3rdPersonFollow::GetRawRigPositions(UnityEngine.Vector3,UnityEngine.Quaternion,UnityEngine.Quaternion,UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void Cinemachine3rdPersonFollow_GetRawRigPositions_m74FD948BB60F544B2883CB985B5CAEB2A7E830B1 (void);
// 0x000001AA UnityEngine.Vector3 Cinemachine.Cinemachine3rdPersonFollow::ResolveCollisions(UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void Cinemachine3rdPersonFollow_ResolveCollisions_m135E87083BF4188402D3AF09224FE1C572BA21C7 (void);
// 0x000001AB System.Void Cinemachine.Cinemachine3rdPersonFollow::.ctor()
extern void Cinemachine3rdPersonFollow__ctor_m9FC063AEC945BFF7CB0D77584F0B4A09546BC805 (void);
// 0x000001AC System.Boolean Cinemachine.CinemachineBasicMultiChannelPerlin::get_IsValid()
extern void CinemachineBasicMultiChannelPerlin_get_IsValid_m89FD92464853D4D80540492E7A94B293D637536E (void);
// 0x000001AD Cinemachine.CinemachineCore/Stage Cinemachine.CinemachineBasicMultiChannelPerlin::get_Stage()
extern void CinemachineBasicMultiChannelPerlin_get_Stage_mFBFFEC86F9A8F773FA9028D684D39194F8DF042D (void);
// 0x000001AE System.Void Cinemachine.CinemachineBasicMultiChannelPerlin::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineBasicMultiChannelPerlin_MutateCameraState_m71D2179E138E53253A53FC2033BBF5DB002CB888 (void);
// 0x000001AF System.Void Cinemachine.CinemachineBasicMultiChannelPerlin::ReSeed()
extern void CinemachineBasicMultiChannelPerlin_ReSeed_m55B7DB6DDB8B7864790E509C07A73E263072A2C9 (void);
// 0x000001B0 System.Void Cinemachine.CinemachineBasicMultiChannelPerlin::Initialize()
extern void CinemachineBasicMultiChannelPerlin_Initialize_mBE33134720655F241B32247831C18F3F4AC7E7E5 (void);
// 0x000001B1 System.Void Cinemachine.CinemachineBasicMultiChannelPerlin::.ctor()
extern void CinemachineBasicMultiChannelPerlin__ctor_m03392D8E786B297606FC3029C2468621D0BD267A (void);
// 0x000001B2 System.Boolean Cinemachine.CinemachineComposer::get_IsValid()
extern void CinemachineComposer_get_IsValid_mDD8A6301558F8579A65C82A84A073EF6CC9F7275 (void);
// 0x000001B3 Cinemachine.CinemachineCore/Stage Cinemachine.CinemachineComposer::get_Stage()
extern void CinemachineComposer_get_Stage_m20189F84AF9911702526B12CB5B27411538D4663 (void);
// 0x000001B4 UnityEngine.Vector3 Cinemachine.CinemachineComposer::get_TrackedPoint()
extern void CinemachineComposer_get_TrackedPoint_mBD61C246B60BC598EF2F407F11BF2162139F54B1 (void);
// 0x000001B5 System.Void Cinemachine.CinemachineComposer::set_TrackedPoint(UnityEngine.Vector3)
extern void CinemachineComposer_set_TrackedPoint_m15F609367B526B54845CB4A22D1874E01B84EDFD (void);
// 0x000001B6 UnityEngine.Vector3 Cinemachine.CinemachineComposer::GetLookAtPointAndSetTrackedPoint(UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void CinemachineComposer_GetLookAtPointAndSetTrackedPoint_m6191ABF0FD235956D9416A5B96C70504548D7CD0 (void);
// 0x000001B7 System.Void Cinemachine.CinemachineComposer::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineComposer_OnTargetObjectWarped_m3E15015DF195EEA065F733FC3A201F22FBBBA7C6 (void);
// 0x000001B8 System.Void Cinemachine.CinemachineComposer::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineComposer_ForceCameraPosition_m5B8C9B0D268DEE13C478EAA9F7B7A1DBB3411B90 (void);
// 0x000001B9 System.Single Cinemachine.CinemachineComposer::GetMaxDampTime()
extern void CinemachineComposer_GetMaxDampTime_mF9651558C16FD35EF56B69268E44F114EB21646A (void);
// 0x000001BA System.Void Cinemachine.CinemachineComposer::PrePipelineMutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineComposer_PrePipelineMutateCameraState_mBEE9891FE6C2A3EA29A82BDD152C737774D0B462 (void);
// 0x000001BB System.Void Cinemachine.CinemachineComposer::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineComposer_MutateCameraState_m500BDD47385EEE6373A5B5919D4B7B06CC798D57 (void);
// 0x000001BC UnityEngine.Rect Cinemachine.CinemachineComposer::get_SoftGuideRect()
extern void CinemachineComposer_get_SoftGuideRect_m2B2596665A05FF432BE719AE225A570F3C83DF8C (void);
// 0x000001BD System.Void Cinemachine.CinemachineComposer::set_SoftGuideRect(UnityEngine.Rect)
extern void CinemachineComposer_set_SoftGuideRect_mC46E102F64D6B1A70F528E2226C0935E485C183D (void);
// 0x000001BE UnityEngine.Rect Cinemachine.CinemachineComposer::get_HardGuideRect()
extern void CinemachineComposer_get_HardGuideRect_m552C95A5B89097FD385E6DED3C04B53B2556A2EE (void);
// 0x000001BF System.Void Cinemachine.CinemachineComposer::set_HardGuideRect(UnityEngine.Rect)
extern void CinemachineComposer_set_HardGuideRect_mAB65433485E384647C3B7D5BA9BE55A841E33AB9 (void);
// 0x000001C0 System.Void Cinemachine.CinemachineComposer::RotateToScreenBounds(Cinemachine.CameraState&,UnityEngine.Rect,UnityEngine.Vector3,UnityEngine.Quaternion&,System.Single,System.Single,System.Single)
extern void CinemachineComposer_RotateToScreenBounds_m62769940088AAC4509FEB682F5902D582B1AE6C1 (void);
// 0x000001C1 System.Boolean Cinemachine.CinemachineComposer::ClampVerticalBounds(UnityEngine.Rect&,UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void CinemachineComposer_ClampVerticalBounds_mAEA1A39D3A98ACAA5AC36B7E3B11376E99E2E68E (void);
// 0x000001C2 System.Void Cinemachine.CinemachineComposer::.ctor()
extern void CinemachineComposer__ctor_mA02E72656795D0813435386C46CEEB144AB29820 (void);
// 0x000001C3 System.Void Cinemachine.CinemachineComposer/FovCache::UpdateCache(Cinemachine.LensSettings,UnityEngine.Rect,UnityEngine.Rect,System.Single)
extern void FovCache_UpdateCache_m2EFDABF6DAFD0ACF434A8A83F5CAB0AA4B4F3519 (void);
// 0x000001C4 UnityEngine.Rect Cinemachine.CinemachineComposer/FovCache::ScreenToFOV(UnityEngine.Rect,System.Single,System.Single,System.Single)
extern void FovCache_ScreenToFOV_m813E0A11A9BEBC417751E33DA5E18A5A0DADFF2B (void);
// 0x000001C5 UnityEngine.Rect Cinemachine.CinemachineFramingTransposer::get_SoftGuideRect()
extern void CinemachineFramingTransposer_get_SoftGuideRect_mEAA618B22D45A8C57B8A5AE984660585B0EE2D87 (void);
// 0x000001C6 System.Void Cinemachine.CinemachineFramingTransposer::set_SoftGuideRect(UnityEngine.Rect)
extern void CinemachineFramingTransposer_set_SoftGuideRect_mC3076D642DBCDBC1AC725A4F1E1E090F8F1AC9EF (void);
// 0x000001C7 UnityEngine.Rect Cinemachine.CinemachineFramingTransposer::get_HardGuideRect()
extern void CinemachineFramingTransposer_get_HardGuideRect_mC861BBCE9D49993E237ADA9BBAC17665264A87FA (void);
// 0x000001C8 System.Void Cinemachine.CinemachineFramingTransposer::set_HardGuideRect(UnityEngine.Rect)
extern void CinemachineFramingTransposer_set_HardGuideRect_m1138240B8F7657519AC0571ECE2E6EFB89CC634E (void);
// 0x000001C9 System.Void Cinemachine.CinemachineFramingTransposer::OnValidate()
extern void CinemachineFramingTransposer_OnValidate_mC01E2DF60BA5B6B8D678E429D2FD2C1BE20EDA79 (void);
// 0x000001CA System.Boolean Cinemachine.CinemachineFramingTransposer::get_IsValid()
extern void CinemachineFramingTransposer_get_IsValid_mA6BEC5FF4B2BCA542CACB93FC8817DC0E222CA8B (void);
// 0x000001CB Cinemachine.CinemachineCore/Stage Cinemachine.CinemachineFramingTransposer::get_Stage()
extern void CinemachineFramingTransposer_get_Stage_m46D483051C135C5A2FAA11127927B477E4C3A4B3 (void);
// 0x000001CC System.Boolean Cinemachine.CinemachineFramingTransposer::get_BodyAppliesAfterAim()
extern void CinemachineFramingTransposer_get_BodyAppliesAfterAim_mDE58AC6238D9FFF902F3A490BE5ABEF7CCC350F0 (void);
// 0x000001CD UnityEngine.Vector3 Cinemachine.CinemachineFramingTransposer::get_TrackedPoint()
extern void CinemachineFramingTransposer_get_TrackedPoint_m7AD13AA3ED1185BE57C57925A65A457052F646B7 (void);
// 0x000001CE System.Void Cinemachine.CinemachineFramingTransposer::set_TrackedPoint(UnityEngine.Vector3)
extern void CinemachineFramingTransposer_set_TrackedPoint_m0F66F2FD792A1BC7873FAF52A9975CF2CB30DD82 (void);
// 0x000001CF System.Void Cinemachine.CinemachineFramingTransposer::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineFramingTransposer_OnTargetObjectWarped_m363404C45AF56465366357A3C1C6CE455BDD8045 (void);
// 0x000001D0 System.Void Cinemachine.CinemachineFramingTransposer::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineFramingTransposer_ForceCameraPosition_m359218276D2C475F79427C2BBA9D880F0EF847B0 (void);
// 0x000001D1 System.Single Cinemachine.CinemachineFramingTransposer::GetMaxDampTime()
extern void CinemachineFramingTransposer_GetMaxDampTime_m972BD3E7124A8630DC0C905993BBDE6D1AC9A275 (void);
// 0x000001D2 System.Boolean Cinemachine.CinemachineFramingTransposer::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single,Cinemachine.CinemachineVirtualCameraBase/TransitionParams&)
extern void CinemachineFramingTransposer_OnTransitionFromCamera_mB359F165B80CA2A10C19EA3AF33A9259F0A461BE (void);
// 0x000001D3 System.Boolean Cinemachine.CinemachineFramingTransposer::get_InheritingPosition()
extern void CinemachineFramingTransposer_get_InheritingPosition_m6FD62CC6C818D58C1BDAD0CFDB0DB17490098FAC (void);
// 0x000001D4 System.Void Cinemachine.CinemachineFramingTransposer::set_InheritingPosition(System.Boolean)
extern void CinemachineFramingTransposer_set_InheritingPosition_mE8AC7F16BC034AC01F63BF8871A2380BA533DFEF (void);
// 0x000001D5 UnityEngine.Rect Cinemachine.CinemachineFramingTransposer::ScreenToOrtho(UnityEngine.Rect,System.Single,System.Single)
extern void CinemachineFramingTransposer_ScreenToOrtho_mB36BB70462CD2EE36203D5AD3E4CA83D6CDDB23C (void);
// 0x000001D6 UnityEngine.Vector3 Cinemachine.CinemachineFramingTransposer::OrthoOffsetToScreenBounds(UnityEngine.Vector3,UnityEngine.Rect)
extern void CinemachineFramingTransposer_OrthoOffsetToScreenBounds_m537A7A773E2161BCDBA155497EE09CE363319A92 (void);
// 0x000001D7 UnityEngine.Bounds Cinemachine.CinemachineFramingTransposer::get_LastBounds()
extern void CinemachineFramingTransposer_get_LastBounds_mA41F708F5427B0DCABFAD74902AD2FA131B9315A (void);
// 0x000001D8 System.Void Cinemachine.CinemachineFramingTransposer::set_LastBounds(UnityEngine.Bounds)
extern void CinemachineFramingTransposer_set_LastBounds_mE7C62D2CDC58E8491783977BB73EAB7C1286B76A (void);
// 0x000001D9 UnityEngine.Matrix4x4 Cinemachine.CinemachineFramingTransposer::get_LastBoundsMatrix()
extern void CinemachineFramingTransposer_get_LastBoundsMatrix_mE543BEE3801C0D544E132F28F45F0593AABF0BD4 (void);
// 0x000001DA System.Void Cinemachine.CinemachineFramingTransposer::set_LastBoundsMatrix(UnityEngine.Matrix4x4)
extern void CinemachineFramingTransposer_set_LastBoundsMatrix_m82659FE5FB87F1959EAF0BB4F3FC4A53A4FCADDD (void);
// 0x000001DB System.Void Cinemachine.CinemachineFramingTransposer::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineFramingTransposer_MutateCameraState_m738B55893FF0A80A26234C5CBABDF4441EA13111 (void);
// 0x000001DC System.Single Cinemachine.CinemachineFramingTransposer::GetTargetHeight(UnityEngine.Vector2)
extern void CinemachineFramingTransposer_GetTargetHeight_mC4D0F3C7F1916B41E47FCA12F06B481A83AAF545 (void);
// 0x000001DD UnityEngine.Vector3 Cinemachine.CinemachineFramingTransposer::ComputeGroupBounds(Cinemachine.ICinemachineTargetGroup,Cinemachine.CameraState&)
extern void CinemachineFramingTransposer_ComputeGroupBounds_m266F186335242EE480FA0DA8D2477B9672A9441F (void);
// 0x000001DE UnityEngine.Bounds Cinemachine.CinemachineFramingTransposer::GetScreenSpaceGroupBoundingBox(Cinemachine.ICinemachineTargetGroup,UnityEngine.Vector3&,UnityEngine.Quaternion)
extern void CinemachineFramingTransposer_GetScreenSpaceGroupBoundingBox_mF4E5D1B62BA2FA5EB6A3D83A77E0B3E6F2580148 (void);
// 0x000001DF System.Void Cinemachine.CinemachineFramingTransposer::.ctor()
extern void CinemachineFramingTransposer__ctor_m43A25F96041552E3943E1A17419C76CD73DD5067 (void);
// 0x000001E0 System.Void Cinemachine.CinemachineGroupComposer::OnValidate()
extern void CinemachineGroupComposer_OnValidate_m056733D87C52B7481CB62EAC67A97465E94A344D (void);
// 0x000001E1 UnityEngine.Bounds Cinemachine.CinemachineGroupComposer::get_LastBounds()
extern void CinemachineGroupComposer_get_LastBounds_mBDD21C72B4902994C351AE2BE99CDE33790374ED (void);
// 0x000001E2 System.Void Cinemachine.CinemachineGroupComposer::set_LastBounds(UnityEngine.Bounds)
extern void CinemachineGroupComposer_set_LastBounds_m65665450515CF77E6E04C5242803C9E2ED4950A6 (void);
// 0x000001E3 UnityEngine.Matrix4x4 Cinemachine.CinemachineGroupComposer::get_LastBoundsMatrix()
extern void CinemachineGroupComposer_get_LastBoundsMatrix_mAD7553857814F97F5B338B1090953E68487F26F8 (void);
// 0x000001E4 System.Void Cinemachine.CinemachineGroupComposer::set_LastBoundsMatrix(UnityEngine.Matrix4x4)
extern void CinemachineGroupComposer_set_LastBoundsMatrix_m17F3517E0D09514D674A5D2B589E02BA75916BB5 (void);
// 0x000001E5 System.Single Cinemachine.CinemachineGroupComposer::GetMaxDampTime()
extern void CinemachineGroupComposer_GetMaxDampTime_m7EFF6674345C28E480109CE58B36C3553E71BA77 (void);
// 0x000001E6 System.Void Cinemachine.CinemachineGroupComposer::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineGroupComposer_MutateCameraState_m3F09674F5DB0D0D30F4E700F40A59EEA4827D961 (void);
// 0x000001E7 System.Single Cinemachine.CinemachineGroupComposer::GetTargetHeight(UnityEngine.Vector2)
extern void CinemachineGroupComposer_GetTargetHeight_m765D054C90533C449002E5C506D18A980D66E48A (void);
// 0x000001E8 UnityEngine.Bounds Cinemachine.CinemachineGroupComposer::GetScreenSpaceGroupBoundingBox(Cinemachine.ICinemachineTargetGroup,UnityEngine.Matrix4x4,UnityEngine.Vector3&)
extern void CinemachineGroupComposer_GetScreenSpaceGroupBoundingBox_mD21F1915940A7444B239E306204AC359485DA3C8 (void);
// 0x000001E9 System.Void Cinemachine.CinemachineGroupComposer::.ctor()
extern void CinemachineGroupComposer__ctor_m7FC019C66BF7BFC724ECBE6614922A341CEAEB9F (void);
// 0x000001EA System.Boolean Cinemachine.CinemachineHardLockToTarget::get_IsValid()
extern void CinemachineHardLockToTarget_get_IsValid_mB4B8596FAC003DDB676DA62F8791144FF82EC9FF (void);
// 0x000001EB Cinemachine.CinemachineCore/Stage Cinemachine.CinemachineHardLockToTarget::get_Stage()
extern void CinemachineHardLockToTarget_get_Stage_m5593A2FD90EE9EBEA068EE1D2316B2A17BB445C7 (void);
// 0x000001EC System.Single Cinemachine.CinemachineHardLockToTarget::GetMaxDampTime()
extern void CinemachineHardLockToTarget_GetMaxDampTime_m9AE2387AE059EECF8F26E7F790D64B3051DDE58A (void);
// 0x000001ED System.Void Cinemachine.CinemachineHardLockToTarget::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineHardLockToTarget_MutateCameraState_mA26502B42607E6B42316FDB154CCA0F0677D7FB2 (void);
// 0x000001EE System.Void Cinemachine.CinemachineHardLockToTarget::.ctor()
extern void CinemachineHardLockToTarget__ctor_m80D0530B0306D501FB1279AD9D5FC08C86954F39 (void);
// 0x000001EF System.Boolean Cinemachine.CinemachineHardLookAt::get_IsValid()
extern void CinemachineHardLookAt_get_IsValid_m14C472D0B12C8ED2F7CBEDE1463485F546FB8856 (void);
// 0x000001F0 Cinemachine.CinemachineCore/Stage Cinemachine.CinemachineHardLookAt::get_Stage()
extern void CinemachineHardLookAt_get_Stage_mF5E12651C246600173A452EB64701A6D385CF832 (void);
// 0x000001F1 System.Void Cinemachine.CinemachineHardLookAt::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineHardLookAt_MutateCameraState_mC529F56FDA06226E4280449F649102B7392C4D17 (void);
// 0x000001F2 System.Void Cinemachine.CinemachineHardLookAt::.ctor()
extern void CinemachineHardLookAt__ctor_mC6209571CD75BACFB0D27C6A4F23294C575CD139 (void);
// 0x000001F3 System.Void Cinemachine.CinemachineOrbitalTransposer::OnValidate()
extern void CinemachineOrbitalTransposer_OnValidate_m16936FC098624F28C992EF3A43A2A30E01F24478 (void);
// 0x000001F4 System.Single Cinemachine.CinemachineOrbitalTransposer::UpdateHeading(System.Single,UnityEngine.Vector3,Cinemachine.AxisState&)
extern void CinemachineOrbitalTransposer_UpdateHeading_m51697AD5EA097970B5E4A2257741553B45B8E8E5 (void);
// 0x000001F5 System.Single Cinemachine.CinemachineOrbitalTransposer::UpdateHeading(System.Single,UnityEngine.Vector3,Cinemachine.AxisState&,Cinemachine.AxisState/Recentering&,System.Boolean)
extern void CinemachineOrbitalTransposer_UpdateHeading_mB62BE9B437A813916796102106A15EC88B7D6D38 (void);
// 0x000001F6 System.Void Cinemachine.CinemachineOrbitalTransposer::OnEnable()
extern void CinemachineOrbitalTransposer_OnEnable_m1009CB168A884E6799875A253AB33B9BA429FE21 (void);
// 0x000001F7 System.Void Cinemachine.CinemachineOrbitalTransposer::UpdateInputAxisProvider()
extern void CinemachineOrbitalTransposer_UpdateInputAxisProvider_m577FF1105D78BEA23D538257216CCA6AA3939C1D (void);
// 0x000001F8 UnityEngine.Transform Cinemachine.CinemachineOrbitalTransposer::get_PreviousTarget()
extern void CinemachineOrbitalTransposer_get_PreviousTarget_mCD7F8B212E3CF07C2B28269DBD9AEED8FFBCC36B (void);
// 0x000001F9 System.Void Cinemachine.CinemachineOrbitalTransposer::set_PreviousTarget(UnityEngine.Transform)
extern void CinemachineOrbitalTransposer_set_PreviousTarget_m8C785BA96B2C5495772AB2CE5B8AC7A11B5E9B18 (void);
// 0x000001FA System.Void Cinemachine.CinemachineOrbitalTransposer::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineOrbitalTransposer_OnTargetObjectWarped_m9D46C90267A97EB8DCA88B03C0ACEFFC29B1B424 (void);
// 0x000001FB System.Void Cinemachine.CinemachineOrbitalTransposer::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineOrbitalTransposer_ForceCameraPosition_m2152590E3A98A5FDAAF49699DE9EF9311B00BCC4 (void);
// 0x000001FC System.Boolean Cinemachine.CinemachineOrbitalTransposer::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single,Cinemachine.CinemachineVirtualCameraBase/TransitionParams&)
extern void CinemachineOrbitalTransposer_OnTransitionFromCamera_m28AA80DA45100E312174A830FD1AE9676548B391 (void);
// 0x000001FD System.Single Cinemachine.CinemachineOrbitalTransposer::GetAxisClosestValue(UnityEngine.Vector3,UnityEngine.Vector3)
extern void CinemachineOrbitalTransposer_GetAxisClosestValue_m49678E8EEBDB7B18ABA126F1A53ED3DC412DF606 (void);
// 0x000001FE System.Single Cinemachine.CinemachineOrbitalTransposer::get_LastHeading()
extern void CinemachineOrbitalTransposer_get_LastHeading_m2E84E64E45CCFA5EDF4281474B39D2C2D4E77E65 (void);
// 0x000001FF System.Void Cinemachine.CinemachineOrbitalTransposer::set_LastHeading(System.Single)
extern void CinemachineOrbitalTransposer_set_LastHeading_m1081AD7C55D275B8A6CD15E356C6E0896967FCF7 (void);
// 0x00000200 System.Void Cinemachine.CinemachineOrbitalTransposer::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineOrbitalTransposer_MutateCameraState_m3D0B7E27178F330F093CEEE6AE93326CBDFF57AF (void);
// 0x00000201 UnityEngine.Vector3 Cinemachine.CinemachineOrbitalTransposer::GetTargetCameraPosition(UnityEngine.Vector3)
extern void CinemachineOrbitalTransposer_GetTargetCameraPosition_mEF6CEF0A22C999B4B3C29860138A88B629EDA7EC (void);
// 0x00000202 System.Single Cinemachine.CinemachineOrbitalTransposer::GetTargetHeading(System.Single,UnityEngine.Quaternion)
extern void CinemachineOrbitalTransposer_GetTargetHeading_m474077AD308ACEAFFCFFE43ED36B0A645B4FA786 (void);
// 0x00000203 System.Void Cinemachine.CinemachineOrbitalTransposer::.ctor()
extern void CinemachineOrbitalTransposer__ctor_m00999B24FD592B5C32C79C99C6C68B30CB456206 (void);
// 0x00000204 System.Void Cinemachine.CinemachineOrbitalTransposer/Heading::.ctor(Cinemachine.CinemachineOrbitalTransposer/Heading/HeadingDefinition,System.Int32,System.Single)
extern void Heading__ctor_m27AC6DA9204C9B4856DEA05AAAD89E2400FF639A (void);
// 0x00000205 System.Void Cinemachine.CinemachineOrbitalTransposer/UpdateHeadingDelegate::.ctor(System.Object,System.IntPtr)
extern void UpdateHeadingDelegate__ctor_mB9BA33C54488BC8DD418BEEF3A51DB6AF40E361B (void);
// 0x00000206 System.Single Cinemachine.CinemachineOrbitalTransposer/UpdateHeadingDelegate::Invoke(Cinemachine.CinemachineOrbitalTransposer,System.Single,UnityEngine.Vector3)
extern void UpdateHeadingDelegate_Invoke_m3A58C1E3FAF4FE5B175648FF19F95BAD57CC6330 (void);
// 0x00000207 System.IAsyncResult Cinemachine.CinemachineOrbitalTransposer/UpdateHeadingDelegate::BeginInvoke(Cinemachine.CinemachineOrbitalTransposer,System.Single,UnityEngine.Vector3,System.AsyncCallback,System.Object)
extern void UpdateHeadingDelegate_BeginInvoke_mBDCD4A90CE6D3E50F8A7A7FF3A12039EE580E4A4 (void);
// 0x00000208 System.Single Cinemachine.CinemachineOrbitalTransposer/UpdateHeadingDelegate::EndInvoke(System.IAsyncResult)
extern void UpdateHeadingDelegate_EndInvoke_m75EB1823E9A52B6FD0216E863677C5A357A13672 (void);
// 0x00000209 System.Void Cinemachine.CinemachineOrbitalTransposer/<>c::.cctor()
extern void U3CU3Ec__cctor_m040BE18F4CF76FD237A199F900F8B2D09794FBBD (void);
// 0x0000020A System.Void Cinemachine.CinemachineOrbitalTransposer/<>c::.ctor()
extern void U3CU3Ec__ctor_m2CC55D7CF3C4815383423BEA372FB9753A747D29 (void);
// 0x0000020B System.Single Cinemachine.CinemachineOrbitalTransposer/<>c::<.ctor>b__34_0(Cinemachine.CinemachineOrbitalTransposer,System.Single,UnityEngine.Vector3)
extern void U3CU3Ec_U3C_ctorU3Eb__34_0_mEB2AEA2C6607681346D746C7815B32FFE0789E36 (void);
// 0x0000020C System.Boolean Cinemachine.CinemachinePOV::get_IsValid()
extern void CinemachinePOV_get_IsValid_m56F4CD3C9FE5795343397325D6128B34F7282DF3 (void);
// 0x0000020D Cinemachine.CinemachineCore/Stage Cinemachine.CinemachinePOV::get_Stage()
extern void CinemachinePOV_get_Stage_m87C432BCA78705401251C2E0E474704E22CE6D7C (void);
// 0x0000020E System.Void Cinemachine.CinemachinePOV::OnValidate()
extern void CinemachinePOV_OnValidate_m7AC95AEC250D1606DDE3ACDA968E7F6312BA60F7 (void);
// 0x0000020F System.Void Cinemachine.CinemachinePOV::OnEnable()
extern void CinemachinePOV_OnEnable_mD7B0A5051C115961BD8D43641B70BD2512E19B72 (void);
// 0x00000210 System.Void Cinemachine.CinemachinePOV::UpdateInputAxisProvider()
extern void CinemachinePOV_UpdateInputAxisProvider_m47A7388954C01FFE0948F4601D4CE198BEFC221B (void);
// 0x00000211 System.Void Cinemachine.CinemachinePOV::PrePipelineMutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachinePOV_PrePipelineMutateCameraState_m9BB2531A4EF28FD3221EB302288BACC4DE852F4A (void);
// 0x00000212 System.Void Cinemachine.CinemachinePOV::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachinePOV_MutateCameraState_mBBA8EDDE3AD2CD0AA9AF831D81D0A14FAC4BF0E7 (void);
// 0x00000213 UnityEngine.Vector2 Cinemachine.CinemachinePOV::GetRecenterTarget()
extern void CinemachinePOV_GetRecenterTarget_mC5206D2FC5D9809E62E8A536B59700C9F4F38876 (void);
// 0x00000214 System.Single Cinemachine.CinemachinePOV::NormalizeAngle(System.Single)
extern void CinemachinePOV_NormalizeAngle_mA7968F1D5E2F299419C77503DB3742F44BD07E1D (void);
// 0x00000215 System.Void Cinemachine.CinemachinePOV::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachinePOV_ForceCameraPosition_mF4DB8EC103BCAB1AB82FF19EC542E4F6E54D041A (void);
// 0x00000216 System.Boolean Cinemachine.CinemachinePOV::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single,Cinemachine.CinemachineVirtualCameraBase/TransitionParams&)
extern void CinemachinePOV_OnTransitionFromCamera_m6BC39D7F60175A61C402C262EDC067793F0F789C (void);
// 0x00000217 System.Void Cinemachine.CinemachinePOV::SetAxesForRotation(UnityEngine.Quaternion)
extern void CinemachinePOV_SetAxesForRotation_m2FAD19EC947F4B355DED9537C8622F028F01A507 (void);
// 0x00000218 System.Void Cinemachine.CinemachinePOV::.ctor()
extern void CinemachinePOV__ctor_m697E2E56E6B944C9E7334DCFC8AC0BF06DA6BCD0 (void);
// 0x00000219 System.Boolean Cinemachine.CinemachineSameAsFollowTarget::get_IsValid()
extern void CinemachineSameAsFollowTarget_get_IsValid_m1809C5E540F7537CC4286F0958FD1539EECA1125 (void);
// 0x0000021A Cinemachine.CinemachineCore/Stage Cinemachine.CinemachineSameAsFollowTarget::get_Stage()
extern void CinemachineSameAsFollowTarget_get_Stage_m2113E69CBB5E0167E4A5D5B431C70DC7705B6707 (void);
// 0x0000021B System.Single Cinemachine.CinemachineSameAsFollowTarget::GetMaxDampTime()
extern void CinemachineSameAsFollowTarget_GetMaxDampTime_m77DFBB864C5C83A91406C04F746665E4CABC45E4 (void);
// 0x0000021C System.Void Cinemachine.CinemachineSameAsFollowTarget::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineSameAsFollowTarget_MutateCameraState_m85AEA567E9CC87451D0024879F38BCD53C506B00 (void);
// 0x0000021D System.Void Cinemachine.CinemachineSameAsFollowTarget::.ctor()
extern void CinemachineSameAsFollowTarget__ctor_m81457B118206C0E0D833F0015A799194E9774814 (void);
// 0x0000021E System.Boolean Cinemachine.CinemachineTrackedDolly::get_IsValid()
extern void CinemachineTrackedDolly_get_IsValid_m8EDE6D1E0B40C6F90871E4B95DB5E1F4DD49BB4E (void);
// 0x0000021F Cinemachine.CinemachineCore/Stage Cinemachine.CinemachineTrackedDolly::get_Stage()
extern void CinemachineTrackedDolly_get_Stage_mFB4BDBA8C38A47C2E380E031DA81B0D1C3F22433 (void);
// 0x00000220 System.Single Cinemachine.CinemachineTrackedDolly::GetMaxDampTime()
extern void CinemachineTrackedDolly_GetMaxDampTime_m16C0CFB0875FEB726F78C571B4316AC7ADAC5D9C (void);
// 0x00000221 System.Void Cinemachine.CinemachineTrackedDolly::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineTrackedDolly_MutateCameraState_mC2D7BE38E781EDAC4B28B381BBA53F27429CB812 (void);
// 0x00000222 UnityEngine.Quaternion Cinemachine.CinemachineTrackedDolly::GetCameraOrientationAtPathPoint(UnityEngine.Quaternion,UnityEngine.Vector3)
extern void CinemachineTrackedDolly_GetCameraOrientationAtPathPoint_mEDA3B0646C44F84366FA86CD999E75DAE106CB30 (void);
// 0x00000223 UnityEngine.Vector3 Cinemachine.CinemachineTrackedDolly::get_AngularDamping()
extern void CinemachineTrackedDolly_get_AngularDamping_mC3701A9FAAE10CE9FC4F82FC6D3593866C03B6D4 (void);
// 0x00000224 System.Void Cinemachine.CinemachineTrackedDolly::.ctor()
extern void CinemachineTrackedDolly__ctor_mC643FD4B96CA4A08FA2BC2E3800FA9B448A65CEE (void);
// 0x00000225 System.Void Cinemachine.CinemachineTrackedDolly/AutoDolly::.ctor(System.Boolean,System.Single,System.Int32,System.Int32)
extern void AutoDolly__ctor_mB22E90A64C6D9D0F6C0F6FE794446F2867E76793 (void);
// 0x00000226 System.Void Cinemachine.CinemachineTransposer::OnValidate()
extern void CinemachineTransposer_OnValidate_mBD6D72D809B998114DE4FDE462D39D9596E4EED9 (void);
// 0x00000227 System.Boolean Cinemachine.CinemachineTransposer::get_HideOffsetInInspector()
extern void CinemachineTransposer_get_HideOffsetInInspector_m937352B22116BAB61B21EBBF6D3417EE52F0158D (void);
// 0x00000228 System.Void Cinemachine.CinemachineTransposer::set_HideOffsetInInspector(System.Boolean)
extern void CinemachineTransposer_set_HideOffsetInInspector_m8C4560481CC4C6864C5F49A32C3495659E18521E (void);
// 0x00000229 UnityEngine.Vector3 Cinemachine.CinemachineTransposer::get_EffectiveOffset()
extern void CinemachineTransposer_get_EffectiveOffset_m66C67B1F9882DF5B424E58F4B904ED0A3A519183 (void);
// 0x0000022A System.Boolean Cinemachine.CinemachineTransposer::get_IsValid()
extern void CinemachineTransposer_get_IsValid_m60005E62926B8E9927396938C4C980F873F91232 (void);
// 0x0000022B Cinemachine.CinemachineCore/Stage Cinemachine.CinemachineTransposer::get_Stage()
extern void CinemachineTransposer_get_Stage_mD4AE770AE7489A2D32E847C2370E0881BB1E81FB (void);
// 0x0000022C System.Single Cinemachine.CinemachineTransposer::GetMaxDampTime()
extern void CinemachineTransposer_GetMaxDampTime_m4E1F2298C32E2EE3FE5D3ACCEE6F1C990D68F9F9 (void);
// 0x0000022D System.Void Cinemachine.CinemachineTransposer::MutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineTransposer_MutateCameraState_m52392553F3D657BD1825ACC8EDFE79AA520DF52C (void);
// 0x0000022E System.Void Cinemachine.CinemachineTransposer::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineTransposer_OnTargetObjectWarped_m898C8AABB73BBF79CA0825BB3F1F1C0FA19EA9A0 (void);
// 0x0000022F System.Void Cinemachine.CinemachineTransposer::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineTransposer_ForceCameraPosition_m839D8ADF7D8EABD7D108B71DD028C85C119D56E4 (void);
// 0x00000230 System.Void Cinemachine.CinemachineTransposer::InitPrevFrameStateInfo(Cinemachine.CameraState&,System.Single)
extern void CinemachineTransposer_InitPrevFrameStateInfo_m392AB50EFACB254C9CE86F0270ED4A9103AA753C (void);
// 0x00000231 System.Void Cinemachine.CinemachineTransposer::TrackTarget(System.Single,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3&,UnityEngine.Quaternion&)
extern void CinemachineTransposer_TrackTarget_m6681DA4BA5675F68E5EB9BB179AEF1E8A01D64D9 (void);
// 0x00000232 UnityEngine.Vector3 Cinemachine.CinemachineTransposer::GetOffsetForMinimumTargetDistance(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void CinemachineTransposer_GetOffsetForMinimumTargetDistance_mC844A89B44991A156705B0169529FF39BE30ECC8 (void);
// 0x00000233 UnityEngine.Vector3 Cinemachine.CinemachineTransposer::get_Damping()
extern void CinemachineTransposer_get_Damping_m54AE51D0991EF38C1D58A464FBE0B71E8EAA53E9 (void);
// 0x00000234 UnityEngine.Vector3 Cinemachine.CinemachineTransposer::get_AngularDamping()
extern void CinemachineTransposer_get_AngularDamping_mBBC748334418408B75EC350A2E92833FEDD11276 (void);
// 0x00000235 UnityEngine.Vector3 Cinemachine.CinemachineTransposer::GetTargetCameraPosition(UnityEngine.Vector3)
extern void CinemachineTransposer_GetTargetCameraPosition_m1BB4ED7FA1B3BB3EABE41E73C6B46E6E39C671F7 (void);
// 0x00000236 UnityEngine.Quaternion Cinemachine.CinemachineTransposer::GetReferenceOrientation(UnityEngine.Vector3)
extern void CinemachineTransposer_GetReferenceOrientation_m6052EF55BF3528A668CEBE505F8E33708360F0F5 (void);
// 0x00000237 System.Void Cinemachine.CinemachineTransposer::.ctor()
extern void CinemachineTransposer__ctor_m3FA3755910D644CBE2EF94268677DCDE7C24D584 (void);
// 0x00000238 System.Void Cinemachine.AxisState::.ctor(System.Single,System.Single,System.Boolean,System.Boolean,System.Single,System.Single,System.Single,System.String,System.Boolean)
extern void AxisState__ctor_mE1E3449CB695DD0B97602DA2309969235F2AE8A0 (void);
// 0x00000239 System.Void Cinemachine.AxisState::Validate()
extern void AxisState_Validate_mD31D13D5FBDA48541D62D25EBA58C6615141115C (void);
// 0x0000023A System.Void Cinemachine.AxisState::Reset()
extern void AxisState_Reset_m467FB333DF4E419185F468B80CD82F75C773A3FE (void);
// 0x0000023B System.Void Cinemachine.AxisState::SetInputAxisProvider(System.Int32,Cinemachine.AxisState/IInputAxisProvider)
extern void AxisState_SetInputAxisProvider_m7396F12E659493FD37D66F79B04CF93D4BBDA527 (void);
// 0x0000023C System.Boolean Cinemachine.AxisState::get_HasInputProvider()
extern void AxisState_get_HasInputProvider_m38460D72EBD97A207B33485CA157D6D4D3193226 (void);
// 0x0000023D System.Boolean Cinemachine.AxisState::Update(System.Single)
extern void AxisState_Update_mEA3BADC4B491D705D61357CD1ECE295FC243670A (void);
// 0x0000023E System.Single Cinemachine.AxisState::ClampValue(System.Single)
extern void AxisState_ClampValue_m44330844584E13D1E1921B6174DD5257CDFFA960 (void);
// 0x0000023F System.Boolean Cinemachine.AxisState::MaxSpeedUpdate(System.Single,System.Single)
extern void AxisState_MaxSpeedUpdate_mC53D3EABA41652F2D991263538542FA23B8FB517 (void);
// 0x00000240 System.Single Cinemachine.AxisState::GetMaxSpeed()
extern void AxisState_GetMaxSpeed_mE2AB97681281AA228333FC67BD9AB5F8CEA640AA (void);
// 0x00000241 System.Boolean Cinemachine.AxisState::get_ValueRangeLocked()
extern void AxisState_get_ValueRangeLocked_mAA8A098676C624D20443DC6207F7CE4268824369 (void);
// 0x00000242 System.Void Cinemachine.AxisState::set_ValueRangeLocked(System.Boolean)
extern void AxisState_set_ValueRangeLocked_m556066F839F1D835CFB65398E5D2776E74510F2A (void);
// 0x00000243 System.Boolean Cinemachine.AxisState::get_HasRecentering()
extern void AxisState_get_HasRecentering_m02782E465AF3A314B2586C24230C03FBD609EB12 (void);
// 0x00000244 System.Void Cinemachine.AxisState::set_HasRecentering(System.Boolean)
extern void AxisState_set_HasRecentering_m30D6476F657160F87D850632F36DA226C04FCDE6 (void);
// 0x00000245 System.Single Cinemachine.AxisState/IInputAxisProvider::GetAxisValue(System.Int32)
// 0x00000246 System.Void Cinemachine.AxisState/Recentering::.ctor(System.Boolean,System.Single,System.Single)
extern void Recentering__ctor_mDFE3D3BB932AF426369B033D18AD3FDAAF26384F (void);
// 0x00000247 System.Void Cinemachine.AxisState/Recentering::Validate()
extern void Recentering_Validate_mFB967BB954EFD0DD6E2315F53A3241FDC146B18A (void);
// 0x00000248 System.Void Cinemachine.AxisState/Recentering::CopyStateFrom(Cinemachine.AxisState/Recentering&)
extern void Recentering_CopyStateFrom_mE18BDABB9C0A8D71903C3173B9783435DDE64918 (void);
// 0x00000249 System.Void Cinemachine.AxisState/Recentering::CancelRecentering()
extern void Recentering_CancelRecentering_m49877C0EBC7D9873C40CABD8EEF245954703CEC2 (void);
// 0x0000024A System.Void Cinemachine.AxisState/Recentering::RecenterNow()
extern void Recentering_RecenterNow_mB95BFD6D292191AB019A574F835AE4FB2A5ECD54 (void);
// 0x0000024B System.Void Cinemachine.AxisState/Recentering::DoRecentering(Cinemachine.AxisState&,System.Single,System.Single)
extern void Recentering_DoRecentering_mA1AB5ACE77B56D9357CBB46FB4BEAF42AED5CD6C (void);
// 0x0000024C System.Boolean Cinemachine.AxisState/Recentering::LegacyUpgrade(System.Int32&,System.Int32&)
extern void Recentering_LegacyUpgrade_mE331A7312B51DE3F31805A89EC3E4EB9DF71567E (void);
// 0x0000024D Cinemachine.LensSettings Cinemachine.CameraState::get_Lens()
extern void CameraState_get_Lens_m8DD7FD2B8954A56E2CBD83D1EF7A77958F685893 (void);
// 0x0000024E System.Void Cinemachine.CameraState::set_Lens(Cinemachine.LensSettings)
extern void CameraState_set_Lens_mAABE6FFC1E5F9A33EE16A7B009B927ECB2F29523 (void);
// 0x0000024F UnityEngine.Vector3 Cinemachine.CameraState::get_ReferenceUp()
extern void CameraState_get_ReferenceUp_m9A1F4A533328BABA7C81C4AD2F1E830375495B5A (void);
// 0x00000250 System.Void Cinemachine.CameraState::set_ReferenceUp(UnityEngine.Vector3)
extern void CameraState_set_ReferenceUp_mE156A37CA4B6BF3E8BA65A391730873572F24358 (void);
// 0x00000251 UnityEngine.Vector3 Cinemachine.CameraState::get_ReferenceLookAt()
extern void CameraState_get_ReferenceLookAt_m32BCDF0492BA9AAECC597DF02676D66BF0566548 (void);
// 0x00000252 System.Void Cinemachine.CameraState::set_ReferenceLookAt(UnityEngine.Vector3)
extern void CameraState_set_ReferenceLookAt_mF7CF3F3DD4D8DA16C08C4706E6C1128B48A3CEA2 (void);
// 0x00000253 System.Boolean Cinemachine.CameraState::get_HasLookAt()
extern void CameraState_get_HasLookAt_mE3BC5114383606752FDDED488732126B5644E81D (void);
// 0x00000254 UnityEngine.Vector3 Cinemachine.CameraState::get_RawPosition()
extern void CameraState_get_RawPosition_mA01BC7F842C837D49F0542A0475AE0EA9C88539D (void);
// 0x00000255 System.Void Cinemachine.CameraState::set_RawPosition(UnityEngine.Vector3)
extern void CameraState_set_RawPosition_m0E1142A79939C7AD7156986F91CD0F1D60499A31 (void);
// 0x00000256 UnityEngine.Quaternion Cinemachine.CameraState::get_RawOrientation()
extern void CameraState_get_RawOrientation_m61C0AC1D87FB6C869DA02458732BF6023130F163 (void);
// 0x00000257 System.Void Cinemachine.CameraState::set_RawOrientation(UnityEngine.Quaternion)
extern void CameraState_set_RawOrientation_mF473C9D14F4C653E31B9D17B29198A0A26FB710E (void);
// 0x00000258 UnityEngine.Vector3 Cinemachine.CameraState::get_PositionDampingBypass()
extern void CameraState_get_PositionDampingBypass_m4F3CAC6077C7D9CE366DE64FDC0F76B8E4309965 (void);
// 0x00000259 System.Void Cinemachine.CameraState::set_PositionDampingBypass(UnityEngine.Vector3)
extern void CameraState_set_PositionDampingBypass_m6ED6EE6829EAD07FB68F3281F682360F9E0B5707 (void);
// 0x0000025A System.Single Cinemachine.CameraState::get_ShotQuality()
extern void CameraState_get_ShotQuality_m3FE037E90A92A214DAEEA694D75ECF717520E285 (void);
// 0x0000025B System.Void Cinemachine.CameraState::set_ShotQuality(System.Single)
extern void CameraState_set_ShotQuality_m02E14BA3BB2628501258190348C309AF56836E3B (void);
// 0x0000025C UnityEngine.Vector3 Cinemachine.CameraState::get_PositionCorrection()
extern void CameraState_get_PositionCorrection_m19DFDEC5E34379495FE563689462063CF01CC87B (void);
// 0x0000025D System.Void Cinemachine.CameraState::set_PositionCorrection(UnityEngine.Vector3)
extern void CameraState_set_PositionCorrection_m5A6BC8785013D7DA1B8B814BEA2FB2893C8D681B (void);
// 0x0000025E UnityEngine.Quaternion Cinemachine.CameraState::get_OrientationCorrection()
extern void CameraState_get_OrientationCorrection_m50B2841F1C1C41B276CE76048DBE68CC355EBE9E (void);
// 0x0000025F System.Void Cinemachine.CameraState::set_OrientationCorrection(UnityEngine.Quaternion)
extern void CameraState_set_OrientationCorrection_m78B62F6D9C90041D16F969BF5C5DF5775380F4E3 (void);
// 0x00000260 UnityEngine.Vector3 Cinemachine.CameraState::get_CorrectedPosition()
extern void CameraState_get_CorrectedPosition_mFEB78C718574311BE01F52353220D8E3EC062344 (void);
// 0x00000261 UnityEngine.Quaternion Cinemachine.CameraState::get_CorrectedOrientation()
extern void CameraState_get_CorrectedOrientation_mB74864040A12CF81360C263385AE1CFFFA73E9BB (void);
// 0x00000262 UnityEngine.Vector3 Cinemachine.CameraState::get_FinalPosition()
extern void CameraState_get_FinalPosition_mABA119F4F7BDAB3C56B5A9D50A0A4E9F0EC5BFBA (void);
// 0x00000263 UnityEngine.Quaternion Cinemachine.CameraState::get_FinalOrientation()
extern void CameraState_get_FinalOrientation_m44213894D5B3665846C120EA54FD5F116FBBBC40 (void);
// 0x00000264 Cinemachine.CameraState/BlendHintValue Cinemachine.CameraState::get_BlendHint()
extern void CameraState_get_BlendHint_m787612D5DE9717F032149B538F603DA69B26FC75 (void);
// 0x00000265 System.Void Cinemachine.CameraState::set_BlendHint(Cinemachine.CameraState/BlendHintValue)
extern void CameraState_set_BlendHint_mFEAA3F666F38C388C5CCF863FF3711CEEE3A0A52 (void);
// 0x00000266 Cinemachine.CameraState Cinemachine.CameraState::get_Default()
extern void CameraState_get_Default_m12D560DD60BC9AC6B1A0287EF92D21BFF1C1C8A7 (void);
// 0x00000267 System.Int32 Cinemachine.CameraState::get_NumCustomBlendables()
extern void CameraState_get_NumCustomBlendables_m45122BC6F6592ACC07FD85C38B3A756FEC60A7CF (void);
// 0x00000268 System.Void Cinemachine.CameraState::set_NumCustomBlendables(System.Int32)
extern void CameraState_set_NumCustomBlendables_mF90E1B32FE572F25B187D449C5AEE2499AAE564F (void);
// 0x00000269 Cinemachine.CameraState/CustomBlendable Cinemachine.CameraState::GetCustomBlendable(System.Int32)
extern void CameraState_GetCustomBlendable_mD4E4CD7E5D2F4ABF74B78B4997BEA73C65C704BF (void);
// 0x0000026A System.Int32 Cinemachine.CameraState::FindCustomBlendable(UnityEngine.Object)
extern void CameraState_FindCustomBlendable_mADB6FC113F422BEEA9B9DE3CCEAA69C505BEEDAC (void);
// 0x0000026B System.Void Cinemachine.CameraState::AddCustomBlendable(Cinemachine.CameraState/CustomBlendable)
extern void CameraState_AddCustomBlendable_mD2B67C82217C56D550713328D287282A0548CD97 (void);
// 0x0000026C Cinemachine.CameraState Cinemachine.CameraState::Lerp(Cinemachine.CameraState,Cinemachine.CameraState,System.Single)
extern void CameraState_Lerp_m29CBA400AE3DAD80F7B1F9B81B9758244530CB9B (void);
// 0x0000026D System.Single Cinemachine.CameraState::InterpolateFOV(System.Single,System.Single,System.Single,System.Single,System.Single)
extern void CameraState_InterpolateFOV_m2C5E3CCFCAE4D654A2BD7F07A50F5E52EEBB8E02 (void);
// 0x0000026E UnityEngine.Vector3 Cinemachine.CameraState::ApplyPosBlendHint(UnityEngine.Vector3,Cinemachine.CameraState/BlendHintValue,UnityEngine.Vector3,Cinemachine.CameraState/BlendHintValue,UnityEngine.Vector3,UnityEngine.Vector3)
extern void CameraState_ApplyPosBlendHint_m9A27867615504FB4A36D503396BA10DE7603986C (void);
// 0x0000026F UnityEngine.Quaternion Cinemachine.CameraState::ApplyRotBlendHint(UnityEngine.Quaternion,Cinemachine.CameraState/BlendHintValue,UnityEngine.Quaternion,Cinemachine.CameraState/BlendHintValue,UnityEngine.Quaternion,UnityEngine.Quaternion)
extern void CameraState_ApplyRotBlendHint_mECDD8502F1EB7BC1B728A7DC3247AEC7B618DDE5 (void);
// 0x00000270 UnityEngine.Vector3 Cinemachine.CameraState::InterpolatePosition(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void CameraState_InterpolatePosition_m731CF3321931B836BFF7D6025001E0DBDBBF8341 (void);
// 0x00000271 System.Void Cinemachine.CameraState::.cctor()
extern void CameraState__cctor_m9FC1441CCCB6B5F891327B1F238C4B26FEC06760 (void);
// 0x00000272 System.Void Cinemachine.CameraState/CustomBlendable::.ctor(UnityEngine.Object,System.Single)
extern void CustomBlendable__ctor_mA7DEF75ACB9FDE678221EF6176FBD4DC4441FB07 (void);
// 0x00000273 Cinemachine.ICinemachineCamera Cinemachine.CinemachineBlend::get_CamA()
extern void CinemachineBlend_get_CamA_m84EE61BF64BEBAA6DD45591F1D6E727B894DAC91 (void);
// 0x00000274 System.Void Cinemachine.CinemachineBlend::set_CamA(Cinemachine.ICinemachineCamera)
extern void CinemachineBlend_set_CamA_m5E656E137DE95F70ADF349416BDF9845358143BF (void);
// 0x00000275 Cinemachine.ICinemachineCamera Cinemachine.CinemachineBlend::get_CamB()
extern void CinemachineBlend_get_CamB_m81ADE44158093EBCB50F04D90A1DD775FC02C4A7 (void);
// 0x00000276 System.Void Cinemachine.CinemachineBlend::set_CamB(Cinemachine.ICinemachineCamera)
extern void CinemachineBlend_set_CamB_m502F49F7663036661B7C21945F58ED2C584308EA (void);
// 0x00000277 UnityEngine.AnimationCurve Cinemachine.CinemachineBlend::get_BlendCurve()
extern void CinemachineBlend_get_BlendCurve_m6A1FF79078DEA51B8343A4135E7A5E002D5D13C6 (void);
// 0x00000278 System.Void Cinemachine.CinemachineBlend::set_BlendCurve(UnityEngine.AnimationCurve)
extern void CinemachineBlend_set_BlendCurve_m1C92DE13808FD00C1AE25E8D2AA898B82E77129C (void);
// 0x00000279 System.Single Cinemachine.CinemachineBlend::get_TimeInBlend()
extern void CinemachineBlend_get_TimeInBlend_mFA561FA319D53F2A245E6D14A67F10356FDE9502 (void);
// 0x0000027A System.Void Cinemachine.CinemachineBlend::set_TimeInBlend(System.Single)
extern void CinemachineBlend_set_TimeInBlend_mCB11D4F786D1D2201521E1C5E43FBAA7CF77202E (void);
// 0x0000027B System.Single Cinemachine.CinemachineBlend::get_BlendWeight()
extern void CinemachineBlend_get_BlendWeight_mCCA9907E0F251FB96CCC75DE16EB76359E69D392 (void);
// 0x0000027C System.Boolean Cinemachine.CinemachineBlend::get_IsValid()
extern void CinemachineBlend_get_IsValid_m55FFFA5BC32710DA0EF7CA8DBD7B0303D562D0D2 (void);
// 0x0000027D System.Single Cinemachine.CinemachineBlend::get_Duration()
extern void CinemachineBlend_get_Duration_mB9E2A918F60A7F8BFFADB38BE2D51455FECDF7E4 (void);
// 0x0000027E System.Void Cinemachine.CinemachineBlend::set_Duration(System.Single)
extern void CinemachineBlend_set_Duration_m6624099445533093B65C3E92C25060E2C5B2692B (void);
// 0x0000027F System.Boolean Cinemachine.CinemachineBlend::get_IsComplete()
extern void CinemachineBlend_get_IsComplete_m3FF0BF1A998D7E09ED0FCBEA109C9BEE7721CA50 (void);
// 0x00000280 System.String Cinemachine.CinemachineBlend::get_Description()
extern void CinemachineBlend_get_Description_m4096D0C82956E1009FA82A07FA6BB184FD5EBC59 (void);
// 0x00000281 System.Boolean Cinemachine.CinemachineBlend::Uses(Cinemachine.ICinemachineCamera)
extern void CinemachineBlend_Uses_mE5C14AEF4BE8C61F17564F4F5DA84831449B6F4B (void);
// 0x00000282 System.Void Cinemachine.CinemachineBlend::.ctor(Cinemachine.ICinemachineCamera,Cinemachine.ICinemachineCamera,UnityEngine.AnimationCurve,System.Single,System.Single)
extern void CinemachineBlend__ctor_mB06EF56D92F3900609669689E8820647EE84B5A3 (void);
// 0x00000283 System.Void Cinemachine.CinemachineBlend::UpdateCameraState(UnityEngine.Vector3,System.Single)
extern void CinemachineBlend_UpdateCameraState_m4B58F6808D5B9494A583E9C0CBDC4841CBEB99E1 (void);
// 0x00000284 Cinemachine.CameraState Cinemachine.CinemachineBlend::get_State()
extern void CinemachineBlend_get_State_m353325CD92B13EF46EAF00985769217EA4F98FA1 (void);
// 0x00000285 System.Single Cinemachine.CinemachineBlendDefinition::get_BlendTime()
extern void CinemachineBlendDefinition_get_BlendTime_m2185E8662569BE0201996EAA3AC55C1A095CA5E3 (void);
// 0x00000286 System.Void Cinemachine.CinemachineBlendDefinition::.ctor(Cinemachine.CinemachineBlendDefinition/Style,System.Single)
extern void CinemachineBlendDefinition__ctor_m51379366ABFBFF4642735E6C843F54CF45D642CF (void);
// 0x00000287 System.Void Cinemachine.CinemachineBlendDefinition::CreateStandardCurves()
extern void CinemachineBlendDefinition_CreateStandardCurves_m4877FF63D3A4E8933F6817ECAEB9B500B9A3D56B (void);
// 0x00000288 UnityEngine.AnimationCurve Cinemachine.CinemachineBlendDefinition::get_BlendCurve()
extern void CinemachineBlendDefinition_get_BlendCurve_m547D15706E83EACB4DE888750C0728BDE5974873 (void);
// 0x00000289 System.Void Cinemachine.StaticPointVirtualCamera::.ctor(Cinemachine.CameraState,System.String)
extern void StaticPointVirtualCamera__ctor_mAC0BFA55F9A05C87AFAFC15C1282DCF7A88F7330 (void);
// 0x0000028A System.Void Cinemachine.StaticPointVirtualCamera::SetState(Cinemachine.CameraState)
extern void StaticPointVirtualCamera_SetState_m0111F6AAC091400D8554DFCD60258C958D241933 (void);
// 0x0000028B System.String Cinemachine.StaticPointVirtualCamera::get_Name()
extern void StaticPointVirtualCamera_get_Name_m88CDC311CAE2371482E697C343C5D364D3921FBA (void);
// 0x0000028C System.Void Cinemachine.StaticPointVirtualCamera::set_Name(System.String)
extern void StaticPointVirtualCamera_set_Name_mC42E291C5240205CAE873C773EA2B4D1AEBCBA38 (void);
// 0x0000028D System.String Cinemachine.StaticPointVirtualCamera::get_Description()
extern void StaticPointVirtualCamera_get_Description_mD42A5CEF974DE56D2F2ADEE0D041A51FAA24FDA8 (void);
// 0x0000028E System.Int32 Cinemachine.StaticPointVirtualCamera::get_Priority()
extern void StaticPointVirtualCamera_get_Priority_mD186335682BAEEA3BDBB50BA6667DC287FAFAF55 (void);
// 0x0000028F System.Void Cinemachine.StaticPointVirtualCamera::set_Priority(System.Int32)
extern void StaticPointVirtualCamera_set_Priority_m1200B4DCA10859C74244CBA6D6619222450613A4 (void);
// 0x00000290 UnityEngine.Transform Cinemachine.StaticPointVirtualCamera::get_LookAt()
extern void StaticPointVirtualCamera_get_LookAt_m81DE46064CF375735C542138F35390F99692F864 (void);
// 0x00000291 System.Void Cinemachine.StaticPointVirtualCamera::set_LookAt(UnityEngine.Transform)
extern void StaticPointVirtualCamera_set_LookAt_m0AB6CA2B5FCE282A9D34CF1F90D6B53E538921D3 (void);
// 0x00000292 UnityEngine.Transform Cinemachine.StaticPointVirtualCamera::get_Follow()
extern void StaticPointVirtualCamera_get_Follow_m5C80C9614891CEA38FD1C386B5EA6A0A5D2D856C (void);
// 0x00000293 System.Void Cinemachine.StaticPointVirtualCamera::set_Follow(UnityEngine.Transform)
extern void StaticPointVirtualCamera_set_Follow_m607FEDDF53E09CD16CA022F1E55783558FA71746 (void);
// 0x00000294 Cinemachine.CameraState Cinemachine.StaticPointVirtualCamera::get_State()
extern void StaticPointVirtualCamera_get_State_m4864EB89CDE70665713ADCF80A4612B5BDE43980 (void);
// 0x00000295 System.Void Cinemachine.StaticPointVirtualCamera::set_State(Cinemachine.CameraState)
extern void StaticPointVirtualCamera_set_State_mC75EE398CBB9A6BE8054F5CD5C4AF90982EEF670 (void);
// 0x00000296 UnityEngine.GameObject Cinemachine.StaticPointVirtualCamera::get_VirtualCameraGameObject()
extern void StaticPointVirtualCamera_get_VirtualCameraGameObject_mE9318C1A3D5D4779A2D20ECC5FE32C2872E8059E (void);
// 0x00000297 System.Boolean Cinemachine.StaticPointVirtualCamera::get_IsValid()
extern void StaticPointVirtualCamera_get_IsValid_m207DE6EDCE733D57C032075ED3FEE27A0DA5EDA4 (void);
// 0x00000298 Cinemachine.ICinemachineCamera Cinemachine.StaticPointVirtualCamera::get_ParentCamera()
extern void StaticPointVirtualCamera_get_ParentCamera_m939FE729B7EEC40DA987EA842094EF2D2D660B0E (void);
// 0x00000299 System.Boolean Cinemachine.StaticPointVirtualCamera::IsLiveChild(Cinemachine.ICinemachineCamera,System.Boolean)
extern void StaticPointVirtualCamera_IsLiveChild_mE99E5559C21364521C4DF662E25EC8CA3300AD45 (void);
// 0x0000029A System.Void Cinemachine.StaticPointVirtualCamera::UpdateCameraState(UnityEngine.Vector3,System.Single)
extern void StaticPointVirtualCamera_UpdateCameraState_m032CCA1E862B142F48323104B4785597D6F1BE50 (void);
// 0x0000029B System.Void Cinemachine.StaticPointVirtualCamera::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
extern void StaticPointVirtualCamera_InternalUpdateCameraState_m1B0FEA4EB03147B15FDA4D1B8BC57F1259BB4008 (void);
// 0x0000029C System.Void Cinemachine.StaticPointVirtualCamera::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void StaticPointVirtualCamera_OnTransitionFromCamera_m9B762A7A6E09D9F4B670045857761C91EFC28823 (void);
// 0x0000029D System.Void Cinemachine.StaticPointVirtualCamera::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void StaticPointVirtualCamera_OnTargetObjectWarped_m41F5BB8D4A13B4B4D72A8B764E61A077F8CD167F (void);
// 0x0000029E System.Void Cinemachine.BlendSourceVirtualCamera::.ctor(Cinemachine.CinemachineBlend)
extern void BlendSourceVirtualCamera__ctor_m762CFEB65D584FC854F9653CF1A97444FF86E08B (void);
// 0x0000029F Cinemachine.CinemachineBlend Cinemachine.BlendSourceVirtualCamera::get_Blend()
extern void BlendSourceVirtualCamera_get_Blend_mB5C0C8918EA30ABEE4F85F1BB493075EFF0F1B60 (void);
// 0x000002A0 System.Void Cinemachine.BlendSourceVirtualCamera::set_Blend(Cinemachine.CinemachineBlend)
extern void BlendSourceVirtualCamera_set_Blend_m2EBC2E6A8F75FF3F416F0FE2583DA24E6320FEFA (void);
// 0x000002A1 System.String Cinemachine.BlendSourceVirtualCamera::get_Name()
extern void BlendSourceVirtualCamera_get_Name_m4F4C48F79D68A9E15606415175DD1067B950677C (void);
// 0x000002A2 System.String Cinemachine.BlendSourceVirtualCamera::get_Description()
extern void BlendSourceVirtualCamera_get_Description_m3B5EA1CECACCF4EA3B337E1DEA134DE4F87234C5 (void);
// 0x000002A3 System.Int32 Cinemachine.BlendSourceVirtualCamera::get_Priority()
extern void BlendSourceVirtualCamera_get_Priority_m043ABE54F59106B010EEBC2F48AEF70E82AFBF92 (void);
// 0x000002A4 System.Void Cinemachine.BlendSourceVirtualCamera::set_Priority(System.Int32)
extern void BlendSourceVirtualCamera_set_Priority_mC7108E9EAC45C4F8492791A250F72100A044508C (void);
// 0x000002A5 UnityEngine.Transform Cinemachine.BlendSourceVirtualCamera::get_LookAt()
extern void BlendSourceVirtualCamera_get_LookAt_m923B7FD1549B3E1090A3ACBB9E51A28A195D7813 (void);
// 0x000002A6 System.Void Cinemachine.BlendSourceVirtualCamera::set_LookAt(UnityEngine.Transform)
extern void BlendSourceVirtualCamera_set_LookAt_m4D4DB97225E4779DBE60447EF5E89A8EA91CEDFC (void);
// 0x000002A7 UnityEngine.Transform Cinemachine.BlendSourceVirtualCamera::get_Follow()
extern void BlendSourceVirtualCamera_get_Follow_m2AFD8A2446B3DD4C713C4BE180974AEA67F27B7C (void);
// 0x000002A8 System.Void Cinemachine.BlendSourceVirtualCamera::set_Follow(UnityEngine.Transform)
extern void BlendSourceVirtualCamera_set_Follow_m24D9B623C684CD670659A4E36371C78007DEE55A (void);
// 0x000002A9 Cinemachine.CameraState Cinemachine.BlendSourceVirtualCamera::get_State()
extern void BlendSourceVirtualCamera_get_State_mA0FD90B6B6D4FF668604E9B199E4DBB6299D28D8 (void);
// 0x000002AA System.Void Cinemachine.BlendSourceVirtualCamera::set_State(Cinemachine.CameraState)
extern void BlendSourceVirtualCamera_set_State_m1939F89FAA80BDCB54AA3983EA6DDCB582E1C6BB (void);
// 0x000002AB UnityEngine.GameObject Cinemachine.BlendSourceVirtualCamera::get_VirtualCameraGameObject()
extern void BlendSourceVirtualCamera_get_VirtualCameraGameObject_mFA88FE034A5AD685D2E797CD21050EEF5FE3E2AB (void);
// 0x000002AC System.Boolean Cinemachine.BlendSourceVirtualCamera::get_IsValid()
extern void BlendSourceVirtualCamera_get_IsValid_m4D11A4E0F85913145D907D6DF092E653D3BCB272 (void);
// 0x000002AD Cinemachine.ICinemachineCamera Cinemachine.BlendSourceVirtualCamera::get_ParentCamera()
extern void BlendSourceVirtualCamera_get_ParentCamera_mAAB7D1922FEB01F0D76E175DFF5F588B3557B46D (void);
// 0x000002AE System.Boolean Cinemachine.BlendSourceVirtualCamera::IsLiveChild(Cinemachine.ICinemachineCamera,System.Boolean)
extern void BlendSourceVirtualCamera_IsLiveChild_m5D3C8B7EA632D8E40D2D5B75F43B762524A3D8BB (void);
// 0x000002AF Cinemachine.CameraState Cinemachine.BlendSourceVirtualCamera::CalculateNewState(System.Single)
extern void BlendSourceVirtualCamera_CalculateNewState_mA5EA36A4D37412F1B2B14CFA7E7C1478CACEEF5D (void);
// 0x000002B0 System.Void Cinemachine.BlendSourceVirtualCamera::UpdateCameraState(UnityEngine.Vector3,System.Single)
extern void BlendSourceVirtualCamera_UpdateCameraState_m7B24A298453FCB56F8B840E7DA846270F621AE55 (void);
// 0x000002B1 System.Void Cinemachine.BlendSourceVirtualCamera::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
extern void BlendSourceVirtualCamera_InternalUpdateCameraState_m4E07980798FF47304F5A3A420EDDFD99E8F7B62F (void);
// 0x000002B2 System.Void Cinemachine.BlendSourceVirtualCamera::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void BlendSourceVirtualCamera_OnTransitionFromCamera_mEACC986DA2FD0B5ECA68773558FC33504FB32947 (void);
// 0x000002B3 System.Void Cinemachine.BlendSourceVirtualCamera::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void BlendSourceVirtualCamera_OnTargetObjectWarped_mBA61A40425AE0741B93ABEC054F616B6E7C39A4C (void);
// 0x000002B4 Cinemachine.CinemachineBlendDefinition Cinemachine.CinemachineBlenderSettings::GetBlendForVirtualCameras(System.String,System.String,Cinemachine.CinemachineBlendDefinition)
extern void CinemachineBlenderSettings_GetBlendForVirtualCameras_m83B852A5B14C8ED39E2FC581D3BB11528FD3B565 (void);
// 0x000002B5 System.Void Cinemachine.CinemachineBlenderSettings::.ctor()
extern void CinemachineBlenderSettings__ctor_m8548E0C3CD5CBF25ADEE8574A5258A021D1E1A07 (void);
// 0x000002B6 Cinemachine.CinemachineVirtualCameraBase Cinemachine.CinemachineComponentBase::get_VirtualCamera()
extern void CinemachineComponentBase_get_VirtualCamera_mDDC4BEDF77A93F4C25C2E62CBF96542ABB6FE3BA (void);
// 0x000002B7 UnityEngine.Transform Cinemachine.CinemachineComponentBase::get_FollowTarget()
extern void CinemachineComponentBase_get_FollowTarget_m6A52B9EAC2F1B1DD8D8F901A48F52A296B4715AC (void);
// 0x000002B8 UnityEngine.Transform Cinemachine.CinemachineComponentBase::get_LookAtTarget()
extern void CinemachineComponentBase_get_LookAtTarget_m0B8D7462A7C631E082634733954374BD9C030F70 (void);
// 0x000002B9 System.Void Cinemachine.CinemachineComponentBase::UpdateFollowTargetCache()
extern void CinemachineComponentBase_UpdateFollowTargetCache_m8047A77301A9616719C733A8D394D881FB78BA0B (void);
// 0x000002BA Cinemachine.ICinemachineTargetGroup Cinemachine.CinemachineComponentBase::get_AbstractFollowTargetGroup()
extern void CinemachineComponentBase_get_AbstractFollowTargetGroup_m3A97181333E7E463488F030F83D72D4D671946D1 (void);
// 0x000002BB Cinemachine.CinemachineTargetGroup Cinemachine.CinemachineComponentBase::get_FollowTargetGroup()
extern void CinemachineComponentBase_get_FollowTargetGroup_m7AFAB2E9C70EC126379938A1FCFC90B14EC20472 (void);
// 0x000002BC UnityEngine.Vector3 Cinemachine.CinemachineComponentBase::get_FollowTargetPosition()
extern void CinemachineComponentBase_get_FollowTargetPosition_mF3A92D2EE8A07BC0E1FC820AFAA5F4CC24CD1C94 (void);
// 0x000002BD UnityEngine.Quaternion Cinemachine.CinemachineComponentBase::get_FollowTargetRotation()
extern void CinemachineComponentBase_get_FollowTargetRotation_m63FA12EC6372FC0D1D4C0224C86AD054EA31387F (void);
// 0x000002BE System.Void Cinemachine.CinemachineComponentBase::UpdateLookAtTargetCache()
extern void CinemachineComponentBase_UpdateLookAtTargetCache_m0E7E8C9C13122A00F3506B5094A71A22DD001DE6 (void);
// 0x000002BF Cinemachine.ICinemachineTargetGroup Cinemachine.CinemachineComponentBase::get_AbstractLookAtTargetGroup()
extern void CinemachineComponentBase_get_AbstractLookAtTargetGroup_m09E391BC22E9B714A1A18DC19BEF1E445A39AAA8 (void);
// 0x000002C0 Cinemachine.CinemachineTargetGroup Cinemachine.CinemachineComponentBase::get_LookAtTargetGroup()
extern void CinemachineComponentBase_get_LookAtTargetGroup_mF5DE59F602311812B2A1B3EC112ECB26DB0585BA (void);
// 0x000002C1 UnityEngine.Vector3 Cinemachine.CinemachineComponentBase::get_LookAtTargetPosition()
extern void CinemachineComponentBase_get_LookAtTargetPosition_m276755F157FCDC7F0933FF7E965826B6B782031B (void);
// 0x000002C2 UnityEngine.Quaternion Cinemachine.CinemachineComponentBase::get_LookAtTargetRotation()
extern void CinemachineComponentBase_get_LookAtTargetRotation_mCCBCCE7A00B6FECC898C11A787FB18432EF38A86 (void);
// 0x000002C3 Cinemachine.CameraState Cinemachine.CinemachineComponentBase::get_VcamState()
extern void CinemachineComponentBase_get_VcamState_m0F36DA00A9FF33209646471FDF6F7EC6F7DF6B80 (void);
// 0x000002C4 System.Boolean Cinemachine.CinemachineComponentBase::get_IsValid()
// 0x000002C5 System.Void Cinemachine.CinemachineComponentBase::PrePipelineMutateCameraState(Cinemachine.CameraState&,System.Single)
extern void CinemachineComponentBase_PrePipelineMutateCameraState_mAFE097E8C3220CE39BEFFFB48BDF31779A6C68D0 (void);
// 0x000002C6 Cinemachine.CinemachineCore/Stage Cinemachine.CinemachineComponentBase::get_Stage()
// 0x000002C7 System.Boolean Cinemachine.CinemachineComponentBase::get_BodyAppliesAfterAim()
extern void CinemachineComponentBase_get_BodyAppliesAfterAim_mE51BED341B65934E6CA3D8AE31A4F84B2525F52A (void);
// 0x000002C8 System.Void Cinemachine.CinemachineComponentBase::MutateCameraState(Cinemachine.CameraState&,System.Single)
// 0x000002C9 System.Boolean Cinemachine.CinemachineComponentBase::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single,Cinemachine.CinemachineVirtualCameraBase/TransitionParams&)
extern void CinemachineComponentBase_OnTransitionFromCamera_m9DD4DF577144AF4CEA69C855EAA324D1168EBBE4 (void);
// 0x000002CA System.Void Cinemachine.CinemachineComponentBase::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineComponentBase_OnTargetObjectWarped_m68C3CCD5A93FF2DD4013F33DDC1204A97B54A701 (void);
// 0x000002CB System.Void Cinemachine.CinemachineComponentBase::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineComponentBase_ForceCameraPosition_mFDFA0AE6EA6C4E03EAB878E392AD312AAD454EF4 (void);
// 0x000002CC System.Single Cinemachine.CinemachineComponentBase::GetMaxDampTime()
extern void CinemachineComponentBase_GetMaxDampTime_m630233212BCB908E0F9EF150C2FDF5559808691F (void);
// 0x000002CD System.Void Cinemachine.CinemachineComponentBase::.ctor()
extern void CinemachineComponentBase__ctor_mF80CD1194482BC499205396A8622FAE20F5B75D4 (void);
// 0x000002CE Cinemachine.CinemachineCore Cinemachine.CinemachineCore::get_Instance()
extern void CinemachineCore_get_Instance_mCD8E65EBCBB58BEDC6FD0C503AB9E866B76AFA83 (void);
// 0x000002CF System.Single Cinemachine.CinemachineCore::get_DeltaTime()
extern void CinemachineCore_get_DeltaTime_m8AC61BA9F0163DFE1A3D0FC5C40937B7722EB883 (void);
// 0x000002D0 System.Single Cinemachine.CinemachineCore::get_CurrentTime()
extern void CinemachineCore_get_CurrentTime_mBD3A55B23004CB425D9297086BC20D7C55797625 (void);
// 0x000002D1 System.Int32 Cinemachine.CinemachineCore::get_BrainCount()
extern void CinemachineCore_get_BrainCount_mA544A424A3E3FC613955E2D60CA93484BC97616C (void);
// 0x000002D2 Cinemachine.CinemachineBrain Cinemachine.CinemachineCore::GetActiveBrain(System.Int32)
extern void CinemachineCore_GetActiveBrain_m99FB4BE86B83C680EB414B5D1770908EA7ADF558 (void);
// 0x000002D3 System.Void Cinemachine.CinemachineCore::AddActiveBrain(Cinemachine.CinemachineBrain)
extern void CinemachineCore_AddActiveBrain_m0BD0B7F334ABB98A322EACBA8285BD164D6E69AB (void);
// 0x000002D4 System.Void Cinemachine.CinemachineCore::RemoveActiveBrain(Cinemachine.CinemachineBrain)
extern void CinemachineCore_RemoveActiveBrain_m1FF228AA890EFDF236F0E434A1C88701A66BAE15 (void);
// 0x000002D5 System.Int32 Cinemachine.CinemachineCore::get_VirtualCameraCount()
extern void CinemachineCore_get_VirtualCameraCount_m09675B5895A728AC31A0892F5343264CB34FE708 (void);
// 0x000002D6 Cinemachine.CinemachineVirtualCameraBase Cinemachine.CinemachineCore::GetVirtualCamera(System.Int32)
extern void CinemachineCore_GetVirtualCamera_m648982BBF286DB719899EB96C4E7FF17B1B5C86C (void);
// 0x000002D7 System.Void Cinemachine.CinemachineCore::AddActiveCamera(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineCore_AddActiveCamera_m15B0C7AD4C1A0F46FC24A1121B399D80F7026DB7 (void);
// 0x000002D8 System.Void Cinemachine.CinemachineCore::RemoveActiveCamera(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineCore_RemoveActiveCamera_mD28005289E4D2F4000E8121243A97DCE8922B4C1 (void);
// 0x000002D9 System.Void Cinemachine.CinemachineCore::CameraDestroyed(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineCore_CameraDestroyed_m9A825D47C357F36DABCC51C466E0704BD49E13EB (void);
// 0x000002DA System.Void Cinemachine.CinemachineCore::CameraEnabled(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineCore_CameraEnabled_m5DC7D833542C8CEA753704CE9026C4CE9A00EAC6 (void);
// 0x000002DB System.Void Cinemachine.CinemachineCore::CameraDisabled(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineCore_CameraDisabled_m9B1E9D658D5C6090F2C85A82C013908DC99A380E (void);
// 0x000002DC System.Int32 Cinemachine.CinemachineCore::get_FixedFrameCount()
extern void CinemachineCore_get_FixedFrameCount_m119017A9C55B62668AFD1AE6D209A1E9B21210C8 (void);
// 0x000002DD System.Void Cinemachine.CinemachineCore::set_FixedFrameCount(System.Int32)
extern void CinemachineCore_set_FixedFrameCount_m814A0AC94BD3C5FEC3CEB31390AFC79D7F664F6D (void);
// 0x000002DE System.Void Cinemachine.CinemachineCore::UpdateAllActiveVirtualCameras(System.Int32,UnityEngine.Vector3,System.Single)
extern void CinemachineCore_UpdateAllActiveVirtualCameras_mCEAF2622091B0DC36A26A844C7C6022BF3C40A51 (void);
// 0x000002DF System.Void Cinemachine.CinemachineCore::UpdateVirtualCamera(Cinemachine.CinemachineVirtualCameraBase,UnityEngine.Vector3,System.Single)
extern void CinemachineCore_UpdateVirtualCamera_m937B1B00C50FDEFC1C9AE346DF37A0694D04F9EF (void);
// 0x000002E0 System.Void Cinemachine.CinemachineCore::InitializeModule()
extern void CinemachineCore_InitializeModule_m9605C793013867D1CCFA4CE04C6673E6665B6F82 (void);
// 0x000002E1 Cinemachine.CinemachineCore/UpdateFilter Cinemachine.CinemachineCore::get_CurrentUpdateFilter()
extern void CinemachineCore_get_CurrentUpdateFilter_m6FC774F24C226A7BACD909FB796DC1406A5EDCD0 (void);
// 0x000002E2 System.Void Cinemachine.CinemachineCore::set_CurrentUpdateFilter(Cinemachine.CinemachineCore/UpdateFilter)
extern void CinemachineCore_set_CurrentUpdateFilter_m3E96AD239CF49A028CF514AE0631AA05DE5E3313 (void);
// 0x000002E3 UnityEngine.Transform Cinemachine.CinemachineCore::GetUpdateTarget(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineCore_GetUpdateTarget_m4BCCFF232B14DEDDAF22E5E526638833FA065094 (void);
// 0x000002E4 Cinemachine.UpdateTracker/UpdateClock Cinemachine.CinemachineCore::GetVcamUpdateStatus(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineCore_GetVcamUpdateStatus_m2C7C238F785E1F474B1707520007D3AA42129D04 (void);
// 0x000002E5 System.Boolean Cinemachine.CinemachineCore::IsLive(Cinemachine.ICinemachineCamera)
extern void CinemachineCore_IsLive_m61EC3BE5D22564DD740379A88639BF368EBC1E43 (void);
// 0x000002E6 System.Void Cinemachine.CinemachineCore::GenerateCameraActivationEvent(Cinemachine.ICinemachineCamera,Cinemachine.ICinemachineCamera)
extern void CinemachineCore_GenerateCameraActivationEvent_m851F3990838CAAD976391EECAC4D57B1C61E938A (void);
// 0x000002E7 System.Void Cinemachine.CinemachineCore::GenerateCameraCutEvent(Cinemachine.ICinemachineCamera)
extern void CinemachineCore_GenerateCameraCutEvent_m38E839FFCA8034AC081D9F99FBEEC15B872F14C6 (void);
// 0x000002E8 Cinemachine.CinemachineBrain Cinemachine.CinemachineCore::FindPotentialTargetBrain(Cinemachine.CinemachineVirtualCameraBase)
extern void CinemachineCore_FindPotentialTargetBrain_m5DE059E6EDDE3EF8BD7258655A61A70BD7DA6F77 (void);
// 0x000002E9 System.Void Cinemachine.CinemachineCore::.ctor()
extern void CinemachineCore__ctor_mC1794CB6B097D4CB15080ECDB82E4F2267C1D712 (void);
// 0x000002EA System.Void Cinemachine.CinemachineCore::.cctor()
extern void CinemachineCore__cctor_m5F6647805E2D5EC0C7F1B86D109D21F5D66FEEA7 (void);
// 0x000002EB System.Void Cinemachine.CinemachineCore/AxisInputDelegate::.ctor(System.Object,System.IntPtr)
extern void AxisInputDelegate__ctor_m55631A6E688731D441A5822CE96218E7E9CC5B01 (void);
// 0x000002EC System.Single Cinemachine.CinemachineCore/AxisInputDelegate::Invoke(System.String)
extern void AxisInputDelegate_Invoke_m860AF1CED1A9DF40081361395A2E99E5913DE2D4 (void);
// 0x000002ED System.IAsyncResult Cinemachine.CinemachineCore/AxisInputDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void AxisInputDelegate_BeginInvoke_mE17152E703E8CC1FD23F1699D57494CD620D559D (void);
// 0x000002EE System.Single Cinemachine.CinemachineCore/AxisInputDelegate::EndInvoke(System.IAsyncResult)
extern void AxisInputDelegate_EndInvoke_m42BA5EAD29B364609461C59796CF1FE308942777 (void);
// 0x000002EF System.Void Cinemachine.CinemachineCore/GetBlendOverrideDelegate::.ctor(System.Object,System.IntPtr)
extern void GetBlendOverrideDelegate__ctor_m0D9DFFA11AA07FC85C2903B99641E4CE9BF6DC9B (void);
// 0x000002F0 Cinemachine.CinemachineBlendDefinition Cinemachine.CinemachineCore/GetBlendOverrideDelegate::Invoke(Cinemachine.ICinemachineCamera,Cinemachine.ICinemachineCamera,Cinemachine.CinemachineBlendDefinition,UnityEngine.MonoBehaviour)
extern void GetBlendOverrideDelegate_Invoke_mAE517451152A2ADCF950A31A7004F52FA64C8EE0 (void);
// 0x000002F1 System.IAsyncResult Cinemachine.CinemachineCore/GetBlendOverrideDelegate::BeginInvoke(Cinemachine.ICinemachineCamera,Cinemachine.ICinemachineCamera,Cinemachine.CinemachineBlendDefinition,UnityEngine.MonoBehaviour,System.AsyncCallback,System.Object)
extern void GetBlendOverrideDelegate_BeginInvoke_m4CEF86F10D8C529DD09C94310D0E70668307B360 (void);
// 0x000002F2 Cinemachine.CinemachineBlendDefinition Cinemachine.CinemachineCore/GetBlendOverrideDelegate::EndInvoke(System.IAsyncResult)
extern void GetBlendOverrideDelegate_EndInvoke_m07B62A912EE6066CE03A1D3125A0BEB2ED1AC0E4 (void);
// 0x000002F3 System.Void Cinemachine.CinemachineCore/UpdateStatus::.ctor()
extern void UpdateStatus__ctor_mAEEB635F3C3AE9D84B9072DA75E14B098312CACD (void);
// 0x000002F4 System.Void Cinemachine.CinemachineCore/<>c::.cctor()
extern void U3CU3Ec__cctor_m98EAFFDFF71A6A736468C8D60AC3ECE675B49340 (void);
// 0x000002F5 System.Void Cinemachine.CinemachineCore/<>c::.ctor()
extern void U3CU3Ec__ctor_m15EED79FFF0FF14467B49DC3AC7D134CA38240DD (void);
// 0x000002F6 System.Int32 Cinemachine.CinemachineCore/<>c::<GetVirtualCamera>b__30_0(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineVirtualCameraBase)
extern void U3CU3Ec_U3CGetVirtualCameraU3Eb__30_0_mDC45F408EA0E79C405DD08F781D20C1CA3017B77 (void);
// 0x000002F7 Cinemachine.CinemachineVirtualCameraBase Cinemachine.CinemachineExtension::get_VirtualCamera()
extern void CinemachineExtension_get_VirtualCamera_m48F40B632C12E90C690465B01A667A3748761AF8 (void);
// 0x000002F8 System.Void Cinemachine.CinemachineExtension::Awake()
extern void CinemachineExtension_Awake_m090793C691718BB30B2C702DC41A2EE51F47BE2E (void);
// 0x000002F9 System.Void Cinemachine.CinemachineExtension::OnEnable()
extern void CinemachineExtension_OnEnable_m41D46718D51487D5FD1F8C9DF9AB05831CA243A9 (void);
// 0x000002FA System.Void Cinemachine.CinemachineExtension::OnDestroy()
extern void CinemachineExtension_OnDestroy_m63D31EE81830209F4127D04ED9C7021C14A13C0C (void);
// 0x000002FB System.Void Cinemachine.CinemachineExtension::EnsureStarted()
extern void CinemachineExtension_EnsureStarted_m3F2553CBD100D1FC3E126F2966A6673AEE82771D (void);
// 0x000002FC System.Void Cinemachine.CinemachineExtension::ConnectToVcam(System.Boolean)
extern void CinemachineExtension_ConnectToVcam_mB763D1DF3E860D7CF8392A28D47D109E261381B2 (void);
// 0x000002FD System.Void Cinemachine.CinemachineExtension::PrePipelineMutateCameraStateCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CameraState&,System.Single)
extern void CinemachineExtension_PrePipelineMutateCameraStateCallback_mA26EFBE159BE7F5A906A1E7229885E49CD4D8D75 (void);
// 0x000002FE System.Void Cinemachine.CinemachineExtension::InvokePostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore/Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachineExtension_InvokePostPipelineStageCallback_m54C975D864B6A6818DE9658ADC23439E45B35F9C (void);
// 0x000002FF System.Void Cinemachine.CinemachineExtension::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore/Stage,Cinemachine.CameraState&,System.Single)
// 0x00000300 System.Void Cinemachine.CinemachineExtension::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineExtension_OnTargetObjectWarped_m20FB23984C9395B8BF67744C1ED7832FCAAFDAAF (void);
// 0x00000301 System.Void Cinemachine.CinemachineExtension::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineExtension_ForceCameraPosition_m1FD206CC4FBF213FA344D8F059BDE6100FE779FF (void);
// 0x00000302 System.Boolean Cinemachine.CinemachineExtension::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void CinemachineExtension_OnTransitionFromCamera_mBE45BD7A872FF8AC13C1E1EA4B59985FE9A7CD6A (void);
// 0x00000303 System.Single Cinemachine.CinemachineExtension::GetMaxDampTime()
extern void CinemachineExtension_GetMaxDampTime_mD88B3216AEF6C76B58EBEF1ABAAC8B9018C47DE8 (void);
// 0x00000304 T Cinemachine.CinemachineExtension::GetExtraState(Cinemachine.ICinemachineCamera)
// 0x00000305 System.Collections.Generic.List`1<T> Cinemachine.CinemachineExtension::GetAllExtraStates()
// 0x00000306 System.Void Cinemachine.CinemachineExtension::.ctor()
extern void CinemachineExtension__ctor_m7331AF4105FCAFF48E3CC9A412B1953647E0BEBA (void);
// 0x00000307 System.Void Cinemachine.AxisBase::Validate()
extern void AxisBase_Validate_mEEA2E671C4CE0548BEA394B5598EA51929E7D33A (void);
// 0x00000308 System.Void Cinemachine.CinemachineInputAxisDriver::Validate()
extern void CinemachineInputAxisDriver_Validate_m144628F55B154073CD729EE89A3F87217FC01173 (void);
// 0x00000309 System.Boolean Cinemachine.CinemachineInputAxisDriver::Update(System.Single,Cinemachine.AxisBase&)
extern void CinemachineInputAxisDriver_Update_mCF849BA78D16DF068F7723E78D6BC171890AB4CA (void);
// 0x0000030A System.Boolean Cinemachine.CinemachineInputAxisDriver::Update(System.Single,Cinemachine.AxisState&)
extern void CinemachineInputAxisDriver_Update_mB3570630DFFA0617C1E132A764E902F2848DF810 (void);
// 0x0000030B System.Single Cinemachine.CinemachineInputAxisDriver::ClampValue(Cinemachine.AxisBase&,System.Single)
extern void CinemachineInputAxisDriver_ClampValue_m1C0996D4C9242ACB7615CDE6C7C4BE9D39B341AF (void);
// 0x0000030C System.Single Cinemachine.CinemachinePathBase::get_MinPos()
// 0x0000030D System.Single Cinemachine.CinemachinePathBase::get_MaxPos()
// 0x0000030E System.Boolean Cinemachine.CinemachinePathBase::get_Looped()
// 0x0000030F System.Single Cinemachine.CinemachinePathBase::StandardizePos(System.Single)
extern void CinemachinePathBase_StandardizePos_m7B0DB6BC2287BFF4EDD7B5C1351FC1570FD1C00D (void);
// 0x00000310 UnityEngine.Vector3 Cinemachine.CinemachinePathBase::EvaluatePosition(System.Single)
// 0x00000311 UnityEngine.Vector3 Cinemachine.CinemachinePathBase::EvaluateTangent(System.Single)
// 0x00000312 UnityEngine.Quaternion Cinemachine.CinemachinePathBase::EvaluateOrientation(System.Single)
// 0x00000313 System.Single Cinemachine.CinemachinePathBase::FindClosestPoint(UnityEngine.Vector3,System.Int32,System.Int32,System.Int32)
extern void CinemachinePathBase_FindClosestPoint_mB3F074A56F3054EA9D9F8B87209D5A12A305BE8E (void);
// 0x00000314 System.Single Cinemachine.CinemachinePathBase::MinUnit(Cinemachine.CinemachinePathBase/PositionUnits)
extern void CinemachinePathBase_MinUnit_mBF5FEF3F3768DD5BEF8790BDBAFD800F42E170FE (void);
// 0x00000315 System.Single Cinemachine.CinemachinePathBase::MaxUnit(Cinemachine.CinemachinePathBase/PositionUnits)
extern void CinemachinePathBase_MaxUnit_m205374FE01FC307D7D7ABDC7432FED2C94561A67 (void);
// 0x00000316 System.Single Cinemachine.CinemachinePathBase::StandardizeUnit(System.Single,Cinemachine.CinemachinePathBase/PositionUnits)
extern void CinemachinePathBase_StandardizeUnit_m4771C500193C929F3F7719A44D5FF8D7E7406B7B (void);
// 0x00000317 UnityEngine.Vector3 Cinemachine.CinemachinePathBase::EvaluatePositionAtUnit(System.Single,Cinemachine.CinemachinePathBase/PositionUnits)
extern void CinemachinePathBase_EvaluatePositionAtUnit_mCC69EFCF35ED5B1210214A96C100E8B809FD5B85 (void);
// 0x00000318 UnityEngine.Vector3 Cinemachine.CinemachinePathBase::EvaluateTangentAtUnit(System.Single,Cinemachine.CinemachinePathBase/PositionUnits)
extern void CinemachinePathBase_EvaluateTangentAtUnit_mFF4C4E5806694670B0281C62E1E598350D574FE7 (void);
// 0x00000319 UnityEngine.Quaternion Cinemachine.CinemachinePathBase::EvaluateOrientationAtUnit(System.Single,Cinemachine.CinemachinePathBase/PositionUnits)
extern void CinemachinePathBase_EvaluateOrientationAtUnit_m78B5F5388A3DD41392F335CA7DB59CA1D8B978F5 (void);
// 0x0000031A System.Int32 Cinemachine.CinemachinePathBase::get_DistanceCacheSampleStepsPerSegment()
// 0x0000031B System.Void Cinemachine.CinemachinePathBase::InvalidateDistanceCache()
extern void CinemachinePathBase_InvalidateDistanceCache_m630E60D7B6535CD35356161A2C4FE94CBA726C63 (void);
// 0x0000031C System.Boolean Cinemachine.CinemachinePathBase::DistanceCacheIsValid()
extern void CinemachinePathBase_DistanceCacheIsValid_m5B4999C83A60EA0834AB8ACBFBFE298EE5AA6FA9 (void);
// 0x0000031D System.Single Cinemachine.CinemachinePathBase::get_PathLength()
extern void CinemachinePathBase_get_PathLength_m46723487D97919331857A8975C397CB25DAB319D (void);
// 0x0000031E System.Single Cinemachine.CinemachinePathBase::StandardizePathDistance(System.Single)
extern void CinemachinePathBase_StandardizePathDistance_mB0DABA55052793902DC03DF700AE54A9A560A3E0 (void);
// 0x0000031F System.Single Cinemachine.CinemachinePathBase::ToNativePathUnits(System.Single,Cinemachine.CinemachinePathBase/PositionUnits)
extern void CinemachinePathBase_ToNativePathUnits_mDB615D10D6E1F61AF70B41A508AC8986AE59D683 (void);
// 0x00000320 System.Single Cinemachine.CinemachinePathBase::FromPathNativeUnits(System.Single,Cinemachine.CinemachinePathBase/PositionUnits)
extern void CinemachinePathBase_FromPathNativeUnits_m7817218D78BFF77C9F0D52C41B9538E6C6DCF2EB (void);
// 0x00000321 System.Void Cinemachine.CinemachinePathBase::ResamplePath(System.Int32)
extern void CinemachinePathBase_ResamplePath_m87F9A39480F5A2EFBC1ACB5361BD8F1F3316FD01 (void);
// 0x00000322 System.Void Cinemachine.CinemachinePathBase::.ctor()
extern void CinemachinePathBase__ctor_mA1D4CC9C83F490A407AF3B7EB143BEA58C879EEE (void);
// 0x00000323 System.Void Cinemachine.CinemachinePathBase/Appearance::.ctor()
extern void Appearance__ctor_m975B387EF5A573D25BD3C5C57B0314F3C4446196 (void);
// 0x00000324 System.Void Cinemachine.AxisStatePropertyAttribute::.ctor()
extern void AxisStatePropertyAttribute__ctor_mE6EC085C305D367A9C13C5A8F9C71CF740CF31D4 (void);
// 0x00000325 System.Void Cinemachine.OrbitalTransposerHeadingPropertyAttribute::.ctor()
extern void OrbitalTransposerHeadingPropertyAttribute__ctor_mE270F93BA1EA61B3B8D08EEB564E23317ADC7DBA (void);
// 0x00000326 System.Void Cinemachine.LensSettingsPropertyAttribute::.ctor()
extern void LensSettingsPropertyAttribute__ctor_mD29DB77CB5CB59D292D9524BE6909CFAA0554780 (void);
// 0x00000327 System.Void Cinemachine.VcamTargetPropertyAttribute::.ctor()
extern void VcamTargetPropertyAttribute__ctor_m997379231EB2F108F80DC83B01246F4E35D71570 (void);
// 0x00000328 System.Void Cinemachine.CinemachineBlendDefinitionPropertyAttribute::.ctor()
extern void CinemachineBlendDefinitionPropertyAttribute__ctor_mA08F1AA4EB4CEB0759F1C838F8E7D923A12439D7 (void);
// 0x00000329 System.Void Cinemachine.SaveDuringPlayAttribute::.ctor()
extern void SaveDuringPlayAttribute__ctor_m7E6683931B2115F1902B29FCC2B4ED8A166AE4FE (void);
// 0x0000032A System.Void Cinemachine.NoSaveDuringPlayAttribute::.ctor()
extern void NoSaveDuringPlayAttribute__ctor_m999A1E82E9072D6B63A1EE6080F68AFDB15A847B (void);
// 0x0000032B System.Void Cinemachine.TagFieldAttribute::.ctor()
extern void TagFieldAttribute__ctor_m30326F8DBA12F4CB1BE7710455DCFAE79EE3994C (void);
// 0x0000032C System.Void Cinemachine.NoiseSettingsPropertyAttribute::.ctor()
extern void NoiseSettingsPropertyAttribute__ctor_m5C02E6DFB9B65AA11259F8EDF2DA72DFB08DB09F (void);
// 0x0000032D System.Void Cinemachine.CinemachineEmbeddedAssetPropertyAttribute::.ctor(System.Boolean)
extern void CinemachineEmbeddedAssetPropertyAttribute__ctor_mD6C290E553336787289444791FE7FD0E7B57126E (void);
// 0x0000032E Cinemachine.DocumentationSortingAttribute/Level Cinemachine.DocumentationSortingAttribute::get_Category()
extern void DocumentationSortingAttribute_get_Category_mFBDC5B03E1DC7E69766579396C0DE6A5B794B8C1 (void);
// 0x0000032F System.Void Cinemachine.DocumentationSortingAttribute::set_Category(Cinemachine.DocumentationSortingAttribute/Level)
extern void DocumentationSortingAttribute_set_Category_mEF229C6814354009B21F2401F708D041751876D8 (void);
// 0x00000330 System.Void Cinemachine.DocumentationSortingAttribute::.ctor(Cinemachine.DocumentationSortingAttribute/Level)
extern void DocumentationSortingAttribute__ctor_mC444D8C194E049D0E1A8A4E6F83D7D69938B4CEF (void);
// 0x00000331 System.Int32 Cinemachine.CinemachineVirtualCameraBase::get_ValidatingStreamVersion()
extern void CinemachineVirtualCameraBase_get_ValidatingStreamVersion_mAB15E72A5D80AED2EFD0DA0BD8AB00E98030CA73 (void);
// 0x00000332 System.Void Cinemachine.CinemachineVirtualCameraBase::set_ValidatingStreamVersion(System.Int32)
extern void CinemachineVirtualCameraBase_set_ValidatingStreamVersion_m5AB3A39B6875CC5C403E49D9FFF6318CD77E6E6D (void);
// 0x00000333 System.Single Cinemachine.CinemachineVirtualCameraBase::get_FollowTargetAttachment()
extern void CinemachineVirtualCameraBase_get_FollowTargetAttachment_mC63610049FFE9F70B89E7F310C47253C90363352 (void);
// 0x00000334 System.Void Cinemachine.CinemachineVirtualCameraBase::set_FollowTargetAttachment(System.Single)
extern void CinemachineVirtualCameraBase_set_FollowTargetAttachment_m35C90295A253C3071DCF473D134700F3A8F6757C (void);
// 0x00000335 System.Single Cinemachine.CinemachineVirtualCameraBase::get_LookAtTargetAttachment()
extern void CinemachineVirtualCameraBase_get_LookAtTargetAttachment_m54302207ED2A1A7E96A1F9DB52EC0C223754D532 (void);
// 0x00000336 System.Void Cinemachine.CinemachineVirtualCameraBase::set_LookAtTargetAttachment(System.Single)
extern void CinemachineVirtualCameraBase_set_LookAtTargetAttachment_m344BCE5B2905887C117E70412FBE6DF6C704A995 (void);
// 0x00000337 System.Single Cinemachine.CinemachineVirtualCameraBase::GetMaxDampTime()
extern void CinemachineVirtualCameraBase_GetMaxDampTime_m534FD1A5F0E5B1A3F4418266045FEB5CC734C4F3 (void);
// 0x00000338 System.Single Cinemachine.CinemachineVirtualCameraBase::DetachedFollowTargetDamp(System.Single,System.Single,System.Single)
extern void CinemachineVirtualCameraBase_DetachedFollowTargetDamp_mA248235BC7D1A8F9199DFEC135D8770629214BDA (void);
// 0x00000339 UnityEngine.Vector3 Cinemachine.CinemachineVirtualCameraBase::DetachedFollowTargetDamp(UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void CinemachineVirtualCameraBase_DetachedFollowTargetDamp_mFA07AB4CA8E758190A3AD4D83392619A10E19BEB (void);
// 0x0000033A UnityEngine.Vector3 Cinemachine.CinemachineVirtualCameraBase::DetachedFollowTargetDamp(UnityEngine.Vector3,System.Single,System.Single)
extern void CinemachineVirtualCameraBase_DetachedFollowTargetDamp_m4CE171B4B2D093A57D4DA99688A0BFD8788BDA68 (void);
// 0x0000033B System.Single Cinemachine.CinemachineVirtualCameraBase::DetachedLookAtTargetDamp(System.Single,System.Single,System.Single)
extern void CinemachineVirtualCameraBase_DetachedLookAtTargetDamp_m644A94A63215474706B7D1357D810F4CDF309F0A (void);
// 0x0000033C UnityEngine.Vector3 Cinemachine.CinemachineVirtualCameraBase::DetachedLookAtTargetDamp(UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void CinemachineVirtualCameraBase_DetachedLookAtTargetDamp_mD2B62A9293DA4E8913ADF89C61A98FE4F966888E (void);
// 0x0000033D UnityEngine.Vector3 Cinemachine.CinemachineVirtualCameraBase::DetachedLookAtTargetDamp(UnityEngine.Vector3,System.Single,System.Single)
extern void CinemachineVirtualCameraBase_DetachedLookAtTargetDamp_m4F4C54F140B29348D732A4155AB228C5C9CB9DBD (void);
// 0x0000033E System.Void Cinemachine.CinemachineVirtualCameraBase::AddExtension(Cinemachine.CinemachineExtension)
extern void CinemachineVirtualCameraBase_AddExtension_m687616F9DD87E599D98CA6595C522C726BE25C91 (void);
// 0x0000033F System.Void Cinemachine.CinemachineVirtualCameraBase::RemoveExtension(Cinemachine.CinemachineExtension)
extern void CinemachineVirtualCameraBase_RemoveExtension_m4F693698B2195006C3B65D6634106BC5743298BC (void);
// 0x00000340 System.Collections.Generic.List`1<Cinemachine.CinemachineExtension> Cinemachine.CinemachineVirtualCameraBase::get_mExtensions()
extern void CinemachineVirtualCameraBase_get_mExtensions_mF0F262822738E586B3A785C180E622E28C06F6D6 (void);
// 0x00000341 System.Void Cinemachine.CinemachineVirtualCameraBase::set_mExtensions(System.Collections.Generic.List`1<Cinemachine.CinemachineExtension>)
extern void CinemachineVirtualCameraBase_set_mExtensions_m54EFFEDE585CA1012AF5CE6BDA2F6AAA351D8DED (void);
// 0x00000342 System.Void Cinemachine.CinemachineVirtualCameraBase::InvokePostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore/Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachineVirtualCameraBase_InvokePostPipelineStageCallback_mD4F5668E9AB96E8C11F16EC0D3CA769D663F5F51 (void);
// 0x00000343 System.Void Cinemachine.CinemachineVirtualCameraBase::InvokePrePipelineMutateCameraStateCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CameraState&,System.Single)
extern void CinemachineVirtualCameraBase_InvokePrePipelineMutateCameraStateCallback_m1C96DE73EEBCA5BB20BF67FAE3201CD2FC528D8C (void);
// 0x00000344 System.Boolean Cinemachine.CinemachineVirtualCameraBase::InvokeOnTransitionInExtensions(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void CinemachineVirtualCameraBase_InvokeOnTransitionInExtensions_mB3E9947AB53FC729921300DAA1ACEEE493894846 (void);
// 0x00000345 System.String Cinemachine.CinemachineVirtualCameraBase::get_Name()
extern void CinemachineVirtualCameraBase_get_Name_m15C2DEF15C6C85BDEB8AEE64AB915DBE173F0BA0 (void);
// 0x00000346 System.String Cinemachine.CinemachineVirtualCameraBase::get_Description()
extern void CinemachineVirtualCameraBase_get_Description_m198BF619FE868398029A2631C8D11C68F553AF63 (void);
// 0x00000347 System.Int32 Cinemachine.CinemachineVirtualCameraBase::get_Priority()
extern void CinemachineVirtualCameraBase_get_Priority_m56656A6C1F3F6EDABE61AC85E1BA8C638B470310 (void);
// 0x00000348 System.Void Cinemachine.CinemachineVirtualCameraBase::set_Priority(System.Int32)
extern void CinemachineVirtualCameraBase_set_Priority_m6C180B742F19E669D648B6D1BE4D9D9C5824962B (void);
// 0x00000349 System.Void Cinemachine.CinemachineVirtualCameraBase::ApplyPositionBlendMethod(Cinemachine.CameraState&,Cinemachine.CinemachineVirtualCameraBase/BlendHint)
extern void CinemachineVirtualCameraBase_ApplyPositionBlendMethod_m4CA02DB42D981721D75169ACDD7900477819EEC0 (void);
// 0x0000034A UnityEngine.GameObject Cinemachine.CinemachineVirtualCameraBase::get_VirtualCameraGameObject()
extern void CinemachineVirtualCameraBase_get_VirtualCameraGameObject_mDE6EBE29EC5093FDCE5E40963BFB8E39F6C7B518 (void);
// 0x0000034B System.Boolean Cinemachine.CinemachineVirtualCameraBase::get_IsValid()
extern void CinemachineVirtualCameraBase_get_IsValid_m4A8B615DDFE153258564AE9D4ED8F257E9C7E5C5 (void);
// 0x0000034C Cinemachine.CameraState Cinemachine.CinemachineVirtualCameraBase::get_State()
// 0x0000034D Cinemachine.ICinemachineCamera Cinemachine.CinemachineVirtualCameraBase::get_ParentCamera()
extern void CinemachineVirtualCameraBase_get_ParentCamera_mF5286EB2177F8957BC48A0BD3A5815EB408FD60C (void);
// 0x0000034E System.Boolean Cinemachine.CinemachineVirtualCameraBase::IsLiveChild(Cinemachine.ICinemachineCamera,System.Boolean)
extern void CinemachineVirtualCameraBase_IsLiveChild_m1BA561E87306CCFFA9300C53CF38C5940AD1B247 (void);
// 0x0000034F UnityEngine.Transform Cinemachine.CinemachineVirtualCameraBase::get_LookAt()
// 0x00000350 System.Void Cinemachine.CinemachineVirtualCameraBase::set_LookAt(UnityEngine.Transform)
// 0x00000351 UnityEngine.Transform Cinemachine.CinemachineVirtualCameraBase::get_Follow()
// 0x00000352 System.Void Cinemachine.CinemachineVirtualCameraBase::set_Follow(UnityEngine.Transform)
// 0x00000353 System.Boolean Cinemachine.CinemachineVirtualCameraBase::get_PreviousStateIsValid()
extern void CinemachineVirtualCameraBase_get_PreviousStateIsValid_m9AC6D8672852D072384B03B9433FAA24B6021F35 (void);
// 0x00000354 System.Void Cinemachine.CinemachineVirtualCameraBase::set_PreviousStateIsValid(System.Boolean)
extern void CinemachineVirtualCameraBase_set_PreviousStateIsValid_m6B3E5DD2C1EA71B2BA04072A0E3505AAFB2AF008 (void);
// 0x00000355 System.Void Cinemachine.CinemachineVirtualCameraBase::UpdateCameraState(UnityEngine.Vector3,System.Single)
extern void CinemachineVirtualCameraBase_UpdateCameraState_mBCA1562C197A11110116B3909711D0D0EE5F1733 (void);
// 0x00000356 System.Void Cinemachine.CinemachineVirtualCameraBase::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
// 0x00000357 System.Void Cinemachine.CinemachineVirtualCameraBase::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
extern void CinemachineVirtualCameraBase_OnTransitionFromCamera_mF18AFCD175FF50DBA6851279E6C93D0A3625618E (void);
// 0x00000358 System.Void Cinemachine.CinemachineVirtualCameraBase::OnDestroy()
extern void CinemachineVirtualCameraBase_OnDestroy_mFF393A0D56A6468E4A055DC86B52654763CF5C01 (void);
// 0x00000359 System.Void Cinemachine.CinemachineVirtualCameraBase::OnTransformParentChanged()
extern void CinemachineVirtualCameraBase_OnTransformParentChanged_m30B1976A8C859FADD7DBF6508018A382A921A41D (void);
// 0x0000035A System.Void Cinemachine.CinemachineVirtualCameraBase::Start()
extern void CinemachineVirtualCameraBase_Start_mAC4E3C7862E1898426BD04C03F97D2CB65B3E463 (void);
// 0x0000035B System.Void Cinemachine.CinemachineVirtualCameraBase::EnsureStarted()
extern void CinemachineVirtualCameraBase_EnsureStarted_m849F12F97E34D0BB2CFAB2178B5933CB3C07155F (void);
// 0x0000035C Cinemachine.AxisState/IInputAxisProvider Cinemachine.CinemachineVirtualCameraBase::GetInputAxisProvider()
extern void CinemachineVirtualCameraBase_GetInputAxisProvider_m7691338DE9A7FEBB16AE3BC6AD15AC61D2E4D046 (void);
// 0x0000035D System.Void Cinemachine.CinemachineVirtualCameraBase::OnValidate()
extern void CinemachineVirtualCameraBase_OnValidate_mE1DC3F4318A152EE8B1821DE638615477645EF55 (void);
// 0x0000035E System.Void Cinemachine.CinemachineVirtualCameraBase::OnEnable()
extern void CinemachineVirtualCameraBase_OnEnable_m0D02925B2AB25A5F7FB3B032332B70685FCEC035 (void);
// 0x0000035F System.Void Cinemachine.CinemachineVirtualCameraBase::OnDisable()
extern void CinemachineVirtualCameraBase_OnDisable_m385039B02BB5EF010B8F7CD5C8D5FED7BBE7C2D1 (void);
// 0x00000360 System.Void Cinemachine.CinemachineVirtualCameraBase::Update()
extern void CinemachineVirtualCameraBase_Update_m947321B86273A2372CF670BF61DD8763993B63E3 (void);
// 0x00000361 System.Void Cinemachine.CinemachineVirtualCameraBase::UpdateSlaveStatus()
extern void CinemachineVirtualCameraBase_UpdateSlaveStatus_m78E02F6B18B2C3FAF666F744FEA33D2357541557 (void);
// 0x00000362 UnityEngine.Transform Cinemachine.CinemachineVirtualCameraBase::ResolveLookAt(UnityEngine.Transform)
extern void CinemachineVirtualCameraBase_ResolveLookAt_mB4648E8AB85834A25B30DA49D5A200B74F1CC7A5 (void);
// 0x00000363 UnityEngine.Transform Cinemachine.CinemachineVirtualCameraBase::ResolveFollow(UnityEngine.Transform)
extern void CinemachineVirtualCameraBase_ResolveFollow_mC991CC084D6046862E0E0D3172CF7C12FE8EC4F0 (void);
// 0x00000364 System.Void Cinemachine.CinemachineVirtualCameraBase::UpdateVcamPoolStatus()
extern void CinemachineVirtualCameraBase_UpdateVcamPoolStatus_m00D7E5F25FC9CC434AD143635F630984354301C9 (void);
// 0x00000365 System.Void Cinemachine.CinemachineVirtualCameraBase::MoveToTopOfPrioritySubqueue()
extern void CinemachineVirtualCameraBase_MoveToTopOfPrioritySubqueue_m1C3187B5E5F52FA2D2924CD3443435BCA449B631 (void);
// 0x00000366 System.Void Cinemachine.CinemachineVirtualCameraBase::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
extern void CinemachineVirtualCameraBase_OnTargetObjectWarped_m7FFE5632C56D724943F8663E2A4A4B0E3B958946 (void);
// 0x00000367 System.Void Cinemachine.CinemachineVirtualCameraBase::ForceCameraPosition(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void CinemachineVirtualCameraBase_ForceCameraPosition_mBF134754EAD8C7F6DA33A8A52FFD75BEF7C8A31F (void);
// 0x00000368 Cinemachine.CinemachineBlend Cinemachine.CinemachineVirtualCameraBase::CreateBlend(Cinemachine.ICinemachineCamera,Cinemachine.ICinemachineCamera,Cinemachine.CinemachineBlendDefinition,Cinemachine.CinemachineBlend)
extern void CinemachineVirtualCameraBase_CreateBlend_m95B3B2E83C066360A8A238BB5613E979E6369541 (void);
// 0x00000369 Cinemachine.CameraState Cinemachine.CinemachineVirtualCameraBase::PullStateFromVirtualCamera(UnityEngine.Vector3,Cinemachine.LensSettings&)
extern void CinemachineVirtualCameraBase_PullStateFromVirtualCamera_m3F65D0956F682ED45F836E6D7950E40EB6C7D84E (void);
// 0x0000036A System.Void Cinemachine.CinemachineVirtualCameraBase::.ctor()
extern void CinemachineVirtualCameraBase__ctor_m5B13AF0337DBE27A89CAF6E30FA97CBE38823F84 (void);
// 0x0000036B System.Void Cinemachine.ConfinerOven::.ctor(System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2>>&,System.Single&,System.Single)
extern void ConfinerOven__ctor_m48A6169D36FA4125D30C0D6120CAD016194F8909 (void);
// 0x0000036C Cinemachine.ConfinerOven/BakedSolution Cinemachine.ConfinerOven::GetBakedSolution(System.Single)
extern void ConfinerOven_GetBakedSolution_m4851EA63770587CB42588DDD46CB97C75633F495 (void);
// 0x0000036D Cinemachine.ConfinerOven/BakingState Cinemachine.ConfinerOven::get_State()
extern void ConfinerOven_get_State_m05EB332DF4BD4F147E273BA2674EABE440F7A454 (void);
// 0x0000036E System.Void Cinemachine.ConfinerOven::set_State(Cinemachine.ConfinerOven/BakingState)
extern void ConfinerOven_set_State_m3FC0A5E796618E464AE97D0AB10E052434A590C5 (void);
// 0x0000036F System.Void Cinemachine.ConfinerOven::Initialize(System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2>>&,System.Single&,System.Single)
extern void ConfinerOven_Initialize_m8002B599716C3F45FB7F7FD2EDC58D150A85B295 (void);
// 0x00000370 System.Void Cinemachine.ConfinerOven::BakeConfiner(System.Single)
extern void ConfinerOven_BakeConfiner_mF38F9C5E62C35B1641CE6518FE9CE8E882B1E6F5 (void);
// 0x00000371 UnityEngine.Rect Cinemachine.ConfinerOven::GetPolygonBoundingBox(System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2>>&)
extern void ConfinerOven_GetPolygonBoundingBox_m20AD9390507A5F008D5DAA82B0862422A724E18A (void);
// 0x00000372 System.Void Cinemachine.ConfinerOven::ComputeSkeleton(System.Collections.Generic.List`1<Cinemachine.ConfinerOven/PolygonSolution>&)
extern void ConfinerOven_ComputeSkeleton_m064537E254C62F33C2770AB502F5C37D09BBBA6A (void);
// 0x00000373 System.Single Cinemachine.ConfinerOven/BakedSolution::get_FrustumHeight()
extern void BakedSolution_get_FrustumHeight_mD53A0B6A4B8FA2F76504CF1A4D2F8429E47AC76B (void);
// 0x00000374 System.Void Cinemachine.ConfinerOven/BakedSolution::.ctor(System.Single,System.Single,System.Boolean,UnityEngine.Rect,System.Collections.Generic.List`1<System.Collections.Generic.List`1<ClipperLib.IntPoint>>,System.Collections.Generic.List`1<System.Collections.Generic.List`1<ClipperLib.IntPoint>>)
extern void BakedSolution__ctor_m764A15AA9AD75B36FBE0BEED88317DE7D3970CC7 (void);
// 0x00000375 System.Void Cinemachine.ConfinerOven/BakedSolution::Clear()
extern void BakedSolution_Clear_m38FD13E2E690AD2E4082B0463A15EB1ABD4D527F (void);
// 0x00000376 System.Boolean Cinemachine.ConfinerOven/BakedSolution::IsValid(System.Single)
extern void BakedSolution_IsValid_m088087FE81CEB48209DAB579552B9F1B1B2C3364 (void);
// 0x00000377 UnityEngine.Vector2 Cinemachine.ConfinerOven/BakedSolution::ConfinePoint(UnityEngine.Vector2&)
extern void BakedSolution_ConfinePoint_mD522D2F038B40F7A66B2B7817253B2791BEF6FA4 (void);
// 0x00000378 System.Boolean Cinemachine.ConfinerOven/BakedSolution::IsInsideOriginal(ClipperLib.IntPoint)
extern void BakedSolution_IsInsideOriginal_m78F43D3331F08CB54EFD177DE23996F5E3C0B066 (void);
// 0x00000379 System.Single Cinemachine.ConfinerOven/BakedSolution::ClosestPointOnSegment(ClipperLib.IntPoint,ClipperLib.IntPoint,ClipperLib.IntPoint)
extern void BakedSolution_ClosestPointOnSegment_m640814AD98DC8ED622CC6F6CDD515E34F402C523 (void);
// 0x0000037A ClipperLib.IntPoint Cinemachine.ConfinerOven/BakedSolution::IntPointLerp(ClipperLib.IntPoint,ClipperLib.IntPoint,System.Single)
extern void BakedSolution_IntPointLerp_mA505E038E47C5383553C541632DF7B0E9CF145D9 (void);
// 0x0000037B System.Boolean Cinemachine.ConfinerOven/BakedSolution::DoesIntersectOriginal(ClipperLib.IntPoint,ClipperLib.IntPoint)
extern void BakedSolution_DoesIntersectOriginal_m4F340B7A818E7FB1CFA1732D2C6C12156D5A65E2 (void);
// 0x0000037C System.Int32 Cinemachine.ConfinerOven/BakedSolution::FindIntersection(ClipperLib.IntPoint&,ClipperLib.IntPoint&,ClipperLib.IntPoint&,ClipperLib.IntPoint&)
extern void BakedSolution_FindIntersection_m7F71E48AF4363555C58A9117C7A7B3272A3CB902 (void);
// 0x0000037D System.Double Cinemachine.ConfinerOven/BakedSolution::IntPointDiffSqrMagnitude(ClipperLib.IntPoint,ClipperLib.IntPoint)
extern void BakedSolution_IntPointDiffSqrMagnitude_m90D1C80D7F57BA58D4EB1E2F78648EF7DB36B299 (void);
// 0x0000037E System.Single Cinemachine.ConfinerOven/AspectStretcher::get_Aspect()
extern void AspectStretcher_get_Aspect_m5F122CB5941347F158A1AAC93BA287C20EE6A5CB (void);
// 0x0000037F System.Void Cinemachine.ConfinerOven/AspectStretcher::.ctor(System.Single,System.Single)
extern void AspectStretcher__ctor_mDCB6211AC6DD9E121C1936D1CA89A59992810250 (void);
// 0x00000380 UnityEngine.Vector2 Cinemachine.ConfinerOven/AspectStretcher::Stretch(UnityEngine.Vector2)
extern void AspectStretcher_Stretch_mBF0EC7D7CB450374BBB47AE0ECE58FDD605FBA36 (void);
// 0x00000381 UnityEngine.Vector2 Cinemachine.ConfinerOven/AspectStretcher::Unstretch(UnityEngine.Vector2)
extern void AspectStretcher_Unstretch_m6C6ABFB166BF2BC9B4DBDF3B2057018DE19013D6 (void);
// 0x00000382 System.Boolean Cinemachine.ConfinerOven/PolygonSolution::StateChanged(System.Collections.Generic.List`1<System.Collections.Generic.List`1<ClipperLib.IntPoint>>&)
extern void PolygonSolution_StateChanged_m4F55923D1FF840A66DED34E00ABC163A4870674F (void);
// 0x00000383 System.Boolean Cinemachine.ConfinerOven/PolygonSolution::get_IsEmpty()
extern void PolygonSolution_get_IsEmpty_mCA5809BECBE372CE603DC4E4C7E5873309A50196 (void);
// 0x00000384 System.String Cinemachine.ICinemachineCamera::get_Name()
// 0x00000385 System.String Cinemachine.ICinemachineCamera::get_Description()
// 0x00000386 System.Int32 Cinemachine.ICinemachineCamera::get_Priority()
// 0x00000387 System.Void Cinemachine.ICinemachineCamera::set_Priority(System.Int32)
// 0x00000388 UnityEngine.Transform Cinemachine.ICinemachineCamera::get_LookAt()
// 0x00000389 System.Void Cinemachine.ICinemachineCamera::set_LookAt(UnityEngine.Transform)
// 0x0000038A UnityEngine.Transform Cinemachine.ICinemachineCamera::get_Follow()
// 0x0000038B System.Void Cinemachine.ICinemachineCamera::set_Follow(UnityEngine.Transform)
// 0x0000038C Cinemachine.CameraState Cinemachine.ICinemachineCamera::get_State()
// 0x0000038D UnityEngine.GameObject Cinemachine.ICinemachineCamera::get_VirtualCameraGameObject()
// 0x0000038E System.Boolean Cinemachine.ICinemachineCamera::get_IsValid()
// 0x0000038F Cinemachine.ICinemachineCamera Cinemachine.ICinemachineCamera::get_ParentCamera()
// 0x00000390 System.Boolean Cinemachine.ICinemachineCamera::IsLiveChild(Cinemachine.ICinemachineCamera,System.Boolean)
// 0x00000391 System.Void Cinemachine.ICinemachineCamera::UpdateCameraState(UnityEngine.Vector3,System.Single)
// 0x00000392 System.Void Cinemachine.ICinemachineCamera::InternalUpdateCameraState(UnityEngine.Vector3,System.Single)
// 0x00000393 System.Void Cinemachine.ICinemachineCamera::OnTransitionFromCamera(Cinemachine.ICinemachineCamera,UnityEngine.Vector3,System.Single)
// 0x00000394 System.Void Cinemachine.ICinemachineCamera::OnTargetObjectWarped(UnityEngine.Transform,UnityEngine.Vector3)
// 0x00000395 System.Boolean Cinemachine.LensSettings::get_Orthographic()
extern void LensSettings_get_Orthographic_mD89E6548BD05054F1ADFF7CB767ADCBA147970A0 (void);
// 0x00000396 System.Void Cinemachine.LensSettings::set_Orthographic(System.Boolean)
extern void LensSettings_set_Orthographic_m17D40EA48E03E6E1D1FCBC23FCC01599BD7DEC0F (void);
// 0x00000397 UnityEngine.Vector2 Cinemachine.LensSettings::get_SensorSize()
extern void LensSettings_get_SensorSize_mED4695A443BA5CD05E9BF20A8B435B9CEAF56F56 (void);
// 0x00000398 System.Void Cinemachine.LensSettings::set_SensorSize(UnityEngine.Vector2)
extern void LensSettings_set_SensorSize_mCF61646CF243535A7A0FE1C18D187D68F76AA849 (void);
// 0x00000399 System.Single Cinemachine.LensSettings::get_Aspect()
extern void LensSettings_get_Aspect_m9CC9D04C1503CE0708B7E8D7918D51E6D105CBA6 (void);
// 0x0000039A System.Boolean Cinemachine.LensSettings::get_IsPhysicalCamera()
extern void LensSettings_get_IsPhysicalCamera_m51B84703CAE764F7D3F7E581D6374080F3065891 (void);
// 0x0000039B System.Void Cinemachine.LensSettings::set_IsPhysicalCamera(System.Boolean)
extern void LensSettings_set_IsPhysicalCamera_mAD4EF6D6C68EC05EC70CF69FBD4B186BAEEAEE8D (void);
// 0x0000039C Cinemachine.LensSettings Cinemachine.LensSettings::FromCamera(UnityEngine.Camera)
extern void LensSettings_FromCamera_mB70878A0FEE612591846D38DEB0C519E62D26062 (void);
// 0x0000039D System.Void Cinemachine.LensSettings::SnapshotCameraReadOnlyProperties(UnityEngine.Camera)
extern void LensSettings_SnapshotCameraReadOnlyProperties_mBE8E0F11CA4B7B16A6FB8C6C0EAD3215BD18F952 (void);
// 0x0000039E System.Void Cinemachine.LensSettings::SnapshotCameraReadOnlyProperties(Cinemachine.LensSettings&)
extern void LensSettings_SnapshotCameraReadOnlyProperties_m1AF99FBBE30EEDEAAFB4F7C6EBC63C4F7BFE0E5D (void);
// 0x0000039F System.Void Cinemachine.LensSettings::.ctor(System.Single,System.Single,System.Single,System.Single,System.Single)
extern void LensSettings__ctor_m33701EC0CE3BE15F0CC8BC926D4BB090D59FD206 (void);
// 0x000003A0 Cinemachine.LensSettings Cinemachine.LensSettings::Lerp(Cinemachine.LensSettings,Cinemachine.LensSettings,System.Single)
extern void LensSettings_Lerp_m388C5EBB582A55DC6F8BA3E748270E68752E9582 (void);
// 0x000003A1 System.Void Cinemachine.LensSettings::Validate()
extern void LensSettings_Validate_mB36D902613DCFA1D4F31A16CDB87FE2AB23570AF (void);
// 0x000003A2 System.Void Cinemachine.LensSettings::.cctor()
extern void LensSettings__cctor_m83C48E930BB642670AF6DCF8B5600901D03F49F5 (void);
// 0x000003A3 UnityEngine.Vector3 Cinemachine.NoiseSettings::GetCombinedFilterResults(Cinemachine.NoiseSettings/TransformNoiseParams[],System.Single,UnityEngine.Vector3)
extern void NoiseSettings_GetCombinedFilterResults_m2D89EDF921D81B5476532B768C2099BDCBA047AF (void);
// 0x000003A4 System.Single Cinemachine.NoiseSettings::get_SignalDuration()
extern void NoiseSettings_get_SignalDuration_mA7535F6F59953F1931926872B12D6FEC56976AAF (void);
// 0x000003A5 System.Void Cinemachine.NoiseSettings::GetSignal(System.Single,UnityEngine.Vector3&,UnityEngine.Quaternion&)
extern void NoiseSettings_GetSignal_m2E1DEBB169108D53CB89571DB973B6AE997B2B96 (void);
// 0x000003A6 System.Void Cinemachine.NoiseSettings::.ctor()
extern void NoiseSettings__ctor_mFC841D4CF7C2F2B0B0666F32FAF561E8BE089A47 (void);
// 0x000003A7 System.Single Cinemachine.NoiseSettings/NoiseParams::GetValueAt(System.Single,System.Single)
extern void NoiseParams_GetValueAt_mA2C1E6FA7AE9AB3FC9A51024E0D474E5C8596610 (void);
// 0x000003A8 UnityEngine.Vector3 Cinemachine.NoiseSettings/TransformNoiseParams::GetValueAt(System.Single,UnityEngine.Vector3)
extern void TransformNoiseParams_GetValueAt_m89FDF2289D147DC0B617426E76A78402474770CD (void);
// 0x000003A9 System.Void Cinemachine.RuntimeUtility::DestroyObject(UnityEngine.Object)
extern void RuntimeUtility_DestroyObject_m6D1DDFE4299B3873067DC7E57851288F8F78F252 (void);
// 0x000003AA System.Boolean Cinemachine.RuntimeUtility::IsPrefab(UnityEngine.GameObject)
extern void RuntimeUtility_IsPrefab_m073F89A3A5B106FD66AB93D1BE52B27612126F5F (void);
// 0x000003AB System.Boolean Cinemachine.RuntimeUtility::RaycastIgnoreTag(UnityEngine.Ray,UnityEngine.RaycastHit&,System.Single,System.Int32,System.String&)
extern void RuntimeUtility_RaycastIgnoreTag_m028B24F950C8BC320919E184362FEF37DBE54D90 (void);
// 0x000003AC System.Boolean Cinemachine.RuntimeUtility::SphereCastIgnoreTag(UnityEngine.Vector3,System.Single,UnityEngine.Vector3,UnityEngine.RaycastHit&,System.Single,System.Int32,System.String&)
extern void RuntimeUtility_SphereCastIgnoreTag_mF63BBA794BD68DF691D1EC863B2CA138CECA6D64 (void);
// 0x000003AD UnityEngine.SphereCollider Cinemachine.RuntimeUtility::GetScratchCollider()
extern void RuntimeUtility_GetScratchCollider_m45FC237FF7E53D7214EE05733272979DB41B1594 (void);
// 0x000003AE System.Void Cinemachine.RuntimeUtility::DestroyScratchCollider()
extern void RuntimeUtility_DestroyScratchCollider_m0E3F76B3A7CFA392351D2E5D4705069A359B980B (void);
// 0x000003AF System.Void Cinemachine.RuntimeUtility::.cctor()
extern void RuntimeUtility__cctor_m213426BB091AB34EC852D1EACE5B6A50B2069C16 (void);
// 0x000003B0 System.Single Cinemachine.ISignalSource6D::get_SignalDuration()
// 0x000003B1 System.Void Cinemachine.ISignalSource6D::GetSignal(System.Single,UnityEngine.Vector3&,UnityEngine.Quaternion&)
// 0x000003B2 System.Single Cinemachine.SignalSourceAsset::get_SignalDuration()
// 0x000003B3 System.Void Cinemachine.SignalSourceAsset::GetSignal(System.Single,UnityEngine.Vector3&,UnityEngine.Quaternion&)
// 0x000003B4 System.Void Cinemachine.SignalSourceAsset::.ctor()
extern void SignalSourceAsset__ctor_m6BD0FCB4BC617B1339DD54AF64C68D73217F15C4 (void);
// 0x000003B5 System.Boolean Cinemachine.TargetPositionCache::get_UseCache()
extern void TargetPositionCache_get_UseCache_m2A4E7042538DD9DB3384B1F655C2F5F241287ED3 (void);
// 0x000003B6 System.Void Cinemachine.TargetPositionCache::set_UseCache(System.Boolean)
extern void TargetPositionCache_set_UseCache_mE9841EC91604F0D0249732E8AD668C59D46BE7E9 (void);
// 0x000003B7 Cinemachine.TargetPositionCache/Mode Cinemachine.TargetPositionCache::get_CacheMode()
extern void TargetPositionCache_get_CacheMode_mC4847BC1073AF20F9206798A04F0AAEB7675EF2D (void);
// 0x000003B8 System.Void Cinemachine.TargetPositionCache::set_CacheMode(Cinemachine.TargetPositionCache/Mode)
extern void TargetPositionCache_set_CacheMode_mA409087DB626DAE734E50B8F32E458AF8586A819 (void);
// 0x000003B9 System.Boolean Cinemachine.TargetPositionCache::get_IsRecording()
extern void TargetPositionCache_get_IsRecording_m0E103654E5042F7C81BF3E8F6683767490885F63 (void);
// 0x000003BA System.Boolean Cinemachine.TargetPositionCache::get_CurrentPlaybackTimeValid()
extern void TargetPositionCache_get_CurrentPlaybackTimeValid_m52161DB6E5E14903123C1C92B14D48228165B646 (void);
// 0x000003BB System.Boolean Cinemachine.TargetPositionCache::get_IsEmpty()
extern void TargetPositionCache_get_IsEmpty_m05036B2EE99C645BC889DF7A34BB38CD9F701F17 (void);
// 0x000003BC System.Single Cinemachine.TargetPositionCache::get_CurrentTime()
extern void TargetPositionCache_get_CurrentTime_m3F5821119AECD4EC85404EAD43A2165DBC2637C5 (void);
// 0x000003BD System.Void Cinemachine.TargetPositionCache::set_CurrentTime(System.Single)
extern void TargetPositionCache_set_CurrentTime_mA19CF3213984B76FA56B4E05C67CFA4C38665383 (void);
// 0x000003BE System.Int32 Cinemachine.TargetPositionCache::get_CurrentFrame()
extern void TargetPositionCache_get_CurrentFrame_m2319ECEB0B10124D15B040B2990DB4ACA50BB07C (void);
// 0x000003BF System.Void Cinemachine.TargetPositionCache::set_CurrentFrame(System.Int32)
extern void TargetPositionCache_set_CurrentFrame_m989E6580A4D827FE06BCB7F5819794C116E4D584 (void);
// 0x000003C0 System.Boolean Cinemachine.TargetPositionCache::get_IsCameraCut()
extern void TargetPositionCache_get_IsCameraCut_mD135E2C327DC1F9AB5D41DD29F50C60020788DA2 (void);
// 0x000003C1 System.Void Cinemachine.TargetPositionCache::set_IsCameraCut(System.Boolean)
extern void TargetPositionCache_set_IsCameraCut_m129E28E786C665E5DE495E5D1BC511A46CB30ABF (void);
// 0x000003C2 Cinemachine.TargetPositionCache/TimeRange Cinemachine.TargetPositionCache::get_CacheTimeRange()
extern void TargetPositionCache_get_CacheTimeRange_m26A353A12C7452C99C2FEF71809C25914C78529E (void);
// 0x000003C3 System.Boolean Cinemachine.TargetPositionCache::get_HasHurrentTime()
extern void TargetPositionCache_get_HasHurrentTime_mD38DDBFB10FC5D0FB648E927AA8B3F2434DC547E (void);
// 0x000003C4 System.Void Cinemachine.TargetPositionCache::ClearCache()
extern void TargetPositionCache_ClearCache_mEAEE54E7ACFE79BB323DFA679789206770BE11ED (void);
// 0x000003C5 System.Void Cinemachine.TargetPositionCache::CreatePlaybackCurves()
extern void TargetPositionCache_CreatePlaybackCurves_m335FD074A23437FF0DDE3C70BED8EDAC5FFD8BA7 (void);
// 0x000003C6 UnityEngine.Vector3 Cinemachine.TargetPositionCache::GetTargetPosition(UnityEngine.Transform)
extern void TargetPositionCache_GetTargetPosition_m683592ADC5C5B6597CE3A781E1BBE89A1AC9CBB1 (void);
// 0x000003C7 UnityEngine.Quaternion Cinemachine.TargetPositionCache::GetTargetRotation(UnityEngine.Transform)
extern void TargetPositionCache_GetTargetRotation_mBAA85634FCB43634065191EB1F2217462334679D (void);
// 0x000003C8 System.Void Cinemachine.TargetPositionCache::.ctor()
extern void TargetPositionCache__ctor_m0173991EBB133E2CDEF09D3C495FC3CE14ECE9C1 (void);
// 0x000003C9 System.Void Cinemachine.TargetPositionCache::.cctor()
extern void TargetPositionCache__cctor_mF31DF1BD5AFDB4275E7FC81F08D3A03B1EDF3FC1 (void);
// 0x000003CA System.Int32 Cinemachine.TargetPositionCache/CacheCurve::get_Count()
extern void CacheCurve_get_Count_m7BE1AE49E310A7185E449EF27D9715404DB58F4D (void);
// 0x000003CB System.Void Cinemachine.TargetPositionCache/CacheCurve::.ctor(System.Single,System.Single,System.Single)
extern void CacheCurve__ctor_m9126DDC2FF162438BEF34E60AD524A2BD74E09D8 (void);
// 0x000003CC System.Void Cinemachine.TargetPositionCache/CacheCurve::Add(Cinemachine.TargetPositionCache/CacheCurve/Item)
extern void CacheCurve_Add_m325C65AD39FDFBC91F4D5624B8BF7C5560B36DFF (void);
// 0x000003CD System.Void Cinemachine.TargetPositionCache/CacheCurve::AddUntil(Cinemachine.TargetPositionCache/CacheCurve/Item,System.Single,System.Boolean)
extern void CacheCurve_AddUntil_m3613245687496AC0DC18F1EB9A6328E3F8AA203F (void);
// 0x000003CE Cinemachine.TargetPositionCache/CacheCurve/Item Cinemachine.TargetPositionCache/CacheCurve::Evaluate(System.Single)
extern void CacheCurve_Evaluate_m9D2DF73C6C1AF43179910C16C2249A6205429938 (void);
// 0x000003CF Cinemachine.TargetPositionCache/CacheCurve/Item Cinemachine.TargetPositionCache/CacheCurve/Item::Lerp(Cinemachine.TargetPositionCache/CacheCurve/Item,Cinemachine.TargetPositionCache/CacheCurve/Item,System.Single)
extern void Item_Lerp_m729C3CBFCA75B42CC2799D491DEF4C17C53602DC (void);
// 0x000003D0 Cinemachine.TargetPositionCache/CacheCurve/Item Cinemachine.TargetPositionCache/CacheCurve/Item::get_Empty()
extern void Item_get_Empty_m2209C3BE792AABD138C9A597718D01D2FF089CB3 (void);
// 0x000003D1 System.Void Cinemachine.TargetPositionCache/CacheEntry::AddRawItem(System.Single,System.Boolean,UnityEngine.Transform)
extern void CacheEntry_AddRawItem_m56ADB9D380E62201025B3F4B752CDD4E90970B49 (void);
// 0x000003D2 System.Void Cinemachine.TargetPositionCache/CacheEntry::CreateCurves()
extern void CacheEntry_CreateCurves_m3C30DAF286804CB56B42102406ACE0BF891292EA (void);
// 0x000003D3 System.Void Cinemachine.TargetPositionCache/CacheEntry::.ctor()
extern void CacheEntry__ctor_mF5B26181E6FBFC00701BC6A362BEA3416815FD2B (void);
// 0x000003D4 System.Boolean Cinemachine.TargetPositionCache/TimeRange::get_IsEmpty()
extern void TimeRange_get_IsEmpty_m0EBE2CFDA395E03444770956D336B17D2CC676D0 (void);
// 0x000003D5 System.Boolean Cinemachine.TargetPositionCache/TimeRange::Contains(System.Single)
extern void TimeRange_Contains_m2FE15B3333F2883C0580220A5D3FDE954533A8FA (void);
// 0x000003D6 Cinemachine.TargetPositionCache/TimeRange Cinemachine.TargetPositionCache/TimeRange::get_Empty()
extern void TimeRange_get_Empty_m273B20F7E14B9A0670F209E17316EC4EBDD7D053 (void);
// 0x000003D7 System.Void Cinemachine.TargetPositionCache/TimeRange::Include(System.Single)
extern void TimeRange_Include_m98B368672B3FAD811027079C3EA8236914D3729E (void);
// 0x000003D8 System.Void Cinemachine.UpdateTracker::InitializeModule()
extern void UpdateTracker_InitializeModule_m5370F8DEE455815F90E3D955CE59DB9913D08E8F (void);
// 0x000003D9 System.Void Cinemachine.UpdateTracker::UpdateTargets(Cinemachine.UpdateTracker/UpdateClock)
extern void UpdateTracker_UpdateTargets_mD0D8D76B9072DEA87E45FE9A440CF8324C93DEE0 (void);
// 0x000003DA Cinemachine.UpdateTracker/UpdateClock Cinemachine.UpdateTracker::GetPreferredUpdate(UnityEngine.Transform)
extern void UpdateTracker_GetPreferredUpdate_m9C3AD495B5ABFE52C7FF420870F93315B9E85219 (void);
// 0x000003DB System.Void Cinemachine.UpdateTracker::OnUpdate(Cinemachine.UpdateTracker/UpdateClock)
extern void UpdateTracker_OnUpdate_m5F262770C3B9222F8503D50DFE21FF7C9A902C41 (void);
// 0x000003DC System.Void Cinemachine.UpdateTracker::.ctor()
extern void UpdateTracker__ctor_m96110261C2684D9D4FF348FDC8C2C9ADA9107C56 (void);
// 0x000003DD System.Void Cinemachine.UpdateTracker::.cctor()
extern void UpdateTracker__cctor_mED7C5FD366A149F1208622A2F59654F6713B1E65 (void);
// 0x000003DE Cinemachine.UpdateTracker/UpdateClock Cinemachine.UpdateTracker/UpdateStatus::get_PreferredUpdate()
extern void UpdateStatus_get_PreferredUpdate_mF6224BC9B52B95B06ECD82F3CCDAC7B0994B9B6F (void);
// 0x000003DF System.Void Cinemachine.UpdateTracker/UpdateStatus::set_PreferredUpdate(Cinemachine.UpdateTracker/UpdateClock)
extern void UpdateStatus_set_PreferredUpdate_m0D163727BB4C16214C9A22D74656ED09CEF6C929 (void);
// 0x000003E0 System.Void Cinemachine.UpdateTracker/UpdateStatus::.ctor(System.Int32,UnityEngine.Matrix4x4)
extern void UpdateStatus__ctor_mDEAE275BFECF3D63AE2A93D74EABACD19FA21724 (void);
// 0x000003E1 System.Void Cinemachine.UpdateTracker/UpdateStatus::OnUpdate(System.Int32,Cinemachine.UpdateTracker/UpdateClock,UnityEngine.Matrix4x4)
extern void UpdateStatus_OnUpdate_m22DED61941774ECFB0119BAAE3BD2C164D39D521 (void);
// 0x000003E2 System.Single Cinemachine.CinemachineInputProvider::GetAxisValue(System.Int32)
extern void CinemachineInputProvider_GetAxisValue_mACBD1F2A4A8947B16308D241B5077BC882040904 (void);
// 0x000003E3 UnityEngine.InputSystem.InputAction Cinemachine.CinemachineInputProvider::ResolveForPlayer(System.Int32,UnityEngine.InputSystem.InputActionReference)
extern void CinemachineInputProvider_ResolveForPlayer_m059CC48E7DE3AA999AB656ACAC98AE6AEAC035A5 (void);
// 0x000003E4 System.Void Cinemachine.CinemachineInputProvider::OnDisable()
extern void CinemachineInputProvider_OnDisable_mEB784226D47F87DFEC4021FEFC66D5323C4D5ED9 (void);
// 0x000003E5 System.Void Cinemachine.CinemachineInputProvider::.ctor()
extern void CinemachineInputProvider__ctor_m8777E62CF2666361F27D23EBB1C9DCEFA089DC4D (void);
// 0x000003E6 System.Void Cinemachine.CinemachineInputProvider/<>c__DisplayClass6_0::.ctor()
extern void U3CU3Ec__DisplayClass6_0__ctor_m746865333647DCCC84C7BCF4F1696817268C4090 (void);
// 0x000003E7 System.Boolean Cinemachine.CinemachineInputProvider/<>c__DisplayClass6_0::<ResolveForPlayer>b__0(UnityEngine.InputSystem.InputAction)
extern void U3CU3Ec__DisplayClass6_0_U3CResolveForPlayerU3Eb__0_mA1BA43EF633C0D9AAA1439203B89808C28B1CA3D (void);
// 0x000003E8 System.Boolean Cinemachine.CinemachineTriggerAction::Filter(UnityEngine.GameObject)
extern void CinemachineTriggerAction_Filter_m24E0C2EA06B01EDE65C5ABCF0FF7412C15FBA2C9 (void);
// 0x000003E9 System.Void Cinemachine.CinemachineTriggerAction::InternalDoTriggerEnter(UnityEngine.GameObject)
extern void CinemachineTriggerAction_InternalDoTriggerEnter_mB3988F520BC8AA59D9234D2ADF740F0B042CF468 (void);
// 0x000003EA System.Void Cinemachine.CinemachineTriggerAction::InternalDoTriggerExit(UnityEngine.GameObject)
extern void CinemachineTriggerAction_InternalDoTriggerExit_mCD95F85A77DEA5ADA44117BB83D060759735B673 (void);
// 0x000003EB System.Void Cinemachine.CinemachineTriggerAction::OnTriggerEnter(UnityEngine.Collider)
extern void CinemachineTriggerAction_OnTriggerEnter_m96928EE1C51134E6F263AF38DF3F935B6AE9B437 (void);
// 0x000003EC System.Void Cinemachine.CinemachineTriggerAction::OnTriggerExit(UnityEngine.Collider)
extern void CinemachineTriggerAction_OnTriggerExit_m064EAE63E912234D6C9FEBD36C93B365E7C254A7 (void);
// 0x000003ED System.Void Cinemachine.CinemachineTriggerAction::OnCollisionEnter(UnityEngine.Collision)
extern void CinemachineTriggerAction_OnCollisionEnter_m30F4858ADE6F9AE24968B6C4B53003A64C649EFB (void);
// 0x000003EE System.Void Cinemachine.CinemachineTriggerAction::OnCollisionExit(UnityEngine.Collision)
extern void CinemachineTriggerAction_OnCollisionExit_m14FC07565358A5C444DC58DEDF873F9EAB166B68 (void);
// 0x000003EF System.Void Cinemachine.CinemachineTriggerAction::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void CinemachineTriggerAction_OnTriggerEnter2D_m761334328569C317AF12D5DC97F15FB754433A75 (void);
// 0x000003F0 System.Void Cinemachine.CinemachineTriggerAction::OnTriggerExit2D(UnityEngine.Collider2D)
extern void CinemachineTriggerAction_OnTriggerExit2D_mC612B5BBC49A435C39F90DA58E87C48996A21087 (void);
// 0x000003F1 System.Void Cinemachine.CinemachineTriggerAction::OnCollisionEnter2D(UnityEngine.Collision2D)
extern void CinemachineTriggerAction_OnCollisionEnter2D_m1102D331D5FCC51055E4AC4CC6B36BE4966ADB52 (void);
// 0x000003F2 System.Void Cinemachine.CinemachineTriggerAction::OnCollisionExit2D(UnityEngine.Collision2D)
extern void CinemachineTriggerAction_OnCollisionExit2D_m0BF8AFA822490D1DC0E3720DA83D12AC8A34FE90 (void);
// 0x000003F3 System.Void Cinemachine.CinemachineTriggerAction::OnEnable()
extern void CinemachineTriggerAction_OnEnable_m79D396A5F205F320779F5A574F809E5CCA823EA0 (void);
// 0x000003F4 System.Void Cinemachine.CinemachineTriggerAction::.ctor()
extern void CinemachineTriggerAction__ctor_m51FC885E516BEAA36487E1C69FC60915A4499FB8 (void);
// 0x000003F5 System.Void Cinemachine.CinemachineTriggerAction/ActionSettings::.ctor(Cinemachine.CinemachineTriggerAction/ActionSettings/Mode)
extern void ActionSettings__ctor_mD581917562ECC8295F6278BA5AD001705F8E9035 (void);
// 0x000003F6 System.Void Cinemachine.CinemachineTriggerAction/ActionSettings::Invoke()
extern void ActionSettings_Invoke_mF3E35400963944A72FD025FEF8052413056DC716 (void);
// 0x000003F7 System.Void Cinemachine.CinemachineTriggerAction/ActionSettings/TriggerEvent::.ctor()
extern void TriggerEvent__ctor_m1B0E4D0D8DD5D925A7B5F502DECF073FBA41C266 (void);
// 0x000003F8 System.Void Cinemachine.GroupWeightManipulator::Start()
extern void GroupWeightManipulator_Start_m75C9527F322AAB1342866F0E3C9A95A47CD3ADD8 (void);
// 0x000003F9 System.Void Cinemachine.GroupWeightManipulator::OnValidate()
extern void GroupWeightManipulator_OnValidate_m03475E611BFE066FB8D68DF536E590D7A898986D (void);
// 0x000003FA System.Void Cinemachine.GroupWeightManipulator::Update()
extern void GroupWeightManipulator_Update_mF97C2AA28515F222056573441CA7323BCA2A4263 (void);
// 0x000003FB System.Void Cinemachine.GroupWeightManipulator::UpdateWeights()
extern void GroupWeightManipulator_UpdateWeights_m7AD8CE24D796B0B7DBEC5B8CE80EF22791216939 (void);
// 0x000003FC System.Void Cinemachine.GroupWeightManipulator::.ctor()
extern void GroupWeightManipulator__ctor_mB7E3E90299CFB064DFC0735B0D3A95F756B520DB (void);
// 0x000003FD System.Void Cinemachine.CinemachineCollisionImpulseSource::Start()
extern void CinemachineCollisionImpulseSource_Start_m5E5E851F56BBEB52056D04A8BAA9A09628D648E9 (void);
// 0x000003FE System.Void Cinemachine.CinemachineCollisionImpulseSource::OnEnable()
extern void CinemachineCollisionImpulseSource_OnEnable_m96262CAFC11EEA2C8E93D1C5C43550EBBBD5F5F5 (void);
// 0x000003FF System.Void Cinemachine.CinemachineCollisionImpulseSource::OnCollisionEnter(UnityEngine.Collision)
extern void CinemachineCollisionImpulseSource_OnCollisionEnter_m83A9DF31C999E8DADB0ECC1785811FE9E13DF31F (void);
// 0x00000400 System.Void Cinemachine.CinemachineCollisionImpulseSource::OnTriggerEnter(UnityEngine.Collider)
extern void CinemachineCollisionImpulseSource_OnTriggerEnter_mF2DE5CAE0F47A55DBD93891E8BE3878CD2EC13C6 (void);
// 0x00000401 System.Single Cinemachine.CinemachineCollisionImpulseSource::GetMassAndVelocity(UnityEngine.Collider,UnityEngine.Vector3&)
extern void CinemachineCollisionImpulseSource_GetMassAndVelocity_mB95B2A247A38FC23502BFCE4ACBECBB8E6D5478B (void);
// 0x00000402 System.Void Cinemachine.CinemachineCollisionImpulseSource::GenerateImpactEvent(UnityEngine.Collider,UnityEngine.Vector3)
extern void CinemachineCollisionImpulseSource_GenerateImpactEvent_m02923185427CABBF74C0E310B6631551881B084D (void);
// 0x00000403 System.Void Cinemachine.CinemachineCollisionImpulseSource::OnCollisionEnter2D(UnityEngine.Collision2D)
extern void CinemachineCollisionImpulseSource_OnCollisionEnter2D_m3EA8BBA135D81259C8F0C98CB504F61E86A1FCED (void);
// 0x00000404 System.Void Cinemachine.CinemachineCollisionImpulseSource::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void CinemachineCollisionImpulseSource_OnTriggerEnter2D_m128B0315FD9184DC00A136E4C24A19C6D3305FE3 (void);
// 0x00000405 System.Single Cinemachine.CinemachineCollisionImpulseSource::GetMassAndVelocity2D(UnityEngine.Collider2D,UnityEngine.Vector3&)
extern void CinemachineCollisionImpulseSource_GetMassAndVelocity2D_mD290AA11EAE21CDD0B3743B070AD3B1C630DC2C7 (void);
// 0x00000406 System.Void Cinemachine.CinemachineCollisionImpulseSource::GenerateImpactEvent2D(UnityEngine.Collider2D,UnityEngine.Vector3)
extern void CinemachineCollisionImpulseSource_GenerateImpactEvent2D_m7054A182B1B724BFD0BBB6F3867466449495A5A0 (void);
// 0x00000407 System.Void Cinemachine.CinemachineCollisionImpulseSource::.ctor()
extern void CinemachineCollisionImpulseSource__ctor_m52C884476834730DD21BA513FFE95FAF03A1EE72 (void);
// 0x00000408 System.Single Cinemachine.CinemachineFixedSignal::get_SignalDuration()
extern void CinemachineFixedSignal_get_SignalDuration_m45BF3B9C17DCD224D52644987797EF5AD3F2B335 (void);
// 0x00000409 System.Single Cinemachine.CinemachineFixedSignal::AxisDuration(UnityEngine.AnimationCurve)
extern void CinemachineFixedSignal_AxisDuration_m722605DBBFEB163DC9787AD18CD8F7920121B0DC (void);
// 0x0000040A System.Void Cinemachine.CinemachineFixedSignal::GetSignal(System.Single,UnityEngine.Vector3&,UnityEngine.Quaternion&)
extern void CinemachineFixedSignal_GetSignal_m92E661706E11B9D9C231CE543903182387B01FA2 (void);
// 0x0000040B System.Single Cinemachine.CinemachineFixedSignal::AxisValue(UnityEngine.AnimationCurve,System.Single)
extern void CinemachineFixedSignal_AxisValue_mADA40BCB50D24AFA3B306B3C21759DB00CB4116C (void);
// 0x0000040C System.Void Cinemachine.CinemachineFixedSignal::.ctor()
extern void CinemachineFixedSignal__ctor_mBF0542616A9718A1756FDCC01BB94235B9DEE404 (void);
// 0x0000040D System.Void Cinemachine.CinemachineImpulseDefinitionPropertyAttribute::.ctor()
extern void CinemachineImpulseDefinitionPropertyAttribute__ctor_mF66F03AD5A4EB4ECA78856EEAEE26142F522E1D1 (void);
// 0x0000040E System.Void Cinemachine.CinemachineImpulseDefinition::OnValidate()
extern void CinemachineImpulseDefinition_OnValidate_mFA3F1DA4B88CBB26F7529483BAB1AFB7D1ACA39E (void);
// 0x0000040F System.Void Cinemachine.CinemachineImpulseDefinition::CreateEvent(UnityEngine.Vector3,UnityEngine.Vector3)
extern void CinemachineImpulseDefinition_CreateEvent_m4321107CAE385B5FB027FBFF5DD5B7D5B034C783 (void);
// 0x00000410 Cinemachine.CinemachineImpulseManager/ImpulseEvent Cinemachine.CinemachineImpulseDefinition::CreateAndReturnEvent(UnityEngine.Vector3,UnityEngine.Vector3)
extern void CinemachineImpulseDefinition_CreateAndReturnEvent_mA242BCF220FF29B7BD481ECFD63485A8AE5F8220 (void);
// 0x00000411 System.Void Cinemachine.CinemachineImpulseDefinition::.ctor()
extern void CinemachineImpulseDefinition__ctor_mD30405D1F3CE7A681B0907945FB88F845C2FED85 (void);
// 0x00000412 System.Void Cinemachine.CinemachineImpulseDefinition/SignalSource::.ctor(Cinemachine.CinemachineImpulseDefinition,UnityEngine.Vector3)
extern void SignalSource__ctor_mCB153F491DABCD71273BD63B24BF32099AEBEF80 (void);
// 0x00000413 System.Single Cinemachine.CinemachineImpulseDefinition/SignalSource::get_SignalDuration()
extern void SignalSource_get_SignalDuration_m361ECAF68816FA8EC16C6EF9644886A11CFAA837 (void);
// 0x00000414 System.Void Cinemachine.CinemachineImpulseDefinition/SignalSource::GetSignal(System.Single,UnityEngine.Vector3&,UnityEngine.Quaternion&)
extern void SignalSource_GetSignal_m9A46E678A84820D6D5FC33F008DEC2DFCFB94DA1 (void);
// 0x00000415 System.Void Cinemachine.CinemachineImpulseListener::Reset()
extern void CinemachineImpulseListener_Reset_mC94D85F68C6BDDE277ECCFE27B467DAEBE4F9CD4 (void);
// 0x00000416 System.Void Cinemachine.CinemachineImpulseListener::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore/Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachineImpulseListener_PostPipelineStageCallback_m5DB0EB79B863014AEA4AD493E8989EB789B83119 (void);
// 0x00000417 System.Void Cinemachine.CinemachineImpulseListener::.ctor()
extern void CinemachineImpulseListener__ctor_m4D00191CF14DEA2304345E89ABF693D06026AF33 (void);
// 0x00000418 System.Void Cinemachine.CinemachineImpulseEnvelopePropertyAttribute::.ctor()
extern void CinemachineImpulseEnvelopePropertyAttribute__ctor_m102C22E2CEE8BF51F3C95D3C751035320B1C8574 (void);
// 0x00000419 System.Void Cinemachine.CinemachineImpulseChannelPropertyAttribute::.ctor()
extern void CinemachineImpulseChannelPropertyAttribute__ctor_mB2115A1DF97474375A0EF9E96301CF5273149443 (void);
// 0x0000041A System.Void Cinemachine.CinemachineImpulseManager::.ctor()
extern void CinemachineImpulseManager__ctor_m00612FBC540CE6AACDFECE7943168B27C2A3848F (void);
// 0x0000041B Cinemachine.CinemachineImpulseManager Cinemachine.CinemachineImpulseManager::get_Instance()
extern void CinemachineImpulseManager_get_Instance_m2610081DC5D98082D240CE3FD7C6C6CEAE571DE4 (void);
// 0x0000041C System.Void Cinemachine.CinemachineImpulseManager::InitializeModule()
extern void CinemachineImpulseManager_InitializeModule_m6DCF2F486EBEA933CC146F7476010FE2D598E0DF (void);
// 0x0000041D System.Boolean Cinemachine.CinemachineImpulseManager::GetImpulseAt(UnityEngine.Vector3,System.Boolean,System.Int32,UnityEngine.Vector3&,UnityEngine.Quaternion&)
extern void CinemachineImpulseManager_GetImpulseAt_mD63748BEEF92691CD8962594BC86D8AACC6908D6 (void);
// 0x0000041E System.Boolean Cinemachine.CinemachineImpulseManager::get_IgnoreTimeScale()
extern void CinemachineImpulseManager_get_IgnoreTimeScale_m7286B8E9A54BE18D4D002F7824057EF9B4A6F581 (void);
// 0x0000041F System.Void Cinemachine.CinemachineImpulseManager::set_IgnoreTimeScale(System.Boolean)
extern void CinemachineImpulseManager_set_IgnoreTimeScale_m734F8037EA5DDBAFEFE2AE02FE1AC87AD5FD333F (void);
// 0x00000420 System.Single Cinemachine.CinemachineImpulseManager::get_CurrentTime()
extern void CinemachineImpulseManager_get_CurrentTime_mE6D6E38260F7F6CA352A44825C905F3CABC331ED (void);
// 0x00000421 Cinemachine.CinemachineImpulseManager/ImpulseEvent Cinemachine.CinemachineImpulseManager::NewImpulseEvent()
extern void CinemachineImpulseManager_NewImpulseEvent_mF579A9519CE81229E765EFF552B4556FE8625198 (void);
// 0x00000422 System.Void Cinemachine.CinemachineImpulseManager::AddImpulseEvent(Cinemachine.CinemachineImpulseManager/ImpulseEvent)
extern void CinemachineImpulseManager_AddImpulseEvent_m3C54AC87600E365FB98F0A8D43B6A1A0F96EA3C7 (void);
// 0x00000423 System.Void Cinemachine.CinemachineImpulseManager::Clear()
extern void CinemachineImpulseManager_Clear_mA812D41CE685AADD048C6257BBC2EF82F0022F13 (void);
// 0x00000424 System.Void Cinemachine.CinemachineImpulseManager::.cctor()
extern void CinemachineImpulseManager__cctor_mA7E7C7140C2AF2C42811EC72E2B137314E583114 (void);
// 0x00000425 Cinemachine.CinemachineImpulseManager/EnvelopeDefinition Cinemachine.CinemachineImpulseManager/EnvelopeDefinition::Default()
extern void EnvelopeDefinition_Default_m6048BC0ADAE235D4D0F47D57AC6F07F8031E8502 (void);
// 0x00000426 System.Single Cinemachine.CinemachineImpulseManager/EnvelopeDefinition::get_Duration()
extern void EnvelopeDefinition_get_Duration_m494621ABECC584E355834D287BEA915BD68A774F (void);
// 0x00000427 System.Single Cinemachine.CinemachineImpulseManager/EnvelopeDefinition::GetValueAt(System.Single)
extern void EnvelopeDefinition_GetValueAt_mA27AFC5D351DA50CA935ACCAB79D91F1E924C8CC (void);
// 0x00000428 System.Void Cinemachine.CinemachineImpulseManager/EnvelopeDefinition::ChangeStopTime(System.Single,System.Boolean)
extern void EnvelopeDefinition_ChangeStopTime_mA4D7614B6F56A8E279596B52252816EB59843F23 (void);
// 0x00000429 System.Void Cinemachine.CinemachineImpulseManager/EnvelopeDefinition::Clear()
extern void EnvelopeDefinition_Clear_m2B817953AFB7CDAA6B62AEC4A1E6A588484B554B (void);
// 0x0000042A System.Void Cinemachine.CinemachineImpulseManager/EnvelopeDefinition::Validate()
extern void EnvelopeDefinition_Validate_mA0464BC35544052393B17674F751FAA755051B14 (void);
// 0x0000042B System.Boolean Cinemachine.CinemachineImpulseManager/ImpulseEvent::get_Expired()
extern void ImpulseEvent_get_Expired_m06944921FE1EEA9118BFAEE7F52E73280418DCA7 (void);
// 0x0000042C System.Void Cinemachine.CinemachineImpulseManager/ImpulseEvent::Cancel(System.Single,System.Boolean)
extern void ImpulseEvent_Cancel_mA2831A11F90680EE32F4685E6311140D627C877B (void);
// 0x0000042D System.Single Cinemachine.CinemachineImpulseManager/ImpulseEvent::DistanceDecay(System.Single)
extern void ImpulseEvent_DistanceDecay_mF8C3C77FF46D6C2B23BE694CCA9714F76ED60036 (void);
// 0x0000042E System.Boolean Cinemachine.CinemachineImpulseManager/ImpulseEvent::GetDecayedSignal(UnityEngine.Vector3,System.Boolean,UnityEngine.Vector3&,UnityEngine.Quaternion&)
extern void ImpulseEvent_GetDecayedSignal_m973C1F0E6D32DC4DD14ECDF280FE58D14F6943EC (void);
// 0x0000042F System.Void Cinemachine.CinemachineImpulseManager/ImpulseEvent::Clear()
extern void ImpulseEvent_Clear_m3FBD19A05EAC470ACE87FAC6CF8FCBBB01E278A2 (void);
// 0x00000430 System.Void Cinemachine.CinemachineImpulseManager/ImpulseEvent::.ctor()
extern void ImpulseEvent__ctor_mBDBA49A0F06CCB22CAB3ADCFB3B62BB1EF812E53 (void);
// 0x00000431 System.Void Cinemachine.CinemachineImpulseSource::OnValidate()
extern void CinemachineImpulseSource_OnValidate_m83C3BD911B9348F88DC2AE85D1DB974A8E10979D (void);
// 0x00000432 System.Void Cinemachine.CinemachineImpulseSource::GenerateImpulseAt(UnityEngine.Vector3,UnityEngine.Vector3)
extern void CinemachineImpulseSource_GenerateImpulseAt_m0A99A6E18F64EB89296877D1A6816D72CB58CA3B (void);
// 0x00000433 System.Void Cinemachine.CinemachineImpulseSource::GenerateImpulse(UnityEngine.Vector3)
extern void CinemachineImpulseSource_GenerateImpulse_mA0BA98729D31DAA4489F8A795460312C6AC987A0 (void);
// 0x00000434 System.Void Cinemachine.CinemachineImpulseSource::GenerateImpulse(System.Single)
extern void CinemachineImpulseSource_GenerateImpulse_m2F8A5B9B2CB9F5A1F7E76D2034B8F6BBED59C083 (void);
// 0x00000435 System.Void Cinemachine.CinemachineImpulseSource::GenerateImpulse()
extern void CinemachineImpulseSource_GenerateImpulse_mED2BDD40C547E077E1DF815B796F382D4354F7FC (void);
// 0x00000436 System.Void Cinemachine.CinemachineImpulseSource::.ctor()
extern void CinemachineImpulseSource__ctor_m9E80ACB84814DB64C13AD8DA4FEDAF89664D081D (void);
// 0x00000437 System.Void Cinemachine.CinemachineIndependentImpulseListener::Reset()
extern void CinemachineIndependentImpulseListener_Reset_mBCDD4E8A955637C2F86F03E77FD60522366EEF47 (void);
// 0x00000438 System.Void Cinemachine.CinemachineIndependentImpulseListener::OnEnable()
extern void CinemachineIndependentImpulseListener_OnEnable_mB2F604C65010D97C7B9B49DE3EEEC2B2DD20595B (void);
// 0x00000439 System.Void Cinemachine.CinemachineIndependentImpulseListener::Update()
extern void CinemachineIndependentImpulseListener_Update_mD29D193527AEFA832942DED9837FB503532A698F (void);
// 0x0000043A System.Void Cinemachine.CinemachineIndependentImpulseListener::LateUpdate()
extern void CinemachineIndependentImpulseListener_LateUpdate_m1F8FA46BB2ABFD4EE0502A5D1A30B70E31B16971 (void);
// 0x0000043B System.Void Cinemachine.CinemachineIndependentImpulseListener::.ctor()
extern void CinemachineIndependentImpulseListener__ctor_m58D3A75F484AEBA326E4631720198ED751049A38 (void);
// 0x0000043C System.Void Cinemachine.PostFX.CinemachinePostProcessing::PostPipelineStageCallback(Cinemachine.CinemachineVirtualCameraBase,Cinemachine.CinemachineCore/Stage,Cinemachine.CameraState&,System.Single)
extern void CinemachinePostProcessing_PostPipelineStageCallback_mBB56E45B7D4BBEAE04A420C99A3341E0EF7D1C24 (void);
// 0x0000043D System.Void Cinemachine.PostFX.CinemachinePostProcessing::.ctor()
extern void CinemachinePostProcessing__ctor_m036C1F22C14AB44191F6715C831A6A10C39C64BF (void);
// 0x0000043E System.Void Cinemachine.PostFX.CinemachineVolumeSettings::.ctor()
extern void CinemachineVolumeSettings__ctor_m62731AF7317EE4CE5CB2E4E624DCDE9D69EF7B06 (void);
// 0x0000043F System.Void Cinemachine.Utility.CinemachineDebug::ReleaseScreenPos(UnityEngine.Object)
extern void CinemachineDebug_ReleaseScreenPos_mB86CBB15358DB61F1EE1FB14B1A75C22DF973EC1 (void);
// 0x00000440 UnityEngine.Rect Cinemachine.Utility.CinemachineDebug::GetScreenPos(UnityEngine.Object,System.String,UnityEngine.GUIStyle)
extern void CinemachineDebug_GetScreenPos_mDB9E3E780C465A8773B43312A6316F11789F31DB (void);
// 0x00000441 System.Text.StringBuilder Cinemachine.Utility.CinemachineDebug::SBFromPool()
extern void CinemachineDebug_SBFromPool_mB6C8A1699C089516D0C30DB54FACEA9DE7BEBEE1 (void);
// 0x00000442 System.Void Cinemachine.Utility.CinemachineDebug::ReturnToPool(System.Text.StringBuilder)
extern void CinemachineDebug_ReturnToPool_mC5B15ABF0A1EAA33217EA6B204901D2817442704 (void);
// 0x00000443 System.Void Cinemachine.Utility.CinemachineDebug::.ctor()
extern void CinemachineDebug__ctor_m34EA5A3E30773372406A3EFEFEAC4D512FBC53D1 (void);
// 0x00000444 System.Void Cinemachine.Utility.CinemachineDebug/OnGUIDelegate::.ctor(System.Object,System.IntPtr)
extern void OnGUIDelegate__ctor_m368CF0C4912A67D1DBDA8E1F2C2827D0163482FA (void);
// 0x00000445 System.Void Cinemachine.Utility.CinemachineDebug/OnGUIDelegate::Invoke()
extern void OnGUIDelegate_Invoke_mA31514C83F7C6B0DC124FB9C3C9AF1AE46EA3BE2 (void);
// 0x00000446 System.IAsyncResult Cinemachine.Utility.CinemachineDebug/OnGUIDelegate::BeginInvoke(System.AsyncCallback,System.Object)
extern void OnGUIDelegate_BeginInvoke_mB9DDADF15A39323C1F037853E3A73B2AB7697E33 (void);
// 0x00000447 System.Void Cinemachine.Utility.CinemachineDebug/OnGUIDelegate::EndInvoke(System.IAsyncResult)
extern void OnGUIDelegate_EndInvoke_mA2E9D5AB93F6750402449BC316CB9F00CD0013F9 (void);
// 0x00000448 System.Single Cinemachine.Utility.GaussianWindow1d`1::get_Sigma()
// 0x00000449 System.Void Cinemachine.Utility.GaussianWindow1d`1::set_Sigma(System.Single)
// 0x0000044A System.Int32 Cinemachine.Utility.GaussianWindow1d`1::get_KernelSize()
// 0x0000044B System.Void Cinemachine.Utility.GaussianWindow1d`1::GenerateKernel(System.Single,System.Int32)
// 0x0000044C T Cinemachine.Utility.GaussianWindow1d`1::Compute(System.Int32)
// 0x0000044D System.Void Cinemachine.Utility.GaussianWindow1d`1::.ctor(System.Single,System.Int32)
// 0x0000044E System.Void Cinemachine.Utility.GaussianWindow1d`1::Reset()
// 0x0000044F System.Boolean Cinemachine.Utility.GaussianWindow1d`1::IsEmpty()
// 0x00000450 System.Void Cinemachine.Utility.GaussianWindow1d`1::AddValue(T)
// 0x00000451 T Cinemachine.Utility.GaussianWindow1d`1::Filter(T)
// 0x00000452 T Cinemachine.Utility.GaussianWindow1d`1::Value()
// 0x00000453 System.Int32 Cinemachine.Utility.GaussianWindow1d`1::get_BufferLength()
// 0x00000454 System.Void Cinemachine.Utility.GaussianWindow1d`1::SetBufferValue(System.Int32,T)
// 0x00000455 T Cinemachine.Utility.GaussianWindow1d`1::GetBufferValue(System.Int32)
// 0x00000456 System.Void Cinemachine.Utility.GaussianWindow1D_Vector3::.ctor(System.Single,System.Int32)
extern void GaussianWindow1D_Vector3__ctor_m9F9F4D1099F38C2011F89481C3942BCF837A8C8F (void);
// 0x00000457 UnityEngine.Vector3 Cinemachine.Utility.GaussianWindow1D_Vector3::Compute(System.Int32)
extern void GaussianWindow1D_Vector3_Compute_mC47257358568DEC6D1F06A2736F9FFE72840155A (void);
// 0x00000458 System.Void Cinemachine.Utility.GaussianWindow1D_Quaternion::.ctor(System.Single,System.Int32)
extern void GaussianWindow1D_Quaternion__ctor_m42734F192A050DB0229809115A08EB5B2ACFE2B8 (void);
// 0x00000459 UnityEngine.Quaternion Cinemachine.Utility.GaussianWindow1D_Quaternion::Compute(System.Int32)
extern void GaussianWindow1D_Quaternion_Compute_m0E7848F46F6D124039571EC9E16E07F969B5A98D (void);
// 0x0000045A System.Void Cinemachine.Utility.GaussianWindow1D_CameraRotation::.ctor(System.Single,System.Int32)
extern void GaussianWindow1D_CameraRotation__ctor_m4834B72F86867A703ECCA581EA7B7D1636BAA6ED (void);
// 0x0000045B UnityEngine.Vector2 Cinemachine.Utility.GaussianWindow1D_CameraRotation::Compute(System.Int32)
extern void GaussianWindow1D_CameraRotation_Compute_mB07D3BAA51B60DCF8DCF738916D4A8F25D2851C4 (void);
// 0x0000045C System.Single Cinemachine.Utility.PositionPredictor::get_Smoothing()
extern void PositionPredictor_get_Smoothing_mB2305254F86ADC44F77B967664A836A1E523903E (void);
// 0x0000045D System.Void Cinemachine.Utility.PositionPredictor::set_Smoothing(System.Single)
extern void PositionPredictor_set_Smoothing_m4882C9C588E241A637B9E16A372B03DFD486EBB1 (void);
// 0x0000045E System.Boolean Cinemachine.Utility.PositionPredictor::IsEmpty()
extern void PositionPredictor_IsEmpty_mA2B45EC05F649C5F9720C228BFED71E8AD5F62B5 (void);
// 0x0000045F System.Void Cinemachine.Utility.PositionPredictor::ApplyTransformDelta(UnityEngine.Vector3)
extern void PositionPredictor_ApplyTransformDelta_m77976FB10046478DA8110E153218CB9AE00132A1 (void);
// 0x00000460 System.Void Cinemachine.Utility.PositionPredictor::Reset()
extern void PositionPredictor_Reset_mB44898FC7B8E9B0A7F683840935E9BA00E699ADC (void);
// 0x00000461 System.Void Cinemachine.Utility.PositionPredictor::AddPosition(UnityEngine.Vector3,System.Single,System.Single)
extern void PositionPredictor_AddPosition_m1E539B2DB83AD523581841BF1D302643CE9275B3 (void);
// 0x00000462 UnityEngine.Vector3 Cinemachine.Utility.PositionPredictor::PredictPositionDelta(System.Single)
extern void PositionPredictor_PredictPositionDelta_m19C414F8AFAFC691F2FA995D77B0C694E8EDADDD (void);
// 0x00000463 UnityEngine.Vector3 Cinemachine.Utility.PositionPredictor::PredictPosition(System.Single)
extern void PositionPredictor_PredictPosition_mCD92F4061A05A405E45399C22D8E68E9DCA739B8 (void);
// 0x00000464 System.Void Cinemachine.Utility.PositionPredictor::.ctor()
extern void PositionPredictor__ctor_m4D6A0B4370D8836CEF0C54F233EE351EE2A8AEFA (void);
// 0x00000465 System.Single Cinemachine.Utility.Damper::DecayConstant(System.Single,System.Single)
extern void Damper_DecayConstant_m90B73FBD9EFDFDADD53456DFBA5DC3FBD2A250B4 (void);
// 0x00000466 System.Single Cinemachine.Utility.Damper::DecayedRemainder(System.Single,System.Single,System.Single)
extern void Damper_DecayedRemainder_mA1A4A25180833287B1EB3305763101321F042E46 (void);
// 0x00000467 System.Single Cinemachine.Utility.Damper::Damp(System.Single,System.Single,System.Single)
extern void Damper_Damp_mA12020431103076AB69C0FC03C4C07B388AD9E27 (void);
// 0x00000468 UnityEngine.Vector3 Cinemachine.Utility.Damper::Damp(UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void Damper_Damp_m62C13BEDD585C7DE73B4BDFBC28DDA00C4F89EEE (void);
// 0x00000469 UnityEngine.Vector3 Cinemachine.Utility.Damper::Damp(UnityEngine.Vector3,System.Single,System.Single)
extern void Damper_Damp_m5F27E39708AA38EF9CC7D888B6F3681813C0E6F0 (void);
// 0x0000046A System.Void Cinemachine.Utility.HeadingTracker::.ctor(System.Int32)
extern void HeadingTracker__ctor_mF6B909E191467A5BD7D4B982E751ADA11C4608D3 (void);
// 0x0000046B System.Int32 Cinemachine.Utility.HeadingTracker::get_FilterSize()
extern void HeadingTracker_get_FilterSize_mC9A740BF0831E766A9425F01A72681EF912D08E8 (void);
// 0x0000046C System.Void Cinemachine.Utility.HeadingTracker::ClearHistory()
extern void HeadingTracker_ClearHistory_mDE5209EB31B87840F52B0407996951E343711389 (void);
// 0x0000046D System.Single Cinemachine.Utility.HeadingTracker::Decay(System.Single)
extern void HeadingTracker_Decay_mFC85AA39B403F52067DDECD6C488EFCBB7F38BE9 (void);
// 0x0000046E System.Void Cinemachine.Utility.HeadingTracker::Add(UnityEngine.Vector3)
extern void HeadingTracker_Add_m1895E709261177B40C99111534D777A3E484D517 (void);
// 0x0000046F System.Void Cinemachine.Utility.HeadingTracker::PopBottom()
extern void HeadingTracker_PopBottom_m22630D7ACBCF2197BD86E73F987CF15812A1D2B5 (void);
// 0x00000470 System.Void Cinemachine.Utility.HeadingTracker::DecayHistory()
extern void HeadingTracker_DecayHistory_m192F30AA8475481505746C3ACE672088F9D76DBB (void);
// 0x00000471 UnityEngine.Vector3 Cinemachine.Utility.HeadingTracker::GetReliableHeading()
extern void HeadingTracker_GetReliableHeading_m14DC7D8BBE3912362DF154EC669D9406A8597EF8 (void);
// 0x00000472 UnityEngine.Vector3 Cinemachine.Utility.SplineHelpers::Bezier3(System.Single,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void SplineHelpers_Bezier3_m671B7D546F16979F687B01A82D9239C0FF9A6C6F (void);
// 0x00000473 UnityEngine.Vector3 Cinemachine.Utility.SplineHelpers::BezierTangent3(System.Single,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void SplineHelpers_BezierTangent3_m59375A4F9C985BC314131BC4286A02967A2A99B6 (void);
// 0x00000474 System.Single Cinemachine.Utility.SplineHelpers::Bezier1(System.Single,System.Single,System.Single,System.Single,System.Single)
extern void SplineHelpers_Bezier1_m01DF69C839E93F6D90E4CDE0E048DC8E5CEC2AE9 (void);
// 0x00000475 System.Single Cinemachine.Utility.SplineHelpers::BezierTangent1(System.Single,System.Single,System.Single,System.Single,System.Single)
extern void SplineHelpers_BezierTangent1_m6F265CBD431F2BDA6DBBFB16AD818D6EFA3D7690 (void);
// 0x00000476 System.Void Cinemachine.Utility.SplineHelpers::ComputeSmoothControlPoints(UnityEngine.Vector4[]&,UnityEngine.Vector4[]&,UnityEngine.Vector4[]&)
extern void SplineHelpers_ComputeSmoothControlPoints_mCBC6D06822574DCF0525832339422BCBA6AD899B (void);
// 0x00000477 System.Void Cinemachine.Utility.SplineHelpers::ComputeSmoothControlPointsLooped(UnityEngine.Vector4[]&,UnityEngine.Vector4[]&,UnityEngine.Vector4[]&)
extern void SplineHelpers_ComputeSmoothControlPointsLooped_mBD24C3CF63EA1ED0D83053C14DE95515C276DD5F (void);
// 0x00000478 System.Boolean Cinemachine.Utility.UnityVectorExtensions::IsNaN(UnityEngine.Vector2)
extern void UnityVectorExtensions_IsNaN_mFD5E054EBD551DB8C1DAE365C72C31A37AA128FF (void);
// 0x00000479 System.Boolean Cinemachine.Utility.UnityVectorExtensions::IsNaN(UnityEngine.Vector3)
extern void UnityVectorExtensions_IsNaN_m6EAD9206008E12BF8BC6F783809D488AC36AED4E (void);
// 0x0000047A System.Single Cinemachine.Utility.UnityVectorExtensions::ClosestPointOnSegment(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void UnityVectorExtensions_ClosestPointOnSegment_m1BC07881406AD228FC3BD25F04DEEFCD844D0F03 (void);
// 0x0000047B System.Single Cinemachine.Utility.UnityVectorExtensions::ClosestPointOnSegment(UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.Vector2)
extern void UnityVectorExtensions_ClosestPointOnSegment_m2743E36D603D1321F3BF3F0FA76618D30CF48144 (void);
// 0x0000047C UnityEngine.Vector3 Cinemachine.Utility.UnityVectorExtensions::ProjectOntoPlane(UnityEngine.Vector3,UnityEngine.Vector3)
extern void UnityVectorExtensions_ProjectOntoPlane_m8A4C6658A16D9A9E2415D787D52AF418133790D9 (void);
// 0x0000047D UnityEngine.Vector2 Cinemachine.Utility.UnityVectorExtensions::SquareNormalize(UnityEngine.Vector2)
extern void UnityVectorExtensions_SquareNormalize_m6A3571F61DF518AB665E7ECAA1F88B3E71D616A2 (void);
// 0x0000047E System.Int32 Cinemachine.Utility.UnityVectorExtensions::FindIntersection(UnityEngine.Vector2&,UnityEngine.Vector2&,UnityEngine.Vector2&,UnityEngine.Vector2&,UnityEngine.Vector2&)
extern void UnityVectorExtensions_FindIntersection_mD9BA155ECDA240120A4613F3CCB65385131D978E (void);
// 0x0000047F System.Single Cinemachine.Utility.UnityVectorExtensions::Cross(UnityEngine.Vector2,UnityEngine.Vector2)
extern void UnityVectorExtensions_Cross_m3605AB9250A722AA2C53E27ADA17FE0983F5BF76 (void);
// 0x00000480 UnityEngine.Vector2 Cinemachine.Utility.UnityVectorExtensions::Abs(UnityEngine.Vector2)
extern void UnityVectorExtensions_Abs_m76EBBF98B625DB524BC7851ACB0201A6B4C5F348 (void);
// 0x00000481 UnityEngine.Vector3 Cinemachine.Utility.UnityVectorExtensions::Abs(UnityEngine.Vector3)
extern void UnityVectorExtensions_Abs_mF5BB01E967809EAD9B96646DB47CA4457CECB544 (void);
// 0x00000482 System.Boolean Cinemachine.Utility.UnityVectorExtensions::IsUniform(UnityEngine.Vector2)
extern void UnityVectorExtensions_IsUniform_m0A6BCC370C26C2C536B22030915BB3C3B96C47E3 (void);
// 0x00000483 System.Boolean Cinemachine.Utility.UnityVectorExtensions::IsUniform(UnityEngine.Vector3)
extern void UnityVectorExtensions_IsUniform_m0C6E99FC6DA9925EAFF5F0554727C4CDD8C4825B (void);
// 0x00000484 System.Boolean Cinemachine.Utility.UnityVectorExtensions::AlmostZero(UnityEngine.Vector3)
extern void UnityVectorExtensions_AlmostZero_m9F538E467290B6199EA350E4639400BF9984915B (void);
// 0x00000485 System.Single Cinemachine.Utility.UnityVectorExtensions::Angle(UnityEngine.Vector3,UnityEngine.Vector3)
extern void UnityVectorExtensions_Angle_m04A32FB43E3D540CD85EF2A061C485A0EA1848F7 (void);
// 0x00000486 System.Single Cinemachine.Utility.UnityVectorExtensions::SignedAngle(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void UnityVectorExtensions_SignedAngle_mD9BC7BAFD53B8BEE637C33AF52EAB09DFA45F939 (void);
// 0x00000487 UnityEngine.Quaternion Cinemachine.Utility.UnityVectorExtensions::SafeFromToRotation(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void UnityVectorExtensions_SafeFromToRotation_mF94D5E648352AB7EAF0B22D751DED6B1E4E54BD9 (void);
// 0x00000488 UnityEngine.Vector3 Cinemachine.Utility.UnityVectorExtensions::SlerpWithReferenceUp(UnityEngine.Vector3,UnityEngine.Vector3,System.Single,UnityEngine.Vector3)
extern void UnityVectorExtensions_SlerpWithReferenceUp_m141B1B05C8FD1F4D0C4349E9A80BCC72604F0A58 (void);
// 0x00000489 UnityEngine.Quaternion Cinemachine.Utility.UnityQuaternionExtensions::SlerpWithReferenceUp(UnityEngine.Quaternion,UnityEngine.Quaternion,System.Single,UnityEngine.Vector3)
extern void UnityQuaternionExtensions_SlerpWithReferenceUp_mB984001DA18FC2FF5035301F813B132AC999F1B6 (void);
// 0x0000048A UnityEngine.Quaternion Cinemachine.Utility.UnityQuaternionExtensions::Normalized(UnityEngine.Quaternion)
extern void UnityQuaternionExtensions_Normalized_m36AE449C35F60018BD511131B87E1A63D1B7DCA2 (void);
// 0x0000048B UnityEngine.Vector2 Cinemachine.Utility.UnityQuaternionExtensions::GetCameraRotationToTarget(UnityEngine.Quaternion,UnityEngine.Vector3,UnityEngine.Vector3)
extern void UnityQuaternionExtensions_GetCameraRotationToTarget_m744FC3EC6D163C8E4E5FD27AA9B83ADF321ED70F (void);
// 0x0000048C UnityEngine.Quaternion Cinemachine.Utility.UnityQuaternionExtensions::ApplyCameraRotation(UnityEngine.Quaternion,UnityEngine.Vector2,UnityEngine.Vector3)
extern void UnityQuaternionExtensions_ApplyCameraRotation_m950CF054F6A2F4868E5D333046204FB7F016D2DF (void);
// 0x0000048D UnityEngine.Rect Cinemachine.Utility.UnityRectExtensions::Inflated(UnityEngine.Rect,UnityEngine.Vector2)
extern void UnityRectExtensions_Inflated_m07D1A88B141BFE8C3DB3D24ED9045D0D5AF21EB8 (void);
static Il2CppMethodPointer s_methodPointers[1165] = 
{
	EmbeddedAttribute__ctor_m3F1A0F751C498444248AA864896027EFF3D11614,
	IsReadOnlyAttribute__ctor_m9040E090B861BCC28C3BCFEB7D7E21326F067CA9,
	CinemachineCameraOffset_PostPipelineStageCallback_m214222457A0BD96712F898260D4D5F9757C1D736,
	CinemachineCameraOffset__ctor_mBA995110079C215F7AB8FF6DF54C37231C3B5728,
	CinemachineRecomposer_Reset_m88525BE6F6B1DF4ABC2E58CCD4E5C95C3ED79A27,
	CinemachineRecomposer_OnValidate_m9BD3BC5317D1374AEC17027D208741B5A8F62678,
	CinemachineRecomposer_PrePipelineMutateCameraStateCallback_mDE48BF5922B0CB07EEC0EDA9E1E77D86FF57C203,
	CinemachineRecomposer_PostPipelineStageCallback_mE0BE4A9CF309A03D03861E086ED513AEDC9C3078,
	CinemachineRecomposer__ctor_mA94BEB1150CFE4D50C588D2F5C166B268D7B1362,
	CinemachineTouchInputMapper_Start_m3AC349B75F081ACCDA532FBFD15F6C4DC5FA7BCC,
	CinemachineTouchInputMapper_GetInputAxis_mC7DB7FBF8CA101DD4F25DC42253932CAFA2F1413,
	CinemachineTouchInputMapper__ctor_mCE60215EA756B6CC9CDE11A6A29355961C35FCFE,
	CinemachineMixer_OnPlayableDestroy_m15D0D97BC182EEA1A886B55A440F3F37FA1B427B,
	CinemachineMixer_PrepareFrame_mEDA03F2B9CB7AB571903D7BE4CAFA9340020B617,
	CinemachineMixer_ProcessFrame_m34F7C76AC1EB8C4027CD23D54C8A0DF74788076C,
	CinemachineMixer_GetDeltaTime_mAFED8F9148B137A18BB77BBA34B10DC79E4EDBAC,
	CinemachineMixer__ctor_m65687FEE5BF1A97442CCA217DC7E688AF110508A,
	MasterDirectorDelegate__ctor_mFC5DB393BD8432B57F3EA9E183CD4D224AD4E5B3,
	MasterDirectorDelegate_Invoke_mE703899DFD92246C6411D29992C32024398EB999,
	MasterDirectorDelegate_BeginInvoke_m67EDBDBF4F3B3BDA4AF8FDF03D0C43F6DB657E9E,
	MasterDirectorDelegate_EndInvoke_m0DEA9513CDDF240BD9616179C047000F1C5552C3,
	CinemachineShot_CreatePlayable_mEEA36A48B4C1B0AE73DD4E6DB5BB67EDD5CC9FBF,
	CinemachineShot_GatherProperties_mD35DE60059D05AA13705B3AA45C1A2D3FD82E2A2,
	CinemachineShot__ctor_m4E0ED8E81339A16B4BBE6833D2891A59F1868F04,
	CinemachineShotPlayable_get_IsValid_m783EFC14C1B6E0C331E8BE1FB97BF73E5C0FB085,
	CinemachineShotPlayable__ctor_m5831073991E80621F1FD0DAE1862F4B47D4FEC58,
	CinemachineTrack_CreateTrackMixer_mC9AD3E7B72FDAF3BF9ECBFE57BDD75880F7A4346,
	CinemachineTrack__ctor_m346DCFF5C3E9A01315B9C4F59625F3FFAC3DDBDA,
	Cinemachine3rdPersonAim_OnValidate_m1DB2920E91BF684D7E934BC0136839D7ABF49C09,
	Cinemachine3rdPersonAim_Reset_m76AF226247A9F0C4CCDDF0200876BC01859A17DA,
	Cinemachine3rdPersonAim_OnTransitionFromCamera_mB60FDBDAEC3D755C4BC8FF8EB9DB5A8226FE5144,
	Cinemachine3rdPersonAim_DrawReticle_m4B256A71AFE3F96910662DEE45FC49FD1BAACD50,
	Cinemachine3rdPersonAim_GetLookAtPoint_m920FEA216F7AF2AF10154BF104CED04D900A89E4,
	Cinemachine3rdPersonAim_PostPipelineStageCallback_m431D6A5A151FC73D58E2BB5C843C4A9D785AED82,
	Cinemachine3rdPersonAim__ctor_m3FD0201C504BF089A48A2A2054B8CD3F85DB46EF,
	CinemachineBlendListCamera_get_Description_m5C6D715F0F62C76E72B28C22E29B85A99F44FB8A,
	CinemachineBlendListCamera_Reset_mA706C0FB4CC7FD7FCAF338BDA534A803539B6BEA,
	CinemachineBlendListCamera_set_LiveChild_m06CBC3CB11F541FA72E4F5189DA3CDAD2F93A12D,
	CinemachineBlendListCamera_get_LiveChild_mC110B712B11C6D0D8BEE7CF35511A88932FB374B,
	CinemachineBlendListCamera_IsLiveChild_m01E481F15D50EDA15D50F7698A8D4270E9A6DF2D,
	CinemachineBlendListCamera_get_State_m0F2CC117E1188ED5E61F263A3F96C99152603997,
	CinemachineBlendListCamera_get_LookAt_m4987B243A6841944D9CC1DCEEB208D75DD472D8F,
	CinemachineBlendListCamera_set_LookAt_m89A121D81D3A5A9AB901C2490C8582E19D56720B,
	CinemachineBlendListCamera_get_Follow_m4C77B0D9285FF0E0BDE6672AA97CBFEA8F779EAE,
	CinemachineBlendListCamera_set_Follow_m11AC198E828F34AA47C3DEDEE0255BB52155E4F3,
	CinemachineBlendListCamera_OnTargetObjectWarped_m064D8A1708A9EC3A8C3781CDDEAE0DD19F26C226,
	CinemachineBlendListCamera_ForceCameraPosition_m8353DC410D5F9C28E6BD4A6E795E8B02C2AD102F,
	CinemachineBlendListCamera_OnTransitionFromCamera_m0A4B32A2C54128881A91D1AC80C83EA626FF6403,
	CinemachineBlendListCamera_get_TransitioningFrom_mD6696F8110804BEA7C73ECE7815C01349DA80ADD,
	CinemachineBlendListCamera_set_TransitioningFrom_mAD76B896D15BE8EC438A9527249DC62FD696EE0D,
	CinemachineBlendListCamera_InternalUpdateCameraState_m58770001B7B5AC14E824882B59611938B64B289D,
	CinemachineBlendListCamera_OnEnable_m64064AC70DFF2427499FE68274AC45E753D556CA,
	CinemachineBlendListCamera_OnDisable_m46FCC8C90F9233ED5528545F728D23B8AEC439FA,
	CinemachineBlendListCamera_OnTransformChildrenChanged_m08CB2CA52EDFE41199C966A34F478C3D85425EC2,
	CinemachineBlendListCamera_OnGuiHandler_m58B69E2CCF7FA61E5DD1934735E6873DCF379FD0,
	CinemachineBlendListCamera_get_ChildCameras_m85978F41F7E12760B36BE29F70107684A229295D,
	CinemachineBlendListCamera_get_IsBlending_m0BAA4ACB2EBA83796F4E210F8E870329676F4708,
	CinemachineBlendListCamera_InvalidateListOfChildren_m1A851A8A2A3D12271AEBCB7CB52D014AEB6920ED,
	CinemachineBlendListCamera_UpdateListOfChildren_m78195EDC229BA08AB69C876F0574217BFAFCEBB5,
	CinemachineBlendListCamera_ValidateInstructions_m39EE271A6D34B62732B978205EBF6681B6657ECC,
	CinemachineBlendListCamera_AdvanceCurrentInstruction_m6AE0D5A3A44F65265B9C461AAA1C577D80527DDF,
	CinemachineBlendListCamera__ctor_m415640A76DED96AA7D39819787BACBC3220728C5,
	CinemachineBrain_get_OutputCamera_m53C6A01A6715756C5A1B80FB403453B3CB28DF84,
	CinemachineBrain_get_SoloCamera_mEAD650442E6D40F860F2668FD0BFEA14495B1F48,
	CinemachineBrain_set_SoloCamera_mCDFED6D67E47D86163AAB3B63A60BB335586FC58,
	CinemachineBrain_GetSoloGUIColor_m1EDE8585C43B473EDAA59D61D558D83F356E45F8,
	CinemachineBrain_get_DefaultWorldUp_mA052F23DFC679E1E0E15B2466ECB3799B656CBA4,
	CinemachineBrain_OnEnable_m444560E00F8FE814A13A5C18076C4ECFE09A9C12,
	CinemachineBrain_OnDisable_mD0002ADB05DE5396E8782571436DC874A098FC1E,
	CinemachineBrain_OnSceneLoaded_mA0F14A6DD8BC5E68243E6879425E49935DBF7900,
	CinemachineBrain_OnSceneUnloaded_m623A93AF5BB2A7967B0DB47A564EBE856CFC8204,
	CinemachineBrain_Start_m851FA02E684EC0C99687B63CAA12F595C5625BF8,
	CinemachineBrain_OnGuiHandler_m8EBDE5B960F8BD057B3ACEBAB75AC10492B798D8,
	CinemachineBrain_AfterPhysics_mAD691C1010D2426873FE5A5463646DDB307B4410,
	CinemachineBrain_LateUpdate_mE2D66C0664D1B0552A07D508C9D08C6167A0F1CD,
	CinemachineBrain_ManualUpdate_m8D7A7301585B6A15E708BEA2E148B1C7F2F7A487,
	CinemachineBrain_GetEffectiveDeltaTime_m27D6E0AC28FA42C74DD804AB942F0D496D55379B,
	CinemachineBrain_UpdateVirtualCameras_mCA6172FE9872138FF4D2B3867EE7AB5BE6D47F89,
	CinemachineBrain_get_ActiveVirtualCamera_m9111F4A789B4CCE529CDDE345F8B690EFEC2C63B,
	CinemachineBrain_DeepCamBFromBlend_m982D9725A5164F9EBF00366A2D49745179A60A46,
	CinemachineBrain_get_IsBlending_mA7662615642DEFD6893E2D6872A78CEA253474B2,
	CinemachineBrain_get_ActiveBlend_m03CD7DFA8C5D537BEB972918C6F4D2BB2FDB7F15,
	CinemachineBrain_GetBrainFrame_m993AEAFCA2ACA814C76097EFF86FE895258861A5,
	CinemachineBrain_SetCameraOverride_m9B06A2796330BE39B59E4DD8E1A40EDCDA969967,
	CinemachineBrain_ReleaseCameraOverride_m83F54FD0A6837603DDCE2090AC3FDD0A0BAE30DF,
	CinemachineBrain_ProcessActiveCamera_m094A1972B629F11EB580679FEFD78076769180FF,
	CinemachineBrain_UpdateFrame0_m8FD42266AA4C2CCE09B842A5BA7362126585858B,
	CinemachineBrain_ComputeCurrentBlend_m296BA72649974D928612AFC717D7446C028F3858,
	CinemachineBrain_IsLive_mF74210376333DD9865A075E561E6E3DDED510FB2,
	CinemachineBrain_get_CurrentCameraState_mBC8B24EFB25ADD71E4E007CDD351ED790FA76243,
	CinemachineBrain_set_CurrentCameraState_m2624A063E4A16EDCC8E1F8FFB93E96F74E98882B,
	CinemachineBrain_TopCameraFromPriorityQueue_m81361016B63A4BF68BA4D85452BAE8647B90E9EF,
	CinemachineBrain_LookupBlend_mEBAE63022CC081EAF26489C7BBEC2492F32B7FDD,
	CinemachineBrain_PushStateToUnityCamera_m7261800DC4671AD0B91DCACFBCD1B1DAD6B144B3,
	CinemachineBrain__ctor_m86D8371115D9B5138648C75C3135396823DD43EE,
	CinemachineBrain__cctor_mECCA7F7ABF8660A2BAB11A39B29D9923D2361DD8,
	BrainEvent__ctor_m648F7E949F40D8EAB7019FAED3ECE88D8CAF05D7,
	VcamActivatedEvent__ctor_mA99C1BA22F69EE75141BFFBB810E1230DCFA15E6,
	BrainFrame_get_Active_mD8AA67B2ACCA6591C9DA9A495850D2145C5B0712,
	BrainFrame__ctor_mA060413F10EA79721B2D2A33D99DC1D3282831A6,
	U3CAfterPhysicsU3Ed__33__ctor_m24D6754D2DAB3DF174EEE38B2A0B6E6E5D5A5DD2,
	U3CAfterPhysicsU3Ed__33_System_IDisposable_Dispose_mDCB6F829946F1B34F28228BC74725898C5EE8FCD,
	U3CAfterPhysicsU3Ed__33_MoveNext_mDA6F02ED5AF41DC0E1B1AD753F8AAE8F06B9B28A,
	U3CAfterPhysicsU3Ed__33_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mBDD4A0F001AD9DD0F2AB2F992A82F77B770FF837,
	U3CAfterPhysicsU3Ed__33_System_Collections_IEnumerator_Reset_mAA45376E2089E38B00E97B3A6B9F00F2A495B435,
	U3CAfterPhysicsU3Ed__33_System_Collections_IEnumerator_get_Current_m266F0F6B25D7EAA07E9A5A65D99178B51EE354EA,
	CinemachineClearShot_get_Description_m7AF5F30369B2273697549B4E458FD3D7FE7AE694,
	CinemachineClearShot_set_LiveChild_m51685341391760EC4E1053AC1555A39A06185B1E,
	CinemachineClearShot_get_LiveChild_m0E247D53C258CE36DBF28944CD0AD8A47344C4A2,
	CinemachineClearShot_get_State_m5596F81F599D82C8FE6A5383E95D3DF4F803EF7A,
	CinemachineClearShot_IsLiveChild_m27778431D3DC199BD4A07283966ABC71F323942E,
	CinemachineClearShot_get_LookAt_mACAC39B62BB18C014CB0EE0829D37854DEEF1547,
	CinemachineClearShot_set_LookAt_mE444F2137C96A179F9A0DCCACC9D5BEC30C075D4,
	CinemachineClearShot_get_Follow_mCBA54E3955A8DEBD46828F16EAE00AA2B8678C56,
	CinemachineClearShot_set_Follow_mA1A33A5BF458CB7FE8CE965EA59F8F5335128BDE,
	CinemachineClearShot_OnTargetObjectWarped_mFA9A79ADB2FA4A94D6FD73CBF32B38DBA4E34F7D,
	CinemachineClearShot_ForceCameraPosition_m64A96229F7CD5AFC4C163184CABDE5ACED9A027B,
	CinemachineClearShot_InternalUpdateCameraState_m0E642E1D33C0F0BB0628E439A78574B381F08B29,
	CinemachineClearShot_OnEnable_m6FD19FC685EFF8D2432861E8B6FBDDA02A954220,
	CinemachineClearShot_OnDisable_mC02AEC329D9BDB5D6ADFF762B38DD7260C6780F5,
	CinemachineClearShot_OnTransformChildrenChanged_mF8891487D72C8C87FDE3AF59FC308492AFD719EA,
	CinemachineClearShot_OnGuiHandler_m62267DB468A7AB10E6834C1EAC49A795349E59FA,
	CinemachineClearShot_get_IsBlending_mA2F2B1313AB3374D1D1287D67992D756C42587DA,
	CinemachineClearShot_get_ChildCameras_m1F32604733AC3601B4843C072342F408CE19C5B6,
	CinemachineClearShot_InvalidateListOfChildren_mB0CD028BA2D3286D654F260940BBC2234A7038EB,
	CinemachineClearShot_ResetRandomization_m1876DCD195CD2865599F23957CBCCF07F9557109,
	CinemachineClearShot_UpdateListOfChildren_m37DF613332B66C99EF46A5D338356B90A1D0894E,
	CinemachineClearShot_ChooseCurrentCamera_m678A067854D8A908119247136EA38448E98C7F22,
	CinemachineClearShot_Randomize_m8B9933410E1461B3C79A0CE6C332868954306FC7,
	CinemachineClearShot_LookupBlend_mEC42F1C07A25A4D873D61AB6F6CB6C26491E4D83,
	CinemachineClearShot_OnTransitionFromCamera_mEA5216EB1E80B4DC87F35CEE0646FAF2216BFA9B,
	CinemachineClearShot_get_TransitioningFrom_m9C6A21D455B4DF835AB81F4FC5B929AF8E6228C8,
	CinemachineClearShot_set_TransitioningFrom_mBB426F06C8C9E05C7DDBCD76C6001071AB80CA3B,
	CinemachineClearShot__ctor_m5E1633DD8F3F1811A0F4CB5335B4098A691C16BA,
	U3CU3Ec__cctor_m9685B944F64D38F8A51929E1DCF7714D96EE5C6E,
	U3CU3Ec__ctor_m02E5C011A18650E911D7DE28902B36407425A1DA,
	U3CU3Ec_U3CRandomizeU3Eb__47_0_m11EDFFF61087041AA23E34C5AE7D01B6976118F9,
	CinemachineCollider_IsTargetObscured_m728B54117D657C72C3A45B15D097376B916AD081,
	CinemachineCollider_CameraWasDisplaced_mE3C7D73AC6F29D59A945EB4B6E1DFF1A407D7069,
	CinemachineCollider_GetCameraDisplacementDistance_m97DED641EC9ECB65AFAE1E0687AF9DF5A7A073BC,
	CinemachineCollider_OnValidate_mDFCD2F62D4D4C8487A1041106507A47134048FF0,
	CinemachineCollider_OnDestroy_m5CCC19D44E691B93F05BA2CFAF07B48D2EFA9091,
	CinemachineCollider_get_DebugPaths_m10FD1111E853455483AAF675CDBB7ACCF6E967EC,
	CinemachineCollider_GetMaxDampTime_m7D8E44771355BC2FD8C428861A42C21A7B90695A,
	CinemachineCollider_PostPipelineStageCallback_m91F23EE95689CCBCF63C89951CE9A4EE726F59CC,
	CinemachineCollider_PreserveLineOfSight_m55F8D760D87EE4365569DF0360F33E960DE3DB46,
	CinemachineCollider_PullCameraInFrontOfNearestObstacle_m831839A6F16DC4AEE8B11341B5752D0E1402BCDE,
	CinemachineCollider_PushCameraBack_mEA413F0258A0E497FF47208E7C38D607A3E95772,
	CinemachineCollider_GetWalkingDirection_mD0BA4C78DA9671058C3E0DF9AC27661882685D1B,
	CinemachineCollider_GetPushBackDistance_m8467D939C839D655437168AE18EBA9469EFE71B8,
	CinemachineCollider_ClampRayToBounds_mDE4466A0D48B3C73C69C92A9BB69ECE3E703FA0E,
	CinemachineCollider_DestroyCollider_m9E697592872A9B4F2C5D5096CBFAA54882CEC800,
	CinemachineCollider_RespectCameraRadius_m06B1B729256E1787E9FAE46241267FA08E299D4A,
	CinemachineCollider_CheckForTargetObstructions_m525473EF0F2669CD7B83EAA3CE790B11B632D63B,
	CinemachineCollider_IsTargetOffscreen_mEBE97ED4E2F75864D24A6E055BE9133E71732E2C,
	CinemachineCollider__ctor_m3543A3A2E03D8A030138D79AAEC58065C03D2994,
	VcamExtraState_AddPointToDebugPath_mFF718D5B8D9DACD1A94BAFB458A028241E0FC95B,
	VcamExtraState_ApplyDistanceSmoothing_mB2490C4B28326713F8FAECEEBC239B46BDBB853C,
	VcamExtraState_UpdateDistanceSmoothing_m75C77A914C361D02C7C0F9B73A874D309EC124B8,
	VcamExtraState_ResetDistanceSmoothing_m9DA2E009ED1BBFD18F811B5A1E0DF1BE9D91342C,
	VcamExtraState__ctor_mAD425FDD74968E2F744178F85B1C9F5FA2FA875F,
	CinemachineConfiner_CameraWasDisplaced_m83D1EF33F9ED6B52144AB0D3218D2126512B408F,
	CinemachineConfiner_GetCameraDisplacementDistance_mAE964ADE185900F3A1963C8F6008C10F6E9E6975,
	CinemachineConfiner_OnValidate_mD463ED5B94F6B858300D99F45438D5F0FBD949DE,
	CinemachineConfiner_ConnectToVcam_m3DF3703EBA5E402116E0B99FA7F7B7FFDB58497C,
	CinemachineConfiner_get_IsValid_m87C7AC9111017572EEACBF7B38926E5A10F81EF5,
	CinemachineConfiner_GetMaxDampTime_m445F5B5483E8A1058DB72F4376C34FA5B66275A7,
	CinemachineConfiner_PostPipelineStageCallback_m042478453BC335A0410635B429516D39992E2BDE,
	CinemachineConfiner_InvalidatePathCache_m1C66E34112C65B4CDACC628AD8D7F8C90F45706B,
	CinemachineConfiner_ValidatePathCache_m249EEFABC4DDAD7D8CBAC54CE0C7F5CF2BF90CBE,
	CinemachineConfiner_ConfinePoint_m7AE2FFDCD682C31954A51D4F0401FCC00642660A,
	CinemachineConfiner_ConfineScreenEdges_m3EF25363525ACDADF5D9A7AFFBD5805A4B9908FA,
	CinemachineConfiner__ctor_m51000A5BAF0EEDF46F862CB2C77BCBDF41035C68,
	VcamExtraState__ctor_m0EE1BF4E53FB8E8DFF70446D1A47286397ED89FD,
	CinemachineConfiner2D_InvalidateCache_mFDB874DEB9EF79A9BD50704538C6BBB3BC8C6DB3,
	CinemachineConfiner2D_ValidateCache_m80AC2A2077A30BAAE5A91097BE37B681410A8B0F,
	CinemachineConfiner2D_PostPipelineStageCallback_mA43AF7C159E632A9839540D8662D18DFCDE73D7A,
	CinemachineConfiner2D_CalculateHalfFrustumHeight_mDDE47FAE3C3F2353008872F77D39FF651AA1A878,
	CinemachineConfiner2D_OnValidate_m6A0CD8665FF1FDB4AF2AE8F74B6CBC4BD2EAA975,
	CinemachineConfiner2D_Reset_mAA5D5DC189C57A96F8858ADB7C67DC9DBAC9286F,
	CinemachineConfiner2D__ctor_mA19C91BD9ED4615AFDC73AFFC750E1A13B89A4A2,
	VcamExtraState__ctor_m4230EE9C068362D2954AC73B33FF8B627D023268,
	ShapeCache_Invalidate_m0AA1A789129A6F496BDB42C9914A48A80D0BB222,
	ShapeCache_ValidateCache_mA040BB9D38360821A0D577FAA9520E12917B126C,
	ShapeCache_IsValid_mD14BF34734A81849A719899A4F29ED241C21E25B,
	ShapeCache_CalculateDeltaTransformationMatrix_m11C29D7572FAF3F20A15F7144F6D46E8A909E114,
	CinemachineDollyCart_FixedUpdate_m4D0344645368A13DE5E1902FD2409FD75EF64622,
	CinemachineDollyCart_Update_m7245871A1EF878D2225D3278616830FFDEA94632,
	CinemachineDollyCart_LateUpdate_m31652825AA7DF3A37F1FF45F7987A41FF15EB629,
	CinemachineDollyCart_SetCartPosition_mF463212396484570037D81562ED14A21ECFD746F,
	CinemachineDollyCart__ctor_m10FE44DB9AC13A98B146DF4DAAE74E0B642E5068,
	CinemachineExternalCamera_get_State_mC19729B5B332F8A68ACFF3A3AA3594610B52D7FE,
	CinemachineExternalCamera_get_LookAt_m4BBF19283ED8933F78E0A0947D31E21952029ED4,
	CinemachineExternalCamera_set_LookAt_m6B06EE0A2DF54EBCACFB4AF2FDFA7CE1FBA6956D,
	CinemachineExternalCamera_get_Follow_m8FD9C12520C69C131111698EA1C532595B2F795A,
	CinemachineExternalCamera_set_Follow_mE72DB58A3B9A095A004E9A11F5A13E07DB40DB8E,
	CinemachineExternalCamera_InternalUpdateCameraState_m51FFCDE49F3209EF2A25426838FE54BEA17736C9,
	CinemachineExternalCamera__ctor_m3F3ABDD19589BAA8C55855E465E86F94B7C21DA8,
	CinemachineFollowZoom_OnValidate_mC3D5E5866F335052F48BD2B6AA47859E9AE291DB,
	CinemachineFollowZoom_GetMaxDampTime_m7FCFDC2095BEE662F4AC60386D268C2224984F66,
	CinemachineFollowZoom_PostPipelineStageCallback_m584E4DE4F681FE16D996E5D6FBE4A17F2FF5B4B3,
	CinemachineFollowZoom__ctor_mB268F9C261AF80E1B1B8CBD60F439C7CBA594E43,
	VcamExtraState__ctor_m765B777C8201B5A5D21FB547AA0215538E7CD976,
	CinemachineFreeLook_OnValidate_mE135CB8F257CA150B766E7490EDB6617686C1FC8,
	CinemachineFreeLook_GetRig_mD0E1903ADCEA69937E23407FC0837F5EED5F7D2B,
	CinemachineFreeLook_get_RigNames_m28ACE9396AC7E90228CF3E5AFB579391AEC91B26,
	CinemachineFreeLook_OnEnable_mF37DBE66B28EFDB12E5EB7E2FECDE8D387E4EA64,
	CinemachineFreeLook_UpdateInputAxisProvider_mD39FCA17EFAEAF3B386FAB2D171614DBE6878BE4,
	CinemachineFreeLook_OnDestroy_mE5A0B7181DD0B540EA62AA950FFB709B6FE37881,
	CinemachineFreeLook_OnTransformChildrenChanged_m736136F5AEFE8FCEE9AE92AC05BC9F99FBD77021,
	CinemachineFreeLook_Reset_mD2D2A20865B0566F643B934832120872678945C4,
	CinemachineFreeLook_get_PreviousStateIsValid_m5401DE3AB054991B6A5FE6234347ECE270585DE1,
	CinemachineFreeLook_set_PreviousStateIsValid_m55D8DBBB19BE26486ED23321D4F636209A4EADD3,
	CinemachineFreeLook_get_State_mC1F5503F677EFDBE8F7C13AB4861A85289B11851,
	CinemachineFreeLook_get_LookAt_mDC4E1C325D8ABCE90EA23927B556A1CEDCE2E466,
	CinemachineFreeLook_set_LookAt_m6469D5D82E61E12547F31B056318A02901320ED9,
	CinemachineFreeLook_get_Follow_mAE291B3D732A26FB2F8303A21E5B02C7B0F71AD5,
	CinemachineFreeLook_set_Follow_m60B250844E32FA860F71485B30FC96E6DFC39C12,
	CinemachineFreeLook_IsLiveChild_mE77CF2865D9484DBC51179C160279DE1A2AB75A0,
	CinemachineFreeLook_OnTargetObjectWarped_m9538B8833BA2618E0DFFB92D2D5E21EBE2F6F378,
	CinemachineFreeLook_ForceCameraPosition_m61E084EAFA63BD5901D9471DBECA196063CD2BCF,
	CinemachineFreeLook_InternalUpdateCameraState_m4BEF8106D7C7379527BED810D348A1AEE7B456E4,
	CinemachineFreeLook_OnTransitionFromCamera_m7A5C9529C4641C09776A3F5B87B9A8D698C3DE6D,
	CinemachineFreeLook_GetYAxisClosestValue_m0305399E0E68EE0A9FA2F56EFAE695517C79F584,
	CinemachineFreeLook_InvalidateRigCache_m55DF47CBD6057175CBC0513574054639D51D6C7E,
	CinemachineFreeLook_DestroyRigs_m46892877143B854CDA899600B23F789F092FFA79,
	CinemachineFreeLook_CreateRigs_m1B4A9DC51DCE61E3B384B49E75E94FEA50B865E6,
	CinemachineFreeLook_UpdateRigCache_m1D9A5655874FB2B2BFF82C8B4CAE75B804A9D458,
	CinemachineFreeLook_LocateExistingRigs_mFA72C01A434055FF70E58504CBE649C3A19A935E,
	CinemachineFreeLook_get_CachedXAxisHeading_m7B1719BF031EED297D56A9DB32C2F63C018CB636,
	CinemachineFreeLook_set_CachedXAxisHeading_m11AEDBEB4865CFECA9235C8D3320B45DE0EC56C1,
	CinemachineFreeLook_UpdateXAxisHeading_mC7FB1633258C9ADCBE6D379B3865D1DFCB696088,
	CinemachineFreeLook_PushSettingsToRigs_mEEA5AE1B6B7E64CD3E52DAD1F020AF52C2D5C030,
	CinemachineFreeLook_GetYAxisValue_m82E8DA8F7257DEA0BFBFCC41FDB2E214907A9C88,
	CinemachineFreeLook_CalculateNewState_mDEC0D03EDD0F2C9521E25A5E6FCFBE66049E3869,
	CinemachineFreeLook_GetLocalPositionForCameraFromInput_m30BECF828556595138D0AE9908D6009E5BB0E7EE,
	CinemachineFreeLook_UpdateCachedSpline_m1275143847991676F4E0F292FC8CFCD0CE89E382,
	CinemachineFreeLook__ctor_m04F403D8675C975D63009E36A843B28BBD0DDE3E,
	Orbit__ctor_mBDC642CE7F3E574E43895420FD0343C3199FC85A,
	CreateRigDelegate__ctor_m4DD0C7DBDBDA591D52EA8F0328BAB450BFCF51C2,
	CreateRigDelegate_Invoke_mAD1425DD908EFF6A0D37E425A6A2503EB0C0D6F9,
	CreateRigDelegate_BeginInvoke_m3026592E9652091C21A95142D9C9840AAE61EBAD,
	CreateRigDelegate_EndInvoke_mDDDCBA482E40537F256E8B0F686EA019C7FC42F7,
	DestroyRigDelegate__ctor_m6B51E8D805DD7A663BE724FC16D490F5D0D05D69,
	DestroyRigDelegate_Invoke_mE9C9FD19BE4FD0204687FA43F0C771C3C77E11C6,
	DestroyRigDelegate_BeginInvoke_mC12BBE33DEEA306A7AE1FFD1E961069DCC252BE5,
	DestroyRigDelegate_EndInvoke_mE037D325234815525A86DF33050DE927EFCD8F22,
	CinemachineMixingCamera_GetWeight_mC56767C284E7B6C5441789F5D7022B9EC93342E6,
	CinemachineMixingCamera_SetWeight_mD8CB5271CD81FB934D08D156797DF143BD58DA7A,
	CinemachineMixingCamera_GetWeight_mD30103E9B0B8B54EEAB6A07179BE0688B8A18C6B,
	CinemachineMixingCamera_SetWeight_mB1C14E27249BB10421D396CCFEF41D8E18A7CDB3,
	CinemachineMixingCamera_set_LiveChild_m2CAA747551619F08D9AF611F73E8740655A64296,
	CinemachineMixingCamera_get_LiveChild_m3D4BAA0AB4486CFA6DEF9EAC84CAAD32FA78EA95,
	CinemachineMixingCamera_get_State_m58D60DAFE877B686344651AF345BA29EB84CA8CC,
	CinemachineMixingCamera_get_LookAt_m455A20326F89344D9D2B005BEDED109EB439088B,
	CinemachineMixingCamera_set_LookAt_m93815AF154ABAC9FF37C7EE237BDFDABFC1CAFB3,
	CinemachineMixingCamera_get_Follow_m8CCF58027181B96B84CB8EFD681D072E585FBA8E,
	CinemachineMixingCamera_set_Follow_m1ECE7574D20C273C49204FE5B775EC85B2605210,
	CinemachineMixingCamera_OnTargetObjectWarped_mADD9E1BD4142606182E1E3BC9F9D204A981ED905,
	CinemachineMixingCamera_ForceCameraPosition_mF1729BA8B700A249B80DE3EF66451DD422AEFD98,
	CinemachineMixingCamera_OnEnable_mB327FAC23649E787522822C97B2BAAA8B0B01011,
	CinemachineMixingCamera_OnTransformChildrenChanged_m78AE7E56D39CB09C2A55DB891DCE4C0D405B3A3B,
	CinemachineMixingCamera_OnValidate_m66D4D52438E5171467EDA22E164B64BA590AA6E5,
	CinemachineMixingCamera_IsLiveChild_m4E66C3C7A8A5F20C26E4E8519D3590E86F328613,
	CinemachineMixingCamera_get_ChildCameras_m17AAB894A5692CADB6B886AE1823D0007895FB53,
	CinemachineMixingCamera_InvalidateListOfChildren_m18EC553FC321BD26E1FDEE748A9D6398EC7F6B3D,
	CinemachineMixingCamera_ValidateListOfChildren_m0592C962C4CF7089FE842F109D0CD3476410B5CB,
	CinemachineMixingCamera_OnTransitionFromCamera_mA2504937FEC4E030494B431DB73A8FB2801E40CC,
	CinemachineMixingCamera_InternalUpdateCameraState_m95CC38FD924BF718EF4DC7E94B6259E348129112,
	CinemachineMixingCamera__ctor_m5EDF2B338827BF9600E05C360499BB6C8C06E04F,
	CinemachinePath_get_MinPos_m44196276E27917CFAA83FCB6805385F0F49B68E6,
	CinemachinePath_get_MaxPos_m19CBE9ADEA5F1C8153554117E936EE73430A1B7A,
	CinemachinePath_get_Looped_mDC5688C64BEAD83BB772379AF6A94B3D69724F5E,
	CinemachinePath_Reset_mDBB3432FB87DC834F93DC9FFE56204F059186030,
	CinemachinePath_get_DistanceCacheSampleStepsPerSegment_m040784C32B8D4D2D119AB9C189B7761FEAE717AD,
	CinemachinePath_GetBoundingIndices_m907FB06C7E158858C9828D4228AC5317A500B107,
	CinemachinePath_EvaluatePosition_m748123187AAE027319421C5A040783252BA333EB,
	CinemachinePath_EvaluateTangent_m58EFD2AF91AACB4716EF1142DA729FE99A3C4680,
	CinemachinePath_EvaluateOrientation_mC2FC02F92747630BBBC1CAF8E388A50D9701C610,
	CinemachinePath_OnValidate_mA799B5C87BE67DD6CD5A94ED498AB1313E7247A5,
	CinemachinePath__ctor_m29E35B45E4AF67EC3D12CED0F10D7C9014115765,
	CinemachinePipeline__ctor_mA25F961124A6357A5F945EED40D0FBD495840695,
	CinemachinePixelPerfect_PostPipelineStageCallback_mD4F59744645E787D73375AE345486512EF2C284A,
	CinemachinePixelPerfect__ctor_m3AFA2D3FFAB18B940EE356FD8FE96724CBCFD987,
	CinemachineSmoothPath_get_MinPos_m6E0E2A097F67A6B10D6CAC35922DA832B7192598,
	CinemachineSmoothPath_get_MaxPos_m47FAC15FD184422858C94D12FB59C0DF68196B9A,
	CinemachineSmoothPath_get_Looped_m581212992BAC29DDBA308B93A7E078EA7757BEFB,
	CinemachineSmoothPath_get_DistanceCacheSampleStepsPerSegment_m1B87916ED182DE5DF0033DFD586A9205E087C8EA,
	CinemachineSmoothPath_OnValidate_m0D0A65B796AA7D6014FF0FC2B2171EA5DB0DD422,
	CinemachineSmoothPath_Reset_m667726E5707A48BA067A7A7133857087FDC4058E,
	CinemachineSmoothPath_InvalidateDistanceCache_mC7B4228D400267E0F50D1F8E65696DFE40D28F55,
	CinemachineSmoothPath_UpdateControlPoints_m2F8ADDDCC7E141ED441095D92EA8723A6C2380D6,
	CinemachineSmoothPath_GetBoundingIndices_mE692833D63163F7B69AD841A2EA29D7F4A9BE752,
	CinemachineSmoothPath_EvaluatePosition_mCCAABE1DD14E499B981C439C9F30C68F21A66100,
	CinemachineSmoothPath_EvaluateTangent_m0D0D59143BB5132ABD5433E90817F44B302C6B26,
	CinemachineSmoothPath_EvaluateOrientation_mEC5A8EA90524DE4125735E85D9FCC5080D8B065B,
	CinemachineSmoothPath_RollAroundForward_m6D915BAFDE9ECFAC37C521C4F662D68134417065,
	CinemachineSmoothPath__ctor_m45C209574B2FCAE3239F335EF383D4D513DB7623,
	Waypoint_get_AsVector4_m9CB420052E5FB5EA1681133222C5EB982BEA6BAC,
	Waypoint_FromVector4_m1F859E37CBC871BC98DC89550A1C6B264E46FB2A,
	CinemachineStateDrivenCamera_get_Description_m721AB0951987E2034EA458440177C8EF9528CAD5,
	CinemachineStateDrivenCamera_set_LiveChild_m58CFBD5BCD7718A20DB92DFCB57407A51DB967AE,
	CinemachineStateDrivenCamera_get_LiveChild_m4FE60C58C46FDB216A5B65BE67166D2715711A3A,
	CinemachineStateDrivenCamera_IsLiveChild_mDB2DC4068402D3D55B40D792828EBB8C32A083E3,
	CinemachineStateDrivenCamera_get_State_m5A79A831DF33719426266F8DC14CE7BC74DAD1A7,
	CinemachineStateDrivenCamera_get_LookAt_m8DC447924D0D74AFE9F9EE6528A4A71640720560,
	CinemachineStateDrivenCamera_set_LookAt_m58802064EE2F513FCB7FFCA3FF421BA36CA340ED,
	CinemachineStateDrivenCamera_get_Follow_m7B3B9088B452F0AC4803FEA6C0B21BE0359E6517,
	CinemachineStateDrivenCamera_set_Follow_mDFD75630E23CC129D727B564643EE86C58314284,
	CinemachineStateDrivenCamera_OnTargetObjectWarped_mF70391759212BE63CEB7FB51B0A45B93157A14D8,
	CinemachineStateDrivenCamera_ForceCameraPosition_m29A24C9E4E02555029FD1FC6912BB3D54A35B156,
	CinemachineStateDrivenCamera_OnTransitionFromCamera_mEBE4A9F7099581DD5988F7D06E19056C906DEA19,
	CinemachineStateDrivenCamera_get_TransitioningFrom_m6D611FD16354DACC78A99F2B8E3CC13327CCF104,
	CinemachineStateDrivenCamera_set_TransitioningFrom_mC376F532563E04695BD810AFB8FF63589AD82B5C,
	CinemachineStateDrivenCamera_InternalUpdateCameraState_m15DA964B37A1A8B67ACC8D3429089D1948F3FD92,
	CinemachineStateDrivenCamera_OnEnable_m73592A142BE908F77B0AA271DAB6D3931F0985AB,
	CinemachineStateDrivenCamera_OnDisable_m0A9782361F2D03D44648E382D7CF8C43BB9C30A0,
	CinemachineStateDrivenCamera_OnTransformChildrenChanged_mC0E38B870F9476DB6863BCB16D18C36B9BBFFECD,
	CinemachineStateDrivenCamera_OnGuiHandler_mDB24B0B122B8F3CF847139FDC147B7F3CBFE3F05,
	CinemachineStateDrivenCamera_get_ChildCameras_m4C9CBF7126E384CDBBB2AAFE86108F43A2DF6E52,
	CinemachineStateDrivenCamera_get_IsBlending_mD0DC02C494368EF1946180D261E072CC70A859C5,
	CinemachineStateDrivenCamera_CreateFakeHash_m1B5D689454467E54101D56E7FC1096E4E709B80F,
	CinemachineStateDrivenCamera_LookupFakeHash_m06759C84A0584A1F9F290C5E58DFB0FF0AE4BD5B,
	CinemachineStateDrivenCamera_InvalidateListOfChildren_m09761689924E32C52613DFE05E80CD9D7FC3AA0E,
	CinemachineStateDrivenCamera_UpdateListOfChildren_mBA707781DC4090145A34A24903B7F08FD0875AF8,
	CinemachineStateDrivenCamera_ValidateInstructions_m3283C4B0462AC49AAFDBF8020BFCD8E296E7542B,
	CinemachineStateDrivenCamera_ChooseCurrentCamera_m3D70AE6707397EEE221D01F8B25119B2BC7A370F,
	CinemachineStateDrivenCamera_GetClipHash_mAD02DF3C8A12333C4D93FF1DA54D30B4DF2178CA,
	CinemachineStateDrivenCamera_LookupBlend_mD0B7CD5CF181EDDABF0EFE90C829DC5DF5262C41,
	CinemachineStateDrivenCamera__ctor_mB23005EB5EC0817BDFE10B9A1F0865DA83D3CBFE,
	ParentHash__ctor_mFD2F0C557399C8A6C3798E3CDC0EB58B5E82A094,
	CinemachineStoryboard_PostPipelineStageCallback_mCABE6FCDDBC249650661E7F9E4879D456950332B,
	CinemachineStoryboard_ConnectToVcam_m8C550061C8C0F5CF8AA3D57DFCDC41C103FDF66D,
	CinemachineStoryboard_get_CanvasName_m7B8D386FB493150485E1D44C62A7096F2F657C5F,
	CinemachineStoryboard_CameraUpdatedCallback_m234F18B313AD4C89E918AC2F4239FFE79E2C47CD,
	CinemachineStoryboard_LocateMyCanvas_mCCD4AE8516711F4F7947F1403DEC3BD31879C6B6,
	CinemachineStoryboard_CreateCanvas_m8646630AFE1182FFF350AE7277070C881913905E,
	CinemachineStoryboard_DestroyCanvas_mDAE4469DDC233DADBC9940C3C50BE2F0AE15E7A7,
	CinemachineStoryboard_PlaceImage_m2B8471FE0B239D371527BB2670785AB6B86108AF,
	CinemachineStoryboard_StaticBlendingHandler_mB063E4C83DB301BC5F947A7E6E7830C40EE663B1,
	CinemachineStoryboard_InitializeModule_m6F699FC72AEB7184BE2AEFF42BB6FC6794D44EB7,
	CinemachineStoryboard__ctor_m5B6932E31A0425FB1C6EFDE4CC048CEC1F0B89ED,
	CanvasInfo__ctor_mD8E59D1746FD1DC9B497D9668DE2FACB016738DE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	CinemachineTargetGroup_get_Transform_mADEBFE4BA9AF2FDC94C7302B1872D93B40F31586,
	CinemachineTargetGroup_get_BoundingBox_mF6801A2838567BE9DE910D45D9BF05A760646933,
	CinemachineTargetGroup_set_BoundingBox_m4E6C1E1267D257AEDBA80318354B60A655D1097C,
	CinemachineTargetGroup_get_Sphere_m3548B36218DC82389D27BAF6410BD34C1BBE75E8,
	CinemachineTargetGroup_get_IsEmpty_mA2CEE80C159101E17390EAE7A9F1E7F60ECA227C,
	CinemachineTargetGroup_AddMember_mDE00B3D9AB65CBAA2649A911C546D0D00170D67C,
	CinemachineTargetGroup_RemoveMember_mBAB8FD54B83FC8749A6709F8573FFB9B78A17E08,
	CinemachineTargetGroup_FindMember_mD60C186B1844C2FF84E3B10D0F5952A89CCD614D,
	CinemachineTargetGroup_GetWeightedBoundsForMember_m879BB7436547F7658E13FE9D4B1E9831BF6983CE,
	CinemachineTargetGroup_GetViewSpaceBoundingBox_m419CDD33E962D72D728E5351BE524B4887284BA0,
	CinemachineTargetGroup_WeightedMemberBounds_mCBA0F61AABF001E2088F03BC99CF3200FC7C7CCA,
	CinemachineTargetGroup_DoUpdate_m298B1536B6884019681B7DA4E50000ECE3B63D8E,
	CinemachineTargetGroup_CalculateBoundingSphere_m0051F81C12A7F464D8E38E032A461C13BA483E36,
	CinemachineTargetGroup_CalculateAveragePosition_mF78C3AF8AAD414B79ECA6B7995BD8CEF3B51F88C,
	CinemachineTargetGroup_CalculateAverageOrientation_m4112A1C8E182CA4C8C5642F908A59FD21732E7F8,
	CinemachineTargetGroup_CalculateBoundingBox_m8FC29A766DAA5EA8D9D770A70C3BA3F33BCF9C45,
	CinemachineTargetGroup_OnValidate_m00BCA97645EBF6D84D566D10ADADE897E573D300,
	CinemachineTargetGroup_FixedUpdate_m51E54F0F8EB6C01A45EA6ADC82929B9D63A7D1C6,
	CinemachineTargetGroup_Update_m6CF5BB9923882A14E2EB426056BE160EDCB781D9,
	CinemachineTargetGroup_LateUpdate_m320382F4ADE5662C7F06D81ED7505FF0FDAE41B5,
	CinemachineTargetGroup_GetViewSpaceAngularBounds_mBCCF672D0664D37BA01D432B888F37A7665361BD,
	CinemachineTargetGroup__ctor_m59C958FBF749CEEA369DDF27BAA3E9216CA99399,
	CinemachineVirtualCamera_get_State_mF61B23491D389A88595DD95EB27E44EE09F3D40C,
	CinemachineVirtualCamera_get_LookAt_m7FA8E1F163BBB41806692C120B1A3531872E9173,
	CinemachineVirtualCamera_set_LookAt_m16EAA4A1653EAE5AC3490E2B2653E9C15856B199,
	CinemachineVirtualCamera_get_Follow_m2D4644BF8364F8EC6366E86D0E628AF7FBA8884D,
	CinemachineVirtualCamera_set_Follow_mBC7DE30C2BF4E62258116D9AA8F300A1468D0410,
	CinemachineVirtualCamera_GetMaxDampTime_m401AE8ABB66092E3E93BCADF35D846D5E44DAD16,
	CinemachineVirtualCamera_InternalUpdateCameraState_m0A8D802327119F624F26C694E6341B34D38B1057,
	CinemachineVirtualCamera_OnEnable_m05A075F14A81B8DF7362BADC9B3F5B195F912CE1,
	CinemachineVirtualCamera_OnDestroy_m69759804B4988BF64EF56B3F32DFC63BC4C5D533,
	CinemachineVirtualCamera_OnValidate_m6B4FF3C2AD8B3992E2E6759D1D72388EF013F4C5,
	CinemachineVirtualCamera_OnTransformChildrenChanged_mF04206FB649F578387FF1B5E2690862861730775,
	CinemachineVirtualCamera_Reset_mB1C37515D1DF02DDC6EBECAC6F5E8EC2DAAA0990,
	CinemachineVirtualCamera_DestroyPipeline_mBF0ACCB0E14994F96A0DA4F766E9DC4CD65298E4,
	CinemachineVirtualCamera_CreatePipeline_mFE25AD716DEA1E9468F5963DAA0252E300D1EA8D,
	CinemachineVirtualCamera_InvalidateComponentPipeline_m74BC28C9508EA3673CD8DA028883B069A94F652C,
	CinemachineVirtualCamera_GetComponentOwner_m8901A99D0106ADD7B9DF483D5A899E07C6B55DF4,
	CinemachineVirtualCamera_GetComponentPipeline_mD2C278143444B6D6CC40EE5DC5AA5B7259C67296,
	CinemachineVirtualCamera_GetCinemachineComponent_m9FA6F90B033903CAFFD1149E0A58A06313FDC7F3,
	NULL,
	NULL,
	NULL,
	CinemachineVirtualCamera_get_UserIsDragging_mCC9BCC63272BBC50DD6C1C930A1E162F2E7FB118,
	CinemachineVirtualCamera_set_UserIsDragging_mA66BB2778AD5A2D17230207CC6FE1A5055764E51,
	CinemachineVirtualCamera_UpdateComponentPipeline_m40B9D8AFC178A45C7FEE7A5E151D9232E05201AA,
	CinemachineVirtualCamera_SetFlagsForHiddenChild_m0B6CC9E477DF3FDC4A4C85B397DBC02987B8FFFF,
	CinemachineVirtualCamera_CalculateNewState_mDC69D1DC2332963E4EE05DC6B3278483DDB7E271,
	CinemachineVirtualCamera_OnTargetObjectWarped_m97A56F2EF2CAB7C830FE81D8DAF69D70302F3087,
	CinemachineVirtualCamera_ForceCameraPosition_mA54274F343A60C2D8B5D0918B113F8D52A9C096F,
	CinemachineVirtualCamera_SetStateRawPosition_mC33AAABD638BAF99907C51E241D339706F2A6591,
	CinemachineVirtualCamera_OnTransitionFromCamera_m621F8E4CE89A6CD4C718BAE9127944BBBE8A8C39,
	CinemachineVirtualCamera__ctor_mE54D1FBAC8B30DADC6D1A1FF4E7526BEF47AA9D3,
	CreatePipelineDelegate__ctor_mF51B89DEB4EAE7A714B49CA9BF703B8541D419A0,
	CreatePipelineDelegate_Invoke_mF25FE1D09EC7FB09C0E0EDF766B2A19BF31080E5,
	CreatePipelineDelegate_BeginInvoke_m354E9436E905807B4CCD0ACB6528D067E014E638,
	CreatePipelineDelegate_EndInvoke_m038BA53E61623D2190CBCCD6649F230C29CE89F0,
	DestroyPipelineDelegate__ctor_m3D90BC04CC0ADE49A4EE6503D20E7AB776F7A6AA,
	DestroyPipelineDelegate_Invoke_m900F828AF1A5259B1D8606DB45BD14D4CB3274E1,
	DestroyPipelineDelegate_BeginInvoke_m5E9E8B1CCB62A8EA334567CE88741B5356DE062B,
	DestroyPipelineDelegate_EndInvoke_mD018624F272E6D61432DF250DFCDAD7DC2B53BBB,
	U3CU3Ec__cctor_m575A5E831C9D536CC3AF82E75EBEE29E76D43C89,
	U3CU3Ec__ctor_mFB7EABDE6BB8BDE667A9786AC0176017ADEC9AF3,
	U3CU3Ec_U3CUpdateComponentPipelineU3Eb__41_0_mCE45F92D28AB75075C2C97D20DBDAF56CB6D1FA3,
	Cinemachine3rdPersonFollow_OnValidate_mD52752FC1E0022C921AE0857A427EA108096BA83,
	Cinemachine3rdPersonFollow_Reset_m7B9D8F5575FCA0073A412D0147A5949A72D4D39B,
	Cinemachine3rdPersonFollow_OnDestroy_mEADA974793E9164F5B5214D7B61648B8425660FC,
	Cinemachine3rdPersonFollow_get_IsValid_mA7AB0949602C57690E5DA8A590D80112BAB000DA,
	Cinemachine3rdPersonFollow_get_Stage_m1859D4E263C07EACAD8C3C899D327FC85761FFC2,
	Cinemachine3rdPersonFollow_GetMaxDampTime_m98EDF505AFFC8235F306E91EB8C2B1A867A4B641,
	Cinemachine3rdPersonFollow_MutateCameraState_m8EF4ADD2CE87316458D9B4D365FF587EDEE26C4F,
	Cinemachine3rdPersonFollow_OnTargetObjectWarped_m81363B414B8D9AD371FB074CC6C5AC08D7E126AD,
	Cinemachine3rdPersonFollow_PositionCamera_mD6357591900C0D7F3740BCE6FB061F1287630B21,
	Cinemachine3rdPersonFollow_GetRigPositions_m0B350EE139BBE08CEC35AC25DE11BB0D76B9F8E5,
	Cinemachine3rdPersonFollow_GetHeading_m7D65BE2D2EE002F8B65C41D90FAB4FFC89DFAB0E,
	Cinemachine3rdPersonFollow_GetRawRigPositions_m74FD948BB60F544B2883CB985B5CAEB2A7E830B1,
	Cinemachine3rdPersonFollow_ResolveCollisions_m135E87083BF4188402D3AF09224FE1C572BA21C7,
	Cinemachine3rdPersonFollow__ctor_m9FC063AEC945BFF7CB0D77584F0B4A09546BC805,
	CinemachineBasicMultiChannelPerlin_get_IsValid_m89FD92464853D4D80540492E7A94B293D637536E,
	CinemachineBasicMultiChannelPerlin_get_Stage_mFBFFEC86F9A8F773FA9028D684D39194F8DF042D,
	CinemachineBasicMultiChannelPerlin_MutateCameraState_m71D2179E138E53253A53FC2033BBF5DB002CB888,
	CinemachineBasicMultiChannelPerlin_ReSeed_m55B7DB6DDB8B7864790E509C07A73E263072A2C9,
	CinemachineBasicMultiChannelPerlin_Initialize_mBE33134720655F241B32247831C18F3F4AC7E7E5,
	CinemachineBasicMultiChannelPerlin__ctor_m03392D8E786B297606FC3029C2468621D0BD267A,
	CinemachineComposer_get_IsValid_mDD8A6301558F8579A65C82A84A073EF6CC9F7275,
	CinemachineComposer_get_Stage_m20189F84AF9911702526B12CB5B27411538D4663,
	CinemachineComposer_get_TrackedPoint_mBD61C246B60BC598EF2F407F11BF2162139F54B1,
	CinemachineComposer_set_TrackedPoint_m15F609367B526B54845CB4A22D1874E01B84EDFD,
	CinemachineComposer_GetLookAtPointAndSetTrackedPoint_m6191ABF0FD235956D9416A5B96C70504548D7CD0,
	CinemachineComposer_OnTargetObjectWarped_m3E15015DF195EEA065F733FC3A201F22FBBBA7C6,
	CinemachineComposer_ForceCameraPosition_m5B8C9B0D268DEE13C478EAA9F7B7A1DBB3411B90,
	CinemachineComposer_GetMaxDampTime_mF9651558C16FD35EF56B69268E44F114EB21646A,
	CinemachineComposer_PrePipelineMutateCameraState_mBEE9891FE6C2A3EA29A82BDD152C737774D0B462,
	CinemachineComposer_MutateCameraState_m500BDD47385EEE6373A5B5919D4B7B06CC798D57,
	CinemachineComposer_get_SoftGuideRect_m2B2596665A05FF432BE719AE225A570F3C83DF8C,
	CinemachineComposer_set_SoftGuideRect_mC46E102F64D6B1A70F528E2226C0935E485C183D,
	CinemachineComposer_get_HardGuideRect_m552C95A5B89097FD385E6DED3C04B53B2556A2EE,
	CinemachineComposer_set_HardGuideRect_mAB65433485E384647C3B7D5BA9BE55A841E33AB9,
	CinemachineComposer_RotateToScreenBounds_m62769940088AAC4509FEB682F5902D582B1AE6C1,
	CinemachineComposer_ClampVerticalBounds_mAEA1A39D3A98ACAA5AC36B7E3B11376E99E2E68E,
	CinemachineComposer__ctor_mA02E72656795D0813435386C46CEEB144AB29820,
	FovCache_UpdateCache_m2EFDABF6DAFD0ACF434A8A83F5CAB0AA4B4F3519,
	FovCache_ScreenToFOV_m813E0A11A9BEBC417751E33DA5E18A5A0DADFF2B,
	CinemachineFramingTransposer_get_SoftGuideRect_mEAA618B22D45A8C57B8A5AE984660585B0EE2D87,
	CinemachineFramingTransposer_set_SoftGuideRect_mC3076D642DBCDBC1AC725A4F1E1E090F8F1AC9EF,
	CinemachineFramingTransposer_get_HardGuideRect_mC861BBCE9D49993E237ADA9BBAC17665264A87FA,
	CinemachineFramingTransposer_set_HardGuideRect_m1138240B8F7657519AC0571ECE2E6EFB89CC634E,
	CinemachineFramingTransposer_OnValidate_mC01E2DF60BA5B6B8D678E429D2FD2C1BE20EDA79,
	CinemachineFramingTransposer_get_IsValid_mA6BEC5FF4B2BCA542CACB93FC8817DC0E222CA8B,
	CinemachineFramingTransposer_get_Stage_m46D483051C135C5A2FAA11127927B477E4C3A4B3,
	CinemachineFramingTransposer_get_BodyAppliesAfterAim_mDE58AC6238D9FFF902F3A490BE5ABEF7CCC350F0,
	CinemachineFramingTransposer_get_TrackedPoint_m7AD13AA3ED1185BE57C57925A65A457052F646B7,
	CinemachineFramingTransposer_set_TrackedPoint_m0F66F2FD792A1BC7873FAF52A9975CF2CB30DD82,
	CinemachineFramingTransposer_OnTargetObjectWarped_m363404C45AF56465366357A3C1C6CE455BDD8045,
	CinemachineFramingTransposer_ForceCameraPosition_m359218276D2C475F79427C2BBA9D880F0EF847B0,
	CinemachineFramingTransposer_GetMaxDampTime_m972BD3E7124A8630DC0C905993BBDE6D1AC9A275,
	CinemachineFramingTransposer_OnTransitionFromCamera_mB359F165B80CA2A10C19EA3AF33A9259F0A461BE,
	CinemachineFramingTransposer_get_InheritingPosition_m6FD62CC6C818D58C1BDAD0CFDB0DB17490098FAC,
	CinemachineFramingTransposer_set_InheritingPosition_mE8AC7F16BC034AC01F63BF8871A2380BA533DFEF,
	CinemachineFramingTransposer_ScreenToOrtho_mB36BB70462CD2EE36203D5AD3E4CA83D6CDDB23C,
	CinemachineFramingTransposer_OrthoOffsetToScreenBounds_m537A7A773E2161BCDBA155497EE09CE363319A92,
	CinemachineFramingTransposer_get_LastBounds_mA41F708F5427B0DCABFAD74902AD2FA131B9315A,
	CinemachineFramingTransposer_set_LastBounds_mE7C62D2CDC58E8491783977BB73EAB7C1286B76A,
	CinemachineFramingTransposer_get_LastBoundsMatrix_mE543BEE3801C0D544E132F28F45F0593AABF0BD4,
	CinemachineFramingTransposer_set_LastBoundsMatrix_m82659FE5FB87F1959EAF0BB4F3FC4A53A4FCADDD,
	CinemachineFramingTransposer_MutateCameraState_m738B55893FF0A80A26234C5CBABDF4441EA13111,
	CinemachineFramingTransposer_GetTargetHeight_mC4D0F3C7F1916B41E47FCA12F06B481A83AAF545,
	CinemachineFramingTransposer_ComputeGroupBounds_m266F186335242EE480FA0DA8D2477B9672A9441F,
	CinemachineFramingTransposer_GetScreenSpaceGroupBoundingBox_mF4E5D1B62BA2FA5EB6A3D83A77E0B3E6F2580148,
	CinemachineFramingTransposer__ctor_m43A25F96041552E3943E1A17419C76CD73DD5067,
	CinemachineGroupComposer_OnValidate_m056733D87C52B7481CB62EAC67A97465E94A344D,
	CinemachineGroupComposer_get_LastBounds_mBDD21C72B4902994C351AE2BE99CDE33790374ED,
	CinemachineGroupComposer_set_LastBounds_m65665450515CF77E6E04C5242803C9E2ED4950A6,
	CinemachineGroupComposer_get_LastBoundsMatrix_mAD7553857814F97F5B338B1090953E68487F26F8,
	CinemachineGroupComposer_set_LastBoundsMatrix_m17F3517E0D09514D674A5D2B589E02BA75916BB5,
	CinemachineGroupComposer_GetMaxDampTime_m7EFF6674345C28E480109CE58B36C3553E71BA77,
	CinemachineGroupComposer_MutateCameraState_m3F09674F5DB0D0D30F4E700F40A59EEA4827D961,
	CinemachineGroupComposer_GetTargetHeight_m765D054C90533C449002E5C506D18A980D66E48A,
	CinemachineGroupComposer_GetScreenSpaceGroupBoundingBox_mD21F1915940A7444B239E306204AC359485DA3C8,
	CinemachineGroupComposer__ctor_m7FC019C66BF7BFC724ECBE6614922A341CEAEB9F,
	CinemachineHardLockToTarget_get_IsValid_mB4B8596FAC003DDB676DA62F8791144FF82EC9FF,
	CinemachineHardLockToTarget_get_Stage_m5593A2FD90EE9EBEA068EE1D2316B2A17BB445C7,
	CinemachineHardLockToTarget_GetMaxDampTime_m9AE2387AE059EECF8F26E7F790D64B3051DDE58A,
	CinemachineHardLockToTarget_MutateCameraState_mA26502B42607E6B42316FDB154CCA0F0677D7FB2,
	CinemachineHardLockToTarget__ctor_m80D0530B0306D501FB1279AD9D5FC08C86954F39,
	CinemachineHardLookAt_get_IsValid_m14C472D0B12C8ED2F7CBEDE1463485F546FB8856,
	CinemachineHardLookAt_get_Stage_mF5E12651C246600173A452EB64701A6D385CF832,
	CinemachineHardLookAt_MutateCameraState_mC529F56FDA06226E4280449F649102B7392C4D17,
	CinemachineHardLookAt__ctor_mC6209571CD75BACFB0D27C6A4F23294C575CD139,
	CinemachineOrbitalTransposer_OnValidate_m16936FC098624F28C992EF3A43A2A30E01F24478,
	CinemachineOrbitalTransposer_UpdateHeading_m51697AD5EA097970B5E4A2257741553B45B8E8E5,
	CinemachineOrbitalTransposer_UpdateHeading_mB62BE9B437A813916796102106A15EC88B7D6D38,
	CinemachineOrbitalTransposer_OnEnable_m1009CB168A884E6799875A253AB33B9BA429FE21,
	CinemachineOrbitalTransposer_UpdateInputAxisProvider_m577FF1105D78BEA23D538257216CCA6AA3939C1D,
	CinemachineOrbitalTransposer_get_PreviousTarget_mCD7F8B212E3CF07C2B28269DBD9AEED8FFBCC36B,
	CinemachineOrbitalTransposer_set_PreviousTarget_m8C785BA96B2C5495772AB2CE5B8AC7A11B5E9B18,
	CinemachineOrbitalTransposer_OnTargetObjectWarped_m9D46C90267A97EB8DCA88B03C0ACEFFC29B1B424,
	CinemachineOrbitalTransposer_ForceCameraPosition_m2152590E3A98A5FDAAF49699DE9EF9311B00BCC4,
	CinemachineOrbitalTransposer_OnTransitionFromCamera_m28AA80DA45100E312174A830FD1AE9676548B391,
	CinemachineOrbitalTransposer_GetAxisClosestValue_m49678E8EEBDB7B18ABA126F1A53ED3DC412DF606,
	CinemachineOrbitalTransposer_get_LastHeading_m2E84E64E45CCFA5EDF4281474B39D2C2D4E77E65,
	CinemachineOrbitalTransposer_set_LastHeading_m1081AD7C55D275B8A6CD15E356C6E0896967FCF7,
	CinemachineOrbitalTransposer_MutateCameraState_m3D0B7E27178F330F093CEEE6AE93326CBDFF57AF,
	CinemachineOrbitalTransposer_GetTargetCameraPosition_mEF6CEF0A22C999B4B3C29860138A88B629EDA7EC,
	CinemachineOrbitalTransposer_GetTargetHeading_m474077AD308ACEAFFCFFE43ED36B0A645B4FA786,
	CinemachineOrbitalTransposer__ctor_m00999B24FD592B5C32C79C99C6C68B30CB456206,
	Heading__ctor_m27AC6DA9204C9B4856DEA05AAAD89E2400FF639A,
	UpdateHeadingDelegate__ctor_mB9BA33C54488BC8DD418BEEF3A51DB6AF40E361B,
	UpdateHeadingDelegate_Invoke_m3A58C1E3FAF4FE5B175648FF19F95BAD57CC6330,
	UpdateHeadingDelegate_BeginInvoke_mBDCD4A90CE6D3E50F8A7A7FF3A12039EE580E4A4,
	UpdateHeadingDelegate_EndInvoke_m75EB1823E9A52B6FD0216E863677C5A357A13672,
	U3CU3Ec__cctor_m040BE18F4CF76FD237A199F900F8B2D09794FBBD,
	U3CU3Ec__ctor_m2CC55D7CF3C4815383423BEA372FB9753A747D29,
	U3CU3Ec_U3C_ctorU3Eb__34_0_mEB2AEA2C6607681346D746C7815B32FFE0789E36,
	CinemachinePOV_get_IsValid_m56F4CD3C9FE5795343397325D6128B34F7282DF3,
	CinemachinePOV_get_Stage_m87C432BCA78705401251C2E0E474704E22CE6D7C,
	CinemachinePOV_OnValidate_m7AC95AEC250D1606DDE3ACDA968E7F6312BA60F7,
	CinemachinePOV_OnEnable_mD7B0A5051C115961BD8D43641B70BD2512E19B72,
	CinemachinePOV_UpdateInputAxisProvider_m47A7388954C01FFE0948F4601D4CE198BEFC221B,
	CinemachinePOV_PrePipelineMutateCameraState_m9BB2531A4EF28FD3221EB302288BACC4DE852F4A,
	CinemachinePOV_MutateCameraState_mBBA8EDDE3AD2CD0AA9AF831D81D0A14FAC4BF0E7,
	CinemachinePOV_GetRecenterTarget_mC5206D2FC5D9809E62E8A536B59700C9F4F38876,
	CinemachinePOV_NormalizeAngle_mA7968F1D5E2F299419C77503DB3742F44BD07E1D,
	CinemachinePOV_ForceCameraPosition_mF4DB8EC103BCAB1AB82FF19EC542E4F6E54D041A,
	CinemachinePOV_OnTransitionFromCamera_m6BC39D7F60175A61C402C262EDC067793F0F789C,
	CinemachinePOV_SetAxesForRotation_m2FAD19EC947F4B355DED9537C8622F028F01A507,
	CinemachinePOV__ctor_m697E2E56E6B944C9E7334DCFC8AC0BF06DA6BCD0,
	CinemachineSameAsFollowTarget_get_IsValid_m1809C5E540F7537CC4286F0958FD1539EECA1125,
	CinemachineSameAsFollowTarget_get_Stage_m2113E69CBB5E0167E4A5D5B431C70DC7705B6707,
	CinemachineSameAsFollowTarget_GetMaxDampTime_m77DFBB864C5C83A91406C04F746665E4CABC45E4,
	CinemachineSameAsFollowTarget_MutateCameraState_m85AEA567E9CC87451D0024879F38BCD53C506B00,
	CinemachineSameAsFollowTarget__ctor_m81457B118206C0E0D833F0015A799194E9774814,
	CinemachineTrackedDolly_get_IsValid_m8EDE6D1E0B40C6F90871E4B95DB5E1F4DD49BB4E,
	CinemachineTrackedDolly_get_Stage_mFB4BDBA8C38A47C2E380E031DA81B0D1C3F22433,
	CinemachineTrackedDolly_GetMaxDampTime_m16C0CFB0875FEB726F78C571B4316AC7ADAC5D9C,
	CinemachineTrackedDolly_MutateCameraState_mC2D7BE38E781EDAC4B28B381BBA53F27429CB812,
	CinemachineTrackedDolly_GetCameraOrientationAtPathPoint_mEDA3B0646C44F84366FA86CD999E75DAE106CB30,
	CinemachineTrackedDolly_get_AngularDamping_mC3701A9FAAE10CE9FC4F82FC6D3593866C03B6D4,
	CinemachineTrackedDolly__ctor_mC643FD4B96CA4A08FA2BC2E3800FA9B448A65CEE,
	AutoDolly__ctor_mB22E90A64C6D9D0F6C0F6FE794446F2867E76793,
	CinemachineTransposer_OnValidate_mBD6D72D809B998114DE4FDE462D39D9596E4EED9,
	CinemachineTransposer_get_HideOffsetInInspector_m937352B22116BAB61B21EBBF6D3417EE52F0158D,
	CinemachineTransposer_set_HideOffsetInInspector_m8C4560481CC4C6864C5F49A32C3495659E18521E,
	CinemachineTransposer_get_EffectiveOffset_m66C67B1F9882DF5B424E58F4B904ED0A3A519183,
	CinemachineTransposer_get_IsValid_m60005E62926B8E9927396938C4C980F873F91232,
	CinemachineTransposer_get_Stage_mD4AE770AE7489A2D32E847C2370E0881BB1E81FB,
	CinemachineTransposer_GetMaxDampTime_m4E1F2298C32E2EE3FE5D3ACCEE6F1C990D68F9F9,
	CinemachineTransposer_MutateCameraState_m52392553F3D657BD1825ACC8EDFE79AA520DF52C,
	CinemachineTransposer_OnTargetObjectWarped_m898C8AABB73BBF79CA0825BB3F1F1C0FA19EA9A0,
	CinemachineTransposer_ForceCameraPosition_m839D8ADF7D8EABD7D108B71DD028C85C119D56E4,
	CinemachineTransposer_InitPrevFrameStateInfo_m392AB50EFACB254C9CE86F0270ED4A9103AA753C,
	CinemachineTransposer_TrackTarget_m6681DA4BA5675F68E5EB9BB179AEF1E8A01D64D9,
	CinemachineTransposer_GetOffsetForMinimumTargetDistance_mC844A89B44991A156705B0169529FF39BE30ECC8,
	CinemachineTransposer_get_Damping_m54AE51D0991EF38C1D58A464FBE0B71E8EAA53E9,
	CinemachineTransposer_get_AngularDamping_mBBC748334418408B75EC350A2E92833FEDD11276,
	CinemachineTransposer_GetTargetCameraPosition_m1BB4ED7FA1B3BB3EABE41E73C6B46E6E39C671F7,
	CinemachineTransposer_GetReferenceOrientation_m6052EF55BF3528A668CEBE505F8E33708360F0F5,
	CinemachineTransposer__ctor_m3FA3755910D644CBE2EF94268677DCDE7C24D584,
	AxisState__ctor_mE1E3449CB695DD0B97602DA2309969235F2AE8A0,
	AxisState_Validate_mD31D13D5FBDA48541D62D25EBA58C6615141115C,
	AxisState_Reset_m467FB333DF4E419185F468B80CD82F75C773A3FE,
	AxisState_SetInputAxisProvider_m7396F12E659493FD37D66F79B04CF93D4BBDA527,
	AxisState_get_HasInputProvider_m38460D72EBD97A207B33485CA157D6D4D3193226,
	AxisState_Update_mEA3BADC4B491D705D61357CD1ECE295FC243670A,
	AxisState_ClampValue_m44330844584E13D1E1921B6174DD5257CDFFA960,
	AxisState_MaxSpeedUpdate_mC53D3EABA41652F2D991263538542FA23B8FB517,
	AxisState_GetMaxSpeed_mE2AB97681281AA228333FC67BD9AB5F8CEA640AA,
	AxisState_get_ValueRangeLocked_mAA8A098676C624D20443DC6207F7CE4268824369,
	AxisState_set_ValueRangeLocked_m556066F839F1D835CFB65398E5D2776E74510F2A,
	AxisState_get_HasRecentering_m02782E465AF3A314B2586C24230C03FBD609EB12,
	AxisState_set_HasRecentering_m30D6476F657160F87D850632F36DA226C04FCDE6,
	NULL,
	Recentering__ctor_mDFE3D3BB932AF426369B033D18AD3FDAAF26384F,
	Recentering_Validate_mFB967BB954EFD0DD6E2315F53A3241FDC146B18A,
	Recentering_CopyStateFrom_mE18BDABB9C0A8D71903C3173B9783435DDE64918,
	Recentering_CancelRecentering_m49877C0EBC7D9873C40CABD8EEF245954703CEC2,
	Recentering_RecenterNow_mB95BFD6D292191AB019A574F835AE4FB2A5ECD54,
	Recentering_DoRecentering_mA1AB5ACE77B56D9357CBB46FB4BEAF42AED5CD6C,
	Recentering_LegacyUpgrade_mE331A7312B51DE3F31805A89EC3E4EB9DF71567E,
	CameraState_get_Lens_m8DD7FD2B8954A56E2CBD83D1EF7A77958F685893,
	CameraState_set_Lens_mAABE6FFC1E5F9A33EE16A7B009B927ECB2F29523,
	CameraState_get_ReferenceUp_m9A1F4A533328BABA7C81C4AD2F1E830375495B5A,
	CameraState_set_ReferenceUp_mE156A37CA4B6BF3E8BA65A391730873572F24358,
	CameraState_get_ReferenceLookAt_m32BCDF0492BA9AAECC597DF02676D66BF0566548,
	CameraState_set_ReferenceLookAt_mF7CF3F3DD4D8DA16C08C4706E6C1128B48A3CEA2,
	CameraState_get_HasLookAt_mE3BC5114383606752FDDED488732126B5644E81D,
	CameraState_get_RawPosition_mA01BC7F842C837D49F0542A0475AE0EA9C88539D,
	CameraState_set_RawPosition_m0E1142A79939C7AD7156986F91CD0F1D60499A31,
	CameraState_get_RawOrientation_m61C0AC1D87FB6C869DA02458732BF6023130F163,
	CameraState_set_RawOrientation_mF473C9D14F4C653E31B9D17B29198A0A26FB710E,
	CameraState_get_PositionDampingBypass_m4F3CAC6077C7D9CE366DE64FDC0F76B8E4309965,
	CameraState_set_PositionDampingBypass_m6ED6EE6829EAD07FB68F3281F682360F9E0B5707,
	CameraState_get_ShotQuality_m3FE037E90A92A214DAEEA694D75ECF717520E285,
	CameraState_set_ShotQuality_m02E14BA3BB2628501258190348C309AF56836E3B,
	CameraState_get_PositionCorrection_m19DFDEC5E34379495FE563689462063CF01CC87B,
	CameraState_set_PositionCorrection_m5A6BC8785013D7DA1B8B814BEA2FB2893C8D681B,
	CameraState_get_OrientationCorrection_m50B2841F1C1C41B276CE76048DBE68CC355EBE9E,
	CameraState_set_OrientationCorrection_m78B62F6D9C90041D16F969BF5C5DF5775380F4E3,
	CameraState_get_CorrectedPosition_mFEB78C718574311BE01F52353220D8E3EC062344,
	CameraState_get_CorrectedOrientation_mB74864040A12CF81360C263385AE1CFFFA73E9BB,
	CameraState_get_FinalPosition_mABA119F4F7BDAB3C56B5A9D50A0A4E9F0EC5BFBA,
	CameraState_get_FinalOrientation_m44213894D5B3665846C120EA54FD5F116FBBBC40,
	CameraState_get_BlendHint_m787612D5DE9717F032149B538F603DA69B26FC75,
	CameraState_set_BlendHint_mFEAA3F666F38C388C5CCF863FF3711CEEE3A0A52,
	CameraState_get_Default_m12D560DD60BC9AC6B1A0287EF92D21BFF1C1C8A7,
	CameraState_get_NumCustomBlendables_m45122BC6F6592ACC07FD85C38B3A756FEC60A7CF,
	CameraState_set_NumCustomBlendables_mF90E1B32FE572F25B187D449C5AEE2499AAE564F,
	CameraState_GetCustomBlendable_mD4E4CD7E5D2F4ABF74B78B4997BEA73C65C704BF,
	CameraState_FindCustomBlendable_mADB6FC113F422BEEA9B9DE3CCEAA69C505BEEDAC,
	CameraState_AddCustomBlendable_mD2B67C82217C56D550713328D287282A0548CD97,
	CameraState_Lerp_m29CBA400AE3DAD80F7B1F9B81B9758244530CB9B,
	CameraState_InterpolateFOV_m2C5E3CCFCAE4D654A2BD7F07A50F5E52EEBB8E02,
	CameraState_ApplyPosBlendHint_m9A27867615504FB4A36D503396BA10DE7603986C,
	CameraState_ApplyRotBlendHint_mECDD8502F1EB7BC1B728A7DC3247AEC7B618DDE5,
	CameraState_InterpolatePosition_m731CF3321931B836BFF7D6025001E0DBDBBF8341,
	CameraState__cctor_m9FC1441CCCB6B5F891327B1F238C4B26FEC06760,
	CustomBlendable__ctor_mA7DEF75ACB9FDE678221EF6176FBD4DC4441FB07,
	CinemachineBlend_get_CamA_m84EE61BF64BEBAA6DD45591F1D6E727B894DAC91,
	CinemachineBlend_set_CamA_m5E656E137DE95F70ADF349416BDF9845358143BF,
	CinemachineBlend_get_CamB_m81ADE44158093EBCB50F04D90A1DD775FC02C4A7,
	CinemachineBlend_set_CamB_m502F49F7663036661B7C21945F58ED2C584308EA,
	CinemachineBlend_get_BlendCurve_m6A1FF79078DEA51B8343A4135E7A5E002D5D13C6,
	CinemachineBlend_set_BlendCurve_m1C92DE13808FD00C1AE25E8D2AA898B82E77129C,
	CinemachineBlend_get_TimeInBlend_mFA561FA319D53F2A245E6D14A67F10356FDE9502,
	CinemachineBlend_set_TimeInBlend_mCB11D4F786D1D2201521E1C5E43FBAA7CF77202E,
	CinemachineBlend_get_BlendWeight_mCCA9907E0F251FB96CCC75DE16EB76359E69D392,
	CinemachineBlend_get_IsValid_m55FFFA5BC32710DA0EF7CA8DBD7B0303D562D0D2,
	CinemachineBlend_get_Duration_mB9E2A918F60A7F8BFFADB38BE2D51455FECDF7E4,
	CinemachineBlend_set_Duration_m6624099445533093B65C3E92C25060E2C5B2692B,
	CinemachineBlend_get_IsComplete_m3FF0BF1A998D7E09ED0FCBEA109C9BEE7721CA50,
	CinemachineBlend_get_Description_m4096D0C82956E1009FA82A07FA6BB184FD5EBC59,
	CinemachineBlend_Uses_mE5C14AEF4BE8C61F17564F4F5DA84831449B6F4B,
	CinemachineBlend__ctor_mB06EF56D92F3900609669689E8820647EE84B5A3,
	CinemachineBlend_UpdateCameraState_m4B58F6808D5B9494A583E9C0CBDC4841CBEB99E1,
	CinemachineBlend_get_State_m353325CD92B13EF46EAF00985769217EA4F98FA1,
	CinemachineBlendDefinition_get_BlendTime_m2185E8662569BE0201996EAA3AC55C1A095CA5E3,
	CinemachineBlendDefinition__ctor_m51379366ABFBFF4642735E6C843F54CF45D642CF,
	CinemachineBlendDefinition_CreateStandardCurves_m4877FF63D3A4E8933F6817ECAEB9B500B9A3D56B,
	CinemachineBlendDefinition_get_BlendCurve_m547D15706E83EACB4DE888750C0728BDE5974873,
	StaticPointVirtualCamera__ctor_mAC0BFA55F9A05C87AFAFC15C1282DCF7A88F7330,
	StaticPointVirtualCamera_SetState_m0111F6AAC091400D8554DFCD60258C958D241933,
	StaticPointVirtualCamera_get_Name_m88CDC311CAE2371482E697C343C5D364D3921FBA,
	StaticPointVirtualCamera_set_Name_mC42E291C5240205CAE873C773EA2B4D1AEBCBA38,
	StaticPointVirtualCamera_get_Description_mD42A5CEF974DE56D2F2ADEE0D041A51FAA24FDA8,
	StaticPointVirtualCamera_get_Priority_mD186335682BAEEA3BDBB50BA6667DC287FAFAF55,
	StaticPointVirtualCamera_set_Priority_m1200B4DCA10859C74244CBA6D6619222450613A4,
	StaticPointVirtualCamera_get_LookAt_m81DE46064CF375735C542138F35390F99692F864,
	StaticPointVirtualCamera_set_LookAt_m0AB6CA2B5FCE282A9D34CF1F90D6B53E538921D3,
	StaticPointVirtualCamera_get_Follow_m5C80C9614891CEA38FD1C386B5EA6A0A5D2D856C,
	StaticPointVirtualCamera_set_Follow_m607FEDDF53E09CD16CA022F1E55783558FA71746,
	StaticPointVirtualCamera_get_State_m4864EB89CDE70665713ADCF80A4612B5BDE43980,
	StaticPointVirtualCamera_set_State_mC75EE398CBB9A6BE8054F5CD5C4AF90982EEF670,
	StaticPointVirtualCamera_get_VirtualCameraGameObject_mE9318C1A3D5D4779A2D20ECC5FE32C2872E8059E,
	StaticPointVirtualCamera_get_IsValid_m207DE6EDCE733D57C032075ED3FEE27A0DA5EDA4,
	StaticPointVirtualCamera_get_ParentCamera_m939FE729B7EEC40DA987EA842094EF2D2D660B0E,
	StaticPointVirtualCamera_IsLiveChild_mE99E5559C21364521C4DF662E25EC8CA3300AD45,
	StaticPointVirtualCamera_UpdateCameraState_m032CCA1E862B142F48323104B4785597D6F1BE50,
	StaticPointVirtualCamera_InternalUpdateCameraState_m1B0FEA4EB03147B15FDA4D1B8BC57F1259BB4008,
	StaticPointVirtualCamera_OnTransitionFromCamera_m9B762A7A6E09D9F4B670045857761C91EFC28823,
	StaticPointVirtualCamera_OnTargetObjectWarped_m41F5BB8D4A13B4B4D72A8B764E61A077F8CD167F,
	BlendSourceVirtualCamera__ctor_m762CFEB65D584FC854F9653CF1A97444FF86E08B,
	BlendSourceVirtualCamera_get_Blend_mB5C0C8918EA30ABEE4F85F1BB493075EFF0F1B60,
	BlendSourceVirtualCamera_set_Blend_m2EBC2E6A8F75FF3F416F0FE2583DA24E6320FEFA,
	BlendSourceVirtualCamera_get_Name_m4F4C48F79D68A9E15606415175DD1067B950677C,
	BlendSourceVirtualCamera_get_Description_m3B5EA1CECACCF4EA3B337E1DEA134DE4F87234C5,
	BlendSourceVirtualCamera_get_Priority_m043ABE54F59106B010EEBC2F48AEF70E82AFBF92,
	BlendSourceVirtualCamera_set_Priority_mC7108E9EAC45C4F8492791A250F72100A044508C,
	BlendSourceVirtualCamera_get_LookAt_m923B7FD1549B3E1090A3ACBB9E51A28A195D7813,
	BlendSourceVirtualCamera_set_LookAt_m4D4DB97225E4779DBE60447EF5E89A8EA91CEDFC,
	BlendSourceVirtualCamera_get_Follow_m2AFD8A2446B3DD4C713C4BE180974AEA67F27B7C,
	BlendSourceVirtualCamera_set_Follow_m24D9B623C684CD670659A4E36371C78007DEE55A,
	BlendSourceVirtualCamera_get_State_mA0FD90B6B6D4FF668604E9B199E4DBB6299D28D8,
	BlendSourceVirtualCamera_set_State_m1939F89FAA80BDCB54AA3983EA6DDCB582E1C6BB,
	BlendSourceVirtualCamera_get_VirtualCameraGameObject_mFA88FE034A5AD685D2E797CD21050EEF5FE3E2AB,
	BlendSourceVirtualCamera_get_IsValid_m4D11A4E0F85913145D907D6DF092E653D3BCB272,
	BlendSourceVirtualCamera_get_ParentCamera_mAAB7D1922FEB01F0D76E175DFF5F588B3557B46D,
	BlendSourceVirtualCamera_IsLiveChild_m5D3C8B7EA632D8E40D2D5B75F43B762524A3D8BB,
	BlendSourceVirtualCamera_CalculateNewState_mA5EA36A4D37412F1B2B14CFA7E7C1478CACEEF5D,
	BlendSourceVirtualCamera_UpdateCameraState_m7B24A298453FCB56F8B840E7DA846270F621AE55,
	BlendSourceVirtualCamera_InternalUpdateCameraState_m4E07980798FF47304F5A3A420EDDFD99E8F7B62F,
	BlendSourceVirtualCamera_OnTransitionFromCamera_mEACC986DA2FD0B5ECA68773558FC33504FB32947,
	BlendSourceVirtualCamera_OnTargetObjectWarped_mBA61A40425AE0741B93ABEC054F616B6E7C39A4C,
	CinemachineBlenderSettings_GetBlendForVirtualCameras_m83B852A5B14C8ED39E2FC581D3BB11528FD3B565,
	CinemachineBlenderSettings__ctor_m8548E0C3CD5CBF25ADEE8574A5258A021D1E1A07,
	CinemachineComponentBase_get_VirtualCamera_mDDC4BEDF77A93F4C25C2E62CBF96542ABB6FE3BA,
	CinemachineComponentBase_get_FollowTarget_m6A52B9EAC2F1B1DD8D8F901A48F52A296B4715AC,
	CinemachineComponentBase_get_LookAtTarget_m0B8D7462A7C631E082634733954374BD9C030F70,
	CinemachineComponentBase_UpdateFollowTargetCache_m8047A77301A9616719C733A8D394D881FB78BA0B,
	CinemachineComponentBase_get_AbstractFollowTargetGroup_m3A97181333E7E463488F030F83D72D4D671946D1,
	CinemachineComponentBase_get_FollowTargetGroup_m7AFAB2E9C70EC126379938A1FCFC90B14EC20472,
	CinemachineComponentBase_get_FollowTargetPosition_mF3A92D2EE8A07BC0E1FC820AFAA5F4CC24CD1C94,
	CinemachineComponentBase_get_FollowTargetRotation_m63FA12EC6372FC0D1D4C0224C86AD054EA31387F,
	CinemachineComponentBase_UpdateLookAtTargetCache_m0E7E8C9C13122A00F3506B5094A71A22DD001DE6,
	CinemachineComponentBase_get_AbstractLookAtTargetGroup_m09E391BC22E9B714A1A18DC19BEF1E445A39AAA8,
	CinemachineComponentBase_get_LookAtTargetGroup_mF5DE59F602311812B2A1B3EC112ECB26DB0585BA,
	CinemachineComponentBase_get_LookAtTargetPosition_m276755F157FCDC7F0933FF7E965826B6B782031B,
	CinemachineComponentBase_get_LookAtTargetRotation_mCCBCCE7A00B6FECC898C11A787FB18432EF38A86,
	CinemachineComponentBase_get_VcamState_m0F36DA00A9FF33209646471FDF6F7EC6F7DF6B80,
	NULL,
	CinemachineComponentBase_PrePipelineMutateCameraState_mAFE097E8C3220CE39BEFFFB48BDF31779A6C68D0,
	NULL,
	CinemachineComponentBase_get_BodyAppliesAfterAim_mE51BED341B65934E6CA3D8AE31A4F84B2525F52A,
	NULL,
	CinemachineComponentBase_OnTransitionFromCamera_m9DD4DF577144AF4CEA69C855EAA324D1168EBBE4,
	CinemachineComponentBase_OnTargetObjectWarped_m68C3CCD5A93FF2DD4013F33DDC1204A97B54A701,
	CinemachineComponentBase_ForceCameraPosition_mFDFA0AE6EA6C4E03EAB878E392AD312AAD454EF4,
	CinemachineComponentBase_GetMaxDampTime_m630233212BCB908E0F9EF150C2FDF5559808691F,
	CinemachineComponentBase__ctor_mF80CD1194482BC499205396A8622FAE20F5B75D4,
	CinemachineCore_get_Instance_mCD8E65EBCBB58BEDC6FD0C503AB9E866B76AFA83,
	CinemachineCore_get_DeltaTime_m8AC61BA9F0163DFE1A3D0FC5C40937B7722EB883,
	CinemachineCore_get_CurrentTime_mBD3A55B23004CB425D9297086BC20D7C55797625,
	CinemachineCore_get_BrainCount_mA544A424A3E3FC613955E2D60CA93484BC97616C,
	CinemachineCore_GetActiveBrain_m99FB4BE86B83C680EB414B5D1770908EA7ADF558,
	CinemachineCore_AddActiveBrain_m0BD0B7F334ABB98A322EACBA8285BD164D6E69AB,
	CinemachineCore_RemoveActiveBrain_m1FF228AA890EFDF236F0E434A1C88701A66BAE15,
	CinemachineCore_get_VirtualCameraCount_m09675B5895A728AC31A0892F5343264CB34FE708,
	CinemachineCore_GetVirtualCamera_m648982BBF286DB719899EB96C4E7FF17B1B5C86C,
	CinemachineCore_AddActiveCamera_m15B0C7AD4C1A0F46FC24A1121B399D80F7026DB7,
	CinemachineCore_RemoveActiveCamera_mD28005289E4D2F4000E8121243A97DCE8922B4C1,
	CinemachineCore_CameraDestroyed_m9A825D47C357F36DABCC51C466E0704BD49E13EB,
	CinemachineCore_CameraEnabled_m5DC7D833542C8CEA753704CE9026C4CE9A00EAC6,
	CinemachineCore_CameraDisabled_m9B1E9D658D5C6090F2C85A82C013908DC99A380E,
	CinemachineCore_get_FixedFrameCount_m119017A9C55B62668AFD1AE6D209A1E9B21210C8,
	CinemachineCore_set_FixedFrameCount_m814A0AC94BD3C5FEC3CEB31390AFC79D7F664F6D,
	CinemachineCore_UpdateAllActiveVirtualCameras_mCEAF2622091B0DC36A26A844C7C6022BF3C40A51,
	CinemachineCore_UpdateVirtualCamera_m937B1B00C50FDEFC1C9AE346DF37A0694D04F9EF,
	CinemachineCore_InitializeModule_m9605C793013867D1CCFA4CE04C6673E6665B6F82,
	CinemachineCore_get_CurrentUpdateFilter_m6FC774F24C226A7BACD909FB796DC1406A5EDCD0,
	CinemachineCore_set_CurrentUpdateFilter_m3E96AD239CF49A028CF514AE0631AA05DE5E3313,
	CinemachineCore_GetUpdateTarget_m4BCCFF232B14DEDDAF22E5E526638833FA065094,
	CinemachineCore_GetVcamUpdateStatus_m2C7C238F785E1F474B1707520007D3AA42129D04,
	CinemachineCore_IsLive_m61EC3BE5D22564DD740379A88639BF368EBC1E43,
	CinemachineCore_GenerateCameraActivationEvent_m851F3990838CAAD976391EECAC4D57B1C61E938A,
	CinemachineCore_GenerateCameraCutEvent_m38E839FFCA8034AC081D9F99FBEEC15B872F14C6,
	CinemachineCore_FindPotentialTargetBrain_m5DE059E6EDDE3EF8BD7258655A61A70BD7DA6F77,
	CinemachineCore__ctor_mC1794CB6B097D4CB15080ECDB82E4F2267C1D712,
	CinemachineCore__cctor_m5F6647805E2D5EC0C7F1B86D109D21F5D66FEEA7,
	AxisInputDelegate__ctor_m55631A6E688731D441A5822CE96218E7E9CC5B01,
	AxisInputDelegate_Invoke_m860AF1CED1A9DF40081361395A2E99E5913DE2D4,
	AxisInputDelegate_BeginInvoke_mE17152E703E8CC1FD23F1699D57494CD620D559D,
	AxisInputDelegate_EndInvoke_m42BA5EAD29B364609461C59796CF1FE308942777,
	GetBlendOverrideDelegate__ctor_m0D9DFFA11AA07FC85C2903B99641E4CE9BF6DC9B,
	GetBlendOverrideDelegate_Invoke_mAE517451152A2ADCF950A31A7004F52FA64C8EE0,
	GetBlendOverrideDelegate_BeginInvoke_m4CEF86F10D8C529DD09C94310D0E70668307B360,
	GetBlendOverrideDelegate_EndInvoke_m07B62A912EE6066CE03A1D3125A0BEB2ED1AC0E4,
	UpdateStatus__ctor_mAEEB635F3C3AE9D84B9072DA75E14B098312CACD,
	U3CU3Ec__cctor_m98EAFFDFF71A6A736468C8D60AC3ECE675B49340,
	U3CU3Ec__ctor_m15EED79FFF0FF14467B49DC3AC7D134CA38240DD,
	U3CU3Ec_U3CGetVirtualCameraU3Eb__30_0_mDC45F408EA0E79C405DD08F781D20C1CA3017B77,
	CinemachineExtension_get_VirtualCamera_m48F40B632C12E90C690465B01A667A3748761AF8,
	CinemachineExtension_Awake_m090793C691718BB30B2C702DC41A2EE51F47BE2E,
	CinemachineExtension_OnEnable_m41D46718D51487D5FD1F8C9DF9AB05831CA243A9,
	CinemachineExtension_OnDestroy_m63D31EE81830209F4127D04ED9C7021C14A13C0C,
	CinemachineExtension_EnsureStarted_m3F2553CBD100D1FC3E126F2966A6673AEE82771D,
	CinemachineExtension_ConnectToVcam_mB763D1DF3E860D7CF8392A28D47D109E261381B2,
	CinemachineExtension_PrePipelineMutateCameraStateCallback_mA26EFBE159BE7F5A906A1E7229885E49CD4D8D75,
	CinemachineExtension_InvokePostPipelineStageCallback_m54C975D864B6A6818DE9658ADC23439E45B35F9C,
	NULL,
	CinemachineExtension_OnTargetObjectWarped_m20FB23984C9395B8BF67744C1ED7832FCAAFDAAF,
	CinemachineExtension_ForceCameraPosition_m1FD206CC4FBF213FA344D8F059BDE6100FE779FF,
	CinemachineExtension_OnTransitionFromCamera_mBE45BD7A872FF8AC13C1E1EA4B59985FE9A7CD6A,
	CinemachineExtension_GetMaxDampTime_mD88B3216AEF6C76B58EBEF1ABAAC8B9018C47DE8,
	NULL,
	NULL,
	CinemachineExtension__ctor_m7331AF4105FCAFF48E3CC9A412B1953647E0BEBA,
	AxisBase_Validate_mEEA2E671C4CE0548BEA394B5598EA51929E7D33A,
	CinemachineInputAxisDriver_Validate_m144628F55B154073CD729EE89A3F87217FC01173,
	CinemachineInputAxisDriver_Update_mCF849BA78D16DF068F7723E78D6BC171890AB4CA,
	CinemachineInputAxisDriver_Update_mB3570630DFFA0617C1E132A764E902F2848DF810,
	CinemachineInputAxisDriver_ClampValue_m1C0996D4C9242ACB7615CDE6C7C4BE9D39B341AF,
	NULL,
	NULL,
	NULL,
	CinemachinePathBase_StandardizePos_m7B0DB6BC2287BFF4EDD7B5C1351FC1570FD1C00D,
	NULL,
	NULL,
	NULL,
	CinemachinePathBase_FindClosestPoint_mB3F074A56F3054EA9D9F8B87209D5A12A305BE8E,
	CinemachinePathBase_MinUnit_mBF5FEF3F3768DD5BEF8790BDBAFD800F42E170FE,
	CinemachinePathBase_MaxUnit_m205374FE01FC307D7D7ABDC7432FED2C94561A67,
	CinemachinePathBase_StandardizeUnit_m4771C500193C929F3F7719A44D5FF8D7E7406B7B,
	CinemachinePathBase_EvaluatePositionAtUnit_mCC69EFCF35ED5B1210214A96C100E8B809FD5B85,
	CinemachinePathBase_EvaluateTangentAtUnit_mFF4C4E5806694670B0281C62E1E598350D574FE7,
	CinemachinePathBase_EvaluateOrientationAtUnit_m78B5F5388A3DD41392F335CA7DB59CA1D8B978F5,
	NULL,
	CinemachinePathBase_InvalidateDistanceCache_m630E60D7B6535CD35356161A2C4FE94CBA726C63,
	CinemachinePathBase_DistanceCacheIsValid_m5B4999C83A60EA0834AB8ACBFBFE298EE5AA6FA9,
	CinemachinePathBase_get_PathLength_m46723487D97919331857A8975C397CB25DAB319D,
	CinemachinePathBase_StandardizePathDistance_mB0DABA55052793902DC03DF700AE54A9A560A3E0,
	CinemachinePathBase_ToNativePathUnits_mDB615D10D6E1F61AF70B41A508AC8986AE59D683,
	CinemachinePathBase_FromPathNativeUnits_m7817218D78BFF77C9F0D52C41B9538E6C6DCF2EB,
	CinemachinePathBase_ResamplePath_m87F9A39480F5A2EFBC1ACB5361BD8F1F3316FD01,
	CinemachinePathBase__ctor_mA1D4CC9C83F490A407AF3B7EB143BEA58C879EEE,
	Appearance__ctor_m975B387EF5A573D25BD3C5C57B0314F3C4446196,
	AxisStatePropertyAttribute__ctor_mE6EC085C305D367A9C13C5A8F9C71CF740CF31D4,
	OrbitalTransposerHeadingPropertyAttribute__ctor_mE270F93BA1EA61B3B8D08EEB564E23317ADC7DBA,
	LensSettingsPropertyAttribute__ctor_mD29DB77CB5CB59D292D9524BE6909CFAA0554780,
	VcamTargetPropertyAttribute__ctor_m997379231EB2F108F80DC83B01246F4E35D71570,
	CinemachineBlendDefinitionPropertyAttribute__ctor_mA08F1AA4EB4CEB0759F1C838F8E7D923A12439D7,
	SaveDuringPlayAttribute__ctor_m7E6683931B2115F1902B29FCC2B4ED8A166AE4FE,
	NoSaveDuringPlayAttribute__ctor_m999A1E82E9072D6B63A1EE6080F68AFDB15A847B,
	TagFieldAttribute__ctor_m30326F8DBA12F4CB1BE7710455DCFAE79EE3994C,
	NoiseSettingsPropertyAttribute__ctor_m5C02E6DFB9B65AA11259F8EDF2DA72DFB08DB09F,
	CinemachineEmbeddedAssetPropertyAttribute__ctor_mD6C290E553336787289444791FE7FD0E7B57126E,
	DocumentationSortingAttribute_get_Category_mFBDC5B03E1DC7E69766579396C0DE6A5B794B8C1,
	DocumentationSortingAttribute_set_Category_mEF229C6814354009B21F2401F708D041751876D8,
	DocumentationSortingAttribute__ctor_mC444D8C194E049D0E1A8A4E6F83D7D69938B4CEF,
	CinemachineVirtualCameraBase_get_ValidatingStreamVersion_mAB15E72A5D80AED2EFD0DA0BD8AB00E98030CA73,
	CinemachineVirtualCameraBase_set_ValidatingStreamVersion_m5AB3A39B6875CC5C403E49D9FFF6318CD77E6E6D,
	CinemachineVirtualCameraBase_get_FollowTargetAttachment_mC63610049FFE9F70B89E7F310C47253C90363352,
	CinemachineVirtualCameraBase_set_FollowTargetAttachment_m35C90295A253C3071DCF473D134700F3A8F6757C,
	CinemachineVirtualCameraBase_get_LookAtTargetAttachment_m54302207ED2A1A7E96A1F9DB52EC0C223754D532,
	CinemachineVirtualCameraBase_set_LookAtTargetAttachment_m344BCE5B2905887C117E70412FBE6DF6C704A995,
	CinemachineVirtualCameraBase_GetMaxDampTime_m534FD1A5F0E5B1A3F4418266045FEB5CC734C4F3,
	CinemachineVirtualCameraBase_DetachedFollowTargetDamp_mA248235BC7D1A8F9199DFEC135D8770629214BDA,
	CinemachineVirtualCameraBase_DetachedFollowTargetDamp_mFA07AB4CA8E758190A3AD4D83392619A10E19BEB,
	CinemachineVirtualCameraBase_DetachedFollowTargetDamp_m4CE171B4B2D093A57D4DA99688A0BFD8788BDA68,
	CinemachineVirtualCameraBase_DetachedLookAtTargetDamp_m644A94A63215474706B7D1357D810F4CDF309F0A,
	CinemachineVirtualCameraBase_DetachedLookAtTargetDamp_mD2B62A9293DA4E8913ADF89C61A98FE4F966888E,
	CinemachineVirtualCameraBase_DetachedLookAtTargetDamp_m4F4C54F140B29348D732A4155AB228C5C9CB9DBD,
	CinemachineVirtualCameraBase_AddExtension_m687616F9DD87E599D98CA6595C522C726BE25C91,
	CinemachineVirtualCameraBase_RemoveExtension_m4F693698B2195006C3B65D6634106BC5743298BC,
	CinemachineVirtualCameraBase_get_mExtensions_mF0F262822738E586B3A785C180E622E28C06F6D6,
	CinemachineVirtualCameraBase_set_mExtensions_m54EFFEDE585CA1012AF5CE6BDA2F6AAA351D8DED,
	CinemachineVirtualCameraBase_InvokePostPipelineStageCallback_mD4F5668E9AB96E8C11F16EC0D3CA769D663F5F51,
	CinemachineVirtualCameraBase_InvokePrePipelineMutateCameraStateCallback_m1C96DE73EEBCA5BB20BF67FAE3201CD2FC528D8C,
	CinemachineVirtualCameraBase_InvokeOnTransitionInExtensions_mB3E9947AB53FC729921300DAA1ACEEE493894846,
	CinemachineVirtualCameraBase_get_Name_m15C2DEF15C6C85BDEB8AEE64AB915DBE173F0BA0,
	CinemachineVirtualCameraBase_get_Description_m198BF619FE868398029A2631C8D11C68F553AF63,
	CinemachineVirtualCameraBase_get_Priority_m56656A6C1F3F6EDABE61AC85E1BA8C638B470310,
	CinemachineVirtualCameraBase_set_Priority_m6C180B742F19E669D648B6D1BE4D9D9C5824962B,
	CinemachineVirtualCameraBase_ApplyPositionBlendMethod_m4CA02DB42D981721D75169ACDD7900477819EEC0,
	CinemachineVirtualCameraBase_get_VirtualCameraGameObject_mDE6EBE29EC5093FDCE5E40963BFB8E39F6C7B518,
	CinemachineVirtualCameraBase_get_IsValid_m4A8B615DDFE153258564AE9D4ED8F257E9C7E5C5,
	NULL,
	CinemachineVirtualCameraBase_get_ParentCamera_mF5286EB2177F8957BC48A0BD3A5815EB408FD60C,
	CinemachineVirtualCameraBase_IsLiveChild_m1BA561E87306CCFFA9300C53CF38C5940AD1B247,
	NULL,
	NULL,
	NULL,
	NULL,
	CinemachineVirtualCameraBase_get_PreviousStateIsValid_m9AC6D8672852D072384B03B9433FAA24B6021F35,
	CinemachineVirtualCameraBase_set_PreviousStateIsValid_m6B3E5DD2C1EA71B2BA04072A0E3505AAFB2AF008,
	CinemachineVirtualCameraBase_UpdateCameraState_mBCA1562C197A11110116B3909711D0D0EE5F1733,
	NULL,
	CinemachineVirtualCameraBase_OnTransitionFromCamera_mF18AFCD175FF50DBA6851279E6C93D0A3625618E,
	CinemachineVirtualCameraBase_OnDestroy_mFF393A0D56A6468E4A055DC86B52654763CF5C01,
	CinemachineVirtualCameraBase_OnTransformParentChanged_m30B1976A8C859FADD7DBF6508018A382A921A41D,
	CinemachineVirtualCameraBase_Start_mAC4E3C7862E1898426BD04C03F97D2CB65B3E463,
	CinemachineVirtualCameraBase_EnsureStarted_m849F12F97E34D0BB2CFAB2178B5933CB3C07155F,
	CinemachineVirtualCameraBase_GetInputAxisProvider_m7691338DE9A7FEBB16AE3BC6AD15AC61D2E4D046,
	CinemachineVirtualCameraBase_OnValidate_mE1DC3F4318A152EE8B1821DE638615477645EF55,
	CinemachineVirtualCameraBase_OnEnable_m0D02925B2AB25A5F7FB3B032332B70685FCEC035,
	CinemachineVirtualCameraBase_OnDisable_m385039B02BB5EF010B8F7CD5C8D5FED7BBE7C2D1,
	CinemachineVirtualCameraBase_Update_m947321B86273A2372CF670BF61DD8763993B63E3,
	CinemachineVirtualCameraBase_UpdateSlaveStatus_m78E02F6B18B2C3FAF666F744FEA33D2357541557,
	CinemachineVirtualCameraBase_ResolveLookAt_mB4648E8AB85834A25B30DA49D5A200B74F1CC7A5,
	CinemachineVirtualCameraBase_ResolveFollow_mC991CC084D6046862E0E0D3172CF7C12FE8EC4F0,
	CinemachineVirtualCameraBase_UpdateVcamPoolStatus_m00D7E5F25FC9CC434AD143635F630984354301C9,
	CinemachineVirtualCameraBase_MoveToTopOfPrioritySubqueue_m1C3187B5E5F52FA2D2924CD3443435BCA449B631,
	CinemachineVirtualCameraBase_OnTargetObjectWarped_m7FFE5632C56D724943F8663E2A4A4B0E3B958946,
	CinemachineVirtualCameraBase_ForceCameraPosition_mBF134754EAD8C7F6DA33A8A52FFD75BEF7C8A31F,
	CinemachineVirtualCameraBase_CreateBlend_m95B3B2E83C066360A8A238BB5613E979E6369541,
	CinemachineVirtualCameraBase_PullStateFromVirtualCamera_m3F65D0956F682ED45F836E6D7950E40EB6C7D84E,
	CinemachineVirtualCameraBase__ctor_m5B13AF0337DBE27A89CAF6E30FA97CBE38823F84,
	ConfinerOven__ctor_m48A6169D36FA4125D30C0D6120CAD016194F8909,
	ConfinerOven_GetBakedSolution_m4851EA63770587CB42588DDD46CB97C75633F495,
	ConfinerOven_get_State_m05EB332DF4BD4F147E273BA2674EABE440F7A454,
	ConfinerOven_set_State_m3FC0A5E796618E464AE97D0AB10E052434A590C5,
	ConfinerOven_Initialize_m8002B599716C3F45FB7F7FD2EDC58D150A85B295,
	ConfinerOven_BakeConfiner_mF38F9C5E62C35B1641CE6518FE9CE8E882B1E6F5,
	ConfinerOven_GetPolygonBoundingBox_m20AD9390507A5F008D5DAA82B0862422A724E18A,
	ConfinerOven_ComputeSkeleton_m064537E254C62F33C2770AB502F5C37D09BBBA6A,
	BakedSolution_get_FrustumHeight_mD53A0B6A4B8FA2F76504CF1A4D2F8429E47AC76B,
	BakedSolution__ctor_m764A15AA9AD75B36FBE0BEED88317DE7D3970CC7,
	BakedSolution_Clear_m38FD13E2E690AD2E4082B0463A15EB1ABD4D527F,
	BakedSolution_IsValid_m088087FE81CEB48209DAB579552B9F1B1B2C3364,
	BakedSolution_ConfinePoint_mD522D2F038B40F7A66B2B7817253B2791BEF6FA4,
	BakedSolution_IsInsideOriginal_m78F43D3331F08CB54EFD177DE23996F5E3C0B066,
	BakedSolution_ClosestPointOnSegment_m640814AD98DC8ED622CC6F6CDD515E34F402C523,
	BakedSolution_IntPointLerp_mA505E038E47C5383553C541632DF7B0E9CF145D9,
	BakedSolution_DoesIntersectOriginal_m4F340B7A818E7FB1CFA1732D2C6C12156D5A65E2,
	BakedSolution_FindIntersection_m7F71E48AF4363555C58A9117C7A7B3272A3CB902,
	BakedSolution_IntPointDiffSqrMagnitude_m90D1C80D7F57BA58D4EB1E2F78648EF7DB36B299,
	AspectStretcher_get_Aspect_m5F122CB5941347F158A1AAC93BA287C20EE6A5CB,
	AspectStretcher__ctor_mDCB6211AC6DD9E121C1936D1CA89A59992810250,
	AspectStretcher_Stretch_mBF0EC7D7CB450374BBB47AE0ECE58FDD605FBA36,
	AspectStretcher_Unstretch_m6C6ABFB166BF2BC9B4DBDF3B2057018DE19013D6,
	PolygonSolution_StateChanged_m4F55923D1FF840A66DED34E00ABC163A4870674F,
	PolygonSolution_get_IsEmpty_mCA5809BECBE372CE603DC4E4C7E5873309A50196,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	LensSettings_get_Orthographic_mD89E6548BD05054F1ADFF7CB767ADCBA147970A0,
	LensSettings_set_Orthographic_m17D40EA48E03E6E1D1FCBC23FCC01599BD7DEC0F,
	LensSettings_get_SensorSize_mED4695A443BA5CD05E9BF20A8B435B9CEAF56F56,
	LensSettings_set_SensorSize_mCF61646CF243535A7A0FE1C18D187D68F76AA849,
	LensSettings_get_Aspect_m9CC9D04C1503CE0708B7E8D7918D51E6D105CBA6,
	LensSettings_get_IsPhysicalCamera_m51B84703CAE764F7D3F7E581D6374080F3065891,
	LensSettings_set_IsPhysicalCamera_mAD4EF6D6C68EC05EC70CF69FBD4B186BAEEAEE8D,
	LensSettings_FromCamera_mB70878A0FEE612591846D38DEB0C519E62D26062,
	LensSettings_SnapshotCameraReadOnlyProperties_mBE8E0F11CA4B7B16A6FB8C6C0EAD3215BD18F952,
	LensSettings_SnapshotCameraReadOnlyProperties_m1AF99FBBE30EEDEAAFB4F7C6EBC63C4F7BFE0E5D,
	LensSettings__ctor_m33701EC0CE3BE15F0CC8BC926D4BB090D59FD206,
	LensSettings_Lerp_m388C5EBB582A55DC6F8BA3E748270E68752E9582,
	LensSettings_Validate_mB36D902613DCFA1D4F31A16CDB87FE2AB23570AF,
	LensSettings__cctor_m83C48E930BB642670AF6DCF8B5600901D03F49F5,
	NoiseSettings_GetCombinedFilterResults_m2D89EDF921D81B5476532B768C2099BDCBA047AF,
	NoiseSettings_get_SignalDuration_mA7535F6F59953F1931926872B12D6FEC56976AAF,
	NoiseSettings_GetSignal_m2E1DEBB169108D53CB89571DB973B6AE997B2B96,
	NoiseSettings__ctor_mFC841D4CF7C2F2B0B0666F32FAF561E8BE089A47,
	NoiseParams_GetValueAt_mA2C1E6FA7AE9AB3FC9A51024E0D474E5C8596610,
	TransformNoiseParams_GetValueAt_m89FDF2289D147DC0B617426E76A78402474770CD,
	RuntimeUtility_DestroyObject_m6D1DDFE4299B3873067DC7E57851288F8F78F252,
	RuntimeUtility_IsPrefab_m073F89A3A5B106FD66AB93D1BE52B27612126F5F,
	RuntimeUtility_RaycastIgnoreTag_m028B24F950C8BC320919E184362FEF37DBE54D90,
	RuntimeUtility_SphereCastIgnoreTag_mF63BBA794BD68DF691D1EC863B2CA138CECA6D64,
	RuntimeUtility_GetScratchCollider_m45FC237FF7E53D7214EE05733272979DB41B1594,
	RuntimeUtility_DestroyScratchCollider_m0E3F76B3A7CFA392351D2E5D4705069A359B980B,
	RuntimeUtility__cctor_m213426BB091AB34EC852D1EACE5B6A50B2069C16,
	NULL,
	NULL,
	NULL,
	NULL,
	SignalSourceAsset__ctor_m6BD0FCB4BC617B1339DD54AF64C68D73217F15C4,
	TargetPositionCache_get_UseCache_m2A4E7042538DD9DB3384B1F655C2F5F241287ED3,
	TargetPositionCache_set_UseCache_mE9841EC91604F0D0249732E8AD668C59D46BE7E9,
	TargetPositionCache_get_CacheMode_mC4847BC1073AF20F9206798A04F0AAEB7675EF2D,
	TargetPositionCache_set_CacheMode_mA409087DB626DAE734E50B8F32E458AF8586A819,
	TargetPositionCache_get_IsRecording_m0E103654E5042F7C81BF3E8F6683767490885F63,
	TargetPositionCache_get_CurrentPlaybackTimeValid_m52161DB6E5E14903123C1C92B14D48228165B646,
	TargetPositionCache_get_IsEmpty_m05036B2EE99C645BC889DF7A34BB38CD9F701F17,
	TargetPositionCache_get_CurrentTime_m3F5821119AECD4EC85404EAD43A2165DBC2637C5,
	TargetPositionCache_set_CurrentTime_mA19CF3213984B76FA56B4E05C67CFA4C38665383,
	TargetPositionCache_get_CurrentFrame_m2319ECEB0B10124D15B040B2990DB4ACA50BB07C,
	TargetPositionCache_set_CurrentFrame_m989E6580A4D827FE06BCB7F5819794C116E4D584,
	TargetPositionCache_get_IsCameraCut_mD135E2C327DC1F9AB5D41DD29F50C60020788DA2,
	TargetPositionCache_set_IsCameraCut_m129E28E786C665E5DE495E5D1BC511A46CB30ABF,
	TargetPositionCache_get_CacheTimeRange_m26A353A12C7452C99C2FEF71809C25914C78529E,
	TargetPositionCache_get_HasHurrentTime_mD38DDBFB10FC5D0FB648E927AA8B3F2434DC547E,
	TargetPositionCache_ClearCache_mEAEE54E7ACFE79BB323DFA679789206770BE11ED,
	TargetPositionCache_CreatePlaybackCurves_m335FD074A23437FF0DDE3C70BED8EDAC5FFD8BA7,
	TargetPositionCache_GetTargetPosition_m683592ADC5C5B6597CE3A781E1BBE89A1AC9CBB1,
	TargetPositionCache_GetTargetRotation_mBAA85634FCB43634065191EB1F2217462334679D,
	TargetPositionCache__ctor_m0173991EBB133E2CDEF09D3C495FC3CE14ECE9C1,
	TargetPositionCache__cctor_mF31DF1BD5AFDB4275E7FC81F08D3A03B1EDF3FC1,
	CacheCurve_get_Count_m7BE1AE49E310A7185E449EF27D9715404DB58F4D,
	CacheCurve__ctor_m9126DDC2FF162438BEF34E60AD524A2BD74E09D8,
	CacheCurve_Add_m325C65AD39FDFBC91F4D5624B8BF7C5560B36DFF,
	CacheCurve_AddUntil_m3613245687496AC0DC18F1EB9A6328E3F8AA203F,
	CacheCurve_Evaluate_m9D2DF73C6C1AF43179910C16C2249A6205429938,
	Item_Lerp_m729C3CBFCA75B42CC2799D491DEF4C17C53602DC,
	Item_get_Empty_m2209C3BE792AABD138C9A597718D01D2FF089CB3,
	CacheEntry_AddRawItem_m56ADB9D380E62201025B3F4B752CDD4E90970B49,
	CacheEntry_CreateCurves_m3C30DAF286804CB56B42102406ACE0BF891292EA,
	CacheEntry__ctor_mF5B26181E6FBFC00701BC6A362BEA3416815FD2B,
	TimeRange_get_IsEmpty_m0EBE2CFDA395E03444770956D336B17D2CC676D0,
	TimeRange_Contains_m2FE15B3333F2883C0580220A5D3FDE954533A8FA,
	TimeRange_get_Empty_m273B20F7E14B9A0670F209E17316EC4EBDD7D053,
	TimeRange_Include_m98B368672B3FAD811027079C3EA8236914D3729E,
	UpdateTracker_InitializeModule_m5370F8DEE455815F90E3D955CE59DB9913D08E8F,
	UpdateTracker_UpdateTargets_mD0D8D76B9072DEA87E45FE9A440CF8324C93DEE0,
	UpdateTracker_GetPreferredUpdate_m9C3AD495B5ABFE52C7FF420870F93315B9E85219,
	UpdateTracker_OnUpdate_m5F262770C3B9222F8503D50DFE21FF7C9A902C41,
	UpdateTracker__ctor_m96110261C2684D9D4FF348FDC8C2C9ADA9107C56,
	UpdateTracker__cctor_mED7C5FD366A149F1208622A2F59654F6713B1E65,
	UpdateStatus_get_PreferredUpdate_mF6224BC9B52B95B06ECD82F3CCDAC7B0994B9B6F,
	UpdateStatus_set_PreferredUpdate_m0D163727BB4C16214C9A22D74656ED09CEF6C929,
	UpdateStatus__ctor_mDEAE275BFECF3D63AE2A93D74EABACD19FA21724,
	UpdateStatus_OnUpdate_m22DED61941774ECFB0119BAAE3BD2C164D39D521,
	CinemachineInputProvider_GetAxisValue_mACBD1F2A4A8947B16308D241B5077BC882040904,
	CinemachineInputProvider_ResolveForPlayer_m059CC48E7DE3AA999AB656ACAC98AE6AEAC035A5,
	CinemachineInputProvider_OnDisable_mEB784226D47F87DFEC4021FEFC66D5323C4D5ED9,
	CinemachineInputProvider__ctor_m8777E62CF2666361F27D23EBB1C9DCEFA089DC4D,
	U3CU3Ec__DisplayClass6_0__ctor_m746865333647DCCC84C7BCF4F1696817268C4090,
	U3CU3Ec__DisplayClass6_0_U3CResolveForPlayerU3Eb__0_mA1BA43EF633C0D9AAA1439203B89808C28B1CA3D,
	CinemachineTriggerAction_Filter_m24E0C2EA06B01EDE65C5ABCF0FF7412C15FBA2C9,
	CinemachineTriggerAction_InternalDoTriggerEnter_mB3988F520BC8AA59D9234D2ADF740F0B042CF468,
	CinemachineTriggerAction_InternalDoTriggerExit_mCD95F85A77DEA5ADA44117BB83D060759735B673,
	CinemachineTriggerAction_OnTriggerEnter_m96928EE1C51134E6F263AF38DF3F935B6AE9B437,
	CinemachineTriggerAction_OnTriggerExit_m064EAE63E912234D6C9FEBD36C93B365E7C254A7,
	CinemachineTriggerAction_OnCollisionEnter_m30F4858ADE6F9AE24968B6C4B53003A64C649EFB,
	CinemachineTriggerAction_OnCollisionExit_m14FC07565358A5C444DC58DEDF873F9EAB166B68,
	CinemachineTriggerAction_OnTriggerEnter2D_m761334328569C317AF12D5DC97F15FB754433A75,
	CinemachineTriggerAction_OnTriggerExit2D_mC612B5BBC49A435C39F90DA58E87C48996A21087,
	CinemachineTriggerAction_OnCollisionEnter2D_m1102D331D5FCC51055E4AC4CC6B36BE4966ADB52,
	CinemachineTriggerAction_OnCollisionExit2D_m0BF8AFA822490D1DC0E3720DA83D12AC8A34FE90,
	CinemachineTriggerAction_OnEnable_m79D396A5F205F320779F5A574F809E5CCA823EA0,
	CinemachineTriggerAction__ctor_m51FC885E516BEAA36487E1C69FC60915A4499FB8,
	ActionSettings__ctor_mD581917562ECC8295F6278BA5AD001705F8E9035,
	ActionSettings_Invoke_mF3E35400963944A72FD025FEF8052413056DC716,
	TriggerEvent__ctor_m1B0E4D0D8DD5D925A7B5F502DECF073FBA41C266,
	GroupWeightManipulator_Start_m75C9527F322AAB1342866F0E3C9A95A47CD3ADD8,
	GroupWeightManipulator_OnValidate_m03475E611BFE066FB8D68DF536E590D7A898986D,
	GroupWeightManipulator_Update_mF97C2AA28515F222056573441CA7323BCA2A4263,
	GroupWeightManipulator_UpdateWeights_m7AD8CE24D796B0B7DBEC5B8CE80EF22791216939,
	GroupWeightManipulator__ctor_mB7E3E90299CFB064DFC0735B0D3A95F756B520DB,
	CinemachineCollisionImpulseSource_Start_m5E5E851F56BBEB52056D04A8BAA9A09628D648E9,
	CinemachineCollisionImpulseSource_OnEnable_m96262CAFC11EEA2C8E93D1C5C43550EBBBD5F5F5,
	CinemachineCollisionImpulseSource_OnCollisionEnter_m83A9DF31C999E8DADB0ECC1785811FE9E13DF31F,
	CinemachineCollisionImpulseSource_OnTriggerEnter_mF2DE5CAE0F47A55DBD93891E8BE3878CD2EC13C6,
	CinemachineCollisionImpulseSource_GetMassAndVelocity_mB95B2A247A38FC23502BFCE4ACBECBB8E6D5478B,
	CinemachineCollisionImpulseSource_GenerateImpactEvent_m02923185427CABBF74C0E310B6631551881B084D,
	CinemachineCollisionImpulseSource_OnCollisionEnter2D_m3EA8BBA135D81259C8F0C98CB504F61E86A1FCED,
	CinemachineCollisionImpulseSource_OnTriggerEnter2D_m128B0315FD9184DC00A136E4C24A19C6D3305FE3,
	CinemachineCollisionImpulseSource_GetMassAndVelocity2D_mD290AA11EAE21CDD0B3743B070AD3B1C630DC2C7,
	CinemachineCollisionImpulseSource_GenerateImpactEvent2D_m7054A182B1B724BFD0BBB6F3867466449495A5A0,
	CinemachineCollisionImpulseSource__ctor_m52C884476834730DD21BA513FFE95FAF03A1EE72,
	CinemachineFixedSignal_get_SignalDuration_m45BF3B9C17DCD224D52644987797EF5AD3F2B335,
	CinemachineFixedSignal_AxisDuration_m722605DBBFEB163DC9787AD18CD8F7920121B0DC,
	CinemachineFixedSignal_GetSignal_m92E661706E11B9D9C231CE543903182387B01FA2,
	CinemachineFixedSignal_AxisValue_mADA40BCB50D24AFA3B306B3C21759DB00CB4116C,
	CinemachineFixedSignal__ctor_mBF0542616A9718A1756FDCC01BB94235B9DEE404,
	CinemachineImpulseDefinitionPropertyAttribute__ctor_mF66F03AD5A4EB4ECA78856EEAEE26142F522E1D1,
	CinemachineImpulseDefinition_OnValidate_mFA3F1DA4B88CBB26F7529483BAB1AFB7D1ACA39E,
	CinemachineImpulseDefinition_CreateEvent_m4321107CAE385B5FB027FBFF5DD5B7D5B034C783,
	CinemachineImpulseDefinition_CreateAndReturnEvent_mA242BCF220FF29B7BD481ECFD63485A8AE5F8220,
	CinemachineImpulseDefinition__ctor_mD30405D1F3CE7A681B0907945FB88F845C2FED85,
	SignalSource__ctor_mCB153F491DABCD71273BD63B24BF32099AEBEF80,
	SignalSource_get_SignalDuration_m361ECAF68816FA8EC16C6EF9644886A11CFAA837,
	SignalSource_GetSignal_m9A46E678A84820D6D5FC33F008DEC2DFCFB94DA1,
	CinemachineImpulseListener_Reset_mC94D85F68C6BDDE277ECCFE27B467DAEBE4F9CD4,
	CinemachineImpulseListener_PostPipelineStageCallback_m5DB0EB79B863014AEA4AD493E8989EB789B83119,
	CinemachineImpulseListener__ctor_m4D00191CF14DEA2304345E89ABF693D06026AF33,
	CinemachineImpulseEnvelopePropertyAttribute__ctor_m102C22E2CEE8BF51F3C95D3C751035320B1C8574,
	CinemachineImpulseChannelPropertyAttribute__ctor_mB2115A1DF97474375A0EF9E96301CF5273149443,
	CinemachineImpulseManager__ctor_m00612FBC540CE6AACDFECE7943168B27C2A3848F,
	CinemachineImpulseManager_get_Instance_m2610081DC5D98082D240CE3FD7C6C6CEAE571DE4,
	CinemachineImpulseManager_InitializeModule_m6DCF2F486EBEA933CC146F7476010FE2D598E0DF,
	CinemachineImpulseManager_GetImpulseAt_mD63748BEEF92691CD8962594BC86D8AACC6908D6,
	CinemachineImpulseManager_get_IgnoreTimeScale_m7286B8E9A54BE18D4D002F7824057EF9B4A6F581,
	CinemachineImpulseManager_set_IgnoreTimeScale_m734F8037EA5DDBAFEFE2AE02FE1AC87AD5FD333F,
	CinemachineImpulseManager_get_CurrentTime_mE6D6E38260F7F6CA352A44825C905F3CABC331ED,
	CinemachineImpulseManager_NewImpulseEvent_mF579A9519CE81229E765EFF552B4556FE8625198,
	CinemachineImpulseManager_AddImpulseEvent_m3C54AC87600E365FB98F0A8D43B6A1A0F96EA3C7,
	CinemachineImpulseManager_Clear_mA812D41CE685AADD048C6257BBC2EF82F0022F13,
	CinemachineImpulseManager__cctor_mA7E7C7140C2AF2C42811EC72E2B137314E583114,
	EnvelopeDefinition_Default_m6048BC0ADAE235D4D0F47D57AC6F07F8031E8502,
	EnvelopeDefinition_get_Duration_m494621ABECC584E355834D287BEA915BD68A774F,
	EnvelopeDefinition_GetValueAt_mA27AFC5D351DA50CA935ACCAB79D91F1E924C8CC,
	EnvelopeDefinition_ChangeStopTime_mA4D7614B6F56A8E279596B52252816EB59843F23,
	EnvelopeDefinition_Clear_m2B817953AFB7CDAA6B62AEC4A1E6A588484B554B,
	EnvelopeDefinition_Validate_mA0464BC35544052393B17674F751FAA755051B14,
	ImpulseEvent_get_Expired_m06944921FE1EEA9118BFAEE7F52E73280418DCA7,
	ImpulseEvent_Cancel_mA2831A11F90680EE32F4685E6311140D627C877B,
	ImpulseEvent_DistanceDecay_mF8C3C77FF46D6C2B23BE694CCA9714F76ED60036,
	ImpulseEvent_GetDecayedSignal_m973C1F0E6D32DC4DD14ECDF280FE58D14F6943EC,
	ImpulseEvent_Clear_m3FBD19A05EAC470ACE87FAC6CF8FCBBB01E278A2,
	ImpulseEvent__ctor_mBDBA49A0F06CCB22CAB3ADCFB3B62BB1EF812E53,
	CinemachineImpulseSource_OnValidate_m83C3BD911B9348F88DC2AE85D1DB974A8E10979D,
	CinemachineImpulseSource_GenerateImpulseAt_m0A99A6E18F64EB89296877D1A6816D72CB58CA3B,
	CinemachineImpulseSource_GenerateImpulse_mA0BA98729D31DAA4489F8A795460312C6AC987A0,
	CinemachineImpulseSource_GenerateImpulse_m2F8A5B9B2CB9F5A1F7E76D2034B8F6BBED59C083,
	CinemachineImpulseSource_GenerateImpulse_mED2BDD40C547E077E1DF815B796F382D4354F7FC,
	CinemachineImpulseSource__ctor_m9E80ACB84814DB64C13AD8DA4FEDAF89664D081D,
	CinemachineIndependentImpulseListener_Reset_mBCDD4E8A955637C2F86F03E77FD60522366EEF47,
	CinemachineIndependentImpulseListener_OnEnable_mB2F604C65010D97C7B9B49DE3EEEC2B2DD20595B,
	CinemachineIndependentImpulseListener_Update_mD29D193527AEFA832942DED9837FB503532A698F,
	CinemachineIndependentImpulseListener_LateUpdate_m1F8FA46BB2ABFD4EE0502A5D1A30B70E31B16971,
	CinemachineIndependentImpulseListener__ctor_m58D3A75F484AEBA326E4631720198ED751049A38,
	CinemachinePostProcessing_PostPipelineStageCallback_mBB56E45B7D4BBEAE04A420C99A3341E0EF7D1C24,
	CinemachinePostProcessing__ctor_m036C1F22C14AB44191F6715C831A6A10C39C64BF,
	CinemachineVolumeSettings__ctor_m62731AF7317EE4CE5CB2E4E624DCDE9D69EF7B06,
	CinemachineDebug_ReleaseScreenPos_mB86CBB15358DB61F1EE1FB14B1A75C22DF973EC1,
	CinemachineDebug_GetScreenPos_mDB9E3E780C465A8773B43312A6316F11789F31DB,
	CinemachineDebug_SBFromPool_mB6C8A1699C089516D0C30DB54FACEA9DE7BEBEE1,
	CinemachineDebug_ReturnToPool_mC5B15ABF0A1EAA33217EA6B204901D2817442704,
	CinemachineDebug__ctor_m34EA5A3E30773372406A3EFEFEAC4D512FBC53D1,
	OnGUIDelegate__ctor_m368CF0C4912A67D1DBDA8E1F2C2827D0163482FA,
	OnGUIDelegate_Invoke_mA31514C83F7C6B0DC124FB9C3C9AF1AE46EA3BE2,
	OnGUIDelegate_BeginInvoke_mB9DDADF15A39323C1F037853E3A73B2AB7697E33,
	OnGUIDelegate_EndInvoke_mA2E9D5AB93F6750402449BC316CB9F00CD0013F9,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	GaussianWindow1D_Vector3__ctor_m9F9F4D1099F38C2011F89481C3942BCF837A8C8F,
	GaussianWindow1D_Vector3_Compute_mC47257358568DEC6D1F06A2736F9FFE72840155A,
	GaussianWindow1D_Quaternion__ctor_m42734F192A050DB0229809115A08EB5B2ACFE2B8,
	GaussianWindow1D_Quaternion_Compute_m0E7848F46F6D124039571EC9E16E07F969B5A98D,
	GaussianWindow1D_CameraRotation__ctor_m4834B72F86867A703ECCA581EA7B7D1636BAA6ED,
	GaussianWindow1D_CameraRotation_Compute_mB07D3BAA51B60DCF8DCF738916D4A8F25D2851C4,
	PositionPredictor_get_Smoothing_mB2305254F86ADC44F77B967664A836A1E523903E,
	PositionPredictor_set_Smoothing_m4882C9C588E241A637B9E16A372B03DFD486EBB1,
	PositionPredictor_IsEmpty_mA2B45EC05F649C5F9720C228BFED71E8AD5F62B5,
	PositionPredictor_ApplyTransformDelta_m77976FB10046478DA8110E153218CB9AE00132A1,
	PositionPredictor_Reset_mB44898FC7B8E9B0A7F683840935E9BA00E699ADC,
	PositionPredictor_AddPosition_m1E539B2DB83AD523581841BF1D302643CE9275B3,
	PositionPredictor_PredictPositionDelta_m19C414F8AFAFC691F2FA995D77B0C694E8EDADDD,
	PositionPredictor_PredictPosition_mCD92F4061A05A405E45399C22D8E68E9DCA739B8,
	PositionPredictor__ctor_m4D6A0B4370D8836CEF0C54F233EE351EE2A8AEFA,
	Damper_DecayConstant_m90B73FBD9EFDFDADD53456DFBA5DC3FBD2A250B4,
	Damper_DecayedRemainder_mA1A4A25180833287B1EB3305763101321F042E46,
	Damper_Damp_mA12020431103076AB69C0FC03C4C07B388AD9E27,
	Damper_Damp_m62C13BEDD585C7DE73B4BDFBC28DDA00C4F89EEE,
	Damper_Damp_m5F27E39708AA38EF9CC7D888B6F3681813C0E6F0,
	HeadingTracker__ctor_mF6B909E191467A5BD7D4B982E751ADA11C4608D3,
	HeadingTracker_get_FilterSize_mC9A740BF0831E766A9425F01A72681EF912D08E8,
	HeadingTracker_ClearHistory_mDE5209EB31B87840F52B0407996951E343711389,
	HeadingTracker_Decay_mFC85AA39B403F52067DDECD6C488EFCBB7F38BE9,
	HeadingTracker_Add_m1895E709261177B40C99111534D777A3E484D517,
	HeadingTracker_PopBottom_m22630D7ACBCF2197BD86E73F987CF15812A1D2B5,
	HeadingTracker_DecayHistory_m192F30AA8475481505746C3ACE672088F9D76DBB,
	HeadingTracker_GetReliableHeading_m14DC7D8BBE3912362DF154EC669D9406A8597EF8,
	SplineHelpers_Bezier3_m671B7D546F16979F687B01A82D9239C0FF9A6C6F,
	SplineHelpers_BezierTangent3_m59375A4F9C985BC314131BC4286A02967A2A99B6,
	SplineHelpers_Bezier1_m01DF69C839E93F6D90E4CDE0E048DC8E5CEC2AE9,
	SplineHelpers_BezierTangent1_m6F265CBD431F2BDA6DBBFB16AD818D6EFA3D7690,
	SplineHelpers_ComputeSmoothControlPoints_mCBC6D06822574DCF0525832339422BCBA6AD899B,
	SplineHelpers_ComputeSmoothControlPointsLooped_mBD24C3CF63EA1ED0D83053C14DE95515C276DD5F,
	UnityVectorExtensions_IsNaN_mFD5E054EBD551DB8C1DAE365C72C31A37AA128FF,
	UnityVectorExtensions_IsNaN_m6EAD9206008E12BF8BC6F783809D488AC36AED4E,
	UnityVectorExtensions_ClosestPointOnSegment_m1BC07881406AD228FC3BD25F04DEEFCD844D0F03,
	UnityVectorExtensions_ClosestPointOnSegment_m2743E36D603D1321F3BF3F0FA76618D30CF48144,
	UnityVectorExtensions_ProjectOntoPlane_m8A4C6658A16D9A9E2415D787D52AF418133790D9,
	UnityVectorExtensions_SquareNormalize_m6A3571F61DF518AB665E7ECAA1F88B3E71D616A2,
	UnityVectorExtensions_FindIntersection_mD9BA155ECDA240120A4613F3CCB65385131D978E,
	UnityVectorExtensions_Cross_m3605AB9250A722AA2C53E27ADA17FE0983F5BF76,
	UnityVectorExtensions_Abs_m76EBBF98B625DB524BC7851ACB0201A6B4C5F348,
	UnityVectorExtensions_Abs_mF5BB01E967809EAD9B96646DB47CA4457CECB544,
	UnityVectorExtensions_IsUniform_m0A6BCC370C26C2C536B22030915BB3C3B96C47E3,
	UnityVectorExtensions_IsUniform_m0C6E99FC6DA9925EAFF5F0554727C4CDD8C4825B,
	UnityVectorExtensions_AlmostZero_m9F538E467290B6199EA350E4639400BF9984915B,
	UnityVectorExtensions_Angle_m04A32FB43E3D540CD85EF2A061C485A0EA1848F7,
	UnityVectorExtensions_SignedAngle_mD9BC7BAFD53B8BEE637C33AF52EAB09DFA45F939,
	UnityVectorExtensions_SafeFromToRotation_mF94D5E648352AB7EAF0B22D751DED6B1E4E54BD9,
	UnityVectorExtensions_SlerpWithReferenceUp_m141B1B05C8FD1F4D0C4349E9A80BCC72604F0A58,
	UnityQuaternionExtensions_SlerpWithReferenceUp_mB984001DA18FC2FF5035301F813B132AC999F1B6,
	UnityQuaternionExtensions_Normalized_m36AE449C35F60018BD511131B87E1A63D1B7DCA2,
	UnityQuaternionExtensions_GetCameraRotationToTarget_m744FC3EC6D163C8E4E5FD27AA9B83ADF321ED70F,
	UnityQuaternionExtensions_ApplyCameraRotation_m950CF054F6A2F4868E5D333046204FB7F016D2DF,
	UnityRectExtensions_Inflated_m07D1A88B141BFE8C3DB3D24ED9045D0D5AF21EB8,
};
extern void ShapeCache_Invalidate_m0AA1A789129A6F496BDB42C9914A48A80D0BB222_AdjustorThunk (void);
extern void ShapeCache_ValidateCache_mA040BB9D38360821A0D577FAA9520E12917B126C_AdjustorThunk (void);
extern void ShapeCache_IsValid_mD14BF34734A81849A719899A4F29ED241C21E25B_AdjustorThunk (void);
extern void ShapeCache_CalculateDeltaTransformationMatrix_m11C29D7572FAF3F20A15F7144F6D46E8A909E114_AdjustorThunk (void);
extern void Orbit__ctor_mBDC642CE7F3E574E43895420FD0343C3199FC85A_AdjustorThunk (void);
extern void Waypoint_get_AsVector4_m9CB420052E5FB5EA1681133222C5EB982BEA6BAC_AdjustorThunk (void);
extern void ParentHash__ctor_mFD2F0C557399C8A6C3798E3CDC0EB58B5E82A094_AdjustorThunk (void);
extern void FovCache_UpdateCache_m2EFDABF6DAFD0ACF434A8A83F5CAB0AA4B4F3519_AdjustorThunk (void);
extern void FovCache_ScreenToFOV_m813E0A11A9BEBC417751E33DA5E18A5A0DADFF2B_AdjustorThunk (void);
extern void Heading__ctor_m27AC6DA9204C9B4856DEA05AAAD89E2400FF639A_AdjustorThunk (void);
extern void AutoDolly__ctor_mB22E90A64C6D9D0F6C0F6FE794446F2867E76793_AdjustorThunk (void);
extern void AxisState__ctor_mE1E3449CB695DD0B97602DA2309969235F2AE8A0_AdjustorThunk (void);
extern void AxisState_Validate_mD31D13D5FBDA48541D62D25EBA58C6615141115C_AdjustorThunk (void);
extern void AxisState_Reset_m467FB333DF4E419185F468B80CD82F75C773A3FE_AdjustorThunk (void);
extern void AxisState_SetInputAxisProvider_m7396F12E659493FD37D66F79B04CF93D4BBDA527_AdjustorThunk (void);
extern void AxisState_get_HasInputProvider_m38460D72EBD97A207B33485CA157D6D4D3193226_AdjustorThunk (void);
extern void AxisState_Update_mEA3BADC4B491D705D61357CD1ECE295FC243670A_AdjustorThunk (void);
extern void AxisState_ClampValue_m44330844584E13D1E1921B6174DD5257CDFFA960_AdjustorThunk (void);
extern void AxisState_MaxSpeedUpdate_mC53D3EABA41652F2D991263538542FA23B8FB517_AdjustorThunk (void);
extern void AxisState_GetMaxSpeed_mE2AB97681281AA228333FC67BD9AB5F8CEA640AA_AdjustorThunk (void);
extern void AxisState_get_ValueRangeLocked_mAA8A098676C624D20443DC6207F7CE4268824369_AdjustorThunk (void);
extern void AxisState_set_ValueRangeLocked_m556066F839F1D835CFB65398E5D2776E74510F2A_AdjustorThunk (void);
extern void AxisState_get_HasRecentering_m02782E465AF3A314B2586C24230C03FBD609EB12_AdjustorThunk (void);
extern void AxisState_set_HasRecentering_m30D6476F657160F87D850632F36DA226C04FCDE6_AdjustorThunk (void);
extern void Recentering__ctor_mDFE3D3BB932AF426369B033D18AD3FDAAF26384F_AdjustorThunk (void);
extern void Recentering_Validate_mFB967BB954EFD0DD6E2315F53A3241FDC146B18A_AdjustorThunk (void);
extern void Recentering_CopyStateFrom_mE18BDABB9C0A8D71903C3173B9783435DDE64918_AdjustorThunk (void);
extern void Recentering_CancelRecentering_m49877C0EBC7D9873C40CABD8EEF245954703CEC2_AdjustorThunk (void);
extern void Recentering_RecenterNow_mB95BFD6D292191AB019A574F835AE4FB2A5ECD54_AdjustorThunk (void);
extern void Recentering_DoRecentering_mA1AB5ACE77B56D9357CBB46FB4BEAF42AED5CD6C_AdjustorThunk (void);
extern void Recentering_LegacyUpgrade_mE331A7312B51DE3F31805A89EC3E4EB9DF71567E_AdjustorThunk (void);
extern void CameraState_get_Lens_m8DD7FD2B8954A56E2CBD83D1EF7A77958F685893_AdjustorThunk (void);
extern void CameraState_set_Lens_mAABE6FFC1E5F9A33EE16A7B009B927ECB2F29523_AdjustorThunk (void);
extern void CameraState_get_ReferenceUp_m9A1F4A533328BABA7C81C4AD2F1E830375495B5A_AdjustorThunk (void);
extern void CameraState_set_ReferenceUp_mE156A37CA4B6BF3E8BA65A391730873572F24358_AdjustorThunk (void);
extern void CameraState_get_ReferenceLookAt_m32BCDF0492BA9AAECC597DF02676D66BF0566548_AdjustorThunk (void);
extern void CameraState_set_ReferenceLookAt_mF7CF3F3DD4D8DA16C08C4706E6C1128B48A3CEA2_AdjustorThunk (void);
extern void CameraState_get_HasLookAt_mE3BC5114383606752FDDED488732126B5644E81D_AdjustorThunk (void);
extern void CameraState_get_RawPosition_mA01BC7F842C837D49F0542A0475AE0EA9C88539D_AdjustorThunk (void);
extern void CameraState_set_RawPosition_m0E1142A79939C7AD7156986F91CD0F1D60499A31_AdjustorThunk (void);
extern void CameraState_get_RawOrientation_m61C0AC1D87FB6C869DA02458732BF6023130F163_AdjustorThunk (void);
extern void CameraState_set_RawOrientation_mF473C9D14F4C653E31B9D17B29198A0A26FB710E_AdjustorThunk (void);
extern void CameraState_get_PositionDampingBypass_m4F3CAC6077C7D9CE366DE64FDC0F76B8E4309965_AdjustorThunk (void);
extern void CameraState_set_PositionDampingBypass_m6ED6EE6829EAD07FB68F3281F682360F9E0B5707_AdjustorThunk (void);
extern void CameraState_get_ShotQuality_m3FE037E90A92A214DAEEA694D75ECF717520E285_AdjustorThunk (void);
extern void CameraState_set_ShotQuality_m02E14BA3BB2628501258190348C309AF56836E3B_AdjustorThunk (void);
extern void CameraState_get_PositionCorrection_m19DFDEC5E34379495FE563689462063CF01CC87B_AdjustorThunk (void);
extern void CameraState_set_PositionCorrection_m5A6BC8785013D7DA1B8B814BEA2FB2893C8D681B_AdjustorThunk (void);
extern void CameraState_get_OrientationCorrection_m50B2841F1C1C41B276CE76048DBE68CC355EBE9E_AdjustorThunk (void);
extern void CameraState_set_OrientationCorrection_m78B62F6D9C90041D16F969BF5C5DF5775380F4E3_AdjustorThunk (void);
extern void CameraState_get_CorrectedPosition_mFEB78C718574311BE01F52353220D8E3EC062344_AdjustorThunk (void);
extern void CameraState_get_CorrectedOrientation_mB74864040A12CF81360C263385AE1CFFFA73E9BB_AdjustorThunk (void);
extern void CameraState_get_FinalPosition_mABA119F4F7BDAB3C56B5A9D50A0A4E9F0EC5BFBA_AdjustorThunk (void);
extern void CameraState_get_FinalOrientation_m44213894D5B3665846C120EA54FD5F116FBBBC40_AdjustorThunk (void);
extern void CameraState_get_BlendHint_m787612D5DE9717F032149B538F603DA69B26FC75_AdjustorThunk (void);
extern void CameraState_set_BlendHint_mFEAA3F666F38C388C5CCF863FF3711CEEE3A0A52_AdjustorThunk (void);
extern void CameraState_get_NumCustomBlendables_m45122BC6F6592ACC07FD85C38B3A756FEC60A7CF_AdjustorThunk (void);
extern void CameraState_set_NumCustomBlendables_mF90E1B32FE572F25B187D449C5AEE2499AAE564F_AdjustorThunk (void);
extern void CameraState_GetCustomBlendable_mD4E4CD7E5D2F4ABF74B78B4997BEA73C65C704BF_AdjustorThunk (void);
extern void CameraState_FindCustomBlendable_mADB6FC113F422BEEA9B9DE3CCEAA69C505BEEDAC_AdjustorThunk (void);
extern void CameraState_AddCustomBlendable_mD2B67C82217C56D550713328D287282A0548CD97_AdjustorThunk (void);
extern void CameraState_InterpolatePosition_m731CF3321931B836BFF7D6025001E0DBDBBF8341_AdjustorThunk (void);
extern void CustomBlendable__ctor_mA7DEF75ACB9FDE678221EF6176FBD4DC4441FB07_AdjustorThunk (void);
extern void CinemachineBlendDefinition_get_BlendTime_m2185E8662569BE0201996EAA3AC55C1A095CA5E3_AdjustorThunk (void);
extern void CinemachineBlendDefinition__ctor_m51379366ABFBFF4642735E6C843F54CF45D642CF_AdjustorThunk (void);
extern void CinemachineBlendDefinition_CreateStandardCurves_m4877FF63D3A4E8933F6817ECAEB9B500B9A3D56B_AdjustorThunk (void);
extern void CinemachineBlendDefinition_get_BlendCurve_m547D15706E83EACB4DE888750C0728BDE5974873_AdjustorThunk (void);
extern void AxisBase_Validate_mEEA2E671C4CE0548BEA394B5598EA51929E7D33A_AdjustorThunk (void);
extern void CinemachineInputAxisDriver_Validate_m144628F55B154073CD729EE89A3F87217FC01173_AdjustorThunk (void);
extern void CinemachineInputAxisDriver_Update_mCF849BA78D16DF068F7723E78D6BC171890AB4CA_AdjustorThunk (void);
extern void CinemachineInputAxisDriver_Update_mB3570630DFFA0617C1E132A764E902F2848DF810_AdjustorThunk (void);
extern void CinemachineInputAxisDriver_ClampValue_m1C0996D4C9242ACB7615CDE6C7C4BE9D39B341AF_AdjustorThunk (void);
extern void AspectStretcher_get_Aspect_m5F122CB5941347F158A1AAC93BA287C20EE6A5CB_AdjustorThunk (void);
extern void AspectStretcher__ctor_mDCB6211AC6DD9E121C1936D1CA89A59992810250_AdjustorThunk (void);
extern void AspectStretcher_Stretch_mBF0EC7D7CB450374BBB47AE0ECE58FDD605FBA36_AdjustorThunk (void);
extern void AspectStretcher_Unstretch_m6C6ABFB166BF2BC9B4DBDF3B2057018DE19013D6_AdjustorThunk (void);
extern void PolygonSolution_StateChanged_m4F55923D1FF840A66DED34E00ABC163A4870674F_AdjustorThunk (void);
extern void PolygonSolution_get_IsEmpty_mCA5809BECBE372CE603DC4E4C7E5873309A50196_AdjustorThunk (void);
extern void LensSettings_get_Orthographic_mD89E6548BD05054F1ADFF7CB767ADCBA147970A0_AdjustorThunk (void);
extern void LensSettings_set_Orthographic_m17D40EA48E03E6E1D1FCBC23FCC01599BD7DEC0F_AdjustorThunk (void);
extern void LensSettings_get_SensorSize_mED4695A443BA5CD05E9BF20A8B435B9CEAF56F56_AdjustorThunk (void);
extern void LensSettings_set_SensorSize_mCF61646CF243535A7A0FE1C18D187D68F76AA849_AdjustorThunk (void);
extern void LensSettings_get_Aspect_m9CC9D04C1503CE0708B7E8D7918D51E6D105CBA6_AdjustorThunk (void);
extern void LensSettings_get_IsPhysicalCamera_m51B84703CAE764F7D3F7E581D6374080F3065891_AdjustorThunk (void);
extern void LensSettings_set_IsPhysicalCamera_mAD4EF6D6C68EC05EC70CF69FBD4B186BAEEAEE8D_AdjustorThunk (void);
extern void LensSettings_SnapshotCameraReadOnlyProperties_mBE8E0F11CA4B7B16A6FB8C6C0EAD3215BD18F952_AdjustorThunk (void);
extern void LensSettings_SnapshotCameraReadOnlyProperties_m1AF99FBBE30EEDEAAFB4F7C6EBC63C4F7BFE0E5D_AdjustorThunk (void);
extern void LensSettings__ctor_m33701EC0CE3BE15F0CC8BC926D4BB090D59FD206_AdjustorThunk (void);
extern void LensSettings_Validate_mB36D902613DCFA1D4F31A16CDB87FE2AB23570AF_AdjustorThunk (void);
extern void NoiseParams_GetValueAt_mA2C1E6FA7AE9AB3FC9A51024E0D474E5C8596610_AdjustorThunk (void);
extern void TransformNoiseParams_GetValueAt_m89FDF2289D147DC0B617426E76A78402474770CD_AdjustorThunk (void);
extern void TimeRange_get_IsEmpty_m0EBE2CFDA395E03444770956D336B17D2CC676D0_AdjustorThunk (void);
extern void TimeRange_Contains_m2FE15B3333F2883C0580220A5D3FDE954533A8FA_AdjustorThunk (void);
extern void TimeRange_Include_m98B368672B3FAD811027079C3EA8236914D3729E_AdjustorThunk (void);
extern void ActionSettings__ctor_mD581917562ECC8295F6278BA5AD001705F8E9035_AdjustorThunk (void);
extern void ActionSettings_Invoke_mF3E35400963944A72FD025FEF8052413056DC716_AdjustorThunk (void);
extern void EnvelopeDefinition_get_Duration_m494621ABECC584E355834D287BEA915BD68A774F_AdjustorThunk (void);
extern void EnvelopeDefinition_GetValueAt_mA27AFC5D351DA50CA935ACCAB79D91F1E924C8CC_AdjustorThunk (void);
extern void EnvelopeDefinition_ChangeStopTime_mA4D7614B6F56A8E279596B52252816EB59843F23_AdjustorThunk (void);
extern void EnvelopeDefinition_Clear_m2B817953AFB7CDAA6B62AEC4A1E6A588484B554B_AdjustorThunk (void);
extern void EnvelopeDefinition_Validate_mA0464BC35544052393B17674F751FAA755051B14_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[101] = 
{
	{ 0x060000B7, ShapeCache_Invalidate_m0AA1A789129A6F496BDB42C9914A48A80D0BB222_AdjustorThunk },
	{ 0x060000B8, ShapeCache_ValidateCache_mA040BB9D38360821A0D577FAA9520E12917B126C_AdjustorThunk },
	{ 0x060000B9, ShapeCache_IsValid_mD14BF34734A81849A719899A4F29ED241C21E25B_AdjustorThunk },
	{ 0x060000BA, ShapeCache_CalculateDeltaTransformationMatrix_m11C29D7572FAF3F20A15F7144F6D46E8A909E114_AdjustorThunk },
	{ 0x060000EF, Orbit__ctor_mBDC642CE7F3E574E43895420FD0343C3199FC85A_AdjustorThunk },
	{ 0x0600012B, Waypoint_get_AsVector4_m9CB420052E5FB5EA1681133222C5EB982BEA6BAC_AdjustorThunk },
	{ 0x0600014B, ParentHash__ctor_mFD2F0C557399C8A6C3798E3CDC0EB58B5E82A094_AdjustorThunk },
	{ 0x060001C3, FovCache_UpdateCache_m2EFDABF6DAFD0ACF434A8A83F5CAB0AA4B4F3519_AdjustorThunk },
	{ 0x060001C4, FovCache_ScreenToFOV_m813E0A11A9BEBC417751E33DA5E18A5A0DADFF2B_AdjustorThunk },
	{ 0x06000204, Heading__ctor_m27AC6DA9204C9B4856DEA05AAAD89E2400FF639A_AdjustorThunk },
	{ 0x06000225, AutoDolly__ctor_mB22E90A64C6D9D0F6C0F6FE794446F2867E76793_AdjustorThunk },
	{ 0x06000238, AxisState__ctor_mE1E3449CB695DD0B97602DA2309969235F2AE8A0_AdjustorThunk },
	{ 0x06000239, AxisState_Validate_mD31D13D5FBDA48541D62D25EBA58C6615141115C_AdjustorThunk },
	{ 0x0600023A, AxisState_Reset_m467FB333DF4E419185F468B80CD82F75C773A3FE_AdjustorThunk },
	{ 0x0600023B, AxisState_SetInputAxisProvider_m7396F12E659493FD37D66F79B04CF93D4BBDA527_AdjustorThunk },
	{ 0x0600023C, AxisState_get_HasInputProvider_m38460D72EBD97A207B33485CA157D6D4D3193226_AdjustorThunk },
	{ 0x0600023D, AxisState_Update_mEA3BADC4B491D705D61357CD1ECE295FC243670A_AdjustorThunk },
	{ 0x0600023E, AxisState_ClampValue_m44330844584E13D1E1921B6174DD5257CDFFA960_AdjustorThunk },
	{ 0x0600023F, AxisState_MaxSpeedUpdate_mC53D3EABA41652F2D991263538542FA23B8FB517_AdjustorThunk },
	{ 0x06000240, AxisState_GetMaxSpeed_mE2AB97681281AA228333FC67BD9AB5F8CEA640AA_AdjustorThunk },
	{ 0x06000241, AxisState_get_ValueRangeLocked_mAA8A098676C624D20443DC6207F7CE4268824369_AdjustorThunk },
	{ 0x06000242, AxisState_set_ValueRangeLocked_m556066F839F1D835CFB65398E5D2776E74510F2A_AdjustorThunk },
	{ 0x06000243, AxisState_get_HasRecentering_m02782E465AF3A314B2586C24230C03FBD609EB12_AdjustorThunk },
	{ 0x06000244, AxisState_set_HasRecentering_m30D6476F657160F87D850632F36DA226C04FCDE6_AdjustorThunk },
	{ 0x06000246, Recentering__ctor_mDFE3D3BB932AF426369B033D18AD3FDAAF26384F_AdjustorThunk },
	{ 0x06000247, Recentering_Validate_mFB967BB954EFD0DD6E2315F53A3241FDC146B18A_AdjustorThunk },
	{ 0x06000248, Recentering_CopyStateFrom_mE18BDABB9C0A8D71903C3173B9783435DDE64918_AdjustorThunk },
	{ 0x06000249, Recentering_CancelRecentering_m49877C0EBC7D9873C40CABD8EEF245954703CEC2_AdjustorThunk },
	{ 0x0600024A, Recentering_RecenterNow_mB95BFD6D292191AB019A574F835AE4FB2A5ECD54_AdjustorThunk },
	{ 0x0600024B, Recentering_DoRecentering_mA1AB5ACE77B56D9357CBB46FB4BEAF42AED5CD6C_AdjustorThunk },
	{ 0x0600024C, Recentering_LegacyUpgrade_mE331A7312B51DE3F31805A89EC3E4EB9DF71567E_AdjustorThunk },
	{ 0x0600024D, CameraState_get_Lens_m8DD7FD2B8954A56E2CBD83D1EF7A77958F685893_AdjustorThunk },
	{ 0x0600024E, CameraState_set_Lens_mAABE6FFC1E5F9A33EE16A7B009B927ECB2F29523_AdjustorThunk },
	{ 0x0600024F, CameraState_get_ReferenceUp_m9A1F4A533328BABA7C81C4AD2F1E830375495B5A_AdjustorThunk },
	{ 0x06000250, CameraState_set_ReferenceUp_mE156A37CA4B6BF3E8BA65A391730873572F24358_AdjustorThunk },
	{ 0x06000251, CameraState_get_ReferenceLookAt_m32BCDF0492BA9AAECC597DF02676D66BF0566548_AdjustorThunk },
	{ 0x06000252, CameraState_set_ReferenceLookAt_mF7CF3F3DD4D8DA16C08C4706E6C1128B48A3CEA2_AdjustorThunk },
	{ 0x06000253, CameraState_get_HasLookAt_mE3BC5114383606752FDDED488732126B5644E81D_AdjustorThunk },
	{ 0x06000254, CameraState_get_RawPosition_mA01BC7F842C837D49F0542A0475AE0EA9C88539D_AdjustorThunk },
	{ 0x06000255, CameraState_set_RawPosition_m0E1142A79939C7AD7156986F91CD0F1D60499A31_AdjustorThunk },
	{ 0x06000256, CameraState_get_RawOrientation_m61C0AC1D87FB6C869DA02458732BF6023130F163_AdjustorThunk },
	{ 0x06000257, CameraState_set_RawOrientation_mF473C9D14F4C653E31B9D17B29198A0A26FB710E_AdjustorThunk },
	{ 0x06000258, CameraState_get_PositionDampingBypass_m4F3CAC6077C7D9CE366DE64FDC0F76B8E4309965_AdjustorThunk },
	{ 0x06000259, CameraState_set_PositionDampingBypass_m6ED6EE6829EAD07FB68F3281F682360F9E0B5707_AdjustorThunk },
	{ 0x0600025A, CameraState_get_ShotQuality_m3FE037E90A92A214DAEEA694D75ECF717520E285_AdjustorThunk },
	{ 0x0600025B, CameraState_set_ShotQuality_m02E14BA3BB2628501258190348C309AF56836E3B_AdjustorThunk },
	{ 0x0600025C, CameraState_get_PositionCorrection_m19DFDEC5E34379495FE563689462063CF01CC87B_AdjustorThunk },
	{ 0x0600025D, CameraState_set_PositionCorrection_m5A6BC8785013D7DA1B8B814BEA2FB2893C8D681B_AdjustorThunk },
	{ 0x0600025E, CameraState_get_OrientationCorrection_m50B2841F1C1C41B276CE76048DBE68CC355EBE9E_AdjustorThunk },
	{ 0x0600025F, CameraState_set_OrientationCorrection_m78B62F6D9C90041D16F969BF5C5DF5775380F4E3_AdjustorThunk },
	{ 0x06000260, CameraState_get_CorrectedPosition_mFEB78C718574311BE01F52353220D8E3EC062344_AdjustorThunk },
	{ 0x06000261, CameraState_get_CorrectedOrientation_mB74864040A12CF81360C263385AE1CFFFA73E9BB_AdjustorThunk },
	{ 0x06000262, CameraState_get_FinalPosition_mABA119F4F7BDAB3C56B5A9D50A0A4E9F0EC5BFBA_AdjustorThunk },
	{ 0x06000263, CameraState_get_FinalOrientation_m44213894D5B3665846C120EA54FD5F116FBBBC40_AdjustorThunk },
	{ 0x06000264, CameraState_get_BlendHint_m787612D5DE9717F032149B538F603DA69B26FC75_AdjustorThunk },
	{ 0x06000265, CameraState_set_BlendHint_mFEAA3F666F38C388C5CCF863FF3711CEEE3A0A52_AdjustorThunk },
	{ 0x06000267, CameraState_get_NumCustomBlendables_m45122BC6F6592ACC07FD85C38B3A756FEC60A7CF_AdjustorThunk },
	{ 0x06000268, CameraState_set_NumCustomBlendables_mF90E1B32FE572F25B187D449C5AEE2499AAE564F_AdjustorThunk },
	{ 0x06000269, CameraState_GetCustomBlendable_mD4E4CD7E5D2F4ABF74B78B4997BEA73C65C704BF_AdjustorThunk },
	{ 0x0600026A, CameraState_FindCustomBlendable_mADB6FC113F422BEEA9B9DE3CCEAA69C505BEEDAC_AdjustorThunk },
	{ 0x0600026B, CameraState_AddCustomBlendable_mD2B67C82217C56D550713328D287282A0548CD97_AdjustorThunk },
	{ 0x06000270, CameraState_InterpolatePosition_m731CF3321931B836BFF7D6025001E0DBDBBF8341_AdjustorThunk },
	{ 0x06000272, CustomBlendable__ctor_mA7DEF75ACB9FDE678221EF6176FBD4DC4441FB07_AdjustorThunk },
	{ 0x06000285, CinemachineBlendDefinition_get_BlendTime_m2185E8662569BE0201996EAA3AC55C1A095CA5E3_AdjustorThunk },
	{ 0x06000286, CinemachineBlendDefinition__ctor_m51379366ABFBFF4642735E6C843F54CF45D642CF_AdjustorThunk },
	{ 0x06000287, CinemachineBlendDefinition_CreateStandardCurves_m4877FF63D3A4E8933F6817ECAEB9B500B9A3D56B_AdjustorThunk },
	{ 0x06000288, CinemachineBlendDefinition_get_BlendCurve_m547D15706E83EACB4DE888750C0728BDE5974873_AdjustorThunk },
	{ 0x06000307, AxisBase_Validate_mEEA2E671C4CE0548BEA394B5598EA51929E7D33A_AdjustorThunk },
	{ 0x06000308, CinemachineInputAxisDriver_Validate_m144628F55B154073CD729EE89A3F87217FC01173_AdjustorThunk },
	{ 0x06000309, CinemachineInputAxisDriver_Update_mCF849BA78D16DF068F7723E78D6BC171890AB4CA_AdjustorThunk },
	{ 0x0600030A, CinemachineInputAxisDriver_Update_mB3570630DFFA0617C1E132A764E902F2848DF810_AdjustorThunk },
	{ 0x0600030B, CinemachineInputAxisDriver_ClampValue_m1C0996D4C9242ACB7615CDE6C7C4BE9D39B341AF_AdjustorThunk },
	{ 0x0600037E, AspectStretcher_get_Aspect_m5F122CB5941347F158A1AAC93BA287C20EE6A5CB_AdjustorThunk },
	{ 0x0600037F, AspectStretcher__ctor_mDCB6211AC6DD9E121C1936D1CA89A59992810250_AdjustorThunk },
	{ 0x06000380, AspectStretcher_Stretch_mBF0EC7D7CB450374BBB47AE0ECE58FDD605FBA36_AdjustorThunk },
	{ 0x06000381, AspectStretcher_Unstretch_m6C6ABFB166BF2BC9B4DBDF3B2057018DE19013D6_AdjustorThunk },
	{ 0x06000382, PolygonSolution_StateChanged_m4F55923D1FF840A66DED34E00ABC163A4870674F_AdjustorThunk },
	{ 0x06000383, PolygonSolution_get_IsEmpty_mCA5809BECBE372CE603DC4E4C7E5873309A50196_AdjustorThunk },
	{ 0x06000395, LensSettings_get_Orthographic_mD89E6548BD05054F1ADFF7CB767ADCBA147970A0_AdjustorThunk },
	{ 0x06000396, LensSettings_set_Orthographic_m17D40EA48E03E6E1D1FCBC23FCC01599BD7DEC0F_AdjustorThunk },
	{ 0x06000397, LensSettings_get_SensorSize_mED4695A443BA5CD05E9BF20A8B435B9CEAF56F56_AdjustorThunk },
	{ 0x06000398, LensSettings_set_SensorSize_mCF61646CF243535A7A0FE1C18D187D68F76AA849_AdjustorThunk },
	{ 0x06000399, LensSettings_get_Aspect_m9CC9D04C1503CE0708B7E8D7918D51E6D105CBA6_AdjustorThunk },
	{ 0x0600039A, LensSettings_get_IsPhysicalCamera_m51B84703CAE764F7D3F7E581D6374080F3065891_AdjustorThunk },
	{ 0x0600039B, LensSettings_set_IsPhysicalCamera_mAD4EF6D6C68EC05EC70CF69FBD4B186BAEEAEE8D_AdjustorThunk },
	{ 0x0600039D, LensSettings_SnapshotCameraReadOnlyProperties_mBE8E0F11CA4B7B16A6FB8C6C0EAD3215BD18F952_AdjustorThunk },
	{ 0x0600039E, LensSettings_SnapshotCameraReadOnlyProperties_m1AF99FBBE30EEDEAAFB4F7C6EBC63C4F7BFE0E5D_AdjustorThunk },
	{ 0x0600039F, LensSettings__ctor_m33701EC0CE3BE15F0CC8BC926D4BB090D59FD206_AdjustorThunk },
	{ 0x060003A1, LensSettings_Validate_mB36D902613DCFA1D4F31A16CDB87FE2AB23570AF_AdjustorThunk },
	{ 0x060003A7, NoiseParams_GetValueAt_mA2C1E6FA7AE9AB3FC9A51024E0D474E5C8596610_AdjustorThunk },
	{ 0x060003A8, TransformNoiseParams_GetValueAt_m89FDF2289D147DC0B617426E76A78402474770CD_AdjustorThunk },
	{ 0x060003D4, TimeRange_get_IsEmpty_m0EBE2CFDA395E03444770956D336B17D2CC676D0_AdjustorThunk },
	{ 0x060003D5, TimeRange_Contains_m2FE15B3333F2883C0580220A5D3FDE954533A8FA_AdjustorThunk },
	{ 0x060003D7, TimeRange_Include_m98B368672B3FAD811027079C3EA8236914D3729E_AdjustorThunk },
	{ 0x060003F5, ActionSettings__ctor_mD581917562ECC8295F6278BA5AD001705F8E9035_AdjustorThunk },
	{ 0x060003F6, ActionSettings_Invoke_mF3E35400963944A72FD025FEF8052413056DC716_AdjustorThunk },
	{ 0x06000426, EnvelopeDefinition_get_Duration_m494621ABECC584E355834D287BEA915BD68A774F_AdjustorThunk },
	{ 0x06000427, EnvelopeDefinition_GetValueAt_mA27AFC5D351DA50CA935ACCAB79D91F1E924C8CC_AdjustorThunk },
	{ 0x06000428, EnvelopeDefinition_ChangeStopTime_mA4D7614B6F56A8E279596B52252816EB59843F23_AdjustorThunk },
	{ 0x06000429, EnvelopeDefinition_Clear_m2B817953AFB7CDAA6B62AEC4A1E6A588484B554B_AdjustorThunk },
	{ 0x0600042A, EnvelopeDefinition_Validate_mA0464BC35544052393B17674F751FAA755051B14_AdjustorThunk },
};
static const int32_t s_InvokerIndices[1165] = 
{
	3277,
	3277,
	468,
	3277,
	3277,
	3277,
	716,
	468,
	3277,
	3277,
	2334,
	3277,
	2584,
	1423,
	752,
	2336,
	3277,
	1407,
	3207,
	924,
	1951,
	933,
	1409,
	3277,
	3235,
	3277,
	582,
	3277,
	3277,
	3277,
	634,
	2580,
	2391,
	468,
	3277,
	3207,
	3277,
	2580,
	3207,
	1003,
	3134,
	3207,
	2580,
	3207,
	2580,
	1419,
	1449,
	751,
	3207,
	2580,
	1450,
	3277,
	3277,
	3277,
	3277,
	3207,
	3235,
	3277,
	3277,
	3277,
	2606,
	3277,
	3207,
	5060,
	4980,
	5036,
	3271,
	3277,
	3277,
	1433,
	2604,
	3277,
	3277,
	3207,
	3277,
	3277,
	2335,
	1273,
	3207,
	4861,
	3235,
	3207,
	1751,
	144,
	2562,
	2606,
	2606,
	1113,
	1003,
	3134,
	2507,
	3207,
	788,
	2502,
	3277,
	5090,
	3277,
	3277,
	3235,
	3277,
	2562,
	3277,
	3235,
	3207,
	3277,
	3207,
	3207,
	2580,
	3207,
	3134,
	1003,
	3207,
	2580,
	3207,
	2580,
	1419,
	1449,
	1450,
	3277,
	3277,
	3277,
	3277,
	3235,
	3207,
	3277,
	3277,
	3277,
	1960,
	1951,
	788,
	751,
	3207,
	2580,
	3277,
	5090,
	3277,
	869,
	2180,
	2180,
	2334,
	3277,
	3277,
	3207,
	3239,
	468,
	1099,
	418,
	29,
	412,
	415,
	653,
	5090,
	1103,
	2108,
	2108,
	3277,
	2638,
	1090,
	1439,
	2606,
	3277,
	2180,
	2334,
	3277,
	2602,
	3235,
	3239,
	468,
	3277,
	3235,
	2391,
	1100,
	3277,
	3277,
	3277,
	2210,
	468,
	1078,
	3277,
	3277,
	3277,
	3277,
	3277,
	397,
	588,
	3277,
	3277,
	3277,
	3277,
	2606,
	3277,
	3134,
	3207,
	2580,
	3207,
	2580,
	1450,
	3277,
	3277,
	3239,
	468,
	3277,
	3277,
	3277,
	1945,
	5060,
	3277,
	3277,
	3277,
	3277,
	3277,
	3235,
	2602,
	3134,
	3207,
	2580,
	3207,
	2580,
	1003,
	1419,
	1449,
	1450,
	751,
	1091,
	3277,
	3277,
	1951,
	3277,
	839,
	3239,
	2606,
	652,
	3277,
	3239,
	786,
	2389,
	3277,
	3277,
	1439,
	1407,
	571,
	163,
	1951,
	1407,
	2580,
	571,
	2580,
	2333,
	1273,
	2334,
	1414,
	2580,
	3207,
	3134,
	3207,
	2580,
	3207,
	2580,
	1419,
	1449,
	3277,
	3277,
	3277,
	1003,
	3207,
	3277,
	3277,
	751,
	1450,
	3277,
	3239,
	3239,
	3235,
	3277,
	3188,
	654,
	2389,
	2389,
	1980,
	3277,
	3277,
	3277,
	468,
	3277,
	3239,
	3239,
	3235,
	3188,
	3277,
	3277,
	3277,
	3277,
	654,
	2389,
	2389,
	1980,
	1980,
	3277,
	3273,
	4991,
	3207,
	2580,
	3207,
	1003,
	3134,
	3207,
	2580,
	3207,
	2580,
	1419,
	1449,
	751,
	3207,
	2580,
	1450,
	3277,
	3277,
	3277,
	3277,
	3207,
	3235,
	4325,
	826,
	3277,
	3277,
	3277,
	3207,
	826,
	788,
	3277,
	1241,
	468,
	2602,
	3207,
	2580,
	925,
	2580,
	3277,
	1414,
	4980,
	5090,
	3277,
	3277,
	3207,
	3132,
	3131,
	3235,
	1568,
	461,
	3207,
	3132,
	2506,
	3131,
	3235,
	750,
	2580,
	1765,
	1566,
	1568,
	3969,
	3277,
	1567,
	2386,
	3220,
	784,
	3277,
	3277,
	3277,
	3277,
	461,
	3277,
	3134,
	3207,
	2580,
	3207,
	2580,
	3239,
	1450,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	1951,
	3277,
	3207,
	3207,
	1945,
	-1,
	-1,
	-1,
	3235,
	2602,
	3277,
	4980,
	786,
	1419,
	1449,
	2638,
	751,
	3277,
	1407,
	571,
	163,
	1951,
	1407,
	2580,
	571,
	2580,
	5090,
	3277,
	838,
	3277,
	3277,
	3277,
	3235,
	3188,
	3239,
	1118,
	1419,
	1118,
	667,
	938,
	237,
	664,
	3277,
	3235,
	3188,
	1118,
	3277,
	3277,
	3277,
	3235,
	3188,
	3271,
	2638,
	664,
	1419,
	1449,
	3239,
	1118,
	1118,
	3225,
	2597,
	3225,
	2597,
	55,
	379,
	3277,
	460,
	375,
	3225,
	2597,
	3225,
	2597,
	3277,
	3235,
	3188,
	3235,
	3271,
	2638,
	1419,
	1449,
	3239,
	398,
	3235,
	2602,
	586,
	1106,
	3132,
	2506,
	3202,
	2575,
	1118,
	2338,
	1100,
	3970,
	3277,
	3277,
	3132,
	2506,
	3202,
	2575,
	3239,
	1118,
	2338,
	3971,
	3277,
	3235,
	3188,
	3239,
	1118,
	3277,
	3235,
	3188,
	1118,
	3277,
	3277,
	656,
	180,
	3277,
	3277,
	3207,
	2580,
	1419,
	1449,
	398,
	1091,
	3239,
	2606,
	1118,
	2391,
	1089,
	3277,
	695,
	1407,
	652,
	166,
	2334,
	5090,
	3277,
	652,
	3235,
	3188,
	3277,
	3277,
	3277,
	1118,
	1118,
	3269,
	4942,
	1449,
	398,
	2592,
	3277,
	3235,
	3188,
	3239,
	1118,
	3277,
	3235,
	3188,
	3239,
	1118,
	936,
	3271,
	3277,
	510,
	3277,
	3235,
	2602,
	3271,
	3235,
	3188,
	3239,
	1118,
	1419,
	1449,
	1118,
	236,
	182,
	3271,
	3271,
	2391,
	1981,
	3277,
	21,
	3277,
	3277,
	1256,
	3235,
	2210,
	2336,
	1020,
	3239,
	3235,
	2602,
	3235,
	2602,
	2333,
	764,
	3277,
	2502,
	3277,
	3277,
	676,
	950,
	3198,
	2572,
	3271,
	2638,
	3271,
	2638,
	3235,
	3271,
	2638,
	3220,
	2592,
	3271,
	2638,
	3239,
	2606,
	3271,
	2638,
	3220,
	2592,
	3271,
	3220,
	3271,
	3220,
	3188,
	2562,
	5034,
	3188,
	2562,
	2741,
	1765,
	2652,
	3972,
	3621,
	3469,
	3450,
	181,
	5090,
	1414,
	3207,
	2580,
	3207,
	2580,
	3207,
	2580,
	3239,
	2606,
	3239,
	3235,
	3239,
	2606,
	3235,
	3207,
	2180,
	225,
	1450,
	3134,
	3239,
	1273,
	3277,
	3207,
	1121,
	2507,
	3207,
	2580,
	3207,
	3188,
	2562,
	3207,
	2580,
	3207,
	2580,
	3134,
	2507,
	3207,
	3235,
	3207,
	1003,
	1450,
	1450,
	751,
	1419,
	2580,
	3207,
	2580,
	3207,
	3207,
	3188,
	2562,
	3207,
	2580,
	3207,
	2580,
	3134,
	2507,
	3207,
	3235,
	3207,
	1003,
	1570,
	1450,
	1450,
	751,
	1419,
	521,
	3277,
	3207,
	3207,
	3207,
	3277,
	3207,
	3207,
	3271,
	3220,
	3277,
	3207,
	3207,
	3271,
	3220,
	3134,
	3235,
	1118,
	3188,
	3235,
	1118,
	398,
	1419,
	1449,
	3239,
	3277,
	5060,
	5082,
	5082,
	3188,
	1945,
	2580,
	2580,
	3188,
	1945,
	2580,
	2580,
	2580,
	2580,
	2580,
	5053,
	4976,
	705,
	751,
	5090,
	3188,
	2562,
	4861,
	1765,
	2180,
	1409,
	2580,
	1951,
	3277,
	5090,
	1407,
	2334,
	571,
	2334,
	1407,
	243,
	86,
	1572,
	3277,
	5090,
	3277,
	838,
	3207,
	3277,
	3277,
	3277,
	3277,
	2602,
	716,
	468,
	468,
	1419,
	1449,
	634,
	3239,
	-1,
	-1,
	3277,
	3277,
	3277,
	1019,
	1019,
	1079,
	3239,
	3239,
	3235,
	2336,
	2389,
	2389,
	1980,
	416,
	2333,
	2333,
	1087,
	1101,
	1101,
	937,
	3188,
	3277,
	3235,
	3239,
	2336,
	1087,
	1087,
	2562,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	2602,
	3188,
	2562,
	2562,
	3188,
	2562,
	3239,
	2606,
	3239,
	2606,
	3239,
	655,
	664,
	663,
	655,
	664,
	663,
	2580,
	2580,
	3207,
	2580,
	468,
	716,
	634,
	3207,
	3207,
	3188,
	2562,
	1113,
	3207,
	3235,
	3134,
	3207,
	1003,
	3207,
	2580,
	3207,
	2580,
	3235,
	2602,
	1450,
	1450,
	751,
	3277,
	3277,
	3277,
	3277,
	3207,
	3277,
	3277,
	3277,
	3277,
	3277,
	1951,
	1951,
	3277,
	3277,
	1419,
	1449,
	355,
	785,
	3277,
	670,
	1953,
	3188,
	2562,
	670,
	2606,
	4898,
	2502,
	3239,
	138,
	3277,
	2210,
	2381,
	2161,
	4129,
	4019,
	988,
	3684,
	4285,
	3239,
	1439,
	2385,
	2385,
	2089,
	3235,
	3207,
	3207,
	3188,
	2562,
	3207,
	2580,
	3207,
	2580,
	3134,
	3207,
	3235,
	3207,
	1003,
	1450,
	1450,
	751,
	1419,
	3235,
	2602,
	3269,
	2636,
	3239,
	3235,
	2602,
	4823,
	2580,
	2502,
	235,
	4027,
	3277,
	5090,
	4145,
	3239,
	766,
	3277,
	1090,
	1102,
	4980,
	4916,
	3615,
	3413,
	5060,
	5090,
	5090,
	3239,
	766,
	3239,
	766,
	3277,
	5078,
	4984,
	5053,
	4976,
	5078,
	5078,
	5078,
	5082,
	4986,
	5053,
	4976,
	5078,
	4984,
	5096,
	5078,
	5090,
	5090,
	4957,
	4893,
	3277,
	5090,
	3188,
	770,
	2725,
	777,
	2848,
	4244,
	5098,
	767,
	3277,
	3277,
	3235,
	2210,
	5096,
	2606,
	5090,
	4976,
	4791,
	4976,
	3277,
	5090,
	3188,
	2562,
	1252,
	692,
	2333,
	914,
	3277,
	3277,
	3277,
	2180,
	2180,
	2580,
	2580,
	2580,
	2580,
	2580,
	2580,
	2580,
	2580,
	2580,
	2580,
	3277,
	3277,
	2562,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	2580,
	2580,
	1082,
	1419,
	2580,
	2580,
	1082,
	1419,
	3277,
	3239,
	2334,
	766,
	1085,
	3277,
	3277,
	3277,
	1451,
	931,
	3277,
	1419,
	3239,
	766,
	3277,
	468,
	3277,
	3277,
	3277,
	3277,
	5060,
	5090,
	177,
	3235,
	2602,
	3239,
	3207,
	2580,
	3277,
	5090,
	5092,
	3239,
	2336,
	1438,
	3277,
	3277,
	3235,
	1438,
	2336,
	411,
	3277,
	3277,
	3277,
	1451,
	2638,
	2606,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	3277,
	468,
	3277,
	3277,
	4980,
	4082,
	5060,
	4980,
	3277,
	1407,
	3277,
	924,
	2580,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	1437,
	2387,
	1437,
	1978,
	1437,
	2382,
	3239,
	2606,
	3235,
	2638,
	3277,
	773,
	2389,
	2389,
	3277,
	4527,
	4136,
	4136,
	4148,
	4146,
	2562,
	3188,
	3277,
	4942,
	2638,
	3277,
	3277,
	3271,
	3624,
	3624,
	3621,
	3621,
	4162,
	4162,
	4923,
	4924,
	4138,
	4137,
	4563,
	4953,
	3489,
	4528,
	4953,
	4960,
	4923,
	4924,
	4924,
	4529,
	4138,
	4080,
	3899,
	3850,
	4894,
	4142,
	4078,
	4418,
};
static const Il2CppTokenRangePair s_rgctxIndices[6] = 
{
	{ 0x020000BF, { 10, 7 } },
	{ 0x06000186, { 0, 1 } },
	{ 0x06000187, { 1, 2 } },
	{ 0x06000188, { 3, 1 } },
	{ 0x06000304, { 4, 2 } },
	{ 0x06000305, { 6, 4 } },
};
extern const uint32_t g_rgctx_T_t7D7EECD22E6292A52F4B5053F6D7EB5B1B1EDBB7;
extern const uint32_t g_rgctx_GameObject_AddComponent_TisT_tB0F16E9C59ED4F9B760820498F340B215F001515_m07E24B8FB7A704335F4E7C2F81BB46580C5276AC;
extern const uint32_t g_rgctx_T_tB0F16E9C59ED4F9B760820498F340B215F001515;
extern const uint32_t g_rgctx_T_tA55445342C178308C59E835811AF538DE2DDAC5C;
extern const uint32_t g_rgctx_Activator_CreateInstance_TisT_t65951B7B52EA6FA77D467819CAB8F319DFF3FDF0_m3983B818E604277D74931801E463723B58623E1A;
extern const uint32_t g_rgctx_T_t65951B7B52EA6FA77D467819CAB8F319DFF3FDF0;
extern const uint32_t g_rgctx_List_1_t4E32638D800792E68037524AEF48CBE94FF2C883;
extern const uint32_t g_rgctx_List_1__ctor_mF6D3F1AF962498358C97D1314B922B5408271970;
extern const uint32_t g_rgctx_T_t0681CB32D61A3E2A7288FCD6A03418DA8D2EFBB6;
extern const uint32_t g_rgctx_List_1_Add_m52A610DB0097D7BF8CF50E9BD4F18AE76138A928;
extern const uint32_t g_rgctx_GaussianWindow1d_1_set_Sigma_m3F52DED7CEBE83F7F916E77006B302F42C17C8C2;
extern const uint32_t g_rgctx_GaussianWindow1d_1_GenerateKernel_m3EB23A81D0C789417D2D353D10007D738925EEDE;
extern const uint32_t g_rgctx_GaussianWindow1d_1_get_KernelSize_mEC0514BAC9A530EB8FB53416A3DD75190180F109;
extern const uint32_t g_rgctx_TU5BU5D_tF66A514D79A4C70EED2D2959EFE7317B9DC97B87;
extern const uint32_t g_rgctx_GaussianWindow1d_1_AddValue_mF2E9D4B8550134A71DC57771FBACA52B7627E511;
extern const uint32_t g_rgctx_GaussianWindow1d_1_Value_m2BE68174CC09AEFC25ED34C8C68D4AC73FD5B5AD;
extern const uint32_t g_rgctx_GaussianWindow1d_1_Compute_m5C1E45DE7D07A491751129F0DF3E1DD40DA1A4E0;
static const Il2CppRGCTXDefinition s_rgctxValues[17] = 
{
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_T_t7D7EECD22E6292A52F4B5053F6D7EB5B1B1EDBB7 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_GameObject_AddComponent_TisT_tB0F16E9C59ED4F9B760820498F340B215F001515_m07E24B8FB7A704335F4E7C2F81BB46580C5276AC },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_T_tB0F16E9C59ED4F9B760820498F340B215F001515 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_T_tA55445342C178308C59E835811AF538DE2DDAC5C },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_Activator_CreateInstance_TisT_t65951B7B52EA6FA77D467819CAB8F319DFF3FDF0_m3983B818E604277D74931801E463723B58623E1A },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_T_t65951B7B52EA6FA77D467819CAB8F319DFF3FDF0 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_List_1_t4E32638D800792E68037524AEF48CBE94FF2C883 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_List_1__ctor_mF6D3F1AF962498358C97D1314B922B5408271970 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_T_t0681CB32D61A3E2A7288FCD6A03418DA8D2EFBB6 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_List_1_Add_m52A610DB0097D7BF8CF50E9BD4F18AE76138A928 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_GaussianWindow1d_1_set_Sigma_m3F52DED7CEBE83F7F916E77006B302F42C17C8C2 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_GaussianWindow1d_1_GenerateKernel_m3EB23A81D0C789417D2D353D10007D738925EEDE },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_GaussianWindow1d_1_get_KernelSize_mEC0514BAC9A530EB8FB53416A3DD75190180F109 },
	{ (Il2CppRGCTXDataType)2, (const Il2CppRGCTXDefinitionData *)&g_rgctx_TU5BU5D_tF66A514D79A4C70EED2D2959EFE7317B9DC97B87 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_GaussianWindow1d_1_AddValue_mF2E9D4B8550134A71DC57771FBACA52B7627E511 },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_GaussianWindow1d_1_Value_m2BE68174CC09AEFC25ED34C8C68D4AC73FD5B5AD },
	{ (Il2CppRGCTXDataType)3, (const Il2CppRGCTXDefinitionData *)&g_rgctx_GaussianWindow1d_1_Compute_m5C1E45DE7D07A491751129F0DF3E1DD40DA1A4E0 },
};
extern const CustomAttributesCacheGenerator g_Cinemachine_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_Cinemachine_CodeGenModule;
const Il2CppCodeGenModule g_Cinemachine_CodeGenModule = 
{
	"Cinemachine.dll",
	1165,
	s_methodPointers,
	101,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	6,
	s_rgctxIndices,
	17,
	s_rgctxValues,
	NULL,
	g_Cinemachine_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
